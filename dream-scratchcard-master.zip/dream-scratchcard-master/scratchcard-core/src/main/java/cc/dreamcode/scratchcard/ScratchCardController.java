package cc.dreamcode.scratchcard;

import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import eu.okaeri.injector.annotation.Inject;
import lombok.RequiredArgsConstructor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

import java.util.Optional;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class ScratchCardController implements Listener {

    private final ScratchCardService scratchCardService;

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent e) {
        final Player player = e.getPlayer();
        final ItemStack itemStack = e.getItem();
        if (itemStack == null) {
            return;
        }

        if (!e.getAction().equals(Action.RIGHT_CLICK_AIR) &&
                !e.getAction().equals(Action.RIGHT_CLICK_BLOCK)) {
            return;
        }

        final Optional<ScratchCard> optionalScratchCard = this.scratchCardService.parseScratchCard(player, itemStack);
        if (!optionalScratchCard.isPresent()) {
            return;
        }

        e.setCancelled(true);

        final ScratchCard scratchCard = optionalScratchCard.get();
        final ItemStack onlyOne = ItemBuilder.of(itemStack)
                .setAmount(1)
                .toItemStack();

        player.getInventory().removeItem(onlyOne);
        this.scratchCardService.playWithScratchCard(player, scratchCard);
    }

}
