package cc.dreamcode.scratchcard;

import lombok.Getter;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

import java.util.Arrays;
import java.util.Optional;

@Getter
@RequiredArgsConstructor
public enum ScratchCardType {
    SAME_ITEMS("same-items"),
    FIND_ITEM("find-item"),
    WINNING_ITEMS("winning-items");

    private final String name;

    public static Optional<ScratchCardType> getByName(@NonNull String name, boolean ignoreCase) {
        return Arrays.stream(ScratchCardType.values())
                .filter(scratchCardType -> ignoreCase
                        ? scratchCardType.getName().equalsIgnoreCase(name)
                        : scratchCardType.getName().equals(name))
                .findAny();
    }
}
