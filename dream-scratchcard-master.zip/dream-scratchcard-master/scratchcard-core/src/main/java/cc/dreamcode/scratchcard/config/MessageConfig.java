package cc.dreamcode.scratchcard.config;

import cc.dreamcode.notice.minecraft.MinecraftNoticeType;
import cc.dreamcode.notice.minecraft.bukkit.BukkitNotice;
import cc.dreamcode.platform.bukkit.component.configuration.Configuration;
import eu.okaeri.configs.OkaeriConfig;
import eu.okaeri.configs.annotation.Header;
import eu.okaeri.configs.annotation.Headers;
import eu.okaeri.configs.annotation.NameModifier;
import eu.okaeri.configs.annotation.NameStrategy;
import eu.okaeri.configs.annotation.Names;

@Configuration(
        child = "message.yml"
)
@Headers({
        @Header("## Dream-ScratchCard (Message-Config) ##"),
        @Header("Dostepne type: (DO_NOT_SEND, CHAT, ACTION_BAR, SUBTITLE, TITLE, TITLE_SUBTITLE)")
})
@Names(strategy = NameStrategy.HYPHEN_CASE, modifier = NameModifier.TO_LOWER_CASE)
public class MessageConfig extends OkaeriConfig {

    public BukkitNotice usage = new BukkitNotice(MinecraftNoticeType.CHAT, "&7Poprawne uzycie: &c{usage}");
    public BukkitNotice noPermission = new BukkitNotice(MinecraftNoticeType.CHAT, "&4Nie posiadasz uprawnien.");
    public BukkitNotice noPlayer = new BukkitNotice(MinecraftNoticeType.CHAT, "&4Podanego gracza &cnie znaleziono.");
    public BukkitNotice notPlayer = new BukkitNotice(MinecraftNoticeType.CHAT, "&4Nie jestes graczem.");
    public BukkitNotice notNumber = new BukkitNotice(MinecraftNoticeType.CHAT, "&4Podana liczba &cnie jest cyfra.");
    public BukkitNotice reloaded = new BukkitNotice(MinecraftNoticeType.CHAT, "&aPrzeladowano! &7({time})");
    public BukkitNotice reloadError = new BukkitNotice(MinecraftNoticeType.CHAT, "&cZnaleziono problem w konfiguracji: &6{error}");

    public BukkitNotice scratchCardNotFound = new BukkitNotice(MinecraftNoticeType.CHAT, "&cZdrapki o tej nazwie nie znaleziono.");
    public BukkitNotice scratchCardGenerated = new BukkitNotice(MinecraftNoticeType.CHAT, "&7Wygenerowano zdrapke &b{scratchcard} {amount}x &7dla &6{nick}&7.");
    public BukkitNotice scratchCardGeneratedConsumer = new BukkitNotice(MinecraftNoticeType.CHAT, "&7Nadano tobie zdrapke &b{scratchcard} {amount}x &7przez &6{admin}&7.");
    public BukkitNotice scratchCardItemShowed = new BukkitNotice(MinecraftNoticeType.CHAT, "&cTo okienko zostalo juz otworzone!");
    public BukkitNotice losingScratchCard = new BukkitNotice(MinecraftNoticeType.SUBTITLE, "&cNie poszczescilo ci sie... Przegrywasz!");
    public BukkitNotice winningScratchCard = new BukkitNotice(MinecraftNoticeType.SUBTITLE, "&aGratulujemy wygranej!");
    public BukkitNotice scratchCardOpening = new BukkitNotice(MinecraftNoticeType.CHAT, "&aOtwierasz zdrapke...");

    public BukkitNotice playerScratchedCardSuccess = new BukkitNotice(MinecraftNoticeType.CHAT, "&7Gracz &6{nick} &7zdrapal &asukcesem &7zdrapke &b{scratchcard}&7.");
    public BukkitNotice playerScratchedCardFailed = new BukkitNotice(MinecraftNoticeType.CHAT, "&7Gracz &6{nick} &7zdrapal &cbez nagrody &7zdrapke &b{scratchcard}&7.");

}
