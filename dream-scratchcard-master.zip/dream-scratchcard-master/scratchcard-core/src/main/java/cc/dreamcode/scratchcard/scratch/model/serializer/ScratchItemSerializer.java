package cc.dreamcode.scratchcard.scratch.model.serializer;

import cc.dreamcode.scratchcard.scratch.model.ScratchItem;
import eu.okaeri.configs.schema.GenericsDeclaration;
import eu.okaeri.configs.serdes.DeserializationData;
import eu.okaeri.configs.serdes.ObjectSerializer;
import eu.okaeri.configs.serdes.SerializationData;
import lombok.NonNull;
import org.bukkit.inventory.ItemStack;

public class ScratchItemSerializer implements ObjectSerializer<ScratchItem> {
    @Override
    public boolean supports(@NonNull Class<? super ScratchItem> type) {
        return ScratchItem.class.isAssignableFrom(type);
    }

    @Override
    public void serialize(@NonNull ScratchItem object, @NonNull SerializationData data, @NonNull GenericsDeclaration generics) {
        data.add("item-display", object.getDisplayItem());
        data.add("returned-item", object.getReturnedItem());
    }

    @Override
    public ScratchItem deserialize(@NonNull DeserializationData data, @NonNull GenericsDeclaration generics) {
        return new ScratchItem(
                data.get("item-display", ItemStack.class),
                data.get("returned-item", ItemStack.class)
        );
    }
}
