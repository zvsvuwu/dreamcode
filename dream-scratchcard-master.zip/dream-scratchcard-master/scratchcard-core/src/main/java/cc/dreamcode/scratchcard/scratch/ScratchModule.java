package cc.dreamcode.scratchcard.scratch;

import cc.dreamcode.scratchcard.ScratchCard;
import cc.dreamcode.scratchcard.ScratchCardType;
import lombok.Getter;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.bukkit.entity.Player;

@Getter
@RequiredArgsConstructor
public abstract class ScratchModule {

    private final ScratchCardType scratchCardType;

    public abstract void scratch(@NonNull Player player, @NonNull ScratchCard scratchCard);
}
