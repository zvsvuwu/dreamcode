package cc.dreamcode.scratchcard.config;

import cc.dreamcode.menu.bukkit.BukkitMenuBuilder;
import cc.dreamcode.platform.bukkit.component.configuration.Configuration;
import cc.dreamcode.scratchcard.ScratchCard;
import cc.dreamcode.scratchcard.ScratchCardType;
import cc.dreamcode.scratchcard.scratch.model.ScratchItem;
import cc.dreamcode.utilities.builder.ListBuilder;
import cc.dreamcode.utilities.builder.MapBuilder;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import com.cryptomorin.xseries.XMaterial;
import eu.okaeri.configs.OkaeriConfig;
import eu.okaeri.configs.annotation.Comment;
import eu.okaeri.configs.annotation.Header;
import eu.okaeri.configs.annotation.NameModifier;
import eu.okaeri.configs.annotation.NameStrategy;
import eu.okaeri.configs.annotation.Names;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

@Configuration(
        child = "config.yml"
)
@Header("## Dream-ScratchCard (Main-Config) ##")
@Names(strategy = NameStrategy.HYPHEN_CASE, modifier = NameModifier.TO_LOWER_CASE)
public class PluginConfig extends OkaeriConfig {
    @Comment("Debug pokazuje dodatkowe informacje do konsoli. Lepiej wylaczyc. :P")
    public boolean debug = true;

    @Comment("")
    @Comment("Jakie maja byc aktywne typy zdrapek?")
    @Comment("Nieusuniecie zdrapki z tej listy i usuniecie jej z listy zdrapek powoduje blad do konsoli!")
    @Comment("Dostepne typy: SAME_ITEM, FIND_ITEM, WINNING_ITEMS")
    public List<ScratchCardType> activeScratchCards = Arrays.stream(ScratchCardType.values())
            .collect(Collectors.toList());

    @Comment("")
    @Comment("Utworz dla kazdego typu zdrapki item.")
    @Comment("Dostepne typy: SAME_ITEM, FIND_ITEM, WINNING_ITEMS")
    public List<ScratchCard> scratchCards = new ListBuilder<ScratchCard>()
            .add(new ScratchCard(
                    ScratchCardType.SAME_ITEMS,
                    ItemBuilder.of(XMaterial.PAPER.parseItem())
                            .setName("&bZdrapka &b&lALE TRIO!")
                            .setLore("&7Wartosc: &cniska",
                                    "",
                                    "&fZasady gry:",
                                    "&7Znajdz trzy takie same itemy obok siebie poziomo",
                                    "&7Jesli znajdziesz wszystkie trzy, &awygrywasz jedna z nich&7!",
                                    "",
                                    "&7Kliknij &fPPM&7, aby otworzyc zdrapke.")
                            .addEnchant(Enchantment.DURABILITY, 1)
                            .addFlags(ItemFlag.HIDE_ENCHANTS)
                            .toItemStack()
            ))
            .add(new ScratchCard(
                    ScratchCardType.FIND_ITEM,
                    ItemBuilder.of(XMaterial.PAPER.parseItem())
                            .setName("&bZdrapka &b&lPOSZUKIWACZ!")
                            .setLore("&7Wartosc: &bsrednia",
                                    "",
                                    "&fZasady gry:",
                                    "&7Znajdz wylosowany item w kafelkach",
                                    "&7Jesli znajdziesz ten sam item, &awygrywasz go&7!",
                                    "",
                                    "&7Kliknij &fPPM&7, aby otworzyc zdrapke.")
                            .addEnchant(Enchantment.DURABILITY, 1)
                            .addFlags(ItemFlag.HIDE_ENCHANTS)
                            .toItemStack()
            ))
            .add(new ScratchCard(
                    ScratchCardType.WINNING_ITEMS,
                    ItemBuilder.of(XMaterial.PAPER.parseItem())
                            .setName("&bZdrapka &b&lKILKA NA RAZ!")
                            .setLore("&7Wartosc: &awysoka",
                                    "",
                                    "&fZasady gry:",
                                    "&7Znajdz wszystkie pasujace itemy podane po prawej stronie",
                                    "&7Jesli je znajdziesz, &awygrasz wszystkie&7!",
                                    "",
                                    "&7Kliknij &fPPM&7, aby otworzyc zdrapke.")
                            .addEnchant(Enchantment.DURABILITY, 1)
                            .addFlags(ItemFlag.HIDE_ENCHANTS)
                            .toItemStack()
            ))
            .build();

    @Comment("")
    @Comment("Jakie itemy maja byc losowane wszedzie jako malo wartosciowe?")
    @Comment("Najlepiej jak by one w ogole nigdzie sie nie pojawialy jako itemy wygrywajace, moga zmylic zdrapujacego!")
    public List<ItemStack> losingItemList = new ListBuilder<ItemStack>()
            .add(XMaterial.DIRT.parseItem())
            .add(XMaterial.SAND.parseItem())
            .add(XMaterial.STONE.parseItem())
            .add(XMaterial.GRANITE.parseItem())
            .add(XMaterial.DIORITE.parseItem())
            .add(XMaterial.OAK_WOOD.parseItem())
            .build();

    @Comment("")
    @Comment("Jak ma wygladac item od odkrywania?")
    public ItemStack scratchItem = ItemBuilder.of(XMaterial.GREEN_WOOL.parseItem())
            .setName("&aKliknij, aby zdrapac!")
            .toItemStack();

    @Comment("")
    @Comment("ScratchCard dla podkategori -> WINNING_ITEMS")
    @Comment("Ustaw background dla menu od zdrapki WINNING_ITEMS")
    public BukkitMenuBuilder winningItemsMenuBuilder = new BukkitMenuBuilder("&8[&bM&8] Zdrapka &b&lPOSZUKIWACZ!", 5, new MapBuilder<Integer, ItemStack>()
            .put(new Integer[]{7, 8, 16, 18, 25, 34, 43, 44},
                    ItemBuilder.of(XMaterial.BLACK_STAINED_GLASS_PANE.parseItem())
                            .setName(" ")
                            .addEnchant(Enchantment.DURABILITY, 1)
                            .addFlags(ItemFlag.HIDE_ENCHANTS)
                            .toItemStack())
            .build());

    @Comment("")
    @Comment("Ile itemow ma byc podawanych do wylosowania?")
    @Comment("Liczba itemow wygrywajacych nie moze byc wieksza od ilosci podanych itemow do wylosowania!")
    public int winningItemsAmount = 3;

    @Comment("")
    @Comment("Jaka ma byc szansa na wylosowanie wygrywajacej zdrapki?")
    public double winningItemsChance = 50.0D;

    @Comment("")
    @Comment("Jakie sloty maja byc ustawione dla poszukiwanych itemow?")
    public List<Integer> winningItemsSpectateSlots = Arrays.asList(17, 26, 35);

    @Comment("")
    @Comment("Jakie itemy maja byc wykorzystywane do poszukiwania?")
    public List<ScratchItem> winningItemsScratchItems = new ListBuilder<ScratchItem>()
            .add(new ScratchItem(
                    ItemBuilder.of(XMaterial.DIAMOND.parseItem())
                            .setAmount(64)
                            .setName("&b&lDiamencik! &8(64x)")
                            .setLore("&fCenna sprawa!")
                            .toItemStack(),
                    ItemBuilder.of(XMaterial.DIAMOND.parseItem())
                            .setAmount(64)
                            .toItemStack()
            ))
            .add(new ScratchItem(
                    ItemBuilder.of(XMaterial.EMERALD.parseItem())
                            .setAmount(64)
                            .setName("&2&lEmeraldzik! &8(64x)")
                            .setLore("&fDroga sprawa!")
                            .toItemStack(),
                    ItemBuilder.of(XMaterial.EMERALD.parseItem())
                            .setAmount(64)
                            .toItemStack()
            ))
            .add(new ScratchItem(
                    ItemBuilder.of(XMaterial.GOLD_INGOT.parseItem())
                            .setAmount(64)
                            .setName("&6&lZloto! &8(64x)")
                            .setLore("&fWartosciowa sprawa!")
                            .toItemStack(),
                    ItemBuilder.of(XMaterial.GOLD_INGOT.parseItem())
                            .setAmount(64)
                            .toItemStack()
            ))
            .add(new ScratchItem(
                    ItemBuilder.of(XMaterial.IRON_INGOT.parseItem())
                            .setAmount(64)
                            .setName("&7&lZelazo! &8(64x)")
                            .setLore("&fFajnie miec!")
                            .toItemStack(),
                    ItemBuilder.of(XMaterial.IRON_INGOT.parseItem())
                            .setAmount(64)
                            .toItemStack()
            ))
            .build();

    @Comment("")
    @Comment("Jakie sloty maja wypelniac itemy do odkrycia?")
    public List<Integer> winningItemsScratchSlots = Arrays.asList(0, 1, 2, 3, 4, 5, 6, 9, 10, 11, 12, 13, 14, 15, 18, 19, 20, 21, 22, 23, 24, 27, 28, 29, 30, 31, 32, 33, 36, 37, 38, 39, 40, 41, 42);

    @Comment("")
    @Comment("ScratchCard dla podkategori -> SAME_ITEM")
    @Comment("Ustaw background dla menu od zdrapki SAME_ITEM")
    public BukkitMenuBuilder sameItemsMenuBuilder = new BukkitMenuBuilder("&8[&bM&8] Zdrapka &b&lALE TRIO!", 3, new HashMap<>());

    @Comment("")
    @Comment("Ile razy ma byc ten sam item wylosowany?")
    public int sameItemsAmount = 3;

    @Comment("")
    @Comment("Jaka ma byc szansa na wylosowanie tych samych itemow?")
    public double sameItemsChance = 50.0D;

    @Comment("")
    @Comment("W jakich slotach maja byc kafelki do losowania?")
    public List<Integer> sameItemsScratchSlots = Arrays.asList(0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26);

    @Comment("")
    @Comment("Jakie itemy maja byc wykorzystywane przy tej zdrapce?")
    public List<ScratchItem> sameItemsScratchItems = new ListBuilder<ScratchItem>()
            .add(new ScratchItem(
                    ItemBuilder.of(XMaterial.DIAMOND.parseItem())
                            .setAmount(64)
                            .setName("&b&lDiamencik! &8(64x)")
                            .setLore("&fCenna sprawa!")
                            .toItemStack(),
                    ItemBuilder.of(XMaterial.DIAMOND.parseItem())
                            .setAmount(64)
                            .toItemStack()
            ))
            .add(new ScratchItem(
                    ItemBuilder.of(XMaterial.EMERALD.parseItem())
                            .setAmount(64)
                            .setName("&2&lEmeraldzik! &8(64x)")
                            .setLore("&fDroga sprawa!")
                            .toItemStack(),
                    ItemBuilder.of(XMaterial.EMERALD.parseItem())
                            .setAmount(64)
                            .toItemStack()
            ))
            .add(new ScratchItem(
                    ItemBuilder.of(XMaterial.GOLD_INGOT.parseItem())
                            .setAmount(64)
                            .setName("&6&lZloto! &8(64x)")
                            .setLore("&fWartosciowa sprawa!")
                            .toItemStack(),
                    ItemBuilder.of(XMaterial.GOLD_INGOT.parseItem())
                            .setAmount(64)
                            .toItemStack()
            ))
            .add(new ScratchItem(
                    ItemBuilder.of(XMaterial.IRON_INGOT.parseItem())
                            .setAmount(64)
                            .setName("&7&lZelazo! &8(64x)")
                            .setLore("&fFajnie miec!")
                            .toItemStack(),
                    ItemBuilder.of(XMaterial.IRON_INGOT.parseItem())
                            .setAmount(64)
                            .toItemStack()
            ))
            .build();

    @Comment("")
    @Comment("ScratchCard dla podkategori -> FIND_ITEM")
    @Comment("Ustaw background dla menu od zdrapki FIND_ITEM")
    public BukkitMenuBuilder findItemMenuBuilder = new BukkitMenuBuilder("&8[&bM&8] Zdrapka &b&lALE TRIO!", 4, new MapBuilder<Integer, ItemStack>()
            .put(new Integer[]{0, 1, 2, 3, 5, 6, 7, 8},
                    ItemBuilder.of(XMaterial.BLACK_STAINED_GLASS_PANE.parseItem())
                            .setName(" ")
                            .addEnchant(Enchantment.DURABILITY, 1)
                            .addFlags(ItemFlag.HIDE_ENCHANTS)
                            .toItemStack())
            .build());

    @Comment("")
    @Comment("W jakim slocie ma byc pokazany szukany item?")
    public int findItemFindingItemSlot = 4;

    @Comment("")
    @Comment("Jaka ma byc szansa na wylosowanie tych samych itemow?")
    public double findItemChance = 50.0D;

    @Comment("")
    @Comment("W jakich slotach maja byc kafelki do losowania?")
    public List<Integer> findItemScratchSlots = Arrays.asList(9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35);

    @Comment("")
    @Comment("Jakie itemy maja byc wykorzystywane przy tej zdrapce?")
    public List<ScratchItem> findItemScratchItems = new ListBuilder<ScratchItem>()
            .add(new ScratchItem(
                    ItemBuilder.of(XMaterial.DIAMOND.parseItem())
                            .setAmount(64)
                            .setName("&b&lDiamencik! &8(64x)")
                            .setLore("&fCenna sprawa!")
                            .toItemStack(),
                    ItemBuilder.of(XMaterial.DIAMOND.parseItem())
                            .setAmount(64)
                            .toItemStack()
            ))
            .add(new ScratchItem(
                    ItemBuilder.of(XMaterial.EMERALD.parseItem())
                            .setAmount(64)
                            .setName("&2&lEmeraldzik! &8(64x)")
                            .setLore("&fDroga sprawa!")
                            .toItemStack(),
                    ItemBuilder.of(XMaterial.EMERALD.parseItem())
                            .setAmount(64)
                            .toItemStack()
            ))
            .add(new ScratchItem(
                    ItemBuilder.of(XMaterial.GOLD_INGOT.parseItem())
                            .setAmount(64)
                            .setName("&6&lZloto! &8(64x)")
                            .setLore("&fWartosciowa sprawa!")
                            .toItemStack(),
                    ItemBuilder.of(XMaterial.GOLD_INGOT.parseItem())
                            .setAmount(64)
                            .toItemStack()
            ))
            .add(new ScratchItem(
                    ItemBuilder.of(XMaterial.IRON_INGOT.parseItem())
                            .setAmount(64)
                            .setName("&7&lZelazo! &8(64x)")
                            .setLore("&fFajnie miec!")
                            .toItemStack(),
                    ItemBuilder.of(XMaterial.IRON_INGOT.parseItem())
                            .setAmount(64)
                            .toItemStack()
            ))
            .build();
}
