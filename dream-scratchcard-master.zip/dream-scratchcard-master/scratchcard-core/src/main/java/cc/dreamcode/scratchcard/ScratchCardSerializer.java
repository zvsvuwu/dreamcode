package cc.dreamcode.scratchcard;

import eu.okaeri.configs.schema.GenericsDeclaration;
import eu.okaeri.configs.serdes.DeserializationData;
import eu.okaeri.configs.serdes.ObjectSerializer;
import eu.okaeri.configs.serdes.SerializationData;
import lombok.NonNull;
import org.bukkit.inventory.ItemStack;

public class ScratchCardSerializer implements ObjectSerializer<ScratchCard> {
    @Override
    public boolean supports(@NonNull Class<? super ScratchCard> type) {
        return ScratchCard.class.isAssignableFrom(type);
    }

    @Override
    public void serialize(@NonNull ScratchCard object, @NonNull SerializationData data, @NonNull GenericsDeclaration generics) {
        data.add("scratch-card-type", object.getScratchCardType());
        data.add("scratch-card-item", object.getScratchCardItem());
    }

    @Override
    public ScratchCard deserialize(@NonNull DeserializationData data, @NonNull GenericsDeclaration generics) {
        return new ScratchCard(
                data.get("scratch-card-type", ScratchCardType.class),
                data.get("scratch-card-item", ItemStack.class)
        );
    }
}
