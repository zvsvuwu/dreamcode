package cc.dreamcode.scratchcard.command;

import cc.dreamcode.command.annotations.RequiredPermission;
import cc.dreamcode.command.bukkit.BukkitCommand;
import cc.dreamcode.scratchcard.ScratchCardPlugin;
import cc.dreamcode.scratchcard.ScratchCardService;
import cc.dreamcode.scratchcard.ScratchCardType;
import cc.dreamcode.scratchcard.config.MessageConfig;
import cc.dreamcode.scratchcard.config.PluginConfig;
import cc.dreamcode.utilities.ParseUtil;
import cc.dreamcode.utilities.TimeUtil;
import cc.dreamcode.utilities.builder.ListBuilder;
import cc.dreamcode.utilities.builder.MapBuilder;
import eu.okaeri.configs.exception.OkaeriException;
import eu.okaeri.injector.annotation.Inject;
import lombok.NonNull;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RequiredPermission
public class ScratchCardCommand extends BukkitCommand {

    private final ScratchCardPlugin scratchCardPlugin;
    private final PluginConfig pluginConfig;
    private final MessageConfig messageConfig;
    private final ScratchCardService scratchCardService;

    @Inject
    public ScratchCardCommand(final ScratchCardPlugin scratchCardPlugin, final PluginConfig pluginConfig, final MessageConfig messageConfig, final ScratchCardService scratchCardService) {
        super("scratchcard", "zdrapka");

        this.scratchCardPlugin = scratchCardPlugin;
        this.pluginConfig = pluginConfig;
        this.messageConfig = messageConfig;
        this.scratchCardService = scratchCardService;
    }

    @Override
    public void content(@NonNull CommandSender sender, @NonNull String[] args) {
        if (args.length == 3) {
            final Optional<ScratchCardType> optionalScratchCardType = ScratchCardType.getByName(args[0], true);
            if (!optionalScratchCardType.isPresent()) {
                this.messageConfig.scratchCardNotFound.send(sender);
                return;
            }

            final ScratchCardType scratchCardType = optionalScratchCardType.get();

            final String nick = args[1];
            if (nick.equalsIgnoreCase("all")) {

                if (!sender.hasPermission("dream.scratchcard.all")) {
                    this.messageConfig.noPermission.send(sender);
                    return;
                }

                final Optional<Integer> optionalInteger = ParseUtil.parseInteger(args[2]);
                if (!optionalInteger.isPresent()) {
                    this.messageConfig.notNumber.send(sender);
                    return;
                }

                final int amount = optionalInteger.get();
                this.scratchCardPlugin.getServer().getOnlinePlayers().forEach(consumer -> {
                    this.scratchCardService.generateScratchCard(consumer, scratchCardType, amount);

                    this.messageConfig.scratchCardGeneratedConsumer.send(consumer, new MapBuilder<String, Object>()
                            .put("scratchcard", scratchCardType.getName())
                            .put("admin", sender.getName())
                            .put("amount", amount)
                            .build());
                });

                this.messageConfig.scratchCardGenerated.send(sender, new MapBuilder<String, Object>()
                        .put("scratchcard", scratchCardType.getName())
                        .put("nick", "wszystkich")
                        .put("amount", amount)
                        .build());
                return;
            }

            final Player consumer = this.scratchCardPlugin.getServer().getPlayerExact(nick);
            if (consumer == null) {
                this.messageConfig.noPlayer.send(sender);
                return;
            }

            final Optional<Integer> optionalInteger = ParseUtil.parseInteger(args[2]);
            if (!optionalInteger.isPresent()) {
                this.messageConfig.notNumber.send(sender);
                return;
            }

            final int amount = optionalInteger.get();
            this.scratchCardService.generateScratchCard(consumer, scratchCardType, amount);

            this.messageConfig.scratchCardGenerated.send(sender, new MapBuilder<String, Object>()
                    .put("scratchcard", scratchCardType.getName())
                    .put("nick", consumer.getName())
                    .put("amount", amount)
                    .build());

            if (!sender.getName().equals(consumer.getName())) {
                this.messageConfig.scratchCardGeneratedConsumer.send(consumer, new MapBuilder<String, Object>()
                        .put("scratchcard", scratchCardType.getName())
                        .put("admin", sender.getName())
                        .put("amount", amount)
                        .build());
            }
            return;
        }

        if (args.length == 1) {
            if (args[0].equalsIgnoreCase("reload")) {
                if (!sender.hasPermission("dream.scratchcard.reload")) {
                    this.messageConfig.noPermission.send(sender);
                    return;
                }

                final long time = System.currentTimeMillis();
                try {
                    this.messageConfig.load();
                    this.pluginConfig.load();

                    this.messageConfig.reloaded.send(sender, new MapBuilder<String, Object>()
                            .put("time", TimeUtil.convertMills(System.currentTimeMillis() - time))
                            .build());
                }
                catch (NullPointerException | OkaeriException e) {
                    e.printStackTrace();

                    this.messageConfig.reloadError.send(sender, new MapBuilder<String, Object>()
                            .put("error", e.getMessage())
                            .build());
                }

                return;
            }
        }

        this.messageConfig.usage.send(sender, new MapBuilder<String, Object>()
                .put("usage", "/zdrapka [typ] [nick] [ilosc]")
                .build());
    }

    @Override
    public List<String> tab(@NonNull CommandSender sender, @NonNull String[] args) {
        if (args.length == 3) {
            return Collections.singletonList("<amount>");
        }

        if (args.length == 2) {
            return new ListBuilder<String>()
                    .add("all")
                    .addAll(this.scratchCardPlugin.getServer().getOnlinePlayers()
                            .stream()
                            .map(Player::getName)
                            .collect(Collectors.toList()))
                    .build()
                    .stream()
                    .filter(name -> name.startsWith(args[1]))
                    .collect(Collectors.toList());
        }

        if (args.length == 1) {
            return this.pluginConfig.activeScratchCards
                    .stream()
                    .map(ScratchCardType::getName)
                    .filter(name -> name.startsWith(args[0]))
                    .collect(Collectors.toList());
        }

        return null;
    }
}
