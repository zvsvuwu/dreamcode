package cc.dreamcode.scratchcard.scratch.menu;

import cc.dreamcode.menu.bukkit.BukkitMenuBuilder;
import cc.dreamcode.menu.bukkit.base.BukkitMenu;
import cc.dreamcode.menu.bukkit.setup.BukkitMenuPlayerSetup;
import cc.dreamcode.scratchcard.ScratchCardType;
import cc.dreamcode.scratchcard.config.MessageConfig;
import cc.dreamcode.scratchcard.config.PluginConfig;
import cc.dreamcode.scratchcard.scratch.model.ScratchItem;
import cc.dreamcode.utilities.ChanceUtil;
import cc.dreamcode.utilities.builder.MapBuilder;
import cc.dreamcode.utilities.bukkit.ItemUtil;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import eu.okaeri.injector.annotation.Inject;
import eu.okaeri.tasker.core.Tasker;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class WinningItemsScratchMenu implements BukkitMenuPlayerSetup {

    private final PluginConfig pluginConfig;
    private final MessageConfig messageConfig;
    private final Tasker tasker;

    @Override
    public BukkitMenu build(@NonNull HumanEntity humanEntity) {
        final BukkitMenuBuilder menuBuilder = this.pluginConfig.winningItemsMenuBuilder;
        final BukkitMenu bukkitMenu = menuBuilder.buildWithItems();

        final List<ScratchItem> scratchItems = new ArrayList<>(this.pluginConfig.winningItemsScratchItems);
        Collections.shuffle(scratchItems);

        final List<ScratchItem> winningItems = scratchItems.subList(0, this.pluginConfig.winningItemsAmount);
        for (int index = 0; index < this.pluginConfig.winningItemsAmount; index++) {
            final ScratchItem scratchItem = winningItems.get(index);
            final int slot = this.pluginConfig.winningItemsSpectateSlots.get(index);

            bukkitMenu.setItem(slot, ItemBuilder.of(scratchItem.getDisplayItem()).fixColors().toItemStack());
        }

        final boolean winner = ChanceUtil.reachChance(this.pluginConfig.winningItemsChance);
        final int winningItemsAmount = winner
                ? this.pluginConfig.winningItemsAmount
                : this.pluginConfig.winningItemsAmount - ChanceUtil.getRandomInteger(1, this.pluginConfig.winningItemsAmount);

        final List<Integer> scratchSlots = new ArrayList<>(this.pluginConfig.winningItemsScratchSlots);
        Collections.shuffle(scratchSlots);

        final AtomicBoolean rewardReceived = new AtomicBoolean();
        final AtomicInteger showedSlots = new AtomicInteger();
        final AtomicInteger showedWinningSlots = new AtomicInteger();
        final List<Integer> winningSlots = scratchSlots.subList(0, winningItemsAmount);
        this.pluginConfig.winningItemsScratchSlots.forEach(slot ->
            bukkitMenu.setItem(slot, ItemBuilder.of(this.pluginConfig.scratchItem).fixColors().toItemStack(), e -> {
                showedSlots.set(showedSlots.get() + 1);

                if (winningSlots.contains(slot)) {
                    bukkitMenu.setItem(slot, ItemBuilder.of(winningItems.get(showedWinningSlots.getAndIncrement()).getDisplayItem())
                            .fixColors()
                            .toItemStack(), e1 -> this.messageConfig.scratchCardItemShowed.send(e1.getWhoClicked()));

                    if (showedWinningSlots.get() == winningItemsAmount && winner) {
                        this.pluginConfig.winningItemsScratchSlots
                                .stream()
                                .filter(scanSlot -> bukkitMenu.getInventory().getItem(scanSlot)
                                        .isSimilar(ItemBuilder.of(this.pluginConfig.scratchItem).fixColors().toItemStack()))
                                .forEach(scanSlot -> bukkitMenu.setItem(scanSlot, this.pluginConfig.losingItemList.get(
                                        ChanceUtil.getRandomInteger(0, this.pluginConfig.losingItemList.size())
                                ), e1 -> this.messageConfig.scratchCardItemShowed.send(e1.getWhoClicked())));

                        this.tasker.newDelayer(Duration.ofSeconds(1L))
                                .delayed(() -> {
                                    if (rewardReceived.get()) {
                                        return;
                                    }

                                    rewardReceived.set(true);
                                    e.getWhoClicked().closeInventory();

                                    winningItems.stream()
                                            .map(scratchItem -> ItemBuilder.of(scratchItem.getReturnedItem()).fixColors().toItemStack())
                                            .forEach(item -> ItemUtil.giveItem((Player) humanEntity, item));

                                    this.messageConfig.winningScratchCard.send(humanEntity);
                                    this.messageConfig.playerScratchedCardSuccess.sendAll(new MapBuilder<String, Object>()
                                            .put("nick", humanEntity.getName())
                                            .put("scratchcard", ScratchCardType.WINNING_ITEMS.getName())
                                            .build());
                                })
                                .executeSync();
                    }
                    return;
                }

                bukkitMenu.setItem(slot, this.pluginConfig.losingItemList.get(
                        ChanceUtil.getRandomInteger(0, this.pluginConfig.losingItemList.size())
                ), e1 -> this.messageConfig.scratchCardItemShowed.send(e1.getWhoClicked()));

                if (showedSlots.get() == this.pluginConfig.winningItemsScratchSlots.size()) {
                    this.tasker.newDelayer(Duration.ofMillis(200L))
                            .delayed(() -> {
                                if (rewardReceived.get()) {
                                    return;
                                }

                                rewardReceived.set(true);
                                e.getWhoClicked().closeInventory();

                                this.messageConfig.losingScratchCard.send(humanEntity);
                                this.messageConfig.playerScratchedCardFailed.sendAll(new MapBuilder<String, Object>()
                                        .put("nick", humanEntity.getName())
                                        .put("scratchcard", ScratchCardType.WINNING_ITEMS.getName())
                                        .build());
                            })
                            .executeSync();
                }
            }));

        bukkitMenu.setInventoryCloseEvent(event -> {
            if (rewardReceived.get()) {
                return;
            }

            rewardReceived.set(true);

            if (winner) {
                winningItems.stream()
                        .map(scratchItem -> ItemBuilder.of(scratchItem.getReturnedItem()).fixColors().toItemStack())
                        .forEach(item -> ItemUtil.giveItem((Player) humanEntity, item));

                this.messageConfig.winningScratchCard.send(humanEntity);
                this.messageConfig.playerScratchedCardSuccess.sendAll(new MapBuilder<String, Object>()
                        .put("nick", humanEntity.getName())
                        .put("scratchcard", ScratchCardType.WINNING_ITEMS.getName())
                        .build());
                return;
            }

            this.messageConfig.losingScratchCard.send(humanEntity);
            this.messageConfig.playerScratchedCardFailed.sendAll(new MapBuilder<String, Object>()
                    .put("nick", humanEntity.getName())
                    .put("scratchcard", ScratchCardType.WINNING_ITEMS.getName())
                    .build());
        });

        return bukkitMenu;
    }
}
