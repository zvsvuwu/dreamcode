package cc.dreamcode.scratchcard.scratch.model;

import lombok.Data;
import org.bukkit.inventory.ItemStack;

@Data
public class ScratchItem {

    private final ItemStack displayItem;
    private final ItemStack returnedItem;
}
