package cc.dreamcode.scratchcard.scratch;

import cc.dreamcode.scratchcard.ScratchCard;
import cc.dreamcode.scratchcard.ScratchCardPlugin;
import cc.dreamcode.scratchcard.ScratchCardType;
import cc.dreamcode.scratchcard.config.MessageConfig;
import cc.dreamcode.scratchcard.scratch.menu.WinningItemsScratchMenu;
import eu.okaeri.injector.annotation.Inject;
import lombok.NonNull;
import org.bukkit.entity.Player;

public class WinningItemsScratch extends ScratchModule {

    private final MessageConfig messageConfig;
    private final WinningItemsScratchMenu winningItemsMenu;

    @Inject
    public WinningItemsScratch(final ScratchCardPlugin scratchCardPlugin, final MessageConfig messageConfig) {
        super(ScratchCardType.WINNING_ITEMS);

        this.messageConfig = messageConfig;
        this.winningItemsMenu = scratchCardPlugin.createInstance(WinningItemsScratchMenu.class);
    }

    @Override
    public void scratch(@NonNull Player player, @NonNull ScratchCard scratchCard) {
        this.winningItemsMenu.build(player).open(player);
        this.messageConfig.scratchCardOpening.send(player);
    }
}
