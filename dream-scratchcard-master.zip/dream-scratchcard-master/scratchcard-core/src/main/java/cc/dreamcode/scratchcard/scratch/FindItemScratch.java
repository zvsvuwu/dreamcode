package cc.dreamcode.scratchcard.scratch;

import cc.dreamcode.scratchcard.ScratchCard;
import cc.dreamcode.scratchcard.ScratchCardPlugin;
import cc.dreamcode.scratchcard.ScratchCardType;
import cc.dreamcode.scratchcard.config.MessageConfig;
import cc.dreamcode.scratchcard.scratch.menu.FindItemScratchMenu;
import eu.okaeri.injector.annotation.Inject;
import lombok.NonNull;
import org.bukkit.entity.Player;

public class FindItemScratch extends ScratchModule {

    private final MessageConfig messageConfig;
    private final FindItemScratchMenu findItemMenu;

    @Inject
    public FindItemScratch(final ScratchCardPlugin scratchCardPlugin, final MessageConfig messageConfig) {
        super(ScratchCardType.FIND_ITEM);

        this.messageConfig = messageConfig;
        this.findItemMenu = scratchCardPlugin.createInstance(FindItemScratchMenu.class);
    }

    @Override
    public void scratch(@NonNull Player player, @NonNull ScratchCard scratchCard) {
        this.findItemMenu.build(player).open(player);
        this.messageConfig.scratchCardOpening.send(player);
    }
}
