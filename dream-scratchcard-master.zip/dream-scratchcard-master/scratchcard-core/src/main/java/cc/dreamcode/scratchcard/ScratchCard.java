package cc.dreamcode.scratchcard;

import lombok.Data;
import org.bukkit.inventory.ItemStack;

@Data
public class ScratchCard {

    private final ScratchCardType scratchCardType;
    private final ItemStack scratchCardItem;
}
