package cc.dreamcode.scratchcard;

import cc.dreamcode.platform.bukkit.exception.BukkitPluginException;
import cc.dreamcode.scratchcard.config.PluginConfig;
import cc.dreamcode.scratchcard.scratch.FindItemScratch;
import cc.dreamcode.scratchcard.scratch.SameItemsScratch;
import cc.dreamcode.scratchcard.scratch.ScratchModule;
import cc.dreamcode.scratchcard.scratch.WinningItemsScratch;
import cc.dreamcode.utilities.builder.MapBuilder;
import cc.dreamcode.utilities.bukkit.ItemUtil;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import eu.okaeri.injector.annotation.Inject;
import lombok.NonNull;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.Map;
import java.util.Optional;

public class ScratchCardService {

    private final PluginConfig pluginConfig;

    private final Map<ScratchCardType, ScratchModule> scratchModules;

    @Inject
    public ScratchCardService(final ScratchCardPlugin scratchCardPlugin, final PluginConfig pluginConfig) {
        this.pluginConfig = pluginConfig;

        this.scratchModules = new MapBuilder<ScratchCardType, ScratchModule>()
                .put(ScratchCardType.SAME_ITEMS, scratchCardPlugin.createInstance(SameItemsScratch.class))
                .put(ScratchCardType.WINNING_ITEMS, scratchCardPlugin.createInstance(WinningItemsScratch.class))
                .put(ScratchCardType.FIND_ITEM, scratchCardPlugin.createInstance(FindItemScratch.class))
                .build();
    }

    public void generateScratchCard(@NonNull Player player, @NonNull ScratchCardType scratchCardType, int amount) {
        final ScratchCard scratchCard = this.getScratchCard(scratchCardType);
        final ItemStack scratchCardItem = ItemBuilder.of(scratchCard.getScratchCardItem())
                .fixColors(new MapBuilder<String, Object>()
                        .put("nick", player.getName())
                        .build())
                .setAmount(amount)
                .toItemStack();

        ItemUtil.giveItem(player, scratchCardItem);
    }

    public Optional<ScratchCard> parseScratchCard(@NonNull Player player, @NonNull ItemStack itemStack) {
        return this.pluginConfig.scratchCards
                .stream()
                .filter(scratchCard -> ItemBuilder.of(scratchCard.getScratchCardItem())
                        .fixColors(new MapBuilder<String, Object>()
                                .put("nick", player.getName())
                                .build())
                        .setAmount(1)
                        .toItemStack().isSimilar(ItemBuilder.of(itemStack)
                                .setAmount(1)
                                .toItemStack()))
                .findAny();
    }

    public ScratchCard getScratchCard(@NonNull ScratchCardType scratchCardType) {
        final Optional<ScratchCard> optionalScratchCard = this.pluginConfig.scratchCards
                .stream()
                .filter(scan -> scan.getScratchCardType().equals(scratchCardType))
                .findAny();

        if (!optionalScratchCard.isPresent()) {
            throw new BukkitPluginException("Cannot find any scratchcard with type " + scratchCardType);
        }

        return optionalScratchCard.get();
    }

    public void playWithScratchCard(@NonNull Player player, @NonNull ScratchCard scratchCard) {
        final ScratchModule scratchModule = this.scratchModules.get(scratchCard.getScratchCardType());
        if (scratchModule == null) {
            throw new BukkitPluginException("Cannot find any scratchcard module with type " + scratchCard.getScratchCardType());
        }

        scratchModule.scratch(player, scratchCard);
    }
}
