rootProject.name = "dream-vouchers"

include(":plugin-core")