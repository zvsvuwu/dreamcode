package cc.dreamcode.vouchers.controller;

import cc.dreamcode.utilities.builder.MapBuilder;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import cc.dreamcode.vouchers.VouchersPlugin;
import cc.dreamcode.vouchers.config.MessageConfig;
import cc.dreamcode.vouchers.config.PluginConfig;
import cc.dreamcode.vouchers.voucher.Voucher;
import eu.okaeri.injector.annotation.Inject;
import lombok.RequiredArgsConstructor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;

import java.util.Collections;
import java.util.Optional;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class VoucherController implements Listener {

    private final VouchersPlugin vouchersPlugin;
    private final MessageConfig messageConfig;
    private final PluginConfig pluginConfig;

    @EventHandler
    public void onVoucherUse(PlayerInteractEvent event) {
        Player player = event.getPlayer();

        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.LEFT_CLICK_BLOCK) return;

        Optional<Voucher> voucher = this.pluginConfig.vouchers
                .stream()
                .filter(vouchers -> new ItemBuilder(vouchers.getItemStack(), true)
                        .fixColors(new MapBuilder<String, Object>()
                                .put("creator", vouchers.getCreator())
                                .put("time", vouchers.getCreationTime())
                                .build())
                        .setAmount(1)
                        .toItemStack().isSimilar(player.getItemInHand()))
                .findAny();

        if (!voucher.isPresent()) return;

        player.getInventory().removeItem(new ItemBuilder(voucher.get().getItemStack(), true)
                .fixColors(new MapBuilder<String, Object>()
                        .put("creator", voucher.get().getCreator())
                        .put("time", voucher.get().getCreationTime())
                        .build())
                .setAmount(1)
                .toItemStack());

        this.vouchersPlugin.getServer().dispatchCommand(
                this.vouchersPlugin.getServer().getConsoleSender(),
                voucher.get().getCommand().replace("{player}", player.getName()));

        if (this.pluginConfig.voucherUseNotice) {
            this.messageConfig.voucherUsedAll.sendAll(new MapBuilder<String, Object>()
                    .put("id", voucher.get().getId())
                    .put("player", player.getName())
                    .build());
        }

        this.messageConfig.voucherUsed.send(player, Collections.singletonMap("id", voucher.get().getId()));
    }
}
