package cc.dreamcode.vouchers.voucher;

import lombok.Data;
import org.bukkit.inventory.ItemStack;

@Data
public class Voucher {

    private final String id;
    private final ItemStack itemStack;
    private final String command;
    private final String creator;
    private final String creationTime;
}
