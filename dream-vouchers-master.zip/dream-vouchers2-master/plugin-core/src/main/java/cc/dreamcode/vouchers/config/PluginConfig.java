package cc.dreamcode.vouchers.config;

import cc.dreamcode.platform.bukkit.component.configuration.Configuration;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import cc.dreamcode.vouchers.voucher.Voucher;
import eu.okaeri.configs.OkaeriConfig;
import eu.okaeri.configs.annotation.Comment;
import eu.okaeri.configs.annotation.CustomKey;
import eu.okaeri.configs.annotation.Header;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;

import java.util.Collections;
import java.util.List;

@Configuration(child = "config.yml")
@Header("## Dream-Vouchers (Main-Config) ##")
public class PluginConfig extends OkaeriConfig {

    @Comment
    @Comment("Debug pokazuje dodatkowe informacje do konsoli. Lepiej wylaczyc. :P")
    @CustomKey("debug")
    public boolean debug = true;

    @Comment
    @Comment("Wzor zapisywania daty stworzenia vouchera")
    @CustomKey("date-pattern")
    public String datePattern = "dd/MM/yyyy HH:mm:ss";

    @Comment
    @Comment("Lista voucherow")
    @CustomKey("voucher-list")
    public List<Voucher> vouchers = Collections.singletonList(
            new Voucher("1",
                    new ItemBuilder(Material.BOOK)
                            .setName("&6&lVOUCHER NA SVIP")
                            .setLore("&8» &7Używając go otrzymasz range",
                                    "&8» &6SVIP &7na okres &f30dni", "",
                                    "&8» &7Wytworzył: &f{creator} ({time})", "",
                                    "&8» &aKliknij PRAWYM, aby wykorzystać")
                            .addEnchant(Enchantment.THORNS, 2)
                            .addFlags(ItemFlag.HIDE_ENCHANTS)
                            .toItemStack(),
                    "lp user {player} parent set svip",
                    "Keymilo",
                    "08/05/2024 15:46:34"
            )
    );

    @Comment
    @Comment("Czy wysylac wiadomosc kazdemu graczowi o tym, ze otrzymal voucher")
    @CustomKey("notify-all")
    public boolean notifyAll = true;

    @Comment
    @Comment("Czy wysylac wiadomosc kazdemu graczowi o tym, ze ktos uzyl vouchera")
    @CustomKey("voucher-use-notice")
    public boolean voucherUseNotice = true;
}
