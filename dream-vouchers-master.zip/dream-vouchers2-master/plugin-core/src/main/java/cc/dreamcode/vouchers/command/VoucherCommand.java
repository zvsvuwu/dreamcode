package cc.dreamcode.vouchers.command;

import cc.dreamcode.command.CommandBase;
import cc.dreamcode.command.annotation.*;
import cc.dreamcode.utilities.builder.MapBuilder;
import cc.dreamcode.utilities.bukkit.InventoryUtil;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import cc.dreamcode.vouchers.VouchersPlugin;
import cc.dreamcode.vouchers.config.MessageConfig;
import cc.dreamcode.vouchers.config.PluginConfig;
import cc.dreamcode.vouchers.voucher.Voucher;
import eu.okaeri.injector.annotation.Inject;
import lombok.RequiredArgsConstructor;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.Optional;

@Command(name = "voucher")
@RequiredArgsConstructor(onConstructor_ = @Inject)
public class VoucherCommand implements CommandBase {

    private final VouchersPlugin vouchersPlugin;
    private final MessageConfig messageConfig;
    private final PluginConfig pluginConfig;

    @Async
    @Executor(path = "create", description = "Tworzy nowy voucher")
    @Permission("dream-vouchers.create")
    void create(Player player, @Arg String id, @Args(min = 1) String[] command) {

        if (player.getItemInHand() == null || player.getItemInHand().getType() == Material.AIR) {
            this.messageConfig.noItemInHand.send(player);
            return;
        }

        if (player.getItemInHand().getType().isBlock()) {
            this.messageConfig.voucherCannotBeABlock.send(player);
            return;
        }

        if (this.pluginConfig.vouchers.stream().anyMatch(voucher -> voucher.getId().equals(id))) {
            this.messageConfig.voucherAlreadyExists.send(player);
            return;
        }

        this.pluginConfig.vouchers.add(new Voucher(
                id,
                player.getItemInHand(),
                String.join(" ", command),
                player.getName(),
                LocalDateTime.now().format(DateTimeFormatter.ofPattern(this.pluginConfig.datePattern))
        ));
        this.pluginConfig.save();

        this.messageConfig.voucherCreated.send(player);
    }

    @Completion(arg = "id", value = "@ids")
    @Completion(arg = "target", value = "@players")
    @Executor(path = "give", description = "Daje wybrany voucher")
    @Permission("dream-vouchers.give")
    void give(CommandSender sender, @Arg String id, @Arg String target, @Arg(value = "amount") int amount) {

        Optional<Voucher> voucher = this.pluginConfig.vouchers.stream()
                .filter(voucher1 -> voucher1.getId().equals(id))
                .findFirst();

        if (!voucher.isPresent()) {
            this.messageConfig.voucherNotFound.send(sender);
            return;
        }

        if (target.equals("all")) {
            this.vouchersPlugin.getServer().getOnlinePlayers().forEach(player ->
                InventoryUtil.giveItem(
                        player,
                        new ItemBuilder(voucher.get().getItemStack(), true)
                                .fixColors(new MapBuilder<String, Object>()
                                        .put("creator", voucher.get().getCreator())
                                        .put("time", voucher.get().getCreationTime())
                                        .build())
                                .setAmount(amount)
                                .toItemStack()
                ));

            if (this.pluginConfig.notifyAll) {
                this.messageConfig.voucherReceived.sendAll(Collections.singletonMap("id", id));
            }

            this.messageConfig.voucherGiveAll.send(sender, Collections.singletonMap("id", id));
            return;
        }

        Player targetPlayer = this.vouchersPlugin.getServer().getPlayerExact(target);

        if (targetPlayer == null) {
            this.messageConfig.playerNotFound.send(sender);
            return;
        }

        InventoryUtil.giveItem(
                targetPlayer,
                new ItemBuilder(voucher.get().getItemStack(), true)
                        .fixColors(new MapBuilder<String, Object>()
                                .put("creator", voucher.get().getCreator())
                                .put("time", voucher.get().getCreationTime())
                                .build())
                        .setAmount(amount)
                        .toItemStack()
        );

        this.messageConfig.voucherReceived.send(targetPlayer, Collections.singletonMap("id", id));
        this.messageConfig.voucherGivePlayer.send(sender, new MapBuilder<String, Object>()
                .put("id", id)
                .put("player", targetPlayer.getName())
                .build());
    }

    @Async
    @Completion(arg = "id", value = "@ids")
    @Executor(path = "remove", description = "Usuwa wybrany voucher")
    @Permission("dream-vouchers.remove")
    void remove(CommandSender sender, @Arg String id) {

        Optional<Voucher> voucher = this.pluginConfig.vouchers.stream()
                .filter(voucher1 -> voucher1.getId().equals(id))
                .findFirst();

        if (!voucher.isPresent()) {
            this.messageConfig.voucherNotFound.send(sender);
            return;
        }

        this.pluginConfig.vouchers.remove(voucher.get());
        this.pluginConfig.save();

        this.messageConfig.voucherRemoved.send(sender, Collections.singletonMap("id", id));
    }
}
