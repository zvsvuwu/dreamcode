package cc.dreamcode.vouchers;

import cc.dreamcode.command.bukkit.BukkitCommandProvider;
import cc.dreamcode.notice.adventure.BukkitNoticeProvider;
import cc.dreamcode.notice.adventure.serializer.BukkitNoticeSerializer;
import cc.dreamcode.platform.DreamVersion;
import cc.dreamcode.platform.bukkit.DreamBukkitConfig;
import cc.dreamcode.platform.bukkit.DreamBukkitPlatform;
import cc.dreamcode.platform.bukkit.component.ConfigurationResolver;
import cc.dreamcode.platform.component.ComponentService;
import cc.dreamcode.platform.other.component.DreamCommandExtension;
import cc.dreamcode.vouchers.command.VoucherCommand;
import cc.dreamcode.vouchers.command.completion.IdCompletion;
import cc.dreamcode.vouchers.command.completion.PlayersCompletion;
import cc.dreamcode.vouchers.command.handler.InvalidInputHandlerImpl;
import cc.dreamcode.vouchers.command.handler.InvalidPermissionHandlerImpl;
import cc.dreamcode.vouchers.command.handler.InvalidSenderHandlerImpl;
import cc.dreamcode.vouchers.command.handler.InvalidUsageHandlerImpl;
import cc.dreamcode.vouchers.config.MessageConfig;
import cc.dreamcode.vouchers.config.PluginConfig;
import cc.dreamcode.vouchers.controller.VoucherController;
import cc.dreamcode.vouchers.voucher.VoucherSerializer;
import eu.okaeri.configs.serdes.OkaeriSerdesPack;
import eu.okaeri.tasker.bukkit.BukkitTasker;
import lombok.Getter;
import lombok.NonNull;

public final class VouchersPlugin extends DreamBukkitPlatform implements DreamBukkitConfig {

    @Getter private static VouchersPlugin vouchersPlugin;

    @Override
    public void load(@NonNull ComponentService componentService) {
        vouchersPlugin = this;
    }

    @Override
    public void enable(@NonNull ComponentService componentService) {
        componentService.setDebug(false);

        this.registerInjectable(BukkitTasker.newPool(this));
        this.registerInjectable(BukkitNoticeProvider.create(this));

        this.registerInjectable(BukkitCommandProvider.create(this));
        componentService.registerExtension(DreamCommandExtension.class);

        componentService.registerResolver(ConfigurationResolver.class);
        componentService.registerComponent(MessageConfig.class);

        componentService.registerComponent(InvalidInputHandlerImpl.class);
        componentService.registerComponent(InvalidPermissionHandlerImpl.class);
        componentService.registerComponent(InvalidSenderHandlerImpl.class);
        componentService.registerComponent(InvalidUsageHandlerImpl.class);

        componentService.registerComponent(PluginConfig.class, pluginConfig ->
                componentService.setDebug(pluginConfig.debug));

        componentService.registerComponent(IdCompletion.class);
        componentService.registerComponent(PlayersCompletion.class);
        componentService.registerComponent(VoucherCommand.class);
        componentService.registerComponent(VoucherController.class);
    }

    @Override
    public void disable() {
        // features need to be call when server is stopping
    }

    @Override
    public @NonNull DreamVersion getDreamVersion() {
        return DreamVersion.create("Dream-Vouchers", "1.0.3", "torobolin");
    }

    @Override
    public @NonNull OkaeriSerdesPack getConfigSerdesPack() {
        return registry -> {
            registry.register(new BukkitNoticeSerializer());
            registry.register(new VoucherSerializer());
        };
    }

}
