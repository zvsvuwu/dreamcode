package cc.dreamcode.vouchers.command.completion;

import cc.dreamcode.command.suggestion.supplier.SuggestionSupplier;
import cc.dreamcode.platform.other.component.annotation.SuggestionKey;
import cc.dreamcode.vouchers.VouchersPlugin;
import eu.okaeri.injector.annotation.Inject;
import lombok.NonNull;

import java.util.ArrayList;
import java.util.List;

@SuggestionKey("@players")
public class PlayersCompletion implements SuggestionSupplier {

    private @Inject VouchersPlugin vouchersPlugin;

    @Override
    public List<String> supply(@NonNull Class<?> paramType) {
        List<String> playerList = new ArrayList<>();

        playerList.add("all");

        this.vouchersPlugin.getServer().getOnlinePlayers().forEach(player -> playerList.add(player.getName()));

        return playerList;
    }
}
