package cc.dreamcode.vouchers.voucher;

import eu.okaeri.configs.schema.GenericsDeclaration;
import eu.okaeri.configs.serdes.DeserializationData;
import eu.okaeri.configs.serdes.ObjectSerializer;
import eu.okaeri.configs.serdes.SerializationData;
import lombok.NonNull;
import org.bukkit.inventory.ItemStack;

public class VoucherSerializer implements ObjectSerializer<Voucher> {
    @Override
    public boolean supports(@NonNull Class<? super Voucher> type) {
        return Voucher.class.isAssignableFrom(type);
    }

    @Override
    public void serialize(@NonNull Voucher object, @NonNull SerializationData data, @NonNull GenericsDeclaration generics) {
        data.add("id", object.getId());
        data.add("item", object.getItemStack());
        data.add("command", object.getCommand());
        data.add("creator", object.getCreator());
        data.add("creation-time", object.getCreationTime());
    }

    @Override
    public Voucher deserialize(@NonNull DeserializationData data, @NonNull GenericsDeclaration generics) {
        return new Voucher(
                data.get("id", String.class),
                data.get("item", ItemStack.class),
                data.get("command", String.class),
                data.get("creator", String.class),
                data.get("creation-time", String.class)
        );
    }
}
