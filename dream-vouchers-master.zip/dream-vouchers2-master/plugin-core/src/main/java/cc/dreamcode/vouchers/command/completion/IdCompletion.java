package cc.dreamcode.vouchers.command.completion;

import cc.dreamcode.command.suggestion.supplier.SuggestionSupplier;
import cc.dreamcode.platform.other.component.annotation.SuggestionKey;
import cc.dreamcode.vouchers.config.PluginConfig;
import cc.dreamcode.vouchers.voucher.Voucher;
import eu.okaeri.injector.annotation.Inject;
import lombok.NonNull;

import java.util.List;
import java.util.stream.Collectors;

@SuggestionKey("@ids")
public class IdCompletion implements SuggestionSupplier {

    private @Inject PluginConfig pluginConfig;

    @Override
    public List<String> supply(@NonNull Class<?> paramType) {
        return this.pluginConfig.vouchers.stream()
                .map(Voucher::getId)
                .collect(Collectors.toList());
    }
}
