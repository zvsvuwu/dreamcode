package cc.dreamcode.vouchers.config;

import cc.dreamcode.notice.adventure.BukkitNotice;
import cc.dreamcode.platform.bukkit.component.configuration.Configuration;
import eu.okaeri.configs.OkaeriConfig;
import eu.okaeri.configs.annotation.CustomKey;
import eu.okaeri.configs.annotation.Header;
import eu.okaeri.configs.annotation.Headers;

@Configuration(child = "message.yml")
@Headers({
        @Header("## Dream-Vouchers (Message-Config) ##"),
        @Header("Dostepne type: (DO_NOT_SEND, CHAT, ACTION_BAR, SUBTITLE, TITLE, TITLE_SUBTITLE)")
})
public class MessageConfig extends OkaeriConfig {

    @CustomKey("command-usage")
    public BukkitNotice usage = BukkitNotice.chat("&7Przyklady uzycia komendy: &c{label}");
    @CustomKey("command-usage-help")
    public BukkitNotice usagePath = BukkitNotice.chat("&f{usage} &8- &7{description}");

    @CustomKey("command-usage-not-found")
    public BukkitNotice usageNotFound = BukkitNotice.chat("&cNie znaleziono pasujacych do kryteriow komendy.");
    @CustomKey("command-path-not-found")
    public BukkitNotice pathNotFound = BukkitNotice.chat("&cTa komenda jest pusta lub nie posiadasz dostepu do niej.");
    @CustomKey("command-no-permission")
    public BukkitNotice noPermission = BukkitNotice.chat("&cNie posiadasz uprawnien.");
    @CustomKey("command-not-player")
    public BukkitNotice notPlayer = BukkitNotice.chat("&cTa komende mozna tylko wykonac z poziomu gracza.");
    @CustomKey("command-not-console")
    public BukkitNotice notConsole = BukkitNotice.chat("&cTa komende mozna tylko wykonac z poziomu konsoli.");
    @CustomKey("command-invalid-format")
    public BukkitNotice invalidFormat = BukkitNotice.chat("&cPodano nieprawidlowy format argumentu komendy. ({input})");

    @CustomKey("player-not-found")
    public BukkitNotice playerNotFound = BukkitNotice.chat("&cPodanego gracza nie znaleziono.");
    @CustomKey("world-not-found")
    public BukkitNotice worldNotFound = BukkitNotice.chat("&cPodanego swiata nie znaleziono.");

    @CustomKey("voucher-created")
    public BukkitNotice voucherCreated = BukkitNotice.chat("&aPomyslnie stworzono nowy voucher");
    @CustomKey("voucher-not-found")
    public BukkitNotice voucherNotFound = BukkitNotice.chat("&cNie znaleziono vouchera o podanym id");
    @CustomKey("voucher-received")
    public BukkitNotice voucherReceived = BukkitNotice.chat("&aOtrzymales voucher {id}");
    @CustomKey("voucher-give-all")
    public BukkitNotice voucherGiveAll = BukkitNotice.chat("&aPomyslnie dales voucher {id} kazdemu graczowi");
    @CustomKey("voucher-give-player")
    public BukkitNotice voucherGivePlayer = BukkitNotice.chat("&aPomyslnie dales voucher {id} graczowi {player}");
    @CustomKey("voucher-already-exists")
    public BukkitNotice voucherAlreadyExists = BukkitNotice.chat("&cVoucher o podanym id juz istnieje");
    @CustomKey("voucher-removed")
    public BukkitNotice voucherRemoved = BukkitNotice.chat("&aPomyslnie usunieto voucher {id}");
    @CustomKey("voucher-used-all")
    public BukkitNotice voucherUsedAll = BukkitNotice.chat("&aGracz {player} uzyl vouchera {id}");
    @CustomKey("voucher-used")
    public BukkitNotice voucherUsed = BukkitNotice.chat("&aPomyslnie uzyles vouchera {id}");
    @CustomKey("no-item-in-hand")
    public BukkitNotice noItemInHand = BukkitNotice.chat("&Nie masz zadnego przedmiotu w rece");
    @CustomKey("voucher-cannot-be-a-block")
    public BukkitNotice voucherCannotBeABlock = BukkitNotice.chat("&cVoucher nie moze byc blokiem");
}
