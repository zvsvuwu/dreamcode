import com.github.jengelman.gradle.plugins.shadow.tasks.ShadowJar

repositories {
    maven("https://repo.papermc.io/repository/maven-public/")
}

dependencies {
    // -- spigot api -- (base)
    compileOnly("org.spigotmc:spigot-api:1.8.8-R0.1-SNAPSHOT")

    // -- dream-platform --
    implementation("cc.dreamcode.platform:core:1.9.14")
    implementation("cc.dreamcode.platform:bukkit:1.9.14")
    implementation("cc.dreamcode.platform:bukkit-command:1.9.14")
    implementation("cc.dreamcode.platform:bukkit-config:1.9.14")
    implementation("cc.dreamcode.platform:persistence:1.9.14")

    // -- dream-utilities --
    implementation("cc.dreamcode:utilities:1.2.24")
    implementation("cc.dreamcode:utilities-bukkit:1.2.24")

    // -- dream-notice --
    implementation("cc.dreamcode.notice:minecraft:1.3.13")
    implementation("cc.dreamcode.notice:bukkit:1.3.13")
    implementation("cc.dreamcode.notice:bukkit-serdes:1.3.13")

    // -- dream-command --
    implementation("cc.dreamcode.command:core:1.4.19")
    implementation("cc.dreamcode.command:bukkit:1.4.19")

    // -- dream-menu --
    implementation("cc.dreamcode.menu:core:1.2.2")
    implementation("cc.dreamcode.menu:bukkit:1.2.2")
    implementation("cc.dreamcode.menu:bukkit-serdes:1.2.2")

    // -- configs--
    implementation("eu.okaeri:okaeri-configs-yaml-bukkit:5.0.0-beta.5")
    implementation("eu.okaeri:okaeri-configs-serdes-bukkit:5.0.0-beta.5")
    implementation("eu.okaeri:okaeri-configs-serdes-commons:5.0.0-beta.5")

    // -- persistence data --
    implementation("eu.okaeri:okaeri-persistence-flat:2.0.0-beta.1")
    implementation("eu.okaeri:okaeri-persistence-jdbc:2.0.0-beta.1")
    implementation("eu.okaeri:okaeri-persistence-mongo:2.0.0-beta.1")

    // -- persistence data configure --
    implementation("eu.okaeri:okaeri-configs-json-gson:5.0.0-beta.5")
    implementation("eu.okaeri:okaeri-configs-json-simple:5.0.0-beta.5")

    // -- injector --
    implementation("eu.okaeri:okaeri-injector:2.1.0")

    // -- placeholders --
    implementation("eu.okaeri:okaeri-placeholders-core:4.0.7")

    // -- tasker (easy sync/async scheduler) --
    implementation("eu.okaeri:okaeri-tasker-bukkit:2.1.0-beta.3")

    // -- Multi-Version Items helper --
    implementation("com.github.cryptomorin:XSeries:9.9.0")
}

tasks.withType<ShadowJar> {

    archiveFileName.set("Dream-Collection-${project.version}.jar")

    minimize()

    relocate("com.cryptomorin", "cc.dreamcode.collection.libs.com.cryptomorin")
    relocate("eu.okaeri", "cc.dreamcode.collection.libs.eu.okaeri")

    relocate("cc.dreamcode.platform", "cc.dreamcode.collection.libs.cc.dreamcode.platform")
    relocate("cc.dreamcode.utilities", "cc.dreamcode.collection.libs.cc.dreamcode.utilities")
    relocate("cc.dreamcode.menu", "cc.dreamcode.collection.libs.cc.dreamcode.menu")
    relocate("cc.dreamcode.command", "cc.dreamcode.collection.libs.cc.dreamcode.command")
    relocate("cc.dreamcode.notice", "cc.dreamcode.collection.libs.cc.dreamcode.notice")

    relocate("org.bson", "cc.dreamcode.collection.libs.org.bson")
    relocate("com.mongodb", "cc.dreamcode.collection.libs.com.mongodb")
    relocate("com.zaxxer", "cc.dreamcode.collection.libs.com.zaxxer")
    relocate("org.slf4j", "cc.dreamcode.collection.libs.org.slf4j")
    relocate("org.json", "cc.dreamcode.collection.libs.org.json")
    relocate("com.google.gson", "cc.dreamcode.collection.libs.com.google.gson")
}