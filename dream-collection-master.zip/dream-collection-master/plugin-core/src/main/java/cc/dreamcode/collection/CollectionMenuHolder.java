package cc.dreamcode.collection;

import cc.dreamcode.menu.bukkit.base.BukkitMenu;
import eu.okaeri.injector.annotation.Inject;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.bukkit.entity.HumanEntity;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class CollectionMenuHolder {

    private final CollectionPlugin collectionPlugin;

    private BukkitMenu bukkitMenu;

    public void update() {
        this.bukkitMenu = this.collectionPlugin.createInstance(CollectionMenu.class).build();
    }

    public void open(@NonNull HumanEntity humanEntity) {
        if (this.bukkitMenu == null) {
            this.update();
        }

        this.bukkitMenu.open(humanEntity);
    }
}
