package cc.dreamcode.collection;

import cc.dreamcode.collection.config.MessageConfig;
import cc.dreamcode.collection.event.CollectionCompleteEvent;
import cc.dreamcode.utilities.builder.MapBuilder;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import eu.okaeri.injector.annotation.Inject;
import lombok.RequiredArgsConstructor;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class CollectionController implements Listener {

    private final CollectionPlugin collectionPlugin;
    private final MessageConfig messageConfig;

    @EventHandler
    public void onCollectionComplete(CollectionCompleteEvent e) {
        e.getCollectionModel().getRewardCommands().forEach(command ->
                this.collectionPlugin.getServer().dispatchCommand(
                        this.collectionPlugin.getServer().getConsoleSender(),
                        command
                ));

        e.getCollectionModel().getRewardItems().forEach(item ->
                this.collectionPlugin.getServer().getOnlinePlayers().forEach(player ->
                        player.getInventory().addItem(ItemBuilder.of(item).fixColors().toItemStack())
                                .forEach((integer, itemStack) -> player.getWorld().dropItem(player.getLocation(), itemStack))));

        this.messageConfig.collectionSuccess.sendAll(new MapBuilder<String, Object>()
                .put("name", e.getCollectionModel().getName())
                .build());
    }
}
