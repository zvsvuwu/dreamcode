package cc.dreamcode.collection.command;

import cc.dreamcode.collection.CollectionCache;
import cc.dreamcode.collection.config.MessageConfig;
import cc.dreamcode.collection.config.PluginConfig;
import cc.dreamcode.command.annotations.RequiredPermission;
import cc.dreamcode.command.bukkit.BukkitCommand;
import cc.dreamcode.utilities.TimeUtil;
import cc.dreamcode.utilities.builder.MapBuilder;
import eu.okaeri.configs.exception.OkaeriException;
import eu.okaeri.injector.annotation.Inject;
import lombok.NonNull;
import org.bukkit.command.CommandSender;

import java.util.List;

@RequiredPermission
public class CollectionReloadCommand extends BukkitCommand {

    private final PluginConfig pluginConfig;
    private final MessageConfig messageConfig;
    private final CollectionCache collectionCache;

    @Inject
    public CollectionReloadCommand(final PluginConfig pluginConfig, final MessageConfig messageConfig, final CollectionCache collectionCache) {
        super("collectionreload", "zbiorkareload");

        this.pluginConfig = pluginConfig;
        this.messageConfig = messageConfig;
        this.collectionCache = collectionCache;
    }

    @Override
    public void content(@NonNull CommandSender sender, @NonNull String[] args) {
        final long time = System.currentTimeMillis();

        try {
            this.messageConfig.load();
            this.pluginConfig.load();

            this.collectionCache.updateCache(true);

            this.messageConfig.reloaded.send(sender, new MapBuilder<String, Object>()
                    .put("time", TimeUtil.convertMills(System.currentTimeMillis() - time))
                    .build());
        }
        catch (NullPointerException | OkaeriException e) {
            e.printStackTrace();

            this.messageConfig.reloadError.send(sender, new MapBuilder<String, Object>()
                    .put("error", e.getMessage())
                    .build());
        }
    }

    @Override
    public List<String> tab(@NonNull CommandSender sender, @NonNull String[] args) {
        return null;
    }
}
