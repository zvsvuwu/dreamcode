package cc.dreamcode.collection;

import eu.okaeri.persistence.repository.DocumentRepository;
import eu.okaeri.persistence.repository.annotation.DocumentCollection;
import lombok.NonNull;

import java.util.UUID;

@DocumentCollection(path = "collections", keyLength = 36)
public interface CollectionRepository extends DocumentRepository<UUID, Collection> {

    default Collection createCollectionByModel(@NonNull CollectionModel model) {
        final Collection collection = this.findOrCreateByPath(UUID.randomUUID());

        collection.setName(model.getName());
        collection.setStoredAmount(0);

        return collection;
    }
}
