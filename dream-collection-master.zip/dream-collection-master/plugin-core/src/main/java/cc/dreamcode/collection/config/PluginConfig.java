package cc.dreamcode.collection.config;

import cc.dreamcode.collection.CollectionModel;
import cc.dreamcode.menu.bukkit.BukkitMenuBuilder;
import cc.dreamcode.platform.bukkit.component.configuration.Configuration;
import cc.dreamcode.platform.persistence.StorageConfig;
import cc.dreamcode.utilities.builder.ListBuilder;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import com.cryptomorin.xseries.XMaterial;
import eu.okaeri.configs.OkaeriConfig;
import eu.okaeri.configs.annotation.Comment;
import eu.okaeri.configs.annotation.Header;
import eu.okaeri.configs.annotation.NameModifier;
import eu.okaeri.configs.annotation.NameStrategy;
import eu.okaeri.configs.annotation.Names;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

@Configuration(
        child = "config.yml"
)
@Header("## Dream-Collection (Main-Config) ##")
@Names(strategy = NameStrategy.HYPHEN_CASE, modifier = NameModifier.TO_LOWER_CASE)
public class PluginConfig extends OkaeriConfig {
    @Comment("Debug pokazuje dodatkowe informacje do konsoli. Lepiej wylaczyc. :P")
    public boolean debug = true;

    @Comment("")
    @Comment("Jakie maja byc dostepne zbiorki?")
    @Comment("Dostepne placeholdery: ({collection-amount}, {collection-remaining}, {collection-total}, {donator-nick}, {donator-date})")
    public List<CollectionModel> collectionModels = new ListBuilder<CollectionModel>()
            .add(new CollectionModel(
                    "turbodrop",
                    new ItemBuilder(XMaterial.DIAMOND.parseItem())
                            .setName("&9Magiczny diament")
                            .setLore("&7Diament ten znajdziesz w jaskini skarbow...")
                            .addEnchant(Enchantment.DURABILITY, 1, true)
                            .addFlags(ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_ATTRIBUTES)
                            .toItemStack(),
                    300,

                    13,
                    new ItemBuilder(XMaterial.DIAMOND_PICKAXE.parseItem())
                            .setName("&9&lTurboDrop")
                            .setLore("",
                                    "&7Uzbierana kwota w tej zbiorce aktywuje event &9TurboDrop&7.",
                                    "",
                                    "&8Wplacono: &f{collection-amount}/{collection-total}",
                                    "&8Ostatni wplacil: {donator-nick}, data: {donator-date}")
                            .toItemStack(),

                    Collections.singletonList("turbodrop all"),
                    new ArrayList<>()
            ))
            .build();

    @Comment("")
    @Comment("Jak ma wygladac podstawowe menu dla zbiorek?")
    public BukkitMenuBuilder collectionMenuBuilder = new BukkitMenuBuilder("&8[&bM&8] Zbiorki", 3, new HashMap<>());

    @Comment("Uzupelnij dane do logowania bazy danych.")
    public StorageConfig storageConfig = new StorageConfig("dreamcollection");
}
