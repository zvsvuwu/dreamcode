package cc.dreamcode.collection;

import cc.dreamcode.collection.command.CollectionCommand;
import cc.dreamcode.collection.command.CollectionReloadCommand;
import cc.dreamcode.command.bukkit.BukkitCommandProvider;
import cc.dreamcode.menu.bukkit.BukkitMenuProvider;
import cc.dreamcode.menu.bukkit.okaeri.MenuBuilderSerdes;
import cc.dreamcode.notice.minecraft.bukkit.serdes.BukkitNoticeSerdes;
import cc.dreamcode.platform.DreamVersion;
import cc.dreamcode.platform.bukkit.DreamBukkitConfig;
import cc.dreamcode.platform.bukkit.DreamBukkitPlatform;
import cc.dreamcode.platform.bukkit.component.CommandComponentResolver;
import cc.dreamcode.platform.bukkit.component.ConfigurationComponentResolver;
import cc.dreamcode.platform.bukkit.component.ListenerComponentResolver;
import cc.dreamcode.platform.bukkit.component.RunnableComponentResolver;
import cc.dreamcode.platform.component.ComponentManager;
import cc.dreamcode.platform.persistence.DreamPersistence;
import cc.dreamcode.platform.persistence.component.DocumentPersistenceComponentResolver;
import cc.dreamcode.platform.persistence.component.DocumentRepositoryComponentResolver;
import cc.dreamcode.collection.config.MessageConfig;
import cc.dreamcode.collection.config.PluginConfig;
import eu.okaeri.configs.serdes.OkaeriSerdesPack;
import eu.okaeri.configs.yaml.bukkit.serdes.SerdesBukkit;
import eu.okaeri.persistence.document.DocumentPersistence;
import eu.okaeri.tasker.bukkit.BukkitTasker;
import lombok.Getter;
import lombok.NonNull;

public final class CollectionPlugin extends DreamBukkitPlatform implements DreamBukkitConfig, DreamPersistence {

    @Getter private static CollectionPlugin collectionPlugin;

    @Override
    public void load(@NonNull ComponentManager componentManager) {
        collectionPlugin = this;
    }

    @Override
    public void enable(@NonNull ComponentManager componentManager) {
        this.getInjector().registerInjectable(BukkitTasker.newPool(this));
        this.getInjector().registerInjectable(BukkitMenuProvider.create(this));
        this.getInjector().registerInjectable(BukkitCommandProvider.create(this));

        componentManager.registerResolver(CommandComponentResolver.class);
        componentManager.registerResolver(ListenerComponentResolver.class);
        componentManager.registerResolver(RunnableComponentResolver.class);

        componentManager.registerResolver(ConfigurationComponentResolver.class);
        componentManager.registerComponent(MessageConfig.class, messageConfig ->
                this.getInject(BukkitCommandProvider.class).ifPresent(bukkitCommandProvider -> {
                    bukkitCommandProvider.setRequiredPermissionMessage(messageConfig.noPermission.getText());
                    bukkitCommandProvider.setRequiredPlayerMessage(messageConfig.notPlayer.getText());
                }));

        componentManager.registerComponent(PluginConfig.class, pluginConfig -> {
            // register persistence + repositories
            this.getInjector().registerInjectable(pluginConfig.storageConfig);

            componentManager.registerResolver(DocumentPersistenceComponentResolver.class);
            componentManager.registerComponent(DocumentPersistence.class);
            componentManager.registerResolver(DocumentRepositoryComponentResolver.class);

            componentManager.setDebug(pluginConfig.debug);

            componentManager.registerComponent(CollectionRepository.class);
            componentManager.registerComponent(CollectionCache.class, CollectionCache::updateCache);
        });

        componentManager.registerComponent(CollectionService.class);
        componentManager.registerComponent(CollectionMenuHolder.class);
        componentManager.registerComponent(CollectionController.class);

        componentManager.registerComponent(CollectionCommand.class);
        componentManager.registerComponent(CollectionReloadCommand.class);
    }

    @Override
    public void disable() {
        // features need to be call when server is stopping
    }

    @Override
    public @NonNull DreamVersion getDreamVersion() {
        return DreamVersion.create("Dream-Collection", "1.0.5", "Ravis96");
    }

    @Override
    public @NonNull OkaeriSerdesPack getConfigSerdesPack() {
        return registry -> {
            registry.register(new BukkitNoticeSerdes());
            registry.register(new MenuBuilderSerdes());
            registry.register(new CollectionModelSerializer());
        };
    }

    @Override
    public @NonNull OkaeriSerdesPack getPersistenceSerdesPack() {
        return registry -> registry.register(new SerdesBukkit());
    }

}
