package cc.dreamcode.collection;

import cc.dreamcode.collection.config.PluginConfig;
import eu.okaeri.injector.annotation.Inject;
import eu.okaeri.tasker.core.Tasker;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class CollectionCache {

    private final CollectionPlugin collectionPlugin;
    private final PluginConfig pluginConfig;
    private final CollectionRepository collectionRepository;
    private final Tasker tasker;

    private final Map<UUID, Collection> collections = new HashMap<>();
    private final Map<String, UUID> nameToUuids = new HashMap<>();

    public void updateCache(boolean updateMenu) {
        this.tasker.newChain()
                .supplyAsync(this.collectionRepository::findAll)
                .acceptSync(collections -> {

                    if (!this.collections.isEmpty()) {
                        this.collections.clear();
                        this.nameToUuids.clear();
                    }

                    collections.forEach(collection -> {
                        this.collections.put(collection.getUniqueId(), collection);
                        this.nameToUuids.put(collection.getName(), collection.getUniqueId());
                    });
                })
                .acceptAsync(collections -> {

                    final List<CollectionModel> notPresentingModels = this.pluginConfig.collectionModels
                            .stream()
                            .filter(collectionModel -> !this.nameToUuids.containsKey(collectionModel.getName()))
                            .collect(Collectors.toList());

                    notPresentingModels.forEach(collectionModel -> {

                        final Collection collection = this.collectionRepository.createCollectionByModel(collectionModel);
                        this.collections.put(collection.getUniqueId(), collection);
                        this.nameToUuids.put(collection.getName(), collection.getUniqueId());
                    });
                })
                .abortIf(() -> !updateMenu)
                .acceptSync(collections -> this.collectionPlugin.getInject(CollectionMenuHolder.class)
                        .ifPresent(CollectionMenuHolder::update))
                .execute();
    }

    public void updateCache() {
        this.updateCache(false);
    }

    public Optional<Collection> getCollection(@NonNull String name) {

        final UUID uuid = this.nameToUuids.get(name);
        if (uuid == null) {
            return Optional.empty();
        }

        return Optional.ofNullable(this.collections.get(uuid));
    }

    public Optional<Collection> getCollection(@NonNull CollectionModel model) {
        return this.getCollection(model.getName());
    }
}
