package cc.dreamcode.collection;

import eu.okaeri.configs.schema.GenericsDeclaration;
import eu.okaeri.configs.serdes.DeserializationData;
import eu.okaeri.configs.serdes.ObjectSerializer;
import eu.okaeri.configs.serdes.SerializationData;
import lombok.NonNull;
import org.bukkit.inventory.ItemStack;

public class CollectionModelSerializer implements ObjectSerializer<CollectionModel> {
    @Override
    public boolean supports(@NonNull Class<? super CollectionModel> type) {
        return CollectionModel.class.isAssignableFrom(type);
    }

    @Override
    public void serialize(@NonNull CollectionModel object, @NonNull SerializationData data, @NonNull GenericsDeclaration generics) {
        data.add("collection-name", object.getName());
        data.add("collection-item", object.getCollectionItem());
        data.add("collection-size", object.getCollectionSize());

        data.add("collection-menu-item-slot", object.getMenuItemSlot());
        data.add("collection-menu-item-display", object.getMenuItemDisplay());

        data.add("collection-reward-commands", object.getRewardCommands());
        data.add("collection-reward-items", object.getRewardItems());
    }

    @Override
    public CollectionModel deserialize(@NonNull DeserializationData data, @NonNull GenericsDeclaration generics) {
        return new CollectionModel(
                data.get("collection-name", String.class),
                data.get("collection-item", ItemStack.class),
                data.get("collection-size", Integer.class),

                data.get("collection-menu-item-slot", Integer.class),
                data.get("collection-menu-item-display", ItemStack.class),

                data.getAsList("collection-reward-commands", String.class),
                data.getAsList("collection-reward-items", ItemStack.class)
        );
    }
}
