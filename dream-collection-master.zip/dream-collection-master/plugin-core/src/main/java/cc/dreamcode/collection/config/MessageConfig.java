package cc.dreamcode.collection.config;

import cc.dreamcode.notice.minecraft.MinecraftNoticeType;
import cc.dreamcode.notice.minecraft.bukkit.BukkitNotice;
import cc.dreamcode.platform.bukkit.component.configuration.Configuration;
import eu.okaeri.configs.OkaeriConfig;
import eu.okaeri.configs.annotation.Header;
import eu.okaeri.configs.annotation.Headers;
import eu.okaeri.configs.annotation.NameModifier;
import eu.okaeri.configs.annotation.NameStrategy;
import eu.okaeri.configs.annotation.Names;

@Configuration(
        child = "message.yml"
)
@Headers({
        @Header("## Dream-Collection (Message-Config) ##"),
        @Header("Dostepne type: (DO_NOT_SEND, CHAT, ACTION_BAR, SUBTITLE, TITLE, TITLE_SUBTITLE)")
})
@Names(strategy = NameStrategy.HYPHEN_CASE, modifier = NameModifier.TO_LOWER_CASE)
public class MessageConfig extends OkaeriConfig {

    public BukkitNotice usage = new BukkitNotice(MinecraftNoticeType.CHAT, "&7Poprawne uzycie: &5{usage}");
    public BukkitNotice noPermission = new BukkitNotice(MinecraftNoticeType.CHAT, "&cNie posiadasz uprawnien.");
    public BukkitNotice notPlayer = new BukkitNotice(MinecraftNoticeType.CHAT, "&cNie jestes graczem aby to zrobic.");

    public BukkitNotice noItemToGive = new BukkitNotice(MinecraftNoticeType.CHAT, "&cNie posiadasz itemu dla tej zbiorki.");
    public BukkitNotice collectionSuccess = new BukkitNotice(MinecraftNoticeType.CHAT, "&cZbiorka {name} zostala zakonczona! Kazdy otrzymal nagrode!");

    public BukkitNotice collectionNotFound = new BukkitNotice(MinecraftNoticeType.CHAT, "&cZbiorki o podanej nazwie nie znaleziono.");
    public BukkitNotice noItemInHand = new BukkitNotice(MinecraftNoticeType.CHAT, "&cAby to zrobic, musisz trzymac przedmiot w rece.");
    public BukkitNotice collectionItemUpdated = new BukkitNotice(MinecraftNoticeType.CHAT, "&aZmieniono przedmiot zbiorki {name}.");

    public BukkitNotice reloaded = new BukkitNotice(MinecraftNoticeType.CHAT, "&aPrzeladowano! &7({time})");
    public BukkitNotice reloadError = new BukkitNotice(MinecraftNoticeType.CHAT, "&cZnaleziono problem w konfiguracji: &6{error}");
}
