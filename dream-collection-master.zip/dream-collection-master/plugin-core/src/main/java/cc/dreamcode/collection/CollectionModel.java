package cc.dreamcode.collection;

import lombok.AllArgsConstructor;
import lombok.Data;
import org.bukkit.inventory.ItemStack;

import java.util.List;

@Data
@AllArgsConstructor
public class CollectionModel {

    private final String name;

    private ItemStack collectionItem;
    private final int collectionSize;

    private final int menuItemSlot;
    private final ItemStack menuItemDisplay;

    private final List<String> rewardCommands;
    private final List<ItemStack> rewardItems;
}
