package cc.dreamcode.collection;

import cc.dreamcode.collection.config.MessageConfig;
import cc.dreamcode.collection.config.PluginConfig;
import cc.dreamcode.menu.bukkit.BukkitMenuBuilder;
import cc.dreamcode.menu.bukkit.base.BukkitMenu;
import cc.dreamcode.menu.bukkit.setup.BukkitMenuSetup;
import cc.dreamcode.utilities.DateUtil;
import cc.dreamcode.utilities.builder.MapBuilder;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import eu.okaeri.injector.annotation.Inject;
import lombok.RequiredArgsConstructor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.Optional;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class CollectionMenu implements BukkitMenuSetup {

    private final PluginConfig pluginConfig;
    private final MessageConfig messageConfig;
    private final CollectionCache collectionCache;
    private final CollectionService collectionService;

    @Override
    public BukkitMenu build() {

        final BukkitMenuBuilder menuBuilder = this.pluginConfig.collectionMenuBuilder;
        final BukkitMenu bukkitMenu = menuBuilder.buildWithItems();

        this.pluginConfig.collectionModels.forEach(collectionModel -> {

            final Optional<Collection> optionalCollection = this.collectionCache.getCollection(collectionModel);
            if (!optionalCollection.isPresent()) {
                return;
            }

            final Collection collection = optionalCollection.get();

            bukkitMenu.setItem(collectionModel.getMenuItemSlot(), ItemBuilder.of(collectionModel.getMenuItemDisplay())
                    .fixColors(new MapBuilder<String, Object>()
                            .put("collection-amount", collection.getStoredAmount())
                            .put("collection-remaining", collectionModel.getCollectionSize() - collection.getStoredAmount())
                            .put("collection-total", collectionModel.getCollectionSize())
                            .put("donator-nick", collection.getLastDonator() == null ? "-" : collection.getLastDonator())
                            .put("donator-date", collection.getLastDonatorTime() == null ? "-" : DateUtil.format(collection.getLastDonatorTime()))
                            .build())
                    .toItemStack(), e -> {

                        if (!(e.getWhoClicked() instanceof Player)) {
                            return;
                        }

                        final Player player = (Player) e.getWhoClicked();
                        final ItemStack fixedItem = ItemBuilder.of(collectionModel.getCollectionItem()).fixColors().toItemStack();
                        if (!player.getInventory().containsAtLeast(fixedItem, fixedItem.getAmount())) {
                            this.messageConfig.noItemToGive.send(player);
                            return;
                        }

                        player.getInventory().removeItem(fixedItem);
                        this.collectionService.addToCollectionItem(player, collection, collectionModel, fixedItem.getAmount());

                        bukkitMenu.setItem(collectionModel.getMenuItemSlot(), ItemBuilder.of(collectionModel.getMenuItemDisplay())
                                .fixColors(new MapBuilder<String, Object>()
                                        .put("collection-amount", collection.getStoredAmount())
                                        .put("collection-remaining", collectionModel.getCollectionSize() - collection.getStoredAmount())
                                        .put("collection-total", collectionModel.getCollectionSize())
                                        .put("donator-nick", collection.getLastDonator() == null ? "-" : collection.getLastDonator())
                                        .put("donator-date", collection.getLastDonatorTime() == null ? "-" : DateUtil.format(collection.getLastDonatorTime()))
                                        .build())
                                .toItemStack());
                    });
        });

        return bukkitMenu;
    }
}
