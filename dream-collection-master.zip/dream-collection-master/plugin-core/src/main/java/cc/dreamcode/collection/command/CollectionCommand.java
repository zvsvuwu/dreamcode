package cc.dreamcode.collection.command;

import cc.dreamcode.collection.CollectionMenuHolder;
import cc.dreamcode.collection.CollectionModel;
import cc.dreamcode.collection.config.MessageConfig;
import cc.dreamcode.collection.config.PluginConfig;
import cc.dreamcode.command.annotations.RequiredPlayer;
import cc.dreamcode.command.bukkit.BukkitCommand;
import cc.dreamcode.utilities.builder.MapBuilder;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import eu.okaeri.injector.annotation.Inject;
import eu.okaeri.tasker.core.Tasker;
import lombok.NonNull;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@RequiredPlayer
public class CollectionCommand extends BukkitCommand {

    private final PluginConfig pluginConfig;
    private final MessageConfig messageConfig;
    private final CollectionMenuHolder collectionMenuHolder;
    private final Tasker tasker;

    @Inject
    public CollectionCommand(final PluginConfig pluginConfig, final MessageConfig messageConfig, final CollectionMenuHolder collectionMenuHolder, final Tasker tasker) {
        super("collection", "zbiorka");

        this.pluginConfig = pluginConfig;
        this.messageConfig = messageConfig;
        this.collectionMenuHolder = collectionMenuHolder;
        this.tasker = tasker;
    }

    @Override
    public void content(@NonNull CommandSender sender, @NonNull String[] args) {
        final Player player = (Player) sender;

        if (args.length >= 1 && player.hasPermission("dream.collection.admin")) {
            if (args[0].equalsIgnoreCase("setitem")) {
                if (args.length == 1) {
                    this.messageConfig.usage.send(player, new MapBuilder<String, Object>()
                            .put("usage", "/zbiorka setitem (nazwa)").build());
                    return;
                }

                final String model = args[1];
                final Optional<CollectionModel> optionalCollectionModel = this.pluginConfig.collectionModels
                        .stream()
                        .filter(scan -> scan.getName().equals(model))
                        .findAny();

                if (!optionalCollectionModel.isPresent()) {
                    this.messageConfig.collectionNotFound.send(player);
                    return;
                }

                final CollectionModel collectionModel = optionalCollectionModel.get();
                final ItemStack itemInHand = player.getInventory().getItemInHand();
                if (itemInHand == null || itemInHand.getType().equals(Material.AIR)) {
                    this.messageConfig.noItemInHand.send(player);
                    return;
                }

                final ItemStack fixedItem = ItemBuilder.of(itemInHand).breakColors().toItemStack();

                collectionModel.setCollectionItem(fixedItem);
                this.tasker.newSharedChain("dbops:config")
                        .supplyAsync(this.pluginConfig::save)
                        .acceptSync(config -> this.messageConfig.collectionItemUpdated.send(player, new MapBuilder<String, Object>()
                                .put("name", collectionModel.getName())
                                .build()))
                        .execute();
                return;
            }

            this.messageConfig.usage.send(player, new MapBuilder<String, Object>()
                    .put("usage", "/zbiorka [setitem]").build());
            return;
        }

        this.collectionMenuHolder.open(player);
    }

    @Override
    public List<String> tab(@NonNull CommandSender sender, @NonNull String[] args) {

        if (!sender.hasPermission("dream.collection.admin")) {
            return null;
        }

        if (args.length == 1) {
            return Stream.of("setitem")
                    .filter(name -> name.startsWith(args[0]))
                    .collect(Collectors.toList());
        }

        if (args.length == 2) {
            return this.pluginConfig.collectionModels
                    .stream()
                    .map(CollectionModel::getName)
                    .filter(name -> name.startsWith(args[1]))
                    .collect(Collectors.toList());
        }

        return null;
    }
}
