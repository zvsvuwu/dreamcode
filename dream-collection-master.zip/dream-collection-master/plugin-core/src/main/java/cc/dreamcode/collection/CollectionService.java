package cc.dreamcode.collection;

import cc.dreamcode.collection.event.CollectionCompleteEvent;
import eu.okaeri.injector.annotation.Inject;
import eu.okaeri.tasker.core.Tasker;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.bukkit.entity.Player;

import java.time.Instant;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class CollectionService {

    private final CollectionPlugin collectionPlugin;
    private final Tasker tasker;

    public void save(@NonNull Collection collection) {
        this.tasker.newSharedChain("dbops:" + collection.getUniqueId())
                .supplyAsync(collection::save)
                .execute();
    }

    public void addToCollectionItem(@NonNull Player player, @NonNull Collection collection, @NonNull CollectionModel collectionModel, int amount) {
        collection.pay(amount);
        collection.setLastDonator(player.getName());
        collection.setLastDonatorTime(Instant.now());

        if (collection.getStoredAmount() >= collectionModel.getCollectionSize()) {
            this.completeCollection(collection, collectionModel);
            return;
        }

        this.save(collection);
    }

    public void completeCollection(@NonNull Collection collection, @NonNull CollectionModel collectionModel) {
        collection.setStoredAmount(0);
        collection.setLastDonator(null);
        collection.setLastDonatorTime(null);

        final CollectionCompleteEvent collectionCompleteEvent = new CollectionCompleteEvent(collectionModel);
        this.collectionPlugin.getServer().getPluginManager().callEvent(collectionCompleteEvent);

        this.save(collection);
    }
}
