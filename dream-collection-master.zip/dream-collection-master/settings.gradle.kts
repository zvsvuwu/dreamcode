rootProject.name = "dream-collection"

include(":plugin-core")