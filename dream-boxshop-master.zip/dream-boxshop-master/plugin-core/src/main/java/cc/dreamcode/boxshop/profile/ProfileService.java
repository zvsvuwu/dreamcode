package cc.dreamcode.boxshop.profile;

import eu.okaeri.injector.annotation.Inject;
import eu.okaeri.tasker.core.Tasker;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.bukkit.entity.Player;

import java.time.Duration;
import java.util.function.Consumer;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class ProfileService {

    private final ProfileRepository profileRepository;
    private final ProfileCache profileCache;
    private final Tasker tasker;

    public Duration getPlayingTime(@NonNull Player player) {
        return this.profileCache.getProfile(player.getUniqueId())
                .map(Profile::getPlayingTime)
                .orElse(Duration.ZERO);
    }

    public int getKills(@NonNull Player player) {
        return this.profileCache.getProfile(player.getUniqueId())
                .map(Profile::getKills)
                .orElse(0);
    }

    public int getDeaths(@NonNull Player player) {
        return this.profileCache.getProfile(player.getUniqueId())
                .map(Profile::getDeaths)
                .orElse(0);
    }

    public void updateProfile(@NonNull Player player, @NonNull Consumer<Profile> consumer) {
        this.tasker.newSharedChain("dbops;" + player.getUniqueId())
                .supplyAsync(() -> this.profileRepository.findOrCreate(player.getUniqueId(), player.getName()))
                .acceptAsync(profile -> {
                    consumer.accept(profile);
                    profile.save();
                })
                .acceptSync(this.profileCache::update)
                .execute();
    }

}
