package cc.dreamcode.boxshop.profile;

import cc.dreamcode.boxshop.BoxShopPlugin;
import cc.dreamcode.platform.bukkit.component.scheduler.Scheduler;
import eu.okaeri.injector.annotation.Inject;
import lombok.RequiredArgsConstructor;

import java.util.concurrent.atomic.AtomicLong;

@Scheduler(async = false, delay = 1200, interval = 1200)
@RequiredArgsConstructor(onConstructor_ = @Inject)
public class ProfileScheduler implements Runnable {

    private final BoxShopPlugin boxShopPlugin;
    private final ProfileService profileService;

    private final AtomicLong atomicLong = new AtomicLong();

    @Override
    public void run() {
        this.boxShopPlugin.getServer().getOnlinePlayers().forEach(player ->
                this.boxShopPlugin.getServer().getScheduler().runTaskLater(
                        this.boxShopPlugin,
                        () -> this.profileService.updateProfile(player, profile ->
                                profile.setPlayingTime(profile.getPlayingTime().plusMinutes(1L))),
                        this.atomicLong.getAndIncrement()
                ));

        this.atomicLong.set(0L);
    }
}
