package cc.dreamcode.boxshop;

import cc.dreamcode.boxshop.config.PluginConfig;
import cc.dreamcode.boxshop.profile.ProfileService;
import cc.dreamcode.boxshop.vault.VaultHook;
import cc.dreamcode.platform.bukkit.hook.PluginHookManager;
import cc.dreamcode.utilities.bukkit.InventoryUtil;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import eu.okaeri.injector.annotation.Inject;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.time.Duration;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class BoxShopService {

    private final PluginConfig pluginConfig;
    private final ProfileService profileService;
    private final PluginHookManager pluginHookManager;

    public Duration getPlayerPlaytime(@NonNull Player player) {
        return this.profileService.getPlayingTime(player);
    }

    public void takePlayerPlaytime(@NonNull Player player, @NonNull Duration duration) {
        this.profileService.updateProfile(player, profile -> {

            if (profile.getPlayingTime().minus(duration).isNegative()) {
                throw new RuntimeException("Profile does not have enough playtime to modify, aborting... (bug)");
            }

            profile.setPlayingTime(profile.getPlayingTime().minus(duration));
        });
    }

    public int getPlayerItem(@NonNull Player player, @NonNull ItemStack itemStack) {
        return InventoryUtil.countColorizedItems(player.getInventory(), itemStack);
    }

    public boolean takePlayerItem(@NonNull Player player, @NonNull ItemStack itemStack, int amount) {
        return player.getInventory().removeItem(ItemBuilder.of(itemStack)
                .setAmount(amount)
                .fixColors()
                .toItemStack())
                .isEmpty();
    }

    public double getPlayerMoney(@NonNull Player player) {
        return this.pluginHookManager.get(VaultHook.class)
                .map(vaultHook -> vaultHook.getMoney(player).orElse(0.0D))
                .orElse(0.0D);
    }

    public boolean takePlayerMoney(@NonNull Player player, double money) {
        return this.pluginHookManager.get(VaultHook.class)
                .map(vaultHook -> vaultHook.withdraw(player, money))
                .orElse(false);
    }

    public boolean addPlayerMoney(@NonNull Player player, double money) {
        return this.pluginHookManager.get(VaultHook.class)
                .map(vaultHook -> vaultHook.deposit(player, money))
                .orElse(false);
    }

    public int getPlayerKills(@NonNull Player player) {
        return this.profileService.getKills(player);
    }

    public void takePlayerKills(@NonNull Player player, int kills) {
        this.profileService.updateProfile(player, profile -> {

            if (profile.getKills() < kills) {
                throw new RuntimeException("Profile does not have enough kills to modify, aborting... (bug)");
            }

            profile.setKills(profile.getKills() - kills);
        });
    }

    public int getPlayerDeaths(@NonNull Player player) {
        return this.profileService.getDeaths(player);
    }

    public void takePlayerDeaths(@NonNull Player player, int deaths) {
        this.profileService.updateProfile(player, profile -> {

            if (profile.getDeaths() < deaths) {
                throw new RuntimeException("Profile does not have enough deaths to modify, aborting... (bug)");
            }

            profile.setDeaths(profile.getDeaths() - deaths);
        });
    }

    public int getPlayerCrystal(@NonNull Player player) {
        return this.getPlayerItem(player, this.pluginConfig.crystalItem);
    }

    public void takePlayerCrystal(@NonNull Player player, int amount) {
        this.takePlayerItem(player, this.pluginConfig.crystalItem, amount);
    }
}
