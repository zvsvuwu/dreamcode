package cc.dreamcode.boxshop;

import eu.okaeri.configs.schema.GenericsDeclaration;
import eu.okaeri.configs.serdes.DeserializationData;
import eu.okaeri.configs.serdes.ObjectSerializer;
import eu.okaeri.configs.serdes.SerializationData;
import lombok.NonNull;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

public class BoxShopProductSerializer implements ObjectSerializer<BoxShopProduct> {
    @Override
    public boolean supports(@NonNull Class<? super BoxShopProduct> type) {
        return BoxShopProduct.class.isAssignableFrom(type);
    }

    @Override
    public void serialize(@NonNull BoxShopProduct object, @NonNull SerializationData data, @NonNull GenericsDeclaration generics) {
        data.add("product-display-name", object.getDisplayName());
        data.add("product-display-item", object.getDisplayItem());
        data.add("product-actual-item", object.getActualItem());
        data.add("product-slot-in-menu", object.getSlotInMenu());
        if (!object.getBuyCostItem().getType().equals(Material.AIR)) {
            data.add("product-cost-item", object.getBuyCostItem());
        }
        if (object.getBuyCost() != -1.0D) {
            data.add("product-cost", object.getBuyCost());
        }
        data.add("product-selling", object.isSelling());
        data.add("product-sell-cost", object.getSellCost());
    }

    @Override
    public BoxShopProduct deserialize(@NonNull DeserializationData data, @NonNull GenericsDeclaration generics) {
        return new BoxShopProduct(
                data.get("product-display-name", String.class),
                data.get("product-display-item", ItemStack.class),
                data.get("product-actual-item", ItemStack.class),
                data.get("product-slot-in-menu", Integer.class),
                data.containsKey("product-cost-item")
                        ? data.get("product-cost-item", ItemStack.class)
                        : new ItemStack(Material.AIR),
                data.containsKey("product-cost")
                        ? data.get("product-cost", Double.class)
                        : -1.0D,
                data.get("product-selling", Boolean.class),
                data.get("product-sell-cost", Double.class)
        );
    }
}
