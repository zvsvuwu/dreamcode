package cc.dreamcode.boxshop;

import lombok.Data;
import org.bukkit.inventory.ItemStack;

@Data
public class BoxShopProduct {

    private final String displayName;
    private final ItemStack displayItem;

    private final ItemStack actualItem;
    private final int slotInMenu;

    // cost item jak jest w itemach
    private final ItemStack buyCostItem;
    private final double buyCost;

    private final boolean selling;
    private final double sellCost;

}
