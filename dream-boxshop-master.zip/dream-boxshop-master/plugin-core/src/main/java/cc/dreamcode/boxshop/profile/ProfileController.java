package cc.dreamcode.boxshop.profile;

import cc.dreamcode.boxshop.config.PluginConfig;
import eu.okaeri.injector.annotation.Inject;
import lombok.RequiredArgsConstructor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

import java.util.HashMap;
import java.util.Map;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class ProfileController implements Listener {

    private final PluginConfig pluginConfig;
    private final ProfileService profileService;

    private final Map<String, String> lastKill = new HashMap<>();

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {

        final Player victim = event.getEntity();
        final Player killer = victim.getKiller();
        if (killer == null) {
            return;
        }

        if (victim.getAddress() != null && killer.getAddress() != null &&
                !victim.getAddress().getAddress().equals(killer.getAddress().getAddress())) {

            if (!this.lastKill.getOrDefault(victim.getName(), "").equals(killer.getName())) {
                if (this.pluginConfig.ignoredRegions
                        .stream()
                        .noneMatch(region -> region.contains(victim.getLocation()))) {

                    this.lastKill.put(victim.getName(), killer.getName());
                    this.profileService.updateProfile(victim, profile ->
                            profile.setDeaths(profile.getDeaths() + 1));
                }
            }

            if (!this.lastKill.getOrDefault(killer.getName(), "").equals(victim.getName())) {
                if (this.pluginConfig.ignoredRegions
                        .stream()
                        .noneMatch(region -> region.contains(killer.getLocation()))) {

                    this.lastKill.put(killer.getName(), victim.getName());
                    this.profileService.updateProfile(killer, profile ->
                            profile.setKills(profile.getKills() + 1));
                }
            }
        }
    }
}
