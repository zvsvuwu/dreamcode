package cc.dreamcode.boxshop.command;

import cc.dreamcode.boxshop.BoxShopMenu;
import cc.dreamcode.boxshop.BoxShopPlugin;
import cc.dreamcode.boxshop.config.MessageConfig;
import cc.dreamcode.boxshop.config.PluginConfig;
import cc.dreamcode.command.CommandBase;
import cc.dreamcode.command.annotation.Async;
import cc.dreamcode.command.annotation.Command;
import cc.dreamcode.command.annotation.Executor;
import cc.dreamcode.command.annotation.Permission;
import cc.dreamcode.notice.adventure.BukkitNotice;
import cc.dreamcode.utilities.TimeUtil;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import eu.okaeri.configs.exception.OkaeriException;
import eu.okaeri.injector.annotation.Inject;
import eu.okaeri.tasker.core.Tasker;
import lombok.RequiredArgsConstructor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

@Command(name = "shop", aliases = "sklep")
@RequiredArgsConstructor(onConstructor_ = @Inject)
public class ShopCommand implements CommandBase {

    private final BoxShopPlugin boxShopPlugin;
    private final PluginConfig pluginConfig;
    private final MessageConfig messageConfig;
    private final Tasker tasker;

    @Executor(description = "Otwiera menu sklepu.")
    void menu(Player player) {
        final BoxShopMenu boxShopMenu = this.boxShopPlugin.createInstance(BoxShopMenu.class);
        boxShopMenu.build(player).open(player);
    }

    @Permission("dream-shop.setcrystal")
    @Executor(path = "setcrystal", description = "Ustawia nowy przedmiot krysztalu.")
    void setCrystal(Player player) {
        final ItemStack itemInHand = player.getInventory().getItemInMainHand();
        if (itemInHand.getType().equals(Material.AIR)) {
            this.messageConfig.noItemInHand.send(player);
            return;
        }

        this.tasker.newSharedChain("config-sync")
                .async(() -> {
                    this.pluginConfig.crystalItem = ItemBuilder.of(itemInHand)
                            .breakColors()
                            .toItemStack();
                    this.pluginConfig.save();

                    this.messageConfig.crystalSetted.send(player);
                })
                .execute();
    }

    @Async
    @Permission("dream-shop.reload")
    @Executor(path = "reload", description = "Przeladowuje konfiguracje.")
    BukkitNotice reload() {
        final long time = System.currentTimeMillis();

        try {
            this.messageConfig.load();
            this.pluginConfig.load();

            return this.messageConfig.reloaded
                    .with("time", TimeUtil.format(System.currentTimeMillis() - time));
        }
        catch (NullPointerException | OkaeriException e) {
            e.printStackTrace();

            return this.messageConfig.reloadError
                    .with("error", e.getMessage());
        }
    }
}
