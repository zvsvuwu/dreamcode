package cc.dreamcode.boxshop.profile;

import eu.okaeri.configs.annotation.CustomKey;
import eu.okaeri.persistence.document.Document;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.Duration;
import java.util.UUID;

@Data
@EqualsAndHashCode(callSuper = false)
public class Profile extends Document {

    @CustomKey("name")
    private String name;

    @CustomKey("time-playing")
    public Duration playingTime = Duration.ZERO;

    @CustomKey("kills")
    public int kills = 0;

    @CustomKey("deaths")
    public int deaths = 0;

    public UUID getUniqueId() {
        return this.getPath().toUUID();
    }

}
