package cc.dreamcode.boxshop;

import cc.dreamcode.boxshop.config.PluginConfig;
import cc.dreamcode.menu.adventure.BukkitMenuBuilder;
import cc.dreamcode.menu.adventure.base.BukkitMenu;
import cc.dreamcode.menu.adventure.setup.BukkitMenuPlayerSetup;
import cc.dreamcode.utilities.builder.MapBuilder;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import eu.okaeri.injector.annotation.Inject;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class BoxShopMenu implements BukkitMenuPlayerSetup {

    private final BoxShopPlugin boxShopPlugin;
    private final BoxShopService boxShopService;
    private final PluginConfig pluginConfig;

    @Override
    public BukkitMenu build(@NonNull HumanEntity humanEntity) {
        if (!(humanEntity instanceof Player)) {
            throw new RuntimeException("HumanEntity must be Player");
        }

        final Player player = (Player) humanEntity;

        final BukkitMenuBuilder menuBuilder = this.pluginConfig.menuBuilder;
        final BukkitMenu bukkitMenu = menuBuilder.buildEmpty();

        menuBuilder.getItems().forEach((slot, item) -> {

            if (this.pluginConfig.closeMenuSlot == slot) {
                bukkitMenu.setItem(slot, ItemBuilder.of(item).fixColors().toItemStack(), e ->
                        e.getWhoClicked().closeInventory());
                return;
            }

            bukkitMenu.setItem(slot, ItemBuilder.of(item)
                    .fixColors(new MapBuilder<String, Object>()
                            .put("playtime", this.boxShopService.getPlayerPlaytime(player).toMinutes() + "min")
                            .put("money", this.boxShopService.getPlayerMoney(player))
                            .put("kills", this.boxShopService.getPlayerKills(player))
                            .put("deaths", this.boxShopService.getPlayerDeaths(player))
                            .put("crystals", this.boxShopService.getPlayerCrystal(player))
                            .build())
                    .toItemStack());
        });

        this.pluginConfig.boxShopList.forEach(boxShop ->
            bukkitMenu.setItem(boxShop.getSlotInMenu(), ItemBuilder.of(boxShop.getDisplayItem())
                    .fixColors(new MapBuilder<String, Object>()
                            .put("playtime", this.boxShopService.getPlayerPlaytime(player).toMinutes() + "min")
                            .put("money", this.boxShopService.getPlayerMoney(player))
                            .put("kills", this.boxShopService.getPlayerKills(player))
                            .put("deaths", this.boxShopService.getPlayerDeaths(player))
                            .put("crystals", this.boxShopService.getPlayerCrystal(player))
                            .build())
                    .toItemStack(), e -> {

                final BoxShopSubMenu boxShopSubMenu = this.boxShopPlugin.createInstance(BoxShopSubMenu.class);
                boxShopSubMenu.setBoxShop(boxShop);

                boxShopSubMenu.build(e.getWhoClicked()).open(e.getWhoClicked());
            }));

        return bukkitMenu;
    }
}
