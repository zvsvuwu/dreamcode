package cc.dreamcode.boxshop;

import cc.dreamcode.boxshop.config.MessageConfig;
import cc.dreamcode.boxshop.config.PluginConfig;
import cc.dreamcode.menu.adventure.BukkitMenuBuilder;
import cc.dreamcode.menu.adventure.base.BukkitMenu;
import cc.dreamcode.menu.adventure.setup.BukkitMenuPlayerSetup;
import cc.dreamcode.utilities.builder.MapBuilder;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import eu.okaeri.injector.annotation.Inject;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;

import java.time.Duration;
import java.util.Locale;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class BoxShopMenuBuy implements BukkitMenuPlayerSetup {

    private final PluginConfig pluginConfig;
    private final MessageConfig messageConfig;
    private final BoxShopService boxShopService;

    @Setter private BoxShop boxShop;
    @Setter private BoxShopProduct boxShopProduct;

    @Setter private int multiplier = 1;

    @Override
    public BukkitMenu build(@NonNull HumanEntity humanEntity) {
        if (this.boxShop == null || this.boxShopProduct == null) {
            throw new RuntimeException("Field cannot be null");
        }

        if (!(humanEntity instanceof Player)) {
            throw new RuntimeException("HumanEntity must be Player");
        }

        final Player player = (Player) humanEntity;

        final BukkitMenuBuilder menuBuilder = this.pluginConfig.buyMenuBuilder;
        final BukkitMenu bukkitMenu = menuBuilder.buildEmpty();

        menuBuilder.getItems().forEach((slot, item) -> {

            if (this.pluginConfig.closeBuyMenuSlot == slot) {
                bukkitMenu.setItem(slot, ItemBuilder.of(item).fixColors().toItemStack(), event ->
                        event.getWhoClicked().closeInventory());
                return;
            }

            if (this.pluginConfig.buyButtonSlot == slot) {
                bukkitMenu.setItem(slot, ItemBuilder.of(item)
                        .fixColors(new MapBuilder<String, Object>()
                                .put("cost", this.boxShop.getProductCurrency().equals(ProductCurrency.PLAYER_PLAYTIME)
                                        ? Math.round(this.boxShopProduct.getBuyCost()) * this.multiplier + "min"
                                        : this.boxShop.getProductCurrency().equals(ProductCurrency.PLAYER_ITEM)
                                        ? this.boxShopProduct.getBuyCostItem().getItemMeta() != null && this.boxShopProduct.getBuyCostItem().getItemMeta().hasDisplayName()
                                                ? this.boxShopProduct.getBuyCostItem().getItemMeta().getDisplayName() + " " + this.boxShopProduct.getBuyCostItem().getAmount() * this.multiplier + "x"
                                                : this.boxShopProduct.getBuyCostItem().getType().name().toLowerCase(Locale.ROOT) + " " + this.boxShopProduct.getBuyCostItem().getAmount() * this.multiplier + "x"
                                        : this.boxShop.getProductCurrency().equals(ProductCurrency.PLAYER_KILLS)
                                        ? Math.round(this.boxShopProduct.getBuyCost()) * this.multiplier + " killi"
                                        : this.boxShop.getProductCurrency().equals(ProductCurrency.PLAYER_DEATHS)
                                        ? Math.round(this.boxShopProduct.getBuyCost()) * this.multiplier + " zabojstw"
                                        : this.boxShop.getProductCurrency().equals(ProductCurrency.PLAYER_CRYSTAL)
                                        ? Math.round(this.boxShopProduct.getBuyCost()) * this.multiplier + " odlamki"
                                        : this.boxShopProduct.getBuyCost() * this.multiplier + "$")
                                .put("multiplier", this.multiplier)
                                .put("playtime", this.boxShopService.getPlayerPlaytime(player).toMinutes() + "min")
                                .put("money", this.boxShopService.getPlayerMoney(player))
                                .put("kills", this.boxShopService.getPlayerKills(player))
                                .put("deaths", this.boxShopService.getPlayerDeaths(player))
                                .put("crystals", this.boxShopService.getPlayerCrystal(player))
                                .build())
                        .toItemStack(), event -> {
                    event.getWhoClicked().closeInventory();

                    switch (this.boxShop.getProductCurrency()) {
                        case PLAYER_MONEY: {

                            final double moneyToPay = this.boxShopProduct.getBuyCost() * this.multiplier;
                            if (this.boxShopService.getPlayerMoney(player) < moneyToPay) {
                                this.messageConfig.shotItemCannotAfford.send(player, new MapBuilder<String, Object>()
                                        .put("name", this.boxShopProduct.getDisplayName())
                                        .build());
                                return;
                            }

                            this.boxShopService.takePlayerMoney(player, moneyToPay);
                            for (int index = 0; index < this.multiplier; index++) {
                                player.getInventory().addItem(ItemBuilder.of(this.boxShopProduct.getActualItem())
                                        .fixColors()
                                        .toItemStack())
                                        .forEach((i, restItem) -> player.getWorld().dropItem(player.getLocation(), restItem));
                            }

                            this.messageConfig.shopItemPurchased.send(player, new MapBuilder<String, Object>()
                                    .put("name", this.boxShopProduct.getDisplayName())
                                    .build());
                            break;
                        }
                        case PLAYER_KILLS: {

                            final int killsToPay = (int) (this.boxShopProduct.getBuyCost() * this.multiplier);
                            if (this.boxShopService.getPlayerKills(player) < killsToPay) {
                                this.messageConfig.shotItemCannotAfford.send(player, new MapBuilder<String, Object>()
                                        .put("name", this.boxShopProduct.getDisplayName())
                                        .build());
                                return;
                            }

                            this.boxShopService.takePlayerKills(player, killsToPay);
                            for (int index = 0; index < this.multiplier; index++) {
                                player.getInventory().addItem(ItemBuilder.of(this.boxShopProduct.getActualItem())
                                                .fixColors()
                                                .toItemStack())
                                        .forEach((i, restItem) -> player.getWorld().dropItem(player.getLocation(), restItem));
                            }

                            this.messageConfig.shopItemPurchased.send(player, new MapBuilder<String, Object>()
                                    .put("name", this.boxShopProduct.getDisplayName())
                                    .build());
                            break;
                        }
                        case PLAYER_DEATHS: {

                            final int deathsToPay = (int) (this.boxShopProduct.getBuyCost() * this.multiplier);
                            if (this.boxShopService.getPlayerDeaths(player) < deathsToPay) {
                                this.messageConfig.shotItemCannotAfford.send(player, new MapBuilder<String, Object>()
                                        .put("name", this.boxShopProduct.getDisplayName())
                                        .build());
                                return;
                            }

                            this.boxShopService.takePlayerDeaths(player, deathsToPay);
                            for (int index = 0; index < this.multiplier; index++) {
                                player.getInventory().addItem(ItemBuilder.of(this.boxShopProduct.getActualItem())
                                                .fixColors()
                                                .toItemStack())
                                        .forEach((i, restItem) -> player.getWorld().dropItem(player.getLocation(), restItem));
                            }

                            this.messageConfig.shopItemPurchased.send(player, new MapBuilder<String, Object>()
                                    .put("name", this.boxShopProduct.getDisplayName())
                                    .build());
                            break;
                        }
                        case PLAYER_PLAYTIME: {

                            final Duration durationToPay = Duration.ofMinutes((long) (this.boxShopProduct.getBuyCost() * this.multiplier));
                            if (this.boxShopService.getPlayerPlaytime(player).toMinutes() < durationToPay.toMinutes()) {
                                this.messageConfig.shotItemCannotAfford.send(player, new MapBuilder<String, Object>()
                                        .put("name", this.boxShopProduct.getDisplayName())
                                        .build());
                                return;
                            }

                            this.boxShopService.takePlayerPlaytime(player, durationToPay);
                            for (int index = 0; index < this.multiplier; index++) {
                                player.getInventory().addItem(ItemBuilder.of(this.boxShopProduct.getActualItem())
                                                .fixColors()
                                                .toItemStack())
                                        .forEach((i, restItem) -> player.getWorld().dropItem(player.getLocation(), restItem));
                            }

                            this.messageConfig.shopItemPurchased.send(player, new MapBuilder<String, Object>()
                                    .put("name", this.boxShopProduct.getDisplayName())
                                    .build());
                            break;
                        }
                        case PLAYER_ITEM: {

                            final int itemsToPay = this.boxShopProduct.getBuyCostItem().getAmount() * this.multiplier;
                            if (this.boxShopService.getPlayerItem(player, this.boxShopProduct.getBuyCostItem()) < itemsToPay) {
                                this.messageConfig.shotItemCannotAfford.send(player, new MapBuilder<String, Object>()
                                        .put("name", this.boxShopProduct.getDisplayName())
                                        .build());
                                return;
                            }

                            this.boxShopService.takePlayerItem(player, this.boxShopProduct.getBuyCostItem(), itemsToPay);
                            for (int index = 0; index < this.multiplier; index++) {
                                player.getInventory().addItem(ItemBuilder.of(this.boxShopProduct.getActualItem())
                                                .fixColors()
                                                .toItemStack())
                                        .forEach((i, restItem) -> player.getWorld().dropItem(player.getLocation(), restItem));
                            }

                            this.messageConfig.shopItemPurchased.send(player, new MapBuilder<String, Object>()
                                    .put("name", this.boxShopProduct.getDisplayName())
                                    .build());
                            break;
                        }
                        case PLAYER_CRYSTAL: {

                            final int itemsToPay = (int) (this.boxShopProduct.getBuyCost() * this.multiplier);
                            if (this.boxShopService.getPlayerCrystal(player) < itemsToPay) {
                                this.messageConfig.shotItemCannotAfford.send(player, new MapBuilder<String, Object>()
                                        .put("name", this.boxShopProduct.getDisplayName())
                                        .build());
                                return;
                            }

                            this.boxShopService.takePlayerCrystal(player, itemsToPay);
                            for (int index = 0; index < this.multiplier; index++) {
                                player.getInventory().addItem(ItemBuilder.of(this.boxShopProduct.getActualItem())
                                                .fixColors()
                                                .toItemStack())
                                        .forEach((i, restItem) -> player.getWorld().dropItem(player.getLocation(), restItem));
                            }

                            this.messageConfig.shopItemPurchased.send(player, new MapBuilder<String, Object>()
                                    .put("name", this.boxShopProduct.getDisplayName())
                                    .build());
                            break;
                        }
                        default:
                            throw new RuntimeException("Could not found product currency: " + this.boxShop.getProductCurrency());
                    }
                });
                return;
            }

            bukkitMenu.setItem(slot, ItemBuilder.of(item)
                    .fixColors(new MapBuilder<String, Object>()
                            .put("playtime", this.boxShopService.getPlayerPlaytime(player).toMinutes() + "min")
                            .put("money", this.boxShopService.getPlayerMoney(player))
                            .put("kills", this.boxShopService.getPlayerKills(player))
                            .put("deaths", this.boxShopService.getPlayerDeaths(player))
                            .put("crystals", this.boxShopService.getPlayerCrystal(player))
                            .build())
                    .toItemStack());
        });

        bukkitMenu.setItem(this.pluginConfig.buyPreviewSlot, ItemBuilder.of(this.boxShopProduct.getActualItem())
                .fixColors()
                .toItemStack());

        this.pluginConfig.addItemSlots.forEach((slot, increment) ->
            bukkitMenu.setItem(slot, ItemBuilder.of(this.pluginConfig.addDisplayItem)
                    .fixColors(new MapBuilder<String, Object>()
                            .put("amount", increment)
                            .build())
                    .toItemStack(), event -> {

                this.multiplier = this.multiplier + increment;
                if (this.multiplier > 64) {
                    this.multiplier = 64;
                }

                bukkitMenu.setItem(this.pluginConfig.buyPreviewSlot, ItemBuilder.of(this.boxShopProduct.getActualItem())
                        .setAmount(this.multiplier)
                        .fixColors()
                        .toItemStack());

                bukkitMenu.setItem(this.pluginConfig.buyButtonSlot, ItemBuilder.of(menuBuilder.getItems().get(this.pluginConfig.buyButtonSlot))
                        .fixColors(new MapBuilder<String, Object>()
                                .put("cost", this.boxShop.getProductCurrency().equals(ProductCurrency.PLAYER_PLAYTIME)
                                        ? Math.round(this.boxShopProduct.getBuyCost()) * this.multiplier + "min"
                                        : this.boxShop.getProductCurrency().equals(ProductCurrency.PLAYER_ITEM)
                                        ? this.boxShopProduct.getBuyCostItem().getItemMeta() != null && this.boxShopProduct.getBuyCostItem().getItemMeta().hasDisplayName()
                                                ? this.boxShopProduct.getBuyCostItem().getItemMeta().getDisplayName() + " " + this.boxShopProduct.getBuyCostItem().getAmount() * this.multiplier + "x"
                                                : this.boxShopProduct.getBuyCostItem().getType().name().toLowerCase(Locale.ROOT) + " " + this.boxShopProduct.getBuyCostItem().getAmount() * this.multiplier + "x"
                                        : this.boxShop.getProductCurrency().equals(ProductCurrency.PLAYER_KILLS)
                                        ? Math.round(this.boxShopProduct.getBuyCost()) * this.multiplier + " killi"
                                        : this.boxShop.getProductCurrency().equals(ProductCurrency.PLAYER_DEATHS)
                                        ? Math.round(this.boxShopProduct.getBuyCost()) * this.multiplier + " zabojstw"
                                        : this.boxShop.getProductCurrency().equals(ProductCurrency.PLAYER_CRYSTAL)
                                        ? Math.round(this.boxShopProduct.getBuyCost()) * this.multiplier + " odlamki"
                                        : this.boxShopProduct.getBuyCost() * this.multiplier + "$")
                                .put("multiplier", this.multiplier)
                                .put("playtime", this.boxShopService.getPlayerPlaytime(player).toMinutes() + "min")
                                .put("money", this.boxShopService.getPlayerMoney(player))
                                .put("kills", this.boxShopService.getPlayerKills(player))
                                .put("deaths", this.boxShopService.getPlayerDeaths(player))
                                .put("crystals", this.boxShopService.getPlayerCrystal(player))
                                .build())
                        .toItemStack());
            }));

        this.pluginConfig.removeItemSlots.forEach((slot, increment) ->
                bukkitMenu.setItem(slot, ItemBuilder.of(this.pluginConfig.removeDisplayItem)
                        .fixColors(new MapBuilder<String, Object>()
                                .put("amount", increment)
                                .build())
                        .toItemStack(), event -> {

                    this.multiplier = this.multiplier - increment;
                    if (this.multiplier < 1) {
                        this.multiplier = 1;
                    }

                    bukkitMenu.setItem(this.pluginConfig.buyPreviewSlot, ItemBuilder.of(this.boxShopProduct.getActualItem())
                            .setAmount(this.multiplier)
                            .fixColors()
                            .toItemStack());

                    bukkitMenu.setItem(this.pluginConfig.buyButtonSlot, ItemBuilder.of(menuBuilder.getItems().get(this.pluginConfig.buyButtonSlot))
                            .fixColors(new MapBuilder<String, Object>()
                                    .put("cost", this.boxShop.getProductCurrency().equals(ProductCurrency.PLAYER_PLAYTIME)
                                            ? Math.round(this.boxShopProduct.getBuyCost()) * this.multiplier + "min"
                                            : this.boxShop.getProductCurrency().equals(ProductCurrency.PLAYER_ITEM)
                                            ? this.boxShopProduct.getBuyCostItem().getItemMeta() != null && this.boxShopProduct.getBuyCostItem().getItemMeta().hasDisplayName()
                                                    ? this.boxShopProduct.getBuyCostItem().getItemMeta().getDisplayName() + " " + this.boxShopProduct.getBuyCostItem().getAmount() * this.multiplier + "x"
                                                    : this.boxShopProduct.getBuyCostItem().getType().name().toLowerCase(Locale.ROOT) + " " + this.boxShopProduct.getBuyCostItem().getAmount() * this.multiplier + "x"
                                            : this.boxShop.getProductCurrency().equals(ProductCurrency.PLAYER_KILLS)
                                            ? Math.round(this.boxShopProduct.getBuyCost()) * this.multiplier + " killi"
                                            : this.boxShop.getProductCurrency().equals(ProductCurrency.PLAYER_DEATHS)
                                            ? Math.round(this.boxShopProduct.getBuyCost()) * this.multiplier + " zabojstw"
                                            : this.boxShop.getProductCurrency().equals(ProductCurrency.PLAYER_CRYSTAL)
                                            ? Math.round(this.boxShopProduct.getBuyCost()) * this.multiplier + " odlamki"
                                            : this.boxShopProduct.getBuyCost() * this.multiplier + "$")
                                    .put("multiplier", this.multiplier)
                                    .put("playtime", this.boxShopService.getPlayerPlaytime(player).toMinutes() + "min")
                                    .put("money", this.boxShopService.getPlayerMoney(player))
                                    .put("kills", this.boxShopService.getPlayerKills(player))
                                    .put("deaths", this.boxShopService.getPlayerDeaths(player))
                                    .put("crystals", this.boxShopService.getPlayerCrystal(player))
                                    .build())
                            .toItemStack());
                }));

        return bukkitMenu;
    }
}
