package cc.dreamcode.boxshop;

import cc.dreamcode.menu.adventure.BukkitMenuBuilder;
import lombok.Data;
import org.bukkit.inventory.ItemStack;

import java.util.List;

@Data
public class BoxShop {

    private final String name;

    private final int slotInMenu;
    private final ItemStack displayItem;

    private final BukkitMenuBuilder menuBuilder;
    private final int backToMainMenuSlot;

    private final ProductCurrency productCurrency;
    private final List<BoxShopProduct> boxShopProductList;

}
