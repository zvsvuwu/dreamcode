package cc.dreamcode.boxshop.profile;

import lombok.NonNull;

import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.WeakHashMap;

public class ProfileCache {

    private final Map<UUID, Profile> profileMap = new WeakHashMap<>();

    public Optional<Profile> getProfile(@NonNull UUID uuid) {
        return this.profileMap.entrySet()
                .stream()
                .filter(entry -> entry.getKey().equals(uuid))
                .map(Map.Entry::getValue)
                .findAny();
    }

    public void update(@NonNull Profile profile) {
        this.profileMap.put(profile.getUniqueId(), profile);
    }
}
