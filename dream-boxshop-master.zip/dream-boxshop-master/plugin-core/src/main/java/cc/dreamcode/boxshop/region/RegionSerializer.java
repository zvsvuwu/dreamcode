package cc.dreamcode.boxshop.region;

import eu.okaeri.configs.schema.GenericsDeclaration;
import eu.okaeri.configs.serdes.DeserializationData;
import eu.okaeri.configs.serdes.ObjectSerializer;
import eu.okaeri.configs.serdes.SerializationData;
import lombok.NonNull;
import org.bukkit.Location;

public class RegionSerializer implements ObjectSerializer<Region> {
    @Override
    public boolean supports(@NonNull Class<? super Region> type) {
        return Region.class.isAssignableFrom(type);
    }

    @Override
    public void serialize(@NonNull Region object, @NonNull SerializationData data, @NonNull GenericsDeclaration generics) {
        data.add("first-corner", object.getFirstCorner(), Location.class);
        data.add("second-corner", object.getSecondCorner(), Location.class);
    }

    @Override
    public Region deserialize(@NonNull DeserializationData data, @NonNull GenericsDeclaration generics) {
        return new Region(
                data.get("first-corner", Location.class),
                data.get("second-corner", Location.class)
        );
    }
}
