package cc.dreamcode.boxshop;

import cc.dreamcode.menu.adventure.BukkitMenuBuilder;
import eu.okaeri.configs.schema.GenericsDeclaration;
import eu.okaeri.configs.serdes.DeserializationData;
import eu.okaeri.configs.serdes.ObjectSerializer;
import eu.okaeri.configs.serdes.SerializationData;
import lombok.NonNull;
import org.bukkit.inventory.ItemStack;

public class BoxShopSerializer implements ObjectSerializer<BoxShop> {
    @Override
    public boolean supports(@NonNull Class<? super BoxShop> type) {
        return BoxShop.class.isAssignableFrom(type);
    }

    @Override
    public void serialize(@NonNull BoxShop object, @NonNull SerializationData data, @NonNull GenericsDeclaration generics) {
        data.add("shop-name", object.getName());
        data.add("shop-slot-in-menu", object.getSlotInMenu());
        data.add("shop-display-item", object.getDisplayItem());
        data.add("shop-menu-builder", object.getMenuBuilder());
        data.add("shop-back-to-main-menu-slot", object.getBackToMainMenuSlot());
        data.add("shop-product-currency", object.getProductCurrency());
        data.add("shop-product-list", object.getBoxShopProductList());
    }

    @Override
    public BoxShop deserialize(@NonNull DeserializationData data, @NonNull GenericsDeclaration generics) {
        return new BoxShop(
                data.get("shop-name", String.class),
                data.get("shop-slot-in-menu", Integer.class),
                data.get("shop-display-item", ItemStack.class),
                data.get("shop-menu-builder", BukkitMenuBuilder.class),
                data.get("shop-back-to-main-menu-slot", Integer.class),
                data.get("shop-product-currency", ProductCurrency.class),
                data.getAsList("shop-product-list", BoxShopProduct.class)
        );
    }
}
