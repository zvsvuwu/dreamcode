package cc.dreamcode.boxshop;

public enum ProductCurrency {
    PLAYER_PLAYTIME,
    PLAYER_ITEM,
    PLAYER_MONEY,
    PLAYER_KILLS,
    PLAYER_DEATHS,
    PLAYER_CRYSTAL
}
