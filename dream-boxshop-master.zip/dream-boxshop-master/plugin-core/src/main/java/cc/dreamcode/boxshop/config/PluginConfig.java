package cc.dreamcode.boxshop.config;

import cc.dreamcode.boxshop.BoxShop;
import cc.dreamcode.boxshop.BoxShopProduct;
import cc.dreamcode.boxshop.ProductCurrency;
import cc.dreamcode.boxshop.region.Region;
import cc.dreamcode.menu.adventure.BukkitMenuBuilder;
import cc.dreamcode.menu.utilities.MenuUtil;
import cc.dreamcode.platform.bukkit.component.configuration.Configuration;
import cc.dreamcode.platform.persistence.StorageConfig;
import cc.dreamcode.utilities.builder.ListBuilder;
import cc.dreamcode.utilities.builder.MapBuilder;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import com.cryptomorin.xseries.XMaterial;
import eu.okaeri.configs.OkaeriConfig;
import eu.okaeri.configs.annotation.Comment;
import eu.okaeri.configs.annotation.CustomKey;
import eu.okaeri.configs.annotation.Header;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.Map;

@Configuration(child = "config.yml")
@Header("## Dream-BoxShop (Main-Config) ##")
public class PluginConfig extends OkaeriConfig {

    @Comment
    @Comment("Debug pokazuje dodatkowe informacje do konsoli. Lepiej wylaczyc. :P")
    @CustomKey("debug")
    public boolean debug = true;

    @Comment
    @Comment("Ponizej znajduja sie dane do logowania bazy danych:")
    @CustomKey("storage-config")
    public StorageConfig storageConfig = new StorageConfig("dreamboxshop");

    @Comment
    @Comment("Jakie regiony maja byc ignorowane podczas nabijania statystyk?")
    @CustomKey("ignored-regions")
    public List<Region> ignoredRegions = ListBuilder.of(
            new Region(
                    new Location(Bukkit.getWorlds().get(0), 25.0D, 0.0D, 25.0D),
                    new Location(Bukkit.getWorlds().get(0), -25.0D, 255.0D, -25.0D)
            ),
            new Region(
                    new Location(Bukkit.getWorlds().get(0), 50.0D, 0.0D, 50.0D),
                    new Location(Bukkit.getWorlds().get(0), 45.0D, 255.0D, 45.0D)
            )
    );

    @Comment
    @Comment("Jak ma wygladac glowne menu od sklepu?")
    @CustomKey("menu-builder")
    public BukkitMenuBuilder menuBuilder = new BukkitMenuBuilder("&8[&bM&8] Sklep", 5, new MapBuilder<Integer, ItemStack>()
            .put(MenuUtil.countSlot(1, 5), ItemBuilder.of(XMaterial.OAK_SIGN.parseItem())
                    .setName("&7Sklep serwera")
                    .setLore("&7W tym sklepie zakupisz rozne przedmioty",
                            "&7w sklepach &fo roznych walutach&7.",
                            "",
                            "&7Przed zakupem sprawdz &cczy zaplacisz&7.")
                    .toItemStack())
            .put(MenuUtil.countSlot(5, 5), ItemBuilder.of(XMaterial.BARRIER.parseItem())
                    .setName("&cWyjdz z menu")
                    .toItemStack())
            .build());

    @Comment
    @Comment("Pod jakim slotem ma sie znajdowac przycisk od wychodzenia z menu?")
    @CustomKey("close-menu-slot")
    public int closeMenuSlot = MenuUtil.countSlot(5, 5);

    @Comment
    @Comment("Konfiguracja sklepu.")
    @Comment("Ponizej znajduja sie wszystkie ustawienia od poszczegolnych sklepow.")
    @Comment("Nowy sklep tworzysz po przez utworzenie go w tej liscie.")
    @Comment("Przy kopiowaniu wszystkie parametry powinny byc zachowane.")
    @Comment("Czas w sklepie za czas podaje sie w minutach grania!")
    @CustomKey("shop-shop-list")
    public List<BoxShop> boxShopList = ListBuilder.of(
            new BoxShop(
                    "Sklep za czas",
                    MenuUtil.countSlot(3, 2),
                    ItemBuilder.of(XMaterial.CLOCK.parseItem())
                            .setName("&7Sklep za &6czas gry")
                            .setLore("&8» &7Aktualnie posiadasz: &f{playtime}",
                                    "&8» &7Kliknij &fLPM&7, aby przejsc do sklepu.")
                            .toItemStack(),
                    new BukkitMenuBuilder("&8[&bM&8] Sklep za czas", 5, new MapBuilder<Integer, ItemStack>()
                            .put(MenuUtil.countSlot(1, 5), ItemBuilder.of(XMaterial.OAK_SIGN.parseItem())
                                    .setName("&7Sklep za czas")
                                    .setLore("&7W tym sklepie zakupisz rozne przedmioty",
                                            "&7i zaplacisz za nie &fw przegranym czasie gry&7.",
                                            "",
                                            "&8» &7Aktualnie posiadasz: &f{playtime}")
                                    .toItemStack())
                            .put(MenuUtil.countSlot(5, 5), ItemBuilder.of(XMaterial.BARRIER.parseItem())
                                    .setName("&cWyjdz z menu")
                                    .toItemStack())
                            .build()),
                    MenuUtil.countSlot(5, 5),
                    ProductCurrency.PLAYER_PLAYTIME,
                    ListBuilder.of(
                            new BoxShopProduct(
                                    "&4Smoczy helm",
                                    ItemBuilder.of(XMaterial.DIAMOND_HELMET.parseItem())
                                            .setName("&4Smoczy helm")
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    ItemBuilder.of(XMaterial.DIAMOND_HELMET.parseItem())
                                            .setName("&4Smoczy helm")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    MenuUtil.countSlot(3, 2),
                                    new ItemStack(Material.AIR),
                                    20.0D,
                                    false,
                                    0.0D
                            ),
                            new BoxShopProduct(
                                    "&4Smocza klata",
                                    ItemBuilder.of(XMaterial.DIAMOND_CHESTPLATE.parseItem())
                                            .setName("&4Smoczy klata")
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    ItemBuilder.of(XMaterial.DIAMOND_CHESTPLATE.parseItem())
                                            .setName("&4Smoczy klata")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    MenuUtil.countSlot(3, 3),
                                    new ItemStack(Material.AIR),
                                    50.0D,
                                    false,
                                    0.0D
                            ),
                            new BoxShopProduct(
                                    "&4Smocze spodnie",
                                    ItemBuilder.of(XMaterial.DIAMOND_LEGGINGS.parseItem())
                                            .setName("&4Smocze spodnie")
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    ItemBuilder.of(XMaterial.DIAMOND_LEGGINGS.parseItem())
                                            .setName("&4Smoczy spodnie")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    MenuUtil.countSlot(3, 4),
                                    new ItemStack(Material.AIR),
                                    40.0D,
                                    false,
                                    0.0D
                            ),
                            new BoxShopProduct(
                                    "&4Smocze buty",
                                    ItemBuilder.of(XMaterial.DIAMOND_BOOTS.parseItem())
                                            .setName("&4Smocze buty")
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    ItemBuilder.of(XMaterial.DIAMOND_BOOTS.parseItem())
                                            .setName("&4Smoczy buty")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    MenuUtil.countSlot(3, 5),
                                    new ItemStack(Material.AIR),
                                    30.0D,
                                    false,
                                    0.0D
                            ),
                            new BoxShopProduct(
                                    "&9Diamenty",
                                    ItemBuilder.of(XMaterial.DIAMOND.parseItem())
                                            .setName("&9Diamenty")
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "&8» &7Koszt sprzedazy: &f{sell}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.",
                                                    "&8» &7Kliknij &fPPM&7, aby sprzedac.",
                                                    "&8» &7Kliknij &fPPM + SHIFT&7, aby sprzedac wszystko.")
                                            .toItemStack(),
                                    XMaterial.DIAMOND.parseItem(),
                                    MenuUtil.countSlot(3, 6),
                                    new ItemStack(Material.AIR),
                                    3.12D,
                                    true,
                                    2.34D
                            ),
                            new BoxShopProduct(
                                    "&2Emeraldy",
                                    ItemBuilder.of(XMaterial.EMERALD.parseItem())
                                            .setName("&2Emeraldy")
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "&8» &7Koszt sprzedazy: &f{sell}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.",
                                                    "&8» &7Kliknij &fPPM&7, aby sprzedac.",
                                                    "&8» &7Kliknij &fPPM + SHIFT&7, aby sprzedac wszystko.")
                                            .toItemStack(),
                                    XMaterial.EMERALD.parseItem(),
                                    MenuUtil.countSlot(3, 7),
                                    new ItemStack(Material.AIR),
                                    4.32D,
                                    true,
                                    3.64D
                            ),
                            new BoxShopProduct(
                                    "&5Obsydian 64x",
                                    ItemBuilder.of(XMaterial.OBSIDIAN.parseItem())
                                            .setName("&5Obsydian")
                                            .setAmount(64)
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "&8» &7Koszt sprzedazy: &f{sell}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.",
                                                    "&8» &7Kliknij &fPPM&7, aby sprzedac.",
                                                    "&8» &7Kliknij &fPPM + SHIFT&7, aby sprzedac wszystko.")
                                            .toItemStack(),
                                    ItemBuilder.of(XMaterial.OBSIDIAN.parseItem())
                                            .setAmount(64)
                                            .toItemStack(),
                                    MenuUtil.countSlot(3, 8),
                                    new ItemStack(Material.AIR),
                                    1.45D,
                                    true,
                                    0.54D
                            )
                    )
            ),
            new BoxShop(
                    "Sklep za itemy",
                    MenuUtil.countSlot(3, 3),
                    ItemBuilder.of(XMaterial.DIAMOND.parseItem())
                            .setName("&7Sklep za &6itemy")
                            .setLore("&8» &7Kliknij &fLPM&7, aby przejsc do sklepu.")
                            .toItemStack(),
                    new BukkitMenuBuilder("&8[&bM&8] Sklep za itemy", 5, new MapBuilder<Integer, ItemStack>()
                            .put(MenuUtil.countSlot(1, 5), ItemBuilder.of(XMaterial.OAK_SIGN.parseItem())
                                    .setName("&7Sklep za itemy")
                                    .setLore("&7W tym sklepie zakupisz rozne przedmioty",
                                            "&7i zaplacisz za nie &fprzedmiotach&7.")
                                    .toItemStack())
                            .put(MenuUtil.countSlot(5, 5), ItemBuilder.of(XMaterial.BARRIER.parseItem())
                                    .setName("&cWyjdz z menu")
                                    .toItemStack())
                            .build()),
                    MenuUtil.countSlot(5, 5),
                    ProductCurrency.PLAYER_ITEM,
                    ListBuilder.of(
                            new BoxShopProduct(
                                    "&4Smoczy helm",
                                    ItemBuilder.of(XMaterial.DIAMOND_HELMET.parseItem())
                                            .setName("&4Smoczy helm")
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    ItemBuilder.of(XMaterial.DIAMOND_HELMET.parseItem())
                                            .setName("&4Smoczy helm")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    MenuUtil.countSlot(3, 2),
                                    new ItemStack(Material.DIRT, 20),
                                    0.0D,
                                    false,
                                    0.0D
                            ),
                            new BoxShopProduct(
                                    "&4Smocza klata",
                                    ItemBuilder.of(XMaterial.DIAMOND_CHESTPLATE.parseItem())
                                            .setName("&4Smoczy klata")
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    ItemBuilder.of(XMaterial.DIAMOND_CHESTPLATE.parseItem())
                                            .setName("&4Smoczy klata")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    MenuUtil.countSlot(3, 3),
                                    new ItemStack(Material.DIRT, 50),
                                    0.0D,
                                    false,
                                    0.0D
                            ),
                            new BoxShopProduct(
                                    "&4Smocze spodnie",
                                    ItemBuilder.of(XMaterial.DIAMOND_LEGGINGS.parseItem())
                                            .setName("&4Smocze spodnie")
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    ItemBuilder.of(XMaterial.DIAMOND_LEGGINGS.parseItem())
                                            .setName("&4Smoczy spodnie")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    MenuUtil.countSlot(3, 4),
                                    new ItemStack(Material.DIRT, 40),
                                    0.0D,
                                    false,
                                    0.0D
                            ),
                            new BoxShopProduct(
                                    "&4Smocze buty",
                                    ItemBuilder.of(XMaterial.DIAMOND_BOOTS.parseItem())
                                            .setName("&4Smocze buty")
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    ItemBuilder.of(XMaterial.DIAMOND_BOOTS.parseItem())
                                            .setName("&4Smoczy buty")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    MenuUtil.countSlot(3, 5),
                                    new ItemStack(Material.DIRT, 30),
                                    0.0D,
                                    false,
                                    0.0D
                            ),
                            new BoxShopProduct(
                                    "&9Diamenty",
                                    ItemBuilder.of(XMaterial.DIAMOND.parseItem())
                                            .setName("&9Diamenty")
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "&8» &7Koszt sprzedazy: &f{sell}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.",
                                                    "&8» &7Kliknij &fPPM&7, aby sprzedac.",
                                                    "&8» &7Kliknij &fPPM + SHIFT&7, aby sprzedac wszystko.")
                                            .toItemStack(),
                                    XMaterial.DIAMOND.parseItem(),
                                    MenuUtil.countSlot(3, 6),
                                    new ItemStack(Material.DIRT, 3),
                                    0.0D,
                                    true,
                                    2.34D
                            ),
                            new BoxShopProduct(
                                    "&2Emeraldy",
                                    ItemBuilder.of(XMaterial.EMERALD.parseItem())
                                            .setName("&2Emeraldy")
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "&8» &7Koszt sprzedazy: &f{sell}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.",
                                                    "&8» &7Kliknij &fPPM&7, aby sprzedac.",
                                                    "&8» &7Kliknij &fPPM + SHIFT&7, aby sprzedac wszystko.")
                                            .toItemStack(),
                                    XMaterial.EMERALD.parseItem(),
                                    MenuUtil.countSlot(3, 7),
                                    new ItemStack(Material.DIRT, 40),
                                    0.0D,
                                    true,
                                    3.64D
                            ),
                            new BoxShopProduct(
                                    "&5Obsydian 64x",
                                    ItemBuilder.of(XMaterial.OBSIDIAN.parseItem())
                                            .setName("&5Obsydian")
                                            .setAmount(64)
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "&8» &7Koszt sprzedazy: &f{sell}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.",
                                                    "&8» &7Kliknij &fPPM&7, aby sprzedac.",
                                                    "&8» &7Kliknij &fPPM + SHIFT&7, aby sprzedac wszystko.")
                                            .toItemStack(),
                                    ItemBuilder.of(XMaterial.OBSIDIAN.parseItem())
                                            .setAmount(64)
                                            .toItemStack(),
                                    MenuUtil.countSlot(3, 8),
                                    new ItemStack(Material.DIRT, 10),
                                    0.0D,
                                    true,
                                    0.54D
                            )
                    )
            ),
            new BoxShop(
                    "Sklep za krysztaly",
                    MenuUtil.countSlot(3, 4),
                    ItemBuilder.of(XMaterial.PRISMARINE_SHARD.parseItem())
                            .setName("&7Sklep za &bkrysztaly")
                            .setLore("&8» &7Aktualnie posiadasz: &f{crystals} odlamki",
                                    "&8» &7Kliknij &fLPM&7, aby przejsc do sklepu.")
                            .toItemStack(),
                    new BukkitMenuBuilder("&8[&bM&8] Sklep za krysztaly", 5, new MapBuilder<Integer, ItemStack>()
                            .put(MenuUtil.countSlot(1, 5), ItemBuilder.of(XMaterial.OAK_SIGN.parseItem())
                                    .setName("&7Sklep za krysztaly")
                                    .setLore("&7W tym sklepie zakupisz rozne przedmioty",
                                            "&7i zaplacisz za nie &bkrysztalach&7.",
                                            "",
                                            "&8» &7Aktualnie posiadasz: &f{crystals} odlamki")
                                    .toItemStack())
                            .put(MenuUtil.countSlot(5, 5), ItemBuilder.of(XMaterial.BARRIER.parseItem())
                                    .setName("&cWyjdz z menu")
                                    .toItemStack())
                            .build()),
                    MenuUtil.countSlot(5, 5),
                    ProductCurrency.PLAYER_CRYSTAL,
                    ListBuilder.of(
                            new BoxShopProduct(
                                    "&4Smoczy helm",
                                    ItemBuilder.of(XMaterial.DIAMOND_HELMET.parseItem())
                                            .setName("&4Smoczy helm")
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    ItemBuilder.of(XMaterial.DIAMOND_HELMET.parseItem())
                                            .setName("&4Smoczy helm")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    MenuUtil.countSlot(3, 2),
                                    new ItemStack(Material.AIR),
                                    20.0D,
                                    false,
                                    0.0D
                            ),
                            new BoxShopProduct(
                                    "&4Smocza klata",
                                    ItemBuilder.of(XMaterial.DIAMOND_CHESTPLATE.parseItem())
                                            .setName("&4Smoczy klata")
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    ItemBuilder.of(XMaterial.DIAMOND_CHESTPLATE.parseItem())
                                            .setName("&4Smoczy klata")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    MenuUtil.countSlot(3, 3),
                                    new ItemStack(Material.AIR),
                                    50.0D,
                                    false,
                                    0.0D
                            ),
                            new BoxShopProduct(
                                    "&4Smocze spodnie",
                                    ItemBuilder.of(XMaterial.DIAMOND_LEGGINGS.parseItem())
                                            .setName("&4Smocze spodnie")
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    ItemBuilder.of(XMaterial.DIAMOND_LEGGINGS.parseItem())
                                            .setName("&4Smoczy spodnie")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    MenuUtil.countSlot(3, 4),
                                    new ItemStack(Material.AIR),
                                    40.0D,
                                    false,
                                    0.0D
                            ),
                            new BoxShopProduct(
                                    "&4Smocze buty",
                                    ItemBuilder.of(XMaterial.DIAMOND_BOOTS.parseItem())
                                            .setName("&4Smocze buty")
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    ItemBuilder.of(XMaterial.DIAMOND_BOOTS.parseItem())
                                            .setName("&4Smoczy buty")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    MenuUtil.countSlot(3, 5),
                                    new ItemStack(Material.AIR),
                                    30.0D,
                                    false,
                                    0.0D
                            ),
                            new BoxShopProduct(
                                    "&9Diamenty",
                                    ItemBuilder.of(XMaterial.DIAMOND.parseItem())
                                            .setName("&9Diamenty")
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "&8» &7Koszt sprzedazy: &f{sell}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.",
                                                    "&8» &7Kliknij &fPPM&7, aby sprzedac.",
                                                    "&8» &7Kliknij &fPPM + SHIFT&7, aby sprzedac wszystko.")
                                            .toItemStack(),
                                    XMaterial.DIAMOND.parseItem(),
                                    MenuUtil.countSlot(3, 6),
                                    new ItemStack(Material.AIR),
                                    3.12D,
                                    true,
                                    2.34D
                            ),
                            new BoxShopProduct(
                                    "&2Emeraldy",
                                    ItemBuilder.of(XMaterial.EMERALD.parseItem())
                                            .setName("&2Emeraldy")
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "&8» &7Koszt sprzedazy: &f{sell}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.",
                                                    "&8» &7Kliknij &fPPM&7, aby sprzedac.",
                                                    "&8» &7Kliknij &fPPM + SHIFT&7, aby sprzedac wszystko.")
                                            .toItemStack(),
                                    XMaterial.EMERALD.parseItem(),
                                    MenuUtil.countSlot(3, 7),
                                    new ItemStack(Material.AIR),
                                    4.32D,
                                    true,
                                    3.64D
                            ),
                            new BoxShopProduct(
                                    "&5Obsydian 64x",
                                    ItemBuilder.of(XMaterial.OBSIDIAN.parseItem())
                                            .setName("&5Obsydian")
                                            .setAmount(64)
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "&8» &7Koszt sprzedazy: &f{sell}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.",
                                                    "&8» &7Kliknij &fPPM&7, aby sprzedac.",
                                                    "&8» &7Kliknij &fPPM + SHIFT&7, aby sprzedac wszystko.")
                                            .toItemStack(),
                                    ItemBuilder.of(XMaterial.OBSIDIAN.parseItem())
                                            .setAmount(64)
                                            .toItemStack(),
                                    MenuUtil.countSlot(3, 8),
                                    new ItemStack(Material.AIR),
                                    1.45D,
                                    true,
                                    0.54D
                            )
                    )
            ),
            new BoxShop(
                    "Sklep za kase",
                    MenuUtil.countSlot(3, 6),
                    ItemBuilder.of(XMaterial.EMERALD.parseItem())
                            .setName("&7Sklep za &akase")
                            .setLore("&8» &7Aktualnie posiadasz: &f{money}$",
                                    "&8» &7Kliknij &fLPM&7, aby przejsc do sklepu.")
                            .toItemStack(),
                    new BukkitMenuBuilder("&8[&bM&8] Sklep za kase", 5, new MapBuilder<Integer, ItemStack>()
                            .put(MenuUtil.countSlot(1, 5), ItemBuilder.of(XMaterial.OAK_SIGN.parseItem())
                                    .setName("&7Sklep za kase")
                                    .setLore("&7W tym sklepie zakupisz rozne przedmioty",
                                            "&7i zaplacisz za nie &akasie&7.",
                                            "",
                                            "&8» &7Aktualnie posiadasz: &f{money}$")
                                    .toItemStack())
                            .put(MenuUtil.countSlot(5, 5), ItemBuilder.of(XMaterial.BARRIER.parseItem())
                                    .setName("&cWyjdz z menu")
                                    .toItemStack())
                            .build()),
                    MenuUtil.countSlot(5, 5),
                    ProductCurrency.PLAYER_MONEY,
                    ListBuilder.of(
                            new BoxShopProduct(
                                    "&4Smoczy helm",
                                    ItemBuilder.of(XMaterial.DIAMOND_HELMET.parseItem())
                                            .setName("&4Smoczy helm")
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    ItemBuilder.of(XMaterial.DIAMOND_HELMET.parseItem())
                                            .setName("&4Smoczy helm")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    MenuUtil.countSlot(3, 2),
                                    new ItemStack(Material.AIR),
                                    20.0D,
                                    false,
                                    0.0D
                            ),
                            new BoxShopProduct(
                                    "&4Smocza klata",
                                    ItemBuilder.of(XMaterial.DIAMOND_CHESTPLATE.parseItem())
                                            .setName("&4Smoczy klata")
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    ItemBuilder.of(XMaterial.DIAMOND_CHESTPLATE.parseItem())
                                            .setName("&4Smoczy klata")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    MenuUtil.countSlot(3, 3),
                                    new ItemStack(Material.AIR),
                                    50.0D,
                                    false,
                                    0.0D
                            ),
                            new BoxShopProduct(
                                    "&4Smocze spodnie",
                                    ItemBuilder.of(XMaterial.DIAMOND_LEGGINGS.parseItem())
                                            .setName("&4Smocze spodnie")
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    ItemBuilder.of(XMaterial.DIAMOND_LEGGINGS.parseItem())
                                            .setName("&4Smoczy spodnie")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    MenuUtil.countSlot(3, 4),
                                    new ItemStack(Material.AIR),
                                    40.0D,
                                    false,
                                    0.0D
                            ),
                            new BoxShopProduct(
                                    "&4Smocze buty",
                                    ItemBuilder.of(XMaterial.DIAMOND_BOOTS.parseItem())
                                            .setName("&4Smocze buty")
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    ItemBuilder.of(XMaterial.DIAMOND_BOOTS.parseItem())
                                            .setName("&4Smoczy buty")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    MenuUtil.countSlot(3, 5),
                                    new ItemStack(Material.AIR),
                                    30.0D,
                                    false,
                                    0.0D
                            ),
                            new BoxShopProduct(
                                    "&9Diamenty",
                                    ItemBuilder.of(XMaterial.DIAMOND.parseItem())
                                            .setName("&9Diamenty")
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "&8» &7Koszt sprzedazy: &f{sell}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.",
                                                    "&8» &7Kliknij &fPPM&7, aby sprzedac.",
                                                    "&8» &7Kliknij &fPPM + SHIFT&7, aby sprzedac wszystko.")
                                            .toItemStack(),
                                    XMaterial.DIAMOND.parseItem(),
                                    MenuUtil.countSlot(3, 6),
                                    new ItemStack(Material.AIR),
                                    3.12D,
                                    true,
                                    2.34D
                            ),
                            new BoxShopProduct(
                                    "&2Emeraldy",
                                    ItemBuilder.of(XMaterial.EMERALD.parseItem())
                                            .setName("&2Emeraldy")
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "&8» &7Koszt sprzedazy: &f{sell}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.",
                                                    "&8» &7Kliknij &fPPM&7, aby sprzedac.",
                                                    "&8» &7Kliknij &fPPM + SHIFT&7, aby sprzedac wszystko.")
                                            .toItemStack(),
                                    XMaterial.EMERALD.parseItem(),
                                    MenuUtil.countSlot(3, 7),
                                    new ItemStack(Material.AIR),
                                    4.32D,
                                    true,
                                    3.64D
                            ),
                            new BoxShopProduct(
                                    "&5Obsydian 64x",
                                    ItemBuilder.of(XMaterial.OBSIDIAN.parseItem())
                                            .setName("&5Obsydian")
                                            .setAmount(64)
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "&8» &7Koszt sprzedazy: &f{sell}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.",
                                                    "&8» &7Kliknij &fPPM&7, aby sprzedac.",
                                                    "&8» &7Kliknij &fPPM + SHIFT&7, aby sprzedac wszystko.")
                                            .toItemStack(),
                                    ItemBuilder.of(XMaterial.OBSIDIAN.parseItem())
                                            .setAmount(64)
                                            .toItemStack(),
                                    MenuUtil.countSlot(3, 8),
                                    new ItemStack(Material.AIR),
                                    1.45D,
                                    true,
                                    0.54D
                            )
                    )
            ),
            new BoxShop(
                    "Sklep za kille",
                    MenuUtil.countSlot(3, 7),
                    ItemBuilder.of(XMaterial.DIAMOND_SWORD.parseItem())
                            .setName("&7Sklep za &ckille")
                            .setLore("&8» &7Aktualnie posiadasz: &f{kills} killi",
                                    "&8» &7Kliknij &fLPM&7, aby przejsc do sklepu.")
                            .toItemStack(),
                    new BukkitMenuBuilder("&8[&bM&8] Sklep za kille", 5, new MapBuilder<Integer, ItemStack>()
                            .put(MenuUtil.countSlot(1, 5), ItemBuilder.of(XMaterial.OAK_SIGN.parseItem())
                                    .setName("&7Sklep za kille")
                                    .setLore("&7W tym sklepie zakupisz rozne przedmioty",
                                            "&7i zaplacisz za nie &ckillach&7.",
                                            "",
                                            "&8» &7Aktualnie posiadasz: &f{kills} killi")
                                    .toItemStack())
                            .put(MenuUtil.countSlot(5, 5), ItemBuilder.of(XMaterial.BARRIER.parseItem())
                                    .setName("&cWyjdz z menu")
                                    .toItemStack())
                            .build()),
                    MenuUtil.countSlot(5, 5),
                    ProductCurrency.PLAYER_KILLS,
                    ListBuilder.of(
                            new BoxShopProduct(
                                    "&4Smoczy helm",
                                    ItemBuilder.of(XMaterial.DIAMOND_HELMET.parseItem())
                                            .setName("&4Smoczy helm")
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    ItemBuilder.of(XMaterial.DIAMOND_HELMET.parseItem())
                                            .setName("&4Smoczy helm")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    MenuUtil.countSlot(3, 2),
                                    new ItemStack(Material.AIR),
                                    20.0D,
                                    false,
                                    0.0D
                            ),
                            new BoxShopProduct(
                                    "&4Smocza klata",
                                    ItemBuilder.of(XMaterial.DIAMOND_CHESTPLATE.parseItem())
                                            .setName("&4Smoczy klata")
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    ItemBuilder.of(XMaterial.DIAMOND_CHESTPLATE.parseItem())
                                            .setName("&4Smoczy klata")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    MenuUtil.countSlot(3, 3),
                                    new ItemStack(Material.AIR),
                                    50.0D,
                                    false,
                                    0.0D
                            ),
                            new BoxShopProduct(
                                    "&4Smocze spodnie",
                                    ItemBuilder.of(XMaterial.DIAMOND_LEGGINGS.parseItem())
                                            .setName("&4Smocze spodnie")
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    ItemBuilder.of(XMaterial.DIAMOND_LEGGINGS.parseItem())
                                            .setName("&4Smoczy spodnie")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    MenuUtil.countSlot(3, 4),
                                    new ItemStack(Material.AIR),
                                    40.0D,
                                    false,
                                    0.0D
                            ),
                            new BoxShopProduct(
                                    "&4Smocze buty",
                                    ItemBuilder.of(XMaterial.DIAMOND_BOOTS.parseItem())
                                            .setName("&4Smocze buty")
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    ItemBuilder.of(XMaterial.DIAMOND_BOOTS.parseItem())
                                            .setName("&4Smoczy buty")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    MenuUtil.countSlot(3, 5),
                                    new ItemStack(Material.AIR),
                                    30.0D,
                                    false,
                                    0.0D
                            ),
                            new BoxShopProduct(
                                    "&9Diamenty",
                                    ItemBuilder.of(XMaterial.DIAMOND.parseItem())
                                            .setName("&9Diamenty")
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "&8» &7Koszt sprzedazy: &f{sell}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.",
                                                    "&8» &7Kliknij &fPPM&7, aby sprzedac.",
                                                    "&8» &7Kliknij &fPPM + SHIFT&7, aby sprzedac wszystko.")
                                            .toItemStack(),
                                    XMaterial.DIAMOND.parseItem(),
                                    MenuUtil.countSlot(3, 6),
                                    new ItemStack(Material.AIR),
                                    3.12D,
                                    true,
                                    2.34D
                            ),
                            new BoxShopProduct(
                                    "&2Emeraldy",
                                    ItemBuilder.of(XMaterial.EMERALD.parseItem())
                                            .setName("&2Emeraldy")
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "&8» &7Koszt sprzedazy: &f{sell}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.",
                                                    "&8» &7Kliknij &fPPM&7, aby sprzedac.",
                                                    "&8» &7Kliknij &fPPM + SHIFT&7, aby sprzedac wszystko.")
                                            .toItemStack(),
                                    XMaterial.EMERALD.parseItem(),
                                    MenuUtil.countSlot(3, 7),
                                    new ItemStack(Material.AIR),
                                    4.32D,
                                    true,
                                    3.64D
                            ),
                            new BoxShopProduct(
                                    "&5Obsydian 64x",
                                    ItemBuilder.of(XMaterial.OBSIDIAN.parseItem())
                                            .setName("&5Obsydian")
                                            .setAmount(64)
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "&8» &7Koszt sprzedazy: &f{sell}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.",
                                                    "&8» &7Kliknij &fPPM&7, aby sprzedac.",
                                                    "&8» &7Kliknij &fPPM + SHIFT&7, aby sprzedac wszystko.")
                                            .toItemStack(),
                                    ItemBuilder.of(XMaterial.OBSIDIAN.parseItem())
                                            .setAmount(64)
                                            .toItemStack(),
                                    MenuUtil.countSlot(3, 8),
                                    new ItemStack(Material.AIR),
                                    1.45D,
                                    true,
                                    0.54D
                            )
                    )
            ),
            new BoxShop(
                    "Sklep za zgony",
                    MenuUtil.countSlot(3, 8),
                    ItemBuilder.of(XMaterial.SKELETON_SKULL.parseItem())
                            .setName("&7Sklep za &czgony")
                            .setLore("&8» &7Aktualnie posiadasz: &f{deaths} zgonow",
                                    "&8» &7Kliknij &fLPM&7, aby przejsc do sklepu.")
                            .toItemStack(),
                    new BukkitMenuBuilder("&8[&bM&8] Sklep za zgony", 5, new MapBuilder<Integer, ItemStack>()
                            .put(MenuUtil.countSlot(1, 5), ItemBuilder.of(XMaterial.OAK_SIGN.parseItem())
                                    .setName("&7Sklep za zgony")
                                    .setLore("&7W tym sklepie zakupisz rozne przedmioty",
                                            "&7i zaplacisz za nie &czgonach&7.",
                                            "",
                                            "&8» &7Aktualnie posiadasz: &f{deaths} zgonow")
                                    .toItemStack())
                            .put(MenuUtil.countSlot(5, 5), ItemBuilder.of(XMaterial.BARRIER.parseItem())
                                    .setName("&cWyjdz z menu")
                                    .toItemStack())
                            .build()),
                    MenuUtil.countSlot(5, 5),
                    ProductCurrency.PLAYER_DEATHS,
                    ListBuilder.of(
                            new BoxShopProduct(
                                    "&4Smoczy helm",
                                    ItemBuilder.of(XMaterial.DIAMOND_HELMET.parseItem())
                                            .setName("&4Smoczy helm")
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    ItemBuilder.of(XMaterial.DIAMOND_HELMET.parseItem())
                                            .setName("&4Smoczy helm")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    MenuUtil.countSlot(3, 2),
                                    new ItemStack(Material.AIR),
                                    20.0D,
                                    false,
                                    0.0D
                            ),
                            new BoxShopProduct(
                                    "&4Smocza klata",
                                    ItemBuilder.of(XMaterial.DIAMOND_CHESTPLATE.parseItem())
                                            .setName("&4Smoczy klata")
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    ItemBuilder.of(XMaterial.DIAMOND_CHESTPLATE.parseItem())
                                            .setName("&4Smoczy klata")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    MenuUtil.countSlot(3, 3),
                                    new ItemStack(Material.AIR),
                                    50.0D,
                                    false,
                                    0.0D
                            ),
                            new BoxShopProduct(
                                    "&4Smocze spodnie",
                                    ItemBuilder.of(XMaterial.DIAMOND_LEGGINGS.parseItem())
                                            .setName("&4Smocze spodnie")
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    ItemBuilder.of(XMaterial.DIAMOND_LEGGINGS.parseItem())
                                            .setName("&4Smoczy spodnie")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    MenuUtil.countSlot(3, 4),
                                    new ItemStack(Material.AIR),
                                    40.0D,
                                    false,
                                    0.0D
                            ),
                            new BoxShopProduct(
                                    "&4Smocze buty",
                                    ItemBuilder.of(XMaterial.DIAMOND_BOOTS.parseItem())
                                            .setName("&4Smocze buty")
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    ItemBuilder.of(XMaterial.DIAMOND_BOOTS.parseItem())
                                            .setName("&4Smoczy buty")
                                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4)
                                            .addEnchant(Enchantment.DURABILITY, 3)
                                            .toItemStack(),
                                    MenuUtil.countSlot(3, 5),
                                    new ItemStack(Material.AIR),
                                    30.0D,
                                    false,
                                    0.0D
                            ),
                            new BoxShopProduct(
                                    "&9Diamenty",
                                    ItemBuilder.of(XMaterial.DIAMOND.parseItem())
                                            .setName("&9Diamenty")
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "&8» &7Koszt sprzedazy: &f{sell}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.",
                                                    "&8» &7Kliknij &fPPM&7, aby sprzedac.",
                                                    "&8» &7Kliknij &fPPM + SHIFT&7, aby sprzedac wszystko.")
                                            .toItemStack(),
                                    XMaterial.DIAMOND.parseItem(),
                                    MenuUtil.countSlot(3, 6),
                                    new ItemStack(Material.AIR),
                                    3.12D,
                                    true,
                                    2.34D
                            ),
                            new BoxShopProduct(
                                    "&2Emeraldy",
                                    ItemBuilder.of(XMaterial.EMERALD.parseItem())
                                            .setName("&2Emeraldy")
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "&8» &7Koszt sprzedazy: &f{sell}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.",
                                                    "&8» &7Kliknij &fPPM&7, aby sprzedac.",
                                                    "&8» &7Kliknij &fPPM + SHIFT&7, aby sprzedac wszystko.")
                                            .toItemStack(),
                                    XMaterial.EMERALD.parseItem(),
                                    MenuUtil.countSlot(3, 7),
                                    new ItemStack(Material.AIR),
                                    4.32D,
                                    true,
                                    3.64D
                            ),
                            new BoxShopProduct(
                                    "&5Obsydian 64x",
                                    ItemBuilder.of(XMaterial.OBSIDIAN.parseItem())
                                            .setName("&5Obsydian")
                                            .setAmount(64)
                                            .setLore("&8» &7Koszt kupna: &f{cost}",
                                                    "&8» &7Koszt sprzedazy: &f{sell}",
                                                    "",
                                                    "&8» &7Kliknij &fLPM&7, aby zakupic.",
                                                    "&8» &7Kliknij &fPPM&7, aby sprzedac.",
                                                    "&8» &7Kliknij &fPPM + SHIFT&7, aby sprzedac wszystko.")
                                            .toItemStack(),
                                    ItemBuilder.of(XMaterial.OBSIDIAN.parseItem())
                                            .setAmount(64)
                                            .toItemStack(),
                                    MenuUtil.countSlot(3, 8),
                                    new ItemStack(Material.AIR),
                                    1.45D,
                                    true,
                                    0.54D
                            )
                    )
            )
    );

    @Comment
    @Comment("Jak ma wyglada menu od zakupu przedmiotu?")
    @CustomKey("buy-menu-builder")
    public BukkitMenuBuilder buyMenuBuilder = new BukkitMenuBuilder("&8[&bM&8] Zakup przedmiot", 5, new MapBuilder<Integer, ItemStack>()
            .put(MenuUtil.countSlot(4, 5), ItemBuilder.of(Material.GREEN_DYE)
                    .setName("&aPotwierdz zakup przedmiotu")
                    .setLore("&8» &7Koszt kupna: &f{cost}",
                            "&8» &7Kupujesz: &f{multiplier} szt.",
                            "",
                            "&8» &7Kliknij &fLPM&7, aby zakupic.")
                    .toItemStack())
            .put(MenuUtil.countSlot(5, 5), ItemBuilder.of(XMaterial.BARRIER.parseItem())
                    .setName("&cWyjdz z menu")
                    .toItemStack())
            .build());

    @Comment
    @Comment("Pod jakim slotem znajduje sie przycisk od zakupu?")
    @CustomKey("buy-button-slot")
    public int buyButtonSlot = MenuUtil.countSlot(4, 5);

    @Comment
    @Comment("Pod jakim slotem znajduje sie przycisk od wyjscia z menu kupowania?")
    @CustomKey("close-buy-menu-slot")
    public int closeBuyMenuSlot = MenuUtil.countSlot(5, 5);

    @Comment
    @Comment("Pod jakim slotem znajduje sie przedmiot od podgladu?")
    @CustomKey("buy-preview-slot")
    public int buyPreviewSlot = MenuUtil.countSlot(3, 2);

    @Comment
    @Comment("Pod jakimi slotami znajduja sie przyciski od dodawania sztuk? (slot, ilosc)")
    @CustomKey("add-item-slots")
    public Map<Integer, Integer> addItemSlots = MapBuilder.of(
            MenuUtil.countSlot(2, 4), 64,
            MenuUtil.countSlot(3, 4), 10,
            MenuUtil.countSlot(4, 4), 1
    );

    @Comment
    @Comment("Jak ma wygladac item od dodawania przedmiotu w danych sztukach?")
    @CustomKey("add-display-item")
    public ItemStack addDisplayItem = ItemBuilder.of(XMaterial.GREEN_WOOL.parseItem())
            .setName("&7Dodaj &a{amount} sztuki")
            .setLore("&8» &7Kliknij &fLPM&7, aby dodac.")
            .toItemStack();

    @Comment
    @Comment("Pod jakimi slotami znajduja sie przyciski od odejmowania sztuk? (slot, ilosc)")
    @CustomKey("remove-item-slots")
    public Map<Integer, Integer> removeItemSlots = MapBuilder.of(
            MenuUtil.countSlot(2, 6), 64,
            MenuUtil.countSlot(3, 6), 10,
            MenuUtil.countSlot(4, 6), 1
    );

    @Comment
    @Comment("Jak ma wygladac item od usuwania przedmiotu w danych sztukach?")
    @CustomKey("remove-display-item")
    public ItemStack removeDisplayItem = ItemBuilder.of(XMaterial.RED_WOOL.parseItem())
            .setName("&7Usun &c{amount} sztuki")
            .setLore("&8» &7Kliknij &fLPM&7, aby usunac.")
            .toItemStack();

    @Comment
    @Comment("Jak ma wyglada item krysztalu?")
    @CustomKey("crystal-item")
    public ItemStack crystalItem = ItemBuilder.of(Material.PRISMARINE_SHARD)
            .setName("&bKrysztal")
            .setLore("&7Uzyjesz go w sklepie.")
            .toItemStack();
}
