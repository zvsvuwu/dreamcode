package cc.dreamcode.boxshop;

import cc.dreamcode.boxshop.config.MessageConfig;
import cc.dreamcode.menu.adventure.BukkitMenuBuilder;
import cc.dreamcode.menu.adventure.base.BukkitMenu;
import cc.dreamcode.menu.adventure.setup.BukkitMenuPlayerSetup;
import cc.dreamcode.platform.DreamLogger;
import cc.dreamcode.utilities.builder.MapBuilder;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import eu.okaeri.injector.annotation.Inject;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.bukkit.Material;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;

import java.util.Locale;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class BoxShopSubMenu implements BukkitMenuPlayerSetup {

    private final DreamLogger dreamLogger;
    private final BoxShopPlugin boxShopPlugin;
    private final MessageConfig messageConfig;
    private final BoxShopService boxShopService;

    @Setter private BoxShop boxShop;

    @Override
    public BukkitMenu build(@NonNull HumanEntity humanEntity) {

        if (this.boxShop == null) {
            throw new RuntimeException("Fields cannot be null");
        }

        if (!(humanEntity instanceof Player)) {
            throw new RuntimeException("HumanEntity must be Player");
        }

        final Player player = (Player) humanEntity;

        final BukkitMenuBuilder menuBuilder = this.boxShop.getMenuBuilder();
        final BukkitMenu bukkitMenu = menuBuilder.buildEmpty();

        menuBuilder.getItems().forEach((slot, item) -> {

            if (this.boxShop.getBackToMainMenuSlot() == slot) {
                bukkitMenu.setItem(slot, ItemBuilder.of(item).fixColors().toItemStack(), e -> {
                    final BoxShopMenu boxShopMenu = this.boxShopPlugin.createInstance(BoxShopMenu.class);
                    boxShopMenu.build(player).open(player);
                });
                return;
            }

            bukkitMenu.setItem(slot, ItemBuilder.of(item)
                    .fixColors(new MapBuilder<String, Object>()
                            .put("playtime", this.boxShopService.getPlayerPlaytime(player).toMinutes() + "min")
                            .put("money", this.boxShopService.getPlayerMoney(player))
                            .put("kills", this.boxShopService.getPlayerKills(player))
                            .put("deaths", this.boxShopService.getPlayerDeaths(player))
                            .put("crystals", this.boxShopService.getPlayerCrystal(player))
                            .build())
                    .toItemStack());
        });

        this.boxShop.getBoxShopProductList().forEach(boxShopProduct ->
            bukkitMenu.setItem(boxShopProduct.getSlotInMenu(), ItemBuilder.of(boxShopProduct.getDisplayItem())
                    .fixColors(new MapBuilder<String, Object>()
                            .put("cost", this.boxShop.getProductCurrency().equals(ProductCurrency.PLAYER_PLAYTIME)
                                    ? Math.round(boxShopProduct.getBuyCost()) + "min"
                                    : this.boxShop.getProductCurrency().equals(ProductCurrency.PLAYER_ITEM)
                                    ? boxShopProduct.getBuyCostItem().getItemMeta() != null && boxShopProduct.getBuyCostItem().getItemMeta().hasDisplayName()
                                            ? boxShopProduct.getBuyCostItem().getItemMeta().getDisplayName() + " " + boxShopProduct.getBuyCostItem().getAmount() + "x"
                                            : boxShopProduct.getBuyCostItem().getType().name().toLowerCase(Locale.ROOT) + " " + boxShopProduct.getBuyCostItem().getAmount() + "x"
                                    : this.boxShop.getProductCurrency().equals(ProductCurrency.PLAYER_KILLS)
                                    ? Math.round(boxShopProduct.getBuyCost()) + " killi"
                                    : this.boxShop.getProductCurrency().equals(ProductCurrency.PLAYER_DEATHS)
                                    ? Math.round(boxShopProduct.getBuyCost()) + " zabojstw"
                                    : this.boxShop.getProductCurrency().equals(ProductCurrency.PLAYER_CRYSTAL)
                                    ? Math.round(boxShopProduct.getBuyCost()) + " odlamki"
                                    : boxShopProduct.getBuyCost() + "$")
                            .put("sell", boxShopProduct.getSellCost() + "$")
                            .put("playtime", this.boxShopService.getPlayerPlaytime(player).toMinutes() + "min")
                            .put("money", this.boxShopService.getPlayerMoney(player))
                            .put("kills", this.boxShopService.getPlayerKills(player))
                            .put("deaths", this.boxShopService.getPlayerDeaths(player))
                            .put("crystals", this.boxShopService.getPlayerCrystal(player))
                            .build())
                    .toItemStack(), e -> {

                if (e.getClick().isLeftClick()) {
                    if (this.boxShop.getProductCurrency().equals(ProductCurrency.PLAYER_ITEM) &&
                            boxShopProduct.getBuyCostItem().getType().equals(Material.AIR)) {
                        this.dreamLogger.warning("Buy cost item cannot be AIR for ITEM_CURRENCY");
                        return;
                    }

                    final BoxShopMenuBuy boxShopMenuBuy = this.boxShopPlugin.createInstance(BoxShopMenuBuy.class);

                    boxShopMenuBuy.setBoxShop(this.boxShop);
                    boxShopMenuBuy.setBoxShopProduct(boxShopProduct);
                    boxShopMenuBuy.build(player).open(player);
                    return;
                }

                if (!boxShopProduct.isSelling()) {
                    return;
                }

                if (e.getClick().isRightClick()) {

                    int multiplier = 0;
                    double amount = this.boxShopService.getPlayerItem(player, boxShopProduct.getActualItem());

                    double oneProductAmount = boxShopProduct.getActualItem().getAmount();
                    while (amount >= oneProductAmount) {

                        if (multiplier >= 1 && !e.getClick().isShiftClick()) {
                            break;
                        }

                        amount -= oneProductAmount;
                        multiplier++;
                    }

                    if (multiplier == 0) {
                        this.messageConfig.shopNoItemToSell.send(player);
                        return;
                    }

                    for (int index = 0; index < multiplier; index++) {
                        this.boxShopService.takePlayerItem(player, boxShopProduct.getActualItem(), 1);
                        this.boxShopService.addPlayerMoney(player, boxShopProduct.getSellCost());
                    }

                    this.messageConfig.shopItemSold.send(player, new MapBuilder<String, Object>()
                            .put("nick", player.getName())
                            .put("name", boxShopProduct.getDisplayName())
                            .build());
                }
            }));

        return bukkitMenu;
    }
}
