rootProject.name = "dream-boxshop"

include(":plugin-core")