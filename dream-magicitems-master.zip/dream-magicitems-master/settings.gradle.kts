rootProject.name = "dream-magicitems"

include(":plugin-core")