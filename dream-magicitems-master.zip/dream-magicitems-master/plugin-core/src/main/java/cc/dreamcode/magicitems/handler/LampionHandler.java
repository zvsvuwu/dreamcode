package cc.dreamcode.magicitems.handler;

import cc.dreamcode.magicitems.MagicItemType;
import cc.dreamcode.magicitems.config.MessageConfig;
import cc.dreamcode.magicitems.config.PluginConfig;
import cc.dreamcode.magicitems.config.subconfig.LampionConfig;
import cc.dreamcode.magicitems.cooldown.Cooldown;
import cc.dreamcode.magicitems.cooldown.CooldownCache;
import cc.dreamcode.utilities.TimeUtil;
import cc.dreamcode.utilities.builder.MapBuilder;
import eu.okaeri.injector.annotation.Inject;
import lombok.RequiredArgsConstructor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

import java.util.Optional;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class LampionHandler implements MagicItemHandler {

    private final PluginConfig pluginConfig;
    private final MessageConfig messageConfig;
    private final CooldownCache cooldownCache;

    @Override
    public MagicItemType getMagicItemType() {
        return MagicItemType.LAMPION;
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent e) {
        final Player player = e.getPlayer();
        final ItemStack itemUsed = e.getItem();
        if (itemUsed == null || itemUsed.getType().equals(Material.AIR)) {
            return;
        }

        if (!MagicItemType.isMagicItem(itemUsed, this.getMagicItemType())) {
            return;
        }

        final LampionConfig lampionConfig = this.pluginConfig.lampionConfig;
        final Location location = player.getLocation();
        if (lampionConfig.blockedRegions.stream().anyMatch(region -> region.isInside(location))) {
            if (lampionConfig.allowedRegions.stream().noneMatch(region -> region.isInside(location))) {

                if (!lampionConfig.allowBypassPermission) {
                    e.setCancelled(true);

                    this.messageConfig.invalidRegion.send(player);
                    return;
                }

                if (!player.hasPermission(lampionConfig.bypassPermission)) {
                    e.setCancelled(true);

                    this.messageConfig.invalidRegion.send(player);
                    return;
                }
            }
        }

        if (!lampionConfig.cooldown.isNegative() && !lampionConfig.cooldown.isZero()) {
            final Optional<Cooldown> optionalCooldown = this.cooldownCache.getCooldown(player, this.getMagicItemType());
            if (optionalCooldown.isPresent()) {
                e.setCancelled(true);

                final Cooldown cooldown = optionalCooldown.get();
                this.messageConfig.cooldown.send(player, new MapBuilder<String, Object>()
                        .put("time", TimeUtil.convertDurationMills(cooldown.getCounter()))
                        .build());
                return;
            }

            this.cooldownCache.applyCooldown(player, this.getMagicItemType(), lampionConfig.cooldown);
        }

        if (!player.getGameMode().equals(GameMode.CREATIVE)) {
            itemUsed.setAmount(itemUsed.getAmount() - 1);
            if (itemUsed.getAmount() <= 0) {
                player.getInventory().removeItem(itemUsed);
            }
        }

        lampionConfig.potionEffects.forEach(player::addPotionEffect);
        this.messageConfig.lampionCalled.send(player);
    }
}
