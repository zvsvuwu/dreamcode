package cc.dreamcode.magicitems;

import lombok.NonNull;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.Arrays;
import java.util.Optional;

public enum MagicItemType {
    HAK,
    GRANAT_ODPYCHANIA,
    GRANAT_UWIEZIENIA,
    SMOCZA_SIEKIERA,
    SERCE_WARDENA,
    SNIEZKA_TELEPORTACJI,
    BUTY_SONICA,
    LAMPION,
    MIKSTURA_ODMLODZENIA,
    SIERSC_NIEDZWIEDZIA,
    OKO_YETI,
    NOS_OLAFA,
    LODOWA_ROZDZKA;

    public static boolean isMagicItem(@NonNull ItemStack itemStack) {
        return MagicItemType.getMagicItemType(itemStack).isPresent();
    }

    public static boolean isMagicItem(@NonNull ItemStack itemStack, @NonNull MagicItemType magicItemType) {
        return MagicItemType.getMagicItemType(itemStack).orElse(null) == magicItemType;
    }

    public static Optional<MagicItemType> getMagicItemType(@NonNull ItemStack itemStack) {
        final ItemMeta itemMeta = itemStack.getItemMeta();
        final NamespacedKey namespacedKey = MagicItemType.getNamespacedKey();

        if (itemMeta == null) {
            return Optional.empty();
        }

        final String rawType = itemMeta.getPersistentDataContainer().getOrDefault(namespacedKey, PersistentDataType.STRING, "");
        if (rawType.isEmpty()) {
            return Optional.empty();
        }

        return Arrays.stream(MagicItemType.values())
                .filter(type -> type.name().equals(rawType))
                .findAny();
    }

    public static ItemStack setMagicItemType(@NonNull ItemStack itemStack, @NonNull MagicItemType magicItemType) {
        final ItemMeta itemMeta = itemStack.getItemMeta();
        final NamespacedKey namespacedKey = MagicItemType.getNamespacedKey();

        assert itemMeta != null;
        itemMeta.getPersistentDataContainer().set(namespacedKey, PersistentDataType.STRING, magicItemType.name());
        itemStack.setItemMeta(itemMeta);

        return itemStack;
    }

    private static NamespacedKey getNamespacedKey() {
        return new NamespacedKey(MagicItemsPlugin.getMagicItemsPlugin(), "magic-item-type");
    }
}
