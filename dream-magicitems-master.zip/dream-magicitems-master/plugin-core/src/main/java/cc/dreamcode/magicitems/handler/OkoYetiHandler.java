package cc.dreamcode.magicitems.handler;

import cc.dreamcode.magicitems.MagicItemType;
import cc.dreamcode.magicitems.MagicItemsPlugin;
import cc.dreamcode.magicitems.config.MessageConfig;
import cc.dreamcode.magicitems.config.PluginConfig;
import cc.dreamcode.magicitems.config.subconfig.OkoYetiConfig;
import cc.dreamcode.magicitems.cooldown.Cooldown;
import cc.dreamcode.magicitems.cooldown.CooldownCache;
import cc.dreamcode.utilities.TimeUtil;
import cc.dreamcode.utilities.builder.MapBuilder;
import eu.okaeri.injector.annotation.Inject;
import lombok.RequiredArgsConstructor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

import java.util.Optional;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class OkoYetiHandler implements MagicItemHandler {

    private final MagicItemsPlugin magicItemsPlugin;
    private final PluginConfig pluginConfig;
    private final MessageConfig messageConfig;
    private final CooldownCache cooldownCache;

    @Override
    public MagicItemType getMagicItemType() {
        return MagicItemType.OKO_YETI;
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent e) {
        final Player player = e.getPlayer();
        final ItemStack itemUsed = e.getItem();
        if (itemUsed == null || itemUsed.getType().equals(Material.AIR)) {
            return;
        }

        if (!MagicItemType.isMagicItem(itemUsed, this.getMagicItemType())) {
            return;
        }

        final OkoYetiConfig okoYetiConfig = this.pluginConfig.okoYetiConfig;
        final Location location = player.getLocation();
        if (okoYetiConfig.blockedRegions.stream().anyMatch(region -> region.isInside(location))) {
            if (okoYetiConfig.allowedRegions.stream().noneMatch(region -> region.isInside(location))) {

                if (!okoYetiConfig.allowBypassPermission) {
                    e.setCancelled(true);

                    this.messageConfig.invalidRegion.send(player);
                    return;
                }

                if (!player.hasPermission(okoYetiConfig.bypassPermission)) {
                    e.setCancelled(true);

                    this.messageConfig.invalidRegion.send(player);
                    return;
                }
            }
        }

        if (!okoYetiConfig.cooldown.isNegative() && !okoYetiConfig.cooldown.isZero()) {
            final Optional<Cooldown> optionalCooldown = this.cooldownCache.getCooldown(player, this.getMagicItemType());
            if (optionalCooldown.isPresent()) {
                e.setCancelled(true);

                final Cooldown cooldown = optionalCooldown.get();
                this.messageConfig.cooldown.send(player, new MapBuilder<String, Object>()
                        .put("time", TimeUtil.convertDurationMills(cooldown.getCounter()))
                        .build());
                return;
            }

            this.cooldownCache.applyCooldown(player, this.getMagicItemType(), okoYetiConfig.cooldown);
        }

        if (!player.getGameMode().equals(GameMode.CREATIVE)) {
            itemUsed.setAmount(itemUsed.getAmount() - 1);
            if (itemUsed.getAmount() <= 0) {
                player.getInventory().removeItem(itemUsed);
            }
        }

        this.magicItemsPlugin.getServer().getOnlinePlayers()
                .stream()
                .filter(nearPlayer -> {

                    if (nearPlayer.getUniqueId().equals(player.getUniqueId())) {
                        return okoYetiConfig.bypassSource;
                    }

                    return true;
                })
                .filter(nearPlayer -> {
                    if (!okoYetiConfig.allowBypassPermission) {
                        if (okoYetiConfig.blockedRegions.stream().anyMatch(region -> region.isInside(location))) {
                            return okoYetiConfig.allowedRegions.stream().anyMatch(region -> region.isInside(location));
                        }
                    }

                    if (!player.hasPermission(okoYetiConfig.bypassPermission)) {
                        if (okoYetiConfig.blockedRegions.stream().anyMatch(region -> region.isInside(location))) {
                            return okoYetiConfig.allowedRegions.stream().anyMatch(region -> region.isInside(location));
                        }
                    }

                    return true;
                })
                .filter(nearPlayer -> nearPlayer.getLocation().distanceSquared(player.getLocation()) <= okoYetiConfig.distance * 2)
                .forEach(nearPlayer -> okoYetiConfig.potionEffects.forEach(nearPlayer::addPotionEffect));

        this.messageConfig.okoYetiCalled.send(player);
    }
}
