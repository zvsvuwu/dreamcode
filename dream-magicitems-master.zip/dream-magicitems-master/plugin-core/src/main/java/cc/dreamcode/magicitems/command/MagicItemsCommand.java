package cc.dreamcode.magicitems.command;

import cc.dreamcode.command.annotations.RequiredPermission;
import cc.dreamcode.command.bukkit.BukkitCommand;
import cc.dreamcode.magicitems.MagicItem;
import cc.dreamcode.magicitems.MagicItemType;
import cc.dreamcode.magicitems.MagicItemsCache;
import cc.dreamcode.magicitems.MagicItemsPlugin;
import cc.dreamcode.magicitems.MagicItemsService;
import cc.dreamcode.magicitems.config.MessageConfig;
import cc.dreamcode.magicitems.config.PluginConfig;
import cc.dreamcode.magicitems.config.subconfig.HakConfig;
import cc.dreamcode.menu.bukkit.BukkitMenuBuilder;
import cc.dreamcode.menu.bukkit.base.BukkitMenu;
import cc.dreamcode.utilities.ParseUtil;
import cc.dreamcode.utilities.TimeUtil;
import cc.dreamcode.utilities.builder.ListBuilder;
import cc.dreamcode.utilities.builder.MapBuilder;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import eu.okaeri.configs.exception.OkaeriException;
import eu.okaeri.injector.annotation.Inject;
import lombok.NonNull;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

@RequiredPermission
public class MagicItemsCommand extends BukkitCommand {

    private final MagicItemsPlugin magicItemsPlugin;
    private final MessageConfig messageConfig;
    private final PluginConfig pluginConfig;
    private final MagicItemsService magicItemsService;
    private final MagicItemsCache magicItemsCache;

    @Inject
    public MagicItemsCommand(MagicItemsPlugin magicItemsPlugin, MessageConfig messageConfig, PluginConfig pluginConfig, MagicItemsService magicItemsService, MagicItemsCache magicItemsCache) {
        super("magicitems");

        this.magicItemsPlugin = magicItemsPlugin;
        this.messageConfig = messageConfig;
        this.pluginConfig = pluginConfig;
        this.magicItemsService = magicItemsService;
        this.magicItemsCache = magicItemsCache;
    }

    @Override
    public void content(@NonNull CommandSender sender, @NonNull String[] args) {

        if (args.length != 0) {
            if (args[0].equalsIgnoreCase("pick")) {

                if (!(sender instanceof Player)) {
                    this.messageConfig.notPlayer.send(sender);
                    return;
                }

                final Player player = (Player) sender;

                final BukkitMenuBuilder menuBuiler = this.pluginConfig.menuBuilder;
                final BukkitMenu bukkitMenu = menuBuiler.buildWithItems();
                bukkitMenu.setCancelInventoryClick(false);

                this.pluginConfig.magicItems.forEach(magicItem -> {

                    if (magicItem.getMagicItemType().equals(MagicItemType.HAK)) {
                        final HakConfig hakConfig = this.pluginConfig.hakConfig;

                        bukkitMenu.addItem(ItemBuilder.of(magicItem.getFinalItem())
                                .fixColors(new MapBuilder<String, Object>()
                                        .put("actual", 0)
                                        .put("total", hakConfig.totalUsage)
                                        .build())
                                .toItemStack());
                        return;
                    }

                    bukkitMenu.addItem(ItemBuilder.of(magicItem.getFinalItem())
                            .fixColors()
                            .toItemStack());
                });

                bukkitMenu.open(player);
                return;
            }

            if (args[0].equalsIgnoreCase("give")) {

                if (args.length < 3) {
                    this.messageConfig.usage.send(sender, new MapBuilder<String, Object>()
                            .put("usage", "/magicitems give [nick/all] [item] (amount)")
                            .build());
                    return;
                }

                final AtomicInteger amount = new AtomicInteger(1);
                if (args.length == 4) {

                    final Optional<Integer> amountInput = ParseUtil.parseInteger(args[3]);
                    if (!amountInput.isPresent()) {
                        this.messageConfig.numberIsNotValid.send(sender);
                        return;
                    }

                    amount.set(amountInput.get());
                }

                final Optional<MagicItemType> optionalMagicItemType = Arrays.stream(MagicItemType.values())
                        .filter(type -> type.name().equalsIgnoreCase(args[2]))
                        .findAny();

                if (!optionalMagicItemType.isPresent()) {
                    this.messageConfig.magicItemNotFound.send(sender);
                    return;
                }

                final MagicItemType magicItemType = optionalMagicItemType.get();
                final Optional<MagicItem> optionalMagicItem = this.pluginConfig.magicItems
                        .stream()
                        .filter(item -> item.getMagicItemType().equals(magicItemType))
                        .findAny();

                if (!optionalMagicItem.isPresent()) {
                    this.messageConfig.magicItemNotFound.send(sender);
                    return;
                }

                final MagicItem magicItem = optionalMagicItem.get();
                final ItemStack fixedItem;

                if (magicItemType.equals(MagicItemType.HAK)) {
                    final HakConfig hakConfig = this.pluginConfig.hakConfig;

                    fixedItem = ItemBuilder.of(magicItem.getFinalItem())
                            .setAmount(amount.get())
                            .fixColors(new MapBuilder<String, Object>()
                                    .put("actual", 0)
                                    .put("total", hakConfig.totalUsage)
                                    .build())
                            .toItemStack();
                }
                else {
                    fixedItem = ItemBuilder.of(magicItem.getFinalItem())
                            .setAmount(amount.get())
                            .fixColors()
                            .toItemStack();
                }

                final String nick = args[1];
                if (nick.equalsIgnoreCase("all")) {

                    this.magicItemsPlugin.getServer().getOnlinePlayers().forEach(customer -> {
                        customer.getInventory().addItem(fixedItem)
                                .forEach((i, item) -> customer.getWorld().dropItem(customer.getLocation(), item));

                        this.messageConfig.magicItemReceived.send(customer, new MapBuilder<String, Object>()
                                .put("amount", amount.get())
                                .build());
                    });

                    this.messageConfig.magicItemGivedAll.send(sender, new MapBuilder<String, Object>()
                            .put("amount", amount.get())
                            .build());
                    return;
                }

                final Player customer = this.magicItemsPlugin.getServer().getPlayerExact(nick);
                if (customer == null) {
                    this.messageConfig.playerNotFound.send(sender);
                    return;
                }

                customer.getInventory().addItem(fixedItem)
                        .forEach((i, item) -> customer.getWorld().dropItem(customer.getLocation(), item));

                this.messageConfig.magicItemReceived.send(customer, new MapBuilder<String, Object>()
                        .put("amount", amount.get())
                        .build());

                if (!customer.getName().equals(sender.getName())) {
                    this.messageConfig.magicItemGived.send(sender, new MapBuilder<String, Object>()
                            .put("nick", customer.getName())
                            .put("amount", amount.get())
                            .build());
                }
                return;
            }

            if (args[0].equalsIgnoreCase("reload")) {
                final long time = System.currentTimeMillis();

                try {
                    this.messageConfig.load();
                    this.pluginConfig.load();

                    this.messageConfig.reloaded.send(sender, new MapBuilder<String, Object>()
                            .put("time", TimeUtil.convertMills(System.currentTimeMillis() - time))
                            .build());
                }
                catch (NullPointerException | OkaeriException e) {
                    e.printStackTrace();

                    this.messageConfig.reloadError.send(sender, new MapBuilder<String, Object>()
                            .put("error", e.getMessage())
                            .build());
                }
                return;
            }

            if (args[0].equalsIgnoreCase("reloadtextures")) {
                if (!this.pluginConfig.useResourcePack) {
                    this.messageConfig.reloadTexturesError.send(sender);
                    return;
                }

                final long time = System.currentTimeMillis();

                this.magicItemsPlugin.getServer().getOnlinePlayers().forEach(player -> {
                    this.magicItemsCache.setLoadingScreen(player);
                    this.magicItemsService.setLoadingEffects(player);
                    this.magicItemsService.setResourcePack(player);
                });

                this.messageConfig.reloadedTextures.send(sender, new MapBuilder<String, Object>()
                        .put("time", TimeUtil.convertMills(System.currentTimeMillis() - time))
                        .build());
                return;
            }
        }

        this.messageConfig.usage.send(sender, MapBuilder.of("usage", "/magicitem [pick, give, reload, reloadtextures]"));
    }

    @Override
    public List<String> tab(@NonNull CommandSender sender, @NonNull String[] args) {

        if (args.length == 4) {
            if (args[0].equalsIgnoreCase("give")) {
                return Collections.singletonList("<amount>");
            }
        }

        if (args.length == 3) {
            if (args[0].equalsIgnoreCase("give")) {
                return Arrays.stream(MagicItemType.values())
                        .map(Enum::name)
                        .collect(Collectors.toList());
            }
        }

        if (args.length == 2) {
            if (args[0].equalsIgnoreCase("give")) {
                return new ListBuilder<String>()
                        .addAll(this.magicItemsPlugin.getServer().getOnlinePlayers()
                                .stream()
                                .map(Player::getName)
                                .collect(Collectors.toList()))
                        .add("all")
                        .build();
            }
        }

        if (args.length == 1) {
            return Arrays.asList("pick", "give", "reload", "reloadtextures");
        }

        return null;
    }
}
