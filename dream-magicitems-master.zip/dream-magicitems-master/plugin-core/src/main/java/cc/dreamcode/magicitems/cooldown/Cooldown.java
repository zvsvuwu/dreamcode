package cc.dreamcode.magicitems.cooldown;

import cc.dreamcode.magicitems.MagicItemType;
import cc.dreamcode.utilities.CountUtil;
import lombok.Data;

import java.time.Duration;
import java.time.Instant;

@Data
public class Cooldown {

    private final MagicItemType magicItemType;
    private final Instant instant;
    private final Duration duration;

    public boolean isOut() {
        return CountUtil.isOut(this.getCounter());
    }

    public Duration getCounter() {
        return CountUtil.getCountDown(this.instant, this.duration);
    }

}
