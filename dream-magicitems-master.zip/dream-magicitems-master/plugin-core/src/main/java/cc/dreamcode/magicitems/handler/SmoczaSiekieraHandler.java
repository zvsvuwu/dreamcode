package cc.dreamcode.magicitems.handler;

import cc.dreamcode.magicitems.MagicItemType;
import cc.dreamcode.magicitems.MagicItemsPlugin;
import cc.dreamcode.magicitems.config.MessageConfig;
import cc.dreamcode.magicitems.config.PluginConfig;
import cc.dreamcode.magicitems.config.subconfig.SmoczaSiekieraConfig;
import cc.dreamcode.magicitems.drop.ItemDrop;
import cc.dreamcode.utilities.StringUtil;
import cc.dreamcode.utilities.builder.MapBuilder;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import eu.okaeri.injector.annotation.Inject;
import lombok.RequiredArgsConstructor;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class SmoczaSiekieraHandler implements MagicItemHandler {

    private final MagicItemsPlugin magicItemsPlugin;
    private final PluginConfig pluginConfig;
    private final MessageConfig messageConfig;

    @Override
    public MagicItemType getMagicItemType() {
        return MagicItemType.SMOCZA_SIEKIERA;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent e) {
        final Player player = e.getPlayer();
        final Block block = e.getBlock();
        final ItemStack itemInHand = player.getInventory().getItemInMainHand();
        if (!MagicItemType.isMagicItem(itemInHand, this.getMagicItemType())) {
            return;
        }

        final SmoczaSiekieraConfig smoczaSiekieraConfig = this.pluginConfig.smoczaSiekieraConfig;
        final Location location = block.getLocation();
        if (smoczaSiekieraConfig.blockedRegions.stream().anyMatch(region -> region.isInside(location))) {
            if (smoczaSiekieraConfig.allowedRegions.stream().noneMatch(region -> region.isInside(location))) {

                if (!smoczaSiekieraConfig.allowBypassPermission) {
                    e.setCancelled(true);

                    this.messageConfig.invalidRegion.send(player);
                    return;
                }

                if (!player.hasPermission(smoczaSiekieraConfig.bypassPermission)) {
                    e.setCancelled(true);

                    this.messageConfig.invalidRegion.send(player);
                    return;
                }
            }
        }

        smoczaSiekieraConfig.dropItems
                .stream()
                .filter(ItemDrop::hasChance)
                .forEach(itemDrop -> {
                    final int amount = itemDrop.getDropAmount().randomize();

                    itemDrop.getItems().forEach(itemStack -> {

                        final ItemStack fixedItem;

                        if (smoczaSiekieraConfig.randomizeAmount) {
                            fixedItem = new ItemBuilder(itemStack)
                                    .setAmount(itemDrop.getDropAmount().randomize())
                                    .fixColors()
                                    .toItemStack();
                        }
                        else {
                            fixedItem = new ItemBuilder(itemStack)
                                    .setAmount(amount)
                                    .fixColors()
                                    .toItemStack();
                        }

                        if (smoczaSiekieraConfig.moveItemToInventory) {
                            player.getInventory().addItem(fixedItem)
                                    .forEach((i, item) -> player.getWorld().dropItem(player.getLocation(), item));
                        }
                        else {
                            block.getWorld().dropItem(player.getLocation(), fixedItem);
                        }
                    });

                    itemDrop.getCommands().forEach(command ->
                            this.magicItemsPlugin.getServer().dispatchCommand(
                                    this.magicItemsPlugin.getServer().getConsoleSender(),
                                    StringUtil.replace(command, new MapBuilder<String, Object>()
                                            .put("nick", player.getName())
                                            .put("amount", smoczaSiekieraConfig.randomizeAmount
                                                    ? itemDrop.getDropAmount().randomize()
                                                    : amount)
                                            .build())
                            ));
                });
    }
}
