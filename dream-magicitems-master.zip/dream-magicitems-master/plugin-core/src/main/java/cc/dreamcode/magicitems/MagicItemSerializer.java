package cc.dreamcode.magicitems;

import eu.okaeri.configs.schema.GenericsDeclaration;
import eu.okaeri.configs.serdes.DeserializationData;
import eu.okaeri.configs.serdes.ObjectSerializer;
import eu.okaeri.configs.serdes.SerializationData;
import lombok.NonNull;
import org.bukkit.inventory.ItemStack;

public class MagicItemSerializer implements ObjectSerializer<MagicItem> {
    @Override
    public boolean supports(@NonNull Class<? super MagicItem> type) {
        return MagicItem.class.isAssignableFrom(type);
    }

    @Override
    public void serialize(@NonNull MagicItem object, @NonNull SerializationData data, @NonNull GenericsDeclaration generics) {
        data.add("magic-item-type", object.getMagicItemType());
        data.add("magic-item", object.getItem());

        if (object.getCustomModelData() != -1) {
            data.add("magic-item-id", object.getCustomModelData());
        }
    }

    @Override
    public MagicItem deserialize(@NonNull DeserializationData data, @NonNull GenericsDeclaration generics) {
        return new MagicItem(
                data.get("magic-item-type", MagicItemType.class),
                data.get("magic-item", ItemStack.class),
                data.containsKey("magic-item-id") ? data.get("magic-item-id", Integer.class) : -1
        );
    }
}
