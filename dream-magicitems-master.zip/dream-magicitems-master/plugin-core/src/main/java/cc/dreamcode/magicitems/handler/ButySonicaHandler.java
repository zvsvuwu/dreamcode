package cc.dreamcode.magicitems.handler;

import cc.dreamcode.magicitems.MagicItemType;
import cc.dreamcode.magicitems.MagicItemsPlugin;
import cc.dreamcode.magicitems.config.PluginConfig;
import cc.dreamcode.magicitems.config.subconfig.ButySonicaConfig;
import cc.dreamcode.platform.bukkit.component.scheduler.Scheduler;
import eu.okaeri.injector.annotation.Inject;
import lombok.RequiredArgsConstructor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

@Scheduler(async = false, delay = 20, interval = 20)
@RequiredArgsConstructor(onConstructor_ = @Inject)
public class ButySonicaHandler implements Runnable {

    private final MagicItemsPlugin magicItemsPlugin;
    private final PluginConfig pluginConfig;

    @Override
    public void run() {
        this.magicItemsPlugin.getServer().getOnlinePlayers().forEach(player -> {

            final ButySonicaConfig butySonicaConfig = this.pluginConfig.butySonicaConfig;
            final Location location = player.getLocation();
            if (butySonicaConfig.blockedRegions.stream().anyMatch(region -> region.isInside(location))) {
                if (butySonicaConfig.allowedRegions.stream().noneMatch(region -> region.isInside(location))) {
                    if (!butySonicaConfig.allowBypassPermission) {
                        return;
                    }

                    if (!player.hasPermission(butySonicaConfig.bypassPermission)) {
                        return;
                    }
                }
            }

            final PlayerInventory playerInventory = player.getInventory();
            final ItemStack boots = playerInventory.getBoots();
            if (boots == null || boots.getType().equals(Material.AIR)) {
                return;
            }

            if (!MagicItemType.isMagicItem(boots, MagicItemType.BUTY_SONICA)) {
                return;
            }

            butySonicaConfig.potionEffects.forEach(player::addPotionEffect);
        });
    }
}
