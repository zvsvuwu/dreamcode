package cc.dreamcode.magicitems.region;

import lombok.Data;
import lombok.NonNull;
import org.bukkit.Location;
import org.bukkit.World;

import java.util.Objects;

@Data
public class Region {

    private final World world;
    private final Location firstCorner;
    private final Location secondCorner;

    public boolean isInside(@NonNull Location location) {
        if (!Objects.equals(this.world, location.getWorld())) {
            return false;
        }

        if (location.getBlockX() > this.getLowerX() && location.getBlockX() < this.getUpperX()) {
            if (location.getBlockY() > this.getLowerY() && location.getBlockY() < this.getUpperY()) {
                return location.getBlockZ() > this.getLowerZ() && location.getBlockZ() < this.getUpperZ();
            }
        }

        return false;
    }

    public int getUpperX() {
        return Math.max(this.secondCorner.getBlockX(), this.firstCorner.getBlockX());
    }

    public int getUpperY() {
        return Math.max(this.secondCorner.getBlockY(), this.firstCorner.getBlockY());
    }

    public int getUpperZ() {
        return Math.max(this.secondCorner.getBlockZ(), this.firstCorner.getBlockZ());
    }

    public int getLowerX() {
        return Math.min(this.firstCorner.getBlockX(), this.secondCorner.getBlockX());
    }

    public int getLowerY() {
        return Math.min(this.firstCorner.getBlockY(), this.secondCorner.getBlockY());
    }

    public int getLowerZ() {
        return Math.min(this.firstCorner.getBlockZ(), this.secondCorner.getBlockZ());
    }
}
