package cc.dreamcode.magicitems.drop;

import cc.dreamcode.utilities.randomizer.IntRandomizer;
import eu.okaeri.configs.schema.GenericsDeclaration;
import eu.okaeri.configs.serdes.DeserializationData;
import eu.okaeri.configs.serdes.ObjectSerializer;
import eu.okaeri.configs.serdes.SerializationData;
import lombok.NonNull;
import org.bukkit.inventory.ItemStack;

public class ItemDropSerializer implements ObjectSerializer<ItemDrop> {
    @Override
    public boolean supports(@NonNull Class<? super ItemDrop> type) {
        return ItemDrop.class.isAssignableFrom(type);
    }

    @Override
    public void serialize(@NonNull ItemDrop object, @NonNull SerializationData data, @NonNull GenericsDeclaration generics) {
        data.add("drop-chance", object.getChance());
        data.add("drop-amount", object.getDropAmount());
        data.add("drop-items", object.getItems());
        data.add("drop-commands", object.getCommands());
    }

    @Override
    public ItemDrop deserialize(@NonNull DeserializationData data, @NonNull GenericsDeclaration generics) {
        return new ItemDrop(
                data.get("drop-chance", Double.class),
                data.get("drop-amount", IntRandomizer.class),
                data.getAsList("drop-items", ItemStack.class),
                data.getAsList("drop-commands", String.class)
        );
    }
}
