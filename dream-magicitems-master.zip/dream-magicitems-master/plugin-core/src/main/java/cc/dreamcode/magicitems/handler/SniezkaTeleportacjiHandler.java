package cc.dreamcode.magicitems.handler;

import cc.dreamcode.magicitems.MagicItemType;
import cc.dreamcode.magicitems.config.MessageConfig;
import cc.dreamcode.magicitems.config.PluginConfig;
import cc.dreamcode.magicitems.config.subconfig.SniezkaTeleportacjiConfig;
import cc.dreamcode.magicitems.cooldown.Cooldown;
import cc.dreamcode.magicitems.cooldown.CooldownCache;
import cc.dreamcode.utilities.ChanceUtil;
import cc.dreamcode.utilities.TimeUtil;
import cc.dreamcode.utilities.builder.MapBuilder;
import eu.okaeri.injector.annotation.Inject;
import lombok.RequiredArgsConstructor;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.projectiles.ProjectileSource;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class SniezkaTeleportacjiHandler implements MagicItemHandler {

    private final PluginConfig pluginConfig;
    private final MessageConfig messageConfig;
    private final CooldownCache cooldownCache;

    private final List<Projectile> validProjectiles = new ArrayList<>();

    @Override
    public MagicItemType getMagicItemType() {
        return MagicItemType.SNIEZKA_TELEPORTACJI;
    }

    @EventHandler
    public void onProjectileLaunch(ProjectileLaunchEvent e) {
        final Projectile projectile = e.getEntity();
        final ProjectileSource projectileSource = projectile.getShooter();
        if (!(projectileSource instanceof Player)) {
            return;
        }

        final Player player = (Player) projectileSource;
        ItemStack itemInHand = player.getInventory().getItemInMainHand();
        if (!MagicItemType.isMagicItem(itemInHand, this.getMagicItemType())) {

            if (MagicItemType.isMagicItem(itemInHand, MagicItemType.GRANAT_UWIEZIENIA) ||
                    MagicItemType.isMagicItem(itemInHand, MagicItemType.GRANAT_ODPYCHANIA)) {
                return;
            }

            itemInHand = player.getInventory().getItemInOffHand();
        }

        if (!MagicItemType.isMagicItem(itemInHand, this.getMagicItemType())) {
            return;
        }

        final SniezkaTeleportacjiConfig sniezkaTeleportacjiConfig = this.pluginConfig.sniezkaTeleportacjiConfig;
        if (!sniezkaTeleportacjiConfig.throwOnBlockedRegion) {
            final Location location = player.getLocation();
            if (sniezkaTeleportacjiConfig.blockedRegions.stream().anyMatch(region -> region.isInside(location))) {
                if (sniezkaTeleportacjiConfig.allowedRegions.stream().noneMatch(region -> region.isInside(location))) {

                    if (!sniezkaTeleportacjiConfig.allowBypassPermission) {
                        e.setCancelled(true);

                        this.messageConfig.invalidRegion.send(player);
                        return;
                    }

                    if (!player.hasPermission(sniezkaTeleportacjiConfig.bypassPermission)) {
                        e.setCancelled(true);

                        this.messageConfig.invalidRegion.send(player);
                        return;
                    }
                }
            }
        }

        if (!sniezkaTeleportacjiConfig.cooldown.isNegative() && !sniezkaTeleportacjiConfig.cooldown.isZero()) {
            final Optional<Cooldown> optionalCooldown = this.cooldownCache.getCooldown(player, this.getMagicItemType());
            if (optionalCooldown.isPresent()) {
                e.setCancelled(true);

                final Cooldown cooldown = optionalCooldown.get();
                this.messageConfig.cooldown.send(player, new MapBuilder<String, Object>()
                        .put("time", TimeUtil.convertDurationMills(cooldown.getCounter()))
                        .build());
                return;
            }

            this.cooldownCache.applyCooldown(player, this.getMagicItemType(), sniezkaTeleportacjiConfig.cooldown);
        }

        this.validProjectiles.add(projectile);
    }

    @EventHandler
    public void onProjectileHit(ProjectileHitEvent e) {
        final Projectile projectile = e.getEntity();
        if (!this.validProjectiles.contains(projectile)) {
            return;
        }

        final ProjectileSource projectileSource = projectile.getShooter();
        if (!(projectileSource instanceof Player)) {
            return;
        }

        final Player source = (Player) projectileSource;
        final Location sourceLocation = source.getLocation().clone();

        if (e.getHitEntity() == null || !(e.getHitEntity() instanceof Player)) {
            return;
        }

        final Player target = (Player) e.getHitEntity();
        final Location targetLocation = target.getLocation().clone();

        final SniezkaTeleportacjiConfig sniezkaTeleportacjiConfig = this.pluginConfig.sniezkaTeleportacjiConfig;
        if (sniezkaTeleportacjiConfig.blockedRegions.stream().anyMatch(region -> region.isInside(targetLocation))) {
            if (sniezkaTeleportacjiConfig.allowedRegions.stream().noneMatch(region -> region.isInside(targetLocation))) {

                if (!sniezkaTeleportacjiConfig.allowBypassPermission) {
                    this.messageConfig.invalidRegion.send(source);
                    return;
                }

                if (!source.hasPermission(sniezkaTeleportacjiConfig.bypassPermission)) {
                    this.messageConfig.invalidRegion.send(source);
                    return;
                }
            }
        }

        if (ChanceUtil.reachChance(sniezkaTeleportacjiConfig.chance)) {
            source.teleport(targetLocation);

            if (sniezkaTeleportacjiConfig.swapLocations) {
                target.teleport(sourceLocation);
            }

            sniezkaTeleportacjiConfig.potionEffects.forEach(target::addPotionEffect);

            if (sniezkaTeleportacjiConfig.bypassSource) {
                sniezkaTeleportacjiConfig.potionEffects.forEach(source::addPotionEffect);
            }
        }
    }
}
