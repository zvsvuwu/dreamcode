package cc.dreamcode.magicitems.cooldown;

import cc.dreamcode.magicitems.MagicItemType;
import cc.dreamcode.utilities.builder.ListBuilder;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.bukkit.entity.Player;

import java.time.Duration;
import java.time.Instant;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

@RequiredArgsConstructor
public class CooldownCache {

    private final Map<UUID, List<Cooldown>> cooldownMap = new HashMap<>();

    public Optional<Cooldown> getCooldown(@NonNull Player player, @NonNull MagicItemType magicItemType) {
        this.check(player);

        if (!this.cooldownMap.containsKey(player.getUniqueId())) {
            return Optional.empty();
        }

        return this.cooldownMap.get(player.getUniqueId())
                .stream()
                .filter(cooldown -> cooldown.getMagicItemType().equals(magicItemType))
                .findAny();
    }

    public void applyCooldown(@NonNull Player player, @NonNull MagicItemType magicItemType, @NonNull Duration duration) {
        final Cooldown cooldown = new Cooldown(magicItemType, Instant.now(), duration);

        if (!this.cooldownMap.containsKey(player.getUniqueId())) {
            this.cooldownMap.put(player.getUniqueId(), ListBuilder.of(cooldown));
            return;
        }

        this.cooldownMap.get(player.getUniqueId()).add(cooldown);
    }

    public void removeCooldown(@NonNull Player player, @NonNull MagicItemType magicItemType) {

        if (!this.cooldownMap.containsKey(player.getUniqueId())) {
            return;
        }

        this.cooldownMap.get(player.getUniqueId()).removeIf(cooldown ->
                cooldown.getMagicItemType().equals(magicItemType));
    }

    public void checkAll(@NonNull Collection<? extends Player> players) {
        players.forEach(this::check);
    }

    private void check(@NonNull Player player) {
        if (!this.cooldownMap.containsKey(player.getUniqueId())) {
            return;
        }

        this.cooldownMap.get(player.getUniqueId()).removeIf(Cooldown::isOut);
    }
}
