package cc.dreamcode.magicitems.handler;

import cc.dreamcode.magicitems.MagicItem;
import cc.dreamcode.magicitems.MagicItemType;
import cc.dreamcode.magicitems.MagicItemsPlugin;
import cc.dreamcode.magicitems.config.MessageConfig;
import cc.dreamcode.magicitems.config.PluginConfig;
import cc.dreamcode.magicitems.config.subconfig.HakConfig;
import cc.dreamcode.magicitems.cooldown.Cooldown;
import cc.dreamcode.magicitems.cooldown.CooldownCache;
import cc.dreamcode.utilities.TimeUtil;
import cc.dreamcode.utilities.builder.MapBuilder;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import com.cryptomorin.xseries.XSound;
import eu.okaeri.injector.annotation.Inject;
import lombok.RequiredArgsConstructor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.Vector;

import java.util.Optional;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class HakHandler implements MagicItemHandler {

    private static final String TOTAL_USAGE = "TOTAL_USAGE";

    private final PluginConfig pluginConfig;
    private final MessageConfig messageConfig;
    private final CooldownCache cooldownCache;

    @Override
    public MagicItemType getMagicItemType() {
        return MagicItemType.HAK;
    }

    @EventHandler
    public void onFishingLineBreak(PlayerFishEvent e) {
        if (!e.getState().equals(PlayerFishEvent.State.REEL_IN)) {
            return;
        }

        final Player player = e.getPlayer();
        final HakConfig hakConfig = this.pluginConfig.hakConfig;

        int heldItemSlot = player.getInventory().getHeldItemSlot();
        ItemStack fishingRod = player.getInventory().getItem(heldItemSlot);
        if (fishingRod == null || !fishingRod.getType().equals(Material.FISHING_ROD)) {
            return;
        }

        if (!MagicItemType.isMagicItem(fishingRod, this.getMagicItemType())) {
            return;
        }

        final ItemMeta itemMeta = fishingRod.getItemMeta();
        assert itemMeta != null;

        final Damageable damageable = (Damageable) itemMeta;
        damageable.setDamage(0);

        final int usage = itemMeta.getPersistentDataContainer().getOrDefault(HakHandler.getTotalUsageKey(), PersistentDataType.INTEGER, 0);

        final Location location = e.getHook().getLocation();
        if (hakConfig.blockedRegions.stream().anyMatch(region -> region.isInside(location))) {
            if (hakConfig.allowedRegions.stream().noneMatch(region -> region.isInside(location))) {

                if (!hakConfig.allowBypassPermission) {
                    e.setCancelled(true);

                    this.messageConfig.invalidRegion.send(player);
                    return;
                }

                if (!player.hasPermission(hakConfig.bypassPermission)) {
                    e.setCancelled(true);

                    this.messageConfig.invalidRegion.send(player);
                    return;
                }
            }
        }

        if (!hakConfig.cooldown.isNegative() && !hakConfig.cooldown.isZero()) {
            final Optional<Cooldown> optionalCooldown = this.cooldownCache.getCooldown(player, this.getMagicItemType());
            if (optionalCooldown.isPresent()) {
                e.setCancelled(true);

                final Cooldown cooldown = optionalCooldown.get();
                this.messageConfig.cooldown.send(player, new MapBuilder<String, Object>()
                        .put("time", TimeUtil.convertDurationMills(cooldown.getCounter()))
                        .build());
                return;
            }

            this.cooldownCache.applyCooldown(player, this.getMagicItemType(), hakConfig.cooldown);
        }

        final int updateUsage = usage + 1;
        if (usage >= hakConfig.totalUsage) {
            player.getInventory().removeItem(fishingRod);
            assert XSound.ENTITY_ITEM_BREAK.parseSound() != null;
            player.playSound(player.getLocation(), XSound.ENTITY_ITEM_BREAK.parseSound(), 1F, 1F);
            return;
        }

        Vector hookVector = e.getHook().getLocation().toVector();
        Vector subtract = hookVector.subtract(player.getLocation().toVector());

        subtract.multiply(hakConfig.strength);
        subtract.setY(Math.min(subtract.getY(), hakConfig.maxHeight));
        player.setVelocity(subtract);

        this.pluginConfig.magicItems
                .stream()
                .filter(magicItem -> magicItem.getMagicItemType().equals(this.getMagicItemType()))
                .map(MagicItem::getFinalItem)
                .findAny()
                .ifPresent(magicItem -> {

                    final ItemMeta finalItemMeta = magicItem.getItemMeta();
                    assert finalItemMeta != null;
                    finalItemMeta.getPersistentDataContainer().set(HakHandler.getTotalUsageKey(), PersistentDataType.INTEGER, updateUsage);

                    magicItem.setItemMeta(finalItemMeta);
                    player.getInventory().setItem(heldItemSlot, ItemBuilder.of(magicItem)
                            .fixColors(new MapBuilder<String, Object>()
                                    .put("actual", updateUsage)
                                    .put("total", hakConfig.totalUsage)
                                    .build())
                            .toItemStack());
                });
    }

    private static NamespacedKey getTotalUsageKey() {
        return new NamespacedKey(MagicItemsPlugin.getMagicItemsPlugin(), HakHandler.TOTAL_USAGE);
    }
}
