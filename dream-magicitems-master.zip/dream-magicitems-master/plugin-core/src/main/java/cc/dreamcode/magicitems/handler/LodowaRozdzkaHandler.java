package cc.dreamcode.magicitems.handler;

import cc.dreamcode.magicitems.MagicItemType;
import cc.dreamcode.magicitems.config.MessageConfig;
import cc.dreamcode.magicitems.config.PluginConfig;
import cc.dreamcode.magicitems.config.subconfig.LodowaRozdzkaConfig;
import cc.dreamcode.magicitems.cooldown.Cooldown;
import cc.dreamcode.magicitems.cooldown.CooldownCache;
import cc.dreamcode.utilities.TimeUtil;
import cc.dreamcode.utilities.builder.MapBuilder;
import eu.okaeri.injector.annotation.Inject;
import lombok.RequiredArgsConstructor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.inventory.ItemStack;

import java.util.Optional;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class LodowaRozdzkaHandler implements MagicItemHandler {

    private final PluginConfig pluginConfig;
    private final MessageConfig messageConfig;
    private final CooldownCache cooldownCache;

    @Override
    public MagicItemType getMagicItemType() {
        return MagicItemType.LODOWA_ROZDZKA;
    }

    @EventHandler
    public void onEntityDamageByEntity(EntityDamageByEntityEvent e) {
        final Entity victimEntity = e.getEntity();
        if (!(victimEntity instanceof Player)) {
            return;
        }

        final Player victim = (Player) e.getEntity();

        final Entity damagerEntity = e.getDamager();
        if (!(damagerEntity instanceof Player)) {
            return;
        }

        final Player damager = (Player) damagerEntity;
        final ItemStack itemInHand = damager.getInventory().getItemInMainHand();
        if (itemInHand.getType().equals(Material.AIR)) {
            return;
        }

        if (!MagicItemType.isMagicItem(itemInHand, this.getMagicItemType())) {
            return;
        }

        final LodowaRozdzkaConfig lodowaRozdzkaConfig = this.pluginConfig.lodowaRozdzkaConfig;
        final Location location = victim.getLocation();
        if (lodowaRozdzkaConfig.blockedRegions.stream().anyMatch(region -> region.isInside(location))) {
            if (lodowaRozdzkaConfig.allowedRegions.stream().noneMatch(region -> region.isInside(location))) {

                if (!lodowaRozdzkaConfig.allowBypassPermission) {
                    e.setCancelled(true);

                    this.messageConfig.invalidRegion.send(damager);
                    return;
                }

                if (!damager.hasPermission(lodowaRozdzkaConfig.bypassPermission)) {
                    e.setCancelled(true);

                    this.messageConfig.invalidRegion.send(damager);
                    return;
                }
            }
        }

        if (!lodowaRozdzkaConfig.cooldown.isNegative() && !lodowaRozdzkaConfig.cooldown.isZero()) {
            final Optional<Cooldown> optionalCooldown = this.cooldownCache.getCooldown(damager, this.getMagicItemType());
            if (optionalCooldown.isPresent()) {
                e.setCancelled(true);

                final Cooldown cooldown = optionalCooldown.get();
                this.messageConfig.cooldown.send(damager, new MapBuilder<String, Object>()
                        .put("time", TimeUtil.convertDurationMills(cooldown.getCounter()))
                        .build());
                return;
            }

            this.cooldownCache.applyCooldown(damager, this.getMagicItemType(), lodowaRozdzkaConfig.cooldown);
        }

        if (!damager.getGameMode().equals(GameMode.CREATIVE)) {
            itemInHand.setAmount(itemInHand.getAmount() - 1);
            if (itemInHand.getAmount() <= 0) {
                damager.getInventory().removeItem(itemInHand);
            }
        }

        lodowaRozdzkaConfig.potionEffectTypes
                .stream()
                .filter(victim::hasPotionEffect)
                .forEach(victim::removePotionEffect);

        this.messageConfig.lodowaRozdzkaCalledVictim.send(victim, new MapBuilder<String, Object>()
                .put("nick", damager.getName())
                .build());

        this.messageConfig.lodowaRozdzkaCalled.send(damager, new MapBuilder<String, Object>()
                .put("nick", victim.getName())
                .build());
    }
}
