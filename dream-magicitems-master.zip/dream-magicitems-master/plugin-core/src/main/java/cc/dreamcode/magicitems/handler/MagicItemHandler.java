package cc.dreamcode.magicitems.handler;

import cc.dreamcode.magicitems.MagicItemType;
import org.bukkit.event.Listener;

public interface MagicItemHandler extends Listener {

    MagicItemType getMagicItemType();
}
