package cc.dreamcode.magicitems.config;

import cc.dreamcode.notice.minecraft.MinecraftNoticeType;
import cc.dreamcode.notice.minecraft.bukkit.BukkitNotice;
import cc.dreamcode.platform.bukkit.component.configuration.Configuration;
import eu.okaeri.configs.OkaeriConfig;
import eu.okaeri.configs.annotation.Header;
import eu.okaeri.configs.annotation.Headers;
import eu.okaeri.configs.annotation.NameModifier;
import eu.okaeri.configs.annotation.NameStrategy;
import eu.okaeri.configs.annotation.Names;

@Configuration(
        child = "message.yml"
)
@Headers({
        @Header("## Dream-MagicItems (Message-Config) ##"),
        @Header("Dostepne type: (DO_NOT_SEND, CHAT, ACTION_BAR, SUBTITLE, TITLE, TITLE_SUBTITLE)")
})
@Names(strategy = NameStrategy.HYPHEN_CASE, modifier = NameModifier.TO_LOWER_CASE)
public class MessageConfig extends OkaeriConfig {

    public BukkitNotice usage = new BukkitNotice(MinecraftNoticeType.CHAT, "&7Poprawne uzycie: &5{usage}");
    public BukkitNotice noPermission = new BukkitNotice(MinecraftNoticeType.CHAT, "&cNie posiadasz uprawnien.");
    public BukkitNotice notPlayer = new BukkitNotice(MinecraftNoticeType.CHAT, "&cNie jestes graczem aby to zrobic.");

    public BukkitNotice reloaded = new BukkitNotice(MinecraftNoticeType.CHAT, "&aPrzeladowano! &7({time})");
    public BukkitNotice reloadedTextures = new BukkitNotice(MinecraftNoticeType.CHAT, "&aPrzeladowano tekstury! &7({time})");
    public BukkitNotice reloadError = new BukkitNotice(MinecraftNoticeType.CHAT, "&cZnaleziono problem w konfiguracji: &6{error}");
    public BukkitNotice reloadTexturesError = new BukkitNotice(MinecraftNoticeType.CHAT, "&cTekstury sa wylaczone, sprawdz konfiguracje!");

    public BukkitNotice playerNotFound = new BukkitNotice(MinecraftNoticeType.CHAT, "&cPodanego gracza nie znaleziono.");
    public BukkitNotice numberIsNotValid = new BukkitNotice(MinecraftNoticeType.CHAT, "&cPodana liczba nie jest cyfra.");
    public BukkitNotice magicItemNotFound = new BukkitNotice(MinecraftNoticeType.CHAT, "&cNie znaleziono itemu o podanej nazwie.");

    public BukkitNotice magicItemGived = new BukkitNotice(MinecraftNoticeType.CHAT, "&aNadano magiczny przedmiot graczowi {nick}.");
    public BukkitNotice magicItemGivedAll = new BukkitNotice(MinecraftNoticeType.CHAT, "&aNadano wszystkim magiczny przedmiot.");
    public BukkitNotice magicItemReceived = new BukkitNotice(MinecraftNoticeType.CHAT, "&aOdebrano magiczny przedmiot, sprawdz ekwipunek.");

    public BukkitNotice invalidRegion = new BukkitNotice(MinecraftNoticeType.CHAT, "&cNie mozesz tego robic w tym miejscu.");
    public BukkitNotice cooldown = new BukkitNotice(MinecraftNoticeType.CHAT, "&cNie mozesz tego zrobic, poczekaj: &7{time}");

    public BukkitNotice miksturaOdmlodzeniaCalled = new BukkitNotice(MinecraftNoticeType.CHAT, "&aOdnowiono zycie.");
    public BukkitNotice serceWardenaCalled = new BukkitNotice(MinecraftNoticeType.CHAT, "&aNadano efekty gracza w poblizu.");
    public BukkitNotice okoYetiCalled = new BukkitNotice(MinecraftNoticeType.CHAT, "&aNadano efekty gracza w poblizu.");
    public BukkitNotice lampionCalled = new BukkitNotice(MinecraftNoticeType.DO_NOT_SEND, "&aNadano efekty.");
    public BukkitNotice sierscNiedzwiedziaCalled = new BukkitNotice(MinecraftNoticeType.DO_NOT_SEND, "&aNadano efekty.");
    public BukkitNotice lodowaRozdzkaCalled = new BukkitNotice(MinecraftNoticeType.CHAT, "&cUsunieto wszystkie pozytywne efekty graczowi {nick}.");
    public BukkitNotice lodowaRozdzkaCalledVictim = new BukkitNotice(MinecraftNoticeType.CHAT, "&cUsunieto tobie wszystkie pozytywne efekty.");

}
