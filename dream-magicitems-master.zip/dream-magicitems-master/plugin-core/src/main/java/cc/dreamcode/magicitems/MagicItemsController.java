package cc.dreamcode.magicitems;

import cc.dreamcode.magicitems.config.PluginConfig;
import cc.dreamcode.platform.DreamLogger;
import cc.dreamcode.utilities.bukkit.StringColorUtil;
import eu.okaeri.injector.annotation.Inject;
import lombok.RequiredArgsConstructor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.event.player.PlayerResourcePackStatusEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.CraftingInventory;
import org.bukkit.inventory.ItemStack;

import java.util.Arrays;
import java.util.Objects;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class MagicItemsController implements Listener {

    private final PluginConfig pluginConfig;
    private final MagicItemsService magicItemsService;
    private final MagicItemsCache magicItemsCache;
    private final DreamLogger dreamLogger;

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent e) {
        final Player player = e.getPlayer();

        if (this.pluginConfig.useResourcePack) {
            this.magicItemsCache.setLoadingScreen(player);
            this.magicItemsService.setLoadingEffects(player);
            this.magicItemsService.setResourcePack(player);
        }
    }

    @EventHandler
    public void onPlayerResourcePackLoad(PlayerResourcePackStatusEvent e) {
        final Player player = e.getPlayer();

        if (e.getStatus().equals(PlayerResourcePackStatusEvent.Status.DECLINED) ||
                e.getStatus().equals(PlayerResourcePackStatusEvent.Status.FAILED_DOWNLOAD)) {

            player.kickPlayer(StringColorUtil.fixColor(this.pluginConfig.resourcePackError));
            this.dreamLogger.info("Gracz " + player.getName() + " posiada problem z uruchomieniem paczki zasobow. (" + e.getStatus() + ")");
        }
        else if (e.getStatus().equals(PlayerResourcePackStatusEvent.Status.SUCCESSFULLY_LOADED)) {
            this.magicItemsService.unsetLoadingEffects(player);
            this.magicItemsCache.unsetLoadingScreen(player);
        }
    }

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent e) {
        final Player player = e.getPlayer();

        if (this.magicItemsCache.isLoadingScreen(player)) {
            if (e.getTo() != null && e.getFrom().distanceSquared(e.getTo()) != 0.0D) {
                e.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent e) {
        final Player player = e.getPlayer();

        if (this.magicItemsCache.isLoadingScreen(player)) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onPlayerItemDrop(PlayerDropItemEvent e) {
        final Player player = e.getPlayer();

        if (this.magicItemsCache.isLoadingScreen(player)) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onPlayerItemPickup(PlayerPickupItemEvent e) {
        final Player player = e.getPlayer();

        if (this.magicItemsCache.isLoadingScreen(player)) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onPlayerDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player)) {
            return;
        }

        final Player player = (Player) e.getEntity();

        if (this.magicItemsCache.isLoadingScreen(player)) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onPlayerTeleport(PlayerTeleportEvent e) {
        final Player player = e.getPlayer();

        if (this.magicItemsCache.isLoadingScreen(player)) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onItemCraft(CraftItemEvent e) {
        final CraftingInventory craftingInventory = e.getInventory();

        if (Arrays.stream(craftingInventory.getMatrix())
                .filter(Objects::nonNull)
                .anyMatch(MagicItemType::isMagicItem)) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onItemPreCraft(PrepareItemCraftEvent e) {
        final CraftingInventory craftingInventory = e.getInventory();

        if (Arrays.stream(craftingInventory.getMatrix())
                .filter(Objects::nonNull)
                .anyMatch(MagicItemType::isMagicItem)) {
            craftingInventory.setResult(new ItemStack(Material.AIR));
        }
    }


}
