package cc.dreamcode.magicitems.config.subconfig;

import cc.dreamcode.magicitems.drop.ItemDrop;
import cc.dreamcode.magicitems.region.Region;
import cc.dreamcode.utilities.builder.ListBuilder;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import cc.dreamcode.utilities.randomizer.IntRandomizer;
import com.cryptomorin.xseries.XMaterial;
import eu.okaeri.configs.OkaeriConfig;
import eu.okaeri.configs.annotation.Comment;
import org.bukkit.Bukkit;
import org.bukkit.Location;

import java.util.ArrayList;
import java.util.List;

public class SmoczaSiekieraConfig extends OkaeriConfig {

    @Comment("Czy ilosc ma byc przy kazdym itemie mieszana?")
    public boolean randomizeAmount = true;

    @Comment("Czy item ma leciec do eq kopiacego?")
    public boolean moveItemToInventory = true;

    @Comment("Jakie itemy maja wypadac podczas kopania tym itemem?")
    @Comment("Dostepne placeholdery dla komend: ({nick}, {amount})")
    public List<ItemDrop> dropItems = ListBuilder.of(new ItemDrop(
            20.0D,
            new IntRandomizer(1, 2),
            ListBuilder.of(new ItemBuilder(XMaterial.PRISMARINE_SHARD.parseItem())
                    .setName("&4&lSmoczy Odlamek")
                    .setLore("",
                            "&7Przedmiot mozesz wymienic na &fspawn")
                    .toItemStack()),
            new ArrayList<>()
    ));

    @Comment("W jakich regionach ma byc odblokowane uzywanie itemu?")
    public List<Region> allowedRegions = ListBuilder.of(
            new Region(
                    Bukkit.getWorlds().get(0),
                    new Location(Bukkit.getWorlds().get(0), -20.0D, 0.0D, -20.0D),
                    new Location(Bukkit.getWorlds().get(0), 20.0D, 256.0D, 20.0D)
            )
    );

    @Comment("W jakich regionach ma byc zablokowane uzywanie itemu?")
    public List<Region> blockedRegions = ListBuilder.of(
            new Region(
                    Bukkit.getWorlds().get(0),
                    new Location(Bukkit.getWorlds().get(0), -2000.0D, 0.0D, -2000.0D),
                    new Location(Bukkit.getWorlds().get(0), 2000.0D, 256.0D, 2000.0D)
            )
    );

    @Comment("Czy uprawnienia administratora maja umozliwiac uzycie przedmiotu na zablokowanych regionach?")
    public boolean allowBypassPermission = true;

    @Comment("Jakie uprawnienie nada mozliwosc ominiecia zablokowanego regionu?")
    public String bypassPermission = "dream.magicregion.bypass";
}
