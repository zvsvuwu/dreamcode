package cc.dreamcode.magicitems;

import lombok.Data;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

@Data
public class MagicItem {

    private final MagicItemType magicItemType;
    private final ItemStack item;
    private final int customModelData;

    public ItemStack getFinalItem() {
        final ItemStack itemStack = new ItemStack(this.item);
        final ItemMeta itemMeta = itemStack.getItemMeta();

        if (this.customModelData != -1) {
            assert itemMeta != null;
            itemMeta.setCustomModelData(this.customModelData);
        }

        itemStack.setItemMeta(itemMeta);
        return MagicItemType.setMagicItemType(itemStack, this.magicItemType);
    }
}
