package cc.dreamcode.magicitems.drop;

import cc.dreamcode.utilities.ChanceUtil;
import cc.dreamcode.utilities.randomizer.IntRandomizer;
import lombok.Data;
import org.bukkit.inventory.ItemStack;

import java.util.List;

@Data
public class ItemDrop {

    private final double chance;
    private final IntRandomizer dropAmount;
    private final List<ItemStack> items;
    private final List<String> commands;

    public boolean hasChance() {
        return ChanceUtil.reachChance(this.chance);
    }
}
