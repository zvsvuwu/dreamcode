package cc.dreamcode.magicitems.handler;

import cc.dreamcode.magicitems.MagicItemType;
import cc.dreamcode.magicitems.MagicItemsPlugin;
import cc.dreamcode.magicitems.config.MessageConfig;
import cc.dreamcode.magicitems.config.PluginConfig;
import cc.dreamcode.magicitems.config.subconfig.GranatOdpychaniaConfig;
import cc.dreamcode.magicitems.cooldown.Cooldown;
import cc.dreamcode.magicitems.cooldown.CooldownCache;
import cc.dreamcode.utilities.TimeUtil;
import cc.dreamcode.utilities.builder.MapBuilder;
import eu.okaeri.injector.annotation.Inject;
import lombok.RequiredArgsConstructor;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.projectiles.ProjectileSource;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class GranatOdpychaniaHandler implements MagicItemHandler {

    private final MagicItemsPlugin magicItemsPlugin;
    private final PluginConfig pluginConfig;
    private final MessageConfig messageConfig;
    private final CooldownCache cooldownCache;

    private final List<Projectile> validProjectiles = new ArrayList<>();

    @Override
    public MagicItemType getMagicItemType() {
        return MagicItemType.GRANAT_ODPYCHANIA;
    }

    @EventHandler
    public void onProjectileLaunch(ProjectileLaunchEvent e) {
        final Projectile projectile = e.getEntity();
        final ProjectileSource projectileSource = projectile.getShooter();
        if (!(projectileSource instanceof Player)) {
            return;
        }

        final Player player = (Player) projectileSource;
        ItemStack itemInHand = player.getInventory().getItemInMainHand();
        if (!MagicItemType.isMagicItem(itemInHand, this.getMagicItemType())) {

            if (MagicItemType.isMagicItem(itemInHand, MagicItemType.GRANAT_UWIEZIENIA) ||
                    MagicItemType.isMagicItem(itemInHand, MagicItemType.SNIEZKA_TELEPORTACJI)) {
                return;
            }

            itemInHand = player.getInventory().getItemInOffHand();
        }

        if (!MagicItemType.isMagicItem(itemInHand, this.getMagicItemType())) {
            return;
        }

        final GranatOdpychaniaConfig granatOdpychaniaConfig = this.pluginConfig.granatOdpychaniaConfig;
        if (!granatOdpychaniaConfig.throwOnBlockedRegion) {
            final Location location = player.getLocation();
            if (granatOdpychaniaConfig.blockedRegions.stream().anyMatch(region -> region.isInside(location))) {
                if (granatOdpychaniaConfig.allowedRegions.stream().noneMatch(region -> region.isInside(location))) {

                    if (!granatOdpychaniaConfig.allowBypassPermission) {
                        e.setCancelled(true);

                        this.messageConfig.invalidRegion.send(player);
                        return;
                    }

                    if (!player.hasPermission(granatOdpychaniaConfig.bypassPermission)) {
                        e.setCancelled(true);

                        this.messageConfig.invalidRegion.send(player);
                        return;
                    }
                }
            }
        }

        if (!granatOdpychaniaConfig.cooldown.isNegative() && !granatOdpychaniaConfig.cooldown.isZero()) {
            final Optional<Cooldown> optionalCooldown = this.cooldownCache.getCooldown(player, this.getMagicItemType());
            if (optionalCooldown.isPresent()) {
                e.setCancelled(true);

                final Cooldown cooldown = optionalCooldown.get();
                this.messageConfig.cooldown.send(player, new MapBuilder<String, Object>()
                        .put("time", TimeUtil.convertDurationMills(cooldown.getCounter()))
                        .build());
                return;
            }

            this.cooldownCache.applyCooldown(player, this.getMagicItemType(), granatOdpychaniaConfig.cooldown);
        }

        this.validProjectiles.add(projectile);
    }

    @EventHandler
    public void onProjectileHit(ProjectileHitEvent e) {
        final Projectile projectile = e.getEntity();
        if (!this.validProjectiles.contains(projectile)) {
            return;
        }

        final ProjectileSource projectileSource = projectile.getShooter();
        if (!(projectileSource instanceof Player)) {
            return;
        }

        final Player source = (Player) projectileSource;

        final GranatOdpychaniaConfig granatOdpychaniaConfig = this.pluginConfig.granatOdpychaniaConfig;
        final Location location = projectile.getLocation();
        if (granatOdpychaniaConfig.blockedRegions.stream().anyMatch(region -> region.isInside(location))) {
            if (granatOdpychaniaConfig.allowedRegions.stream().noneMatch(region -> region.isInside(location))) {

                if (!granatOdpychaniaConfig.allowBypassPermission) {
                    this.messageConfig.invalidRegion.send(source);
                    return;
                }

                if (!source.hasPermission(granatOdpychaniaConfig.bypassPermission)) {
                    this.messageConfig.invalidRegion.send(source);
                    return;
                }
            }
        }

        if (projectile.getLocation().getWorld() != null) {
            projectile.getLocation().getWorld().createExplosion(projectile.getLocation(), 3.0F, granatOdpychaniaConfig.fireBlocks, granatOdpychaniaConfig.destroyBlocks, source);
        }

        final List<Player> attackedPlayers = this.magicItemsPlugin.getServer().getOnlinePlayers()
                .stream()
                .filter(nearPlayer -> projectile.getLocation().distanceSquared(nearPlayer.getLocation()) <= granatOdpychaniaConfig.distance * 2)
                .filter(nearPlayer -> {

                    if (!granatOdpychaniaConfig.allowBypassPermission) {
                        if (granatOdpychaniaConfig.blockedRegions.stream().anyMatch(region -> region.isInside(location))) {
                            return granatOdpychaniaConfig.allowedRegions.stream().anyMatch(region -> region.isInside(location));
                        }
                    }

                    if (!source.hasPermission(granatOdpychaniaConfig.bypassPermission)) {
                        if (granatOdpychaniaConfig.blockedRegions.stream().anyMatch(region -> region.isInside(location))) {
                            return granatOdpychaniaConfig.allowedRegions.stream().anyMatch(region -> region.isInside(location));
                        }
                    }

                    return true;
                })
                .collect(Collectors.toList());

        attackedPlayers.forEach(player -> player.setVelocity(player.getLocation().clone()
                .subtract(projectile.getLocation())
                .toVector()
                .multiply(granatOdpychaniaConfig.multiplyDistance / player.getLocation().distance(projectile.getLocation()))
                .multiply(granatOdpychaniaConfig.vectorMultiply)
                .setY(Math.min(granatOdpychaniaConfig.height / player.getLocation().distance(projectile.getLocation()), granatOdpychaniaConfig.maxHeight))));
    }
}
