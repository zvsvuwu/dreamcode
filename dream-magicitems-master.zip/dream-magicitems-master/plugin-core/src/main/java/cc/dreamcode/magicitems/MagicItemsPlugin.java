package cc.dreamcode.magicitems;

import cc.dreamcode.command.bukkit.BukkitCommandProvider;
import cc.dreamcode.magicitems.command.MagicItemsCommand;
import cc.dreamcode.magicitems.config.MessageConfig;
import cc.dreamcode.magicitems.config.PluginConfig;
import cc.dreamcode.magicitems.config.serializer.IntRandomizerSerializer;
import cc.dreamcode.magicitems.cooldown.CooldownCache;
import cc.dreamcode.magicitems.cooldown.CooldownScheduler;
import cc.dreamcode.magicitems.drop.ItemDropSerializer;
import cc.dreamcode.magicitems.handler.ButySonicaHandler;
import cc.dreamcode.magicitems.handler.GranatOdpychaniaHandler;
import cc.dreamcode.magicitems.handler.GranatUwiezieniaHandler;
import cc.dreamcode.magicitems.handler.HakHandler;
import cc.dreamcode.magicitems.handler.LampionHandler;
import cc.dreamcode.magicitems.handler.LodowaRozdzkaHandler;
import cc.dreamcode.magicitems.handler.MiksturaOdmlodzeniaHandler;
import cc.dreamcode.magicitems.handler.OkoYetiHandler;
import cc.dreamcode.magicitems.handler.SerceWardenaHandler;
import cc.dreamcode.magicitems.handler.SierscNiedzwiedziaHandler;
import cc.dreamcode.magicitems.handler.SmoczaSiekieraHandler;
import cc.dreamcode.magicitems.handler.SniezkaTeleportacjiHandler;
import cc.dreamcode.magicitems.region.RegionSerializer;
import cc.dreamcode.menu.bukkit.BukkitMenuProvider;
import cc.dreamcode.menu.bukkit.okaeri.MenuBuilderSerdes;
import cc.dreamcode.notice.minecraft.bukkit.serdes.BukkitNoticeSerdes;
import cc.dreamcode.platform.DreamVersion;
import cc.dreamcode.platform.bukkit.DreamBukkitConfig;
import cc.dreamcode.platform.bukkit.DreamBukkitPlatform;
import cc.dreamcode.platform.bukkit.component.CommandComponentResolver;
import cc.dreamcode.platform.bukkit.component.ConfigurationComponentResolver;
import cc.dreamcode.platform.bukkit.component.ListenerComponentResolver;
import cc.dreamcode.platform.bukkit.component.RunnableComponentResolver;
import cc.dreamcode.platform.bukkit.exception.BukkitPluginException;
import cc.dreamcode.platform.component.ComponentManager;
import cc.dreamcode.utilities.bukkit.VersionUtil;
import eu.okaeri.configs.serdes.OkaeriSerdesPack;
import eu.okaeri.tasker.bukkit.BukkitTasker;
import lombok.Getter;
import lombok.NonNull;

public final class MagicItemsPlugin extends DreamBukkitPlatform implements DreamBukkitConfig {

    @Getter private static MagicItemsPlugin magicItemsPlugin;

    @Override
    public void load(@NonNull ComponentManager componentManager) {
        magicItemsPlugin = this;
    }

    @Override
    public void enable(@NonNull ComponentManager componentManager) {
        componentManager.setDebug(false);

        if (!VersionUtil.isSupported(14)) {
            throw new BukkitPluginException("The plugin only works with server version 1.14+.");
        }

        componentManager.registerResolver(ConfigurationComponentResolver.class);
        componentManager.registerComponent(PluginConfig.class, pluginConfig -> {
            if (pluginConfig.useResourcePack && pluginConfig.resourcePackUrl.isEmpty()) {
                throw new BukkitPluginException("Plugin ma wlaczona opcje resource-pack w configu i nie posiada linku, uzupelnij go.");
            }
        });

        componentManager.registerComponent(MessageConfig.class, messageConfig ->
                this.getInject(BukkitCommandProvider.class).ifPresent(bukkitCommandProvider -> {
                    bukkitCommandProvider.setRequiredPermissionMessage(messageConfig.noPermission.getText());
                    bukkitCommandProvider.setRequiredPlayerMessage(messageConfig.notPlayer.getText());
                }));

        this.getInjector().registerInjectable(BukkitTasker.newPool(this));
        this.getInjector().registerInjectable(BukkitCommandProvider.create(this));
        this.getInjector().registerInjectable(BukkitMenuProvider.create(this));

        componentManager.registerResolver(CommandComponentResolver.class);
        componentManager.registerResolver(ListenerComponentResolver.class);
        componentManager.registerResolver(RunnableComponentResolver.class);

        componentManager.registerComponent(CooldownCache.class);
        componentManager.registerComponent(CooldownScheduler.class);

        componentManager.registerComponent(MagicItemsCache.class);
        componentManager.registerComponent(MagicItemsService.class);
        componentManager.registerComponent(MagicItemsController.class);
        componentManager.registerComponent(MagicItemsCommand.class);

        componentManager.registerComponent(HakHandler.class);
        componentManager.registerComponent(GranatOdpychaniaHandler.class);
        componentManager.registerComponent(GranatUwiezieniaHandler.class);
        componentManager.registerComponent(GranatUwiezieniaHandler.CobwebCleanScheduler.class);
        componentManager.registerComponent(SmoczaSiekieraHandler.class);
        componentManager.registerComponent(SerceWardenaHandler.class);
        componentManager.registerComponent(SniezkaTeleportacjiHandler.class);
        componentManager.registerComponent(ButySonicaHandler.class);
        componentManager.registerComponent(LampionHandler.class);
        componentManager.registerComponent(MiksturaOdmlodzeniaHandler.class);
        componentManager.registerComponent(SierscNiedzwiedziaHandler.class);
        componentManager.registerComponent(OkoYetiHandler.class);
        componentManager.registerComponent(LodowaRozdzkaHandler.class);
    }

    @Override
    public void disable() {
        // features need to be call when server is stopping
    }

    @Override
    public @NonNull DreamVersion getDreamVersion() {
        return DreamVersion.create("Dream-MagicItems", "1.0.6", "Ravis96");
    }

    @Override
    public @NonNull OkaeriSerdesPack getConfigSerdesPack() {
        return registry -> {
            registry.register(new BukkitNoticeSerdes());
            registry.register(new MenuBuilderSerdes());
            registry.register(new IntRandomizerSerializer());
            registry.register(new MagicItemSerializer());
            registry.register(new ItemDropSerializer());
            registry.register(new RegionSerializer());
        };
    }
}
