package cc.dreamcode.magicitems.config.subconfig;

import cc.dreamcode.magicitems.region.Region;
import cc.dreamcode.utilities.builder.ListBuilder;
import eu.okaeri.configs.OkaeriConfig;
import eu.okaeri.configs.annotation.Comment;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.time.Duration;
import java.util.List;

public class SniezkaTeleportacjiConfig extends OkaeriConfig {

    @Comment("Jaki cooldown ma byc zastosowany dla sniezki?")
    public Duration cooldown = Duration.ofSeconds(3L);

    @Comment("Jaka ma byc szansa na teleport?")
    public double chance = 50.0D;

    @Comment("Czy gracz ma byc zamieniany pozycjami?")
    public boolean swapLocations = false;

    @Comment("Czy gracz nadajacy ma otrzymac efekty?")
    public boolean bypassSource = false;

    @Comment("Jakie efekty maja byc nadawne na graczu atakowanym?")
    public List<PotionEffect> potionEffects = ListBuilder.of(new PotionEffect(PotionEffectType.SLOW, 300, 0));

    @Comment("W jakich regionach ma byc odblokowane uzywanie itemu?")
    public List<Region> allowedRegions = ListBuilder.of(
            new Region(
                    Bukkit.getWorlds().get(0),
                    new Location(Bukkit.getWorlds().get(0), -20.0D, 0.0D, -20.0D),
                    new Location(Bukkit.getWorlds().get(0), 20.0D, 256.0D, 20.0D)
            )
    );

    @Comment("W jakich regionach ma byc zablokowane uzywanie itemu?")
    public List<Region> blockedRegions = ListBuilder.of(
            new Region(
                    Bukkit.getWorlds().get(0),
                    new Location(Bukkit.getWorlds().get(0), -2000.0D, 0.0D, -2000.0D),
                    new Location(Bukkit.getWorlds().get(0), 2000.0D, 256.0D, 2000.0D)
            )
    );

    @Comment("Czy ma byc blokowana mozliwosc rzutu z zablokowanego regionu?")
    public boolean throwOnBlockedRegion = true;

    @Comment("Czy uprawnienia administratora maja umozliwiac uzycie przedmiotu na zablokowanych regionach?")
    public boolean allowBypassPermission = true;

    @Comment("Jakie uprawnienie nada mozliwosc ominiecia zablokowanego regionu?")
    public String bypassPermission = "dream.magicregion.bypass";
}