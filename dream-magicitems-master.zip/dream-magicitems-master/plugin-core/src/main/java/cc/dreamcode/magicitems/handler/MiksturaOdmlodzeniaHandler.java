package cc.dreamcode.magicitems.handler;

import cc.dreamcode.magicitems.MagicItemType;
import cc.dreamcode.magicitems.config.MessageConfig;
import cc.dreamcode.magicitems.config.PluginConfig;
import cc.dreamcode.magicitems.config.subconfig.MiksturaOdmlodzeniaConfig;
import cc.dreamcode.magicitems.cooldown.Cooldown;
import cc.dreamcode.magicitems.cooldown.CooldownCache;
import cc.dreamcode.utilities.TimeUtil;
import cc.dreamcode.utilities.builder.MapBuilder;
import eu.okaeri.injector.annotation.Inject;
import lombok.RequiredArgsConstructor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.inventory.ItemStack;

import java.util.Optional;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class MiksturaOdmlodzeniaHandler implements MagicItemHandler {

    private final PluginConfig pluginConfig;
    private final MessageConfig messageConfig;
    private final CooldownCache cooldownCache;

    @Override
    public MagicItemType getMagicItemType() {
        return MagicItemType.MIKSTURA_ODMLODZENIA;
    }

    @EventHandler
    public void onPlayerItemConsume(PlayerItemConsumeEvent e) {
        final Player player = e.getPlayer();
        final ItemStack itemUsed = e.getItem();
        if (!MagicItemType.isMagicItem(itemUsed, this.getMagicItemType())) {
            return;
        }

        final MiksturaOdmlodzeniaConfig miksturaOdmlodzeniaConfig = this.pluginConfig.miksturaOdmlodzeniaConfig;
        final Location location = player.getLocation();
        if (miksturaOdmlodzeniaConfig.blockedRegions.stream().anyMatch(region -> region.isInside(location))) {
            if (miksturaOdmlodzeniaConfig.allowedRegions.stream().noneMatch(region -> region.isInside(location))) {

                if (!miksturaOdmlodzeniaConfig.allowBypassPermission) {
                    e.setCancelled(true);

                    this.messageConfig.invalidRegion.send(player);
                    return;
                }

                if (!player.hasPermission(miksturaOdmlodzeniaConfig.bypassPermission)) {
                    e.setCancelled(true);

                    this.messageConfig.invalidRegion.send(player);
                    return;
                }
            }
        }

        if (!miksturaOdmlodzeniaConfig.cooldown.isNegative() && !miksturaOdmlodzeniaConfig.cooldown.isZero()) {
            final Optional<Cooldown> optionalCooldown = this.cooldownCache.getCooldown(player, this.getMagicItemType());
            if (optionalCooldown.isPresent()) {
                e.setCancelled(true);

                final Cooldown cooldown = optionalCooldown.get();
                this.messageConfig.cooldown.send(player, new MapBuilder<String, Object>()
                        .put("time", TimeUtil.convertDurationMills(cooldown.getCounter()))
                        .build());
                return;
            }

            this.cooldownCache.applyCooldown(player, this.getMagicItemType(), miksturaOdmlodzeniaConfig.cooldown);
        }

        if (!player.getGameMode().equals(GameMode.CREATIVE)) {
            itemUsed.setAmount(itemUsed.getAmount() - 1);
            if (itemUsed.getAmount() <= 0) {
                player.getInventory().removeItem(itemUsed);
            }
        }

        player.setHealth(player.getMaxHealth());
        this.messageConfig.miksturaOdmlodzeniaCalled.send(player);
    }
}
