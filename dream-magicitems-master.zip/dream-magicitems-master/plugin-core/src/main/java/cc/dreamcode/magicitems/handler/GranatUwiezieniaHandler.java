package cc.dreamcode.magicitems.handler;

import cc.dreamcode.magicitems.MagicItemType;
import cc.dreamcode.magicitems.config.MessageConfig;
import cc.dreamcode.magicitems.config.PluginConfig;
import cc.dreamcode.magicitems.config.subconfig.GranatUwiezieniaConfig;
import cc.dreamcode.magicitems.cooldown.Cooldown;
import cc.dreamcode.magicitems.cooldown.CooldownCache;
import cc.dreamcode.platform.bukkit.component.scheduler.Scheduler;
import cc.dreamcode.utilities.CountUtil;
import cc.dreamcode.utilities.TimeUtil;
import cc.dreamcode.utilities.builder.MapBuilder;
import eu.okaeri.injector.annotation.Inject;
import lombok.RequiredArgsConstructor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.projectiles.ProjectileSource;

import java.time.Instant;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class GranatUwiezieniaHandler implements MagicItemHandler {

    private final PluginConfig pluginConfig;
    private final MessageConfig messageConfig;
    private final CooldownCache cooldownCache;

    private final List<Projectile> validProjectiles = new ArrayList<>();
    private final Map<Instant, List<Location>> cobwebs = new HashMap<>();

    @Override
    public MagicItemType getMagicItemType() {
        return MagicItemType.GRANAT_UWIEZIENIA;
    }

    @EventHandler
    public void onProjectileLaunch(ProjectileLaunchEvent e) {
        final Projectile projectile = e.getEntity();
        final ProjectileSource projectileSource = projectile.getShooter();
        if (!(projectileSource instanceof Player)) {
            return;
        }

        final Player player = (Player) projectileSource;
        ItemStack itemInHand = player.getInventory().getItemInMainHand();
        if (!MagicItemType.isMagicItem(itemInHand, this.getMagicItemType())) {

            if (MagicItemType.isMagicItem(itemInHand, MagicItemType.GRANAT_ODPYCHANIA) ||
                    MagicItemType.isMagicItem(itemInHand, MagicItemType.SNIEZKA_TELEPORTACJI)) {
                return;
            }

            itemInHand = player.getInventory().getItemInOffHand();
        }

        if (!MagicItemType.isMagicItem(itemInHand, this.getMagicItemType())) {
            return;
        }

        final GranatUwiezieniaConfig granatUwiezieniaConfig = this.pluginConfig.granatUwiezieniaConfig;
        if (!granatUwiezieniaConfig.throwOnBlockedRegion) {
            final Location location = player.getLocation();
            if (granatUwiezieniaConfig.blockedRegions.stream().anyMatch(region -> region.isInside(location))) {
                if (granatUwiezieniaConfig.allowedRegions.stream().noneMatch(region -> region.isInside(location))) {

                    if (!granatUwiezieniaConfig.allowBypassPermission) {
                        e.setCancelled(true);

                        this.messageConfig.invalidRegion.send(player);
                        return;
                    }

                    if (!player.hasPermission(granatUwiezieniaConfig.bypassPermission)) {
                        e.setCancelled(true);

                        this.messageConfig.invalidRegion.send(player);
                        return;
                    }
                }
            }
        }

        if (!granatUwiezieniaConfig.cooldown.isNegative() && !granatUwiezieniaConfig.cooldown.isZero()) {
            final Optional<Cooldown> optionalCooldown = this.cooldownCache.getCooldown(player, this.getMagicItemType());
            if (optionalCooldown.isPresent()) {
                e.setCancelled(true);

                final Cooldown cooldown = optionalCooldown.get();
                this.messageConfig.cooldown.send(player, new MapBuilder<String, Object>()
                        .put("time", TimeUtil.convertDurationMills(cooldown.getCounter()))
                        .build());
                return;
            }

            this.cooldownCache.applyCooldown(player, this.getMagicItemType(), granatUwiezieniaConfig.cooldown);
        }

        this.validProjectiles.add(projectile);
    }

    @EventHandler
    public void onProjectileHit(ProjectileHitEvent e) {
        final Projectile projectile = e.getEntity();
        if (!this.validProjectiles.contains(projectile)) {
            return;
        }

        final ProjectileSource projectileSource = projectile.getShooter();
        if (!(projectileSource instanceof Player)) {
            return;
        }

        final Player source = (Player) projectileSource;

        final GranatUwiezieniaConfig granatUwiezieniaConfig = this.pluginConfig.granatUwiezieniaConfig;
        final Location location = projectile.getLocation();
        if (granatUwiezieniaConfig.blockedRegions.stream().anyMatch(region -> region.isInside(location))) {
            if (granatUwiezieniaConfig.allowedRegions.stream().noneMatch(region -> region.isInside(location))) {

                if (!granatUwiezieniaConfig.allowBypassPermission) {
                    this.messageConfig.invalidRegion.send(source);
                    return;
                }

                if (!source.hasPermission(granatUwiezieniaConfig.bypassPermission)) {
                    this.messageConfig.invalidRegion.send(source);
                    return;
                }
            }
        }

        final World world = projectile.getWorld();
        final List<Location> locations = new ArrayList<>();
        for (int y = 0; y < granatUwiezieniaConfig.height; y++) {
            for (int x = -granatUwiezieniaConfig.length / 2; x < granatUwiezieniaConfig.length / 2; x++) {
                for (int z = -granatUwiezieniaConfig.width / 2; z < granatUwiezieniaConfig.width / 2; z++) {
                    final Block block = world.getBlockAt(location.getBlockX() + x, location.getBlockY() + y, location.getBlockZ() + z);

                    if (granatUwiezieniaConfig.blockedRegions.stream().anyMatch(region -> region.isInside(block.getLocation()))) {
                        if (granatUwiezieniaConfig.allowedRegions.stream().noneMatch(region -> region.isInside(block.getLocation()))) {
                            continue;
                        }
                    }

                    if (block.getType().equals(Material.AIR)) {
                        block.setType(Material.COBWEB);
                        locations.add(block.getLocation());
                    }
                }
            }
        }

        this.cobwebs.put(Instant.now(), locations);
    }

    public void clearCobwebs() {
        final GranatUwiezieniaConfig granatUwiezieniaConfig = this.pluginConfig.granatUwiezieniaConfig;
        final List<Map.Entry<Instant, List<Location>>> instants = this.cobwebs.entrySet()
                .stream()
                .filter(entry -> CountUtil.isOut(CountUtil.getCountDown(entry.getKey(), granatUwiezieniaConfig.cobwebDuration)))
                .collect(Collectors.toList());

        instants.forEach(entry -> {
            this.cobwebs.remove(entry.getKey());

            entry.getValue().forEach(location -> {
                final Block block = location.getBlock();
                if (block.getType().equals(Material.COBWEB)) {
                    block.setType(Material.AIR);
                }
            });
        });
    }

    @Scheduler(async = false, delay = 20, interval = 20)
    @RequiredArgsConstructor(onConstructor_ = @Inject)
    public static class CobwebCleanScheduler implements Runnable {

        private final GranatUwiezieniaHandler granatUwiezieniaHandler;

        @Override
        public void run() {
            this.granatUwiezieniaHandler.clearCobwebs();
        }
    }
}
