package cc.dreamcode.magicitems.config;

import cc.dreamcode.magicitems.MagicItem;
import cc.dreamcode.magicitems.MagicItemType;
import cc.dreamcode.magicitems.config.subconfig.ButySonicaConfig;
import cc.dreamcode.magicitems.config.subconfig.GranatOdpychaniaConfig;
import cc.dreamcode.magicitems.config.subconfig.GranatUwiezieniaConfig;
import cc.dreamcode.magicitems.config.subconfig.HakConfig;
import cc.dreamcode.magicitems.config.subconfig.LampionConfig;
import cc.dreamcode.magicitems.config.subconfig.LodowaRozdzkaConfig;
import cc.dreamcode.magicitems.config.subconfig.MiksturaOdmlodzeniaConfig;
import cc.dreamcode.magicitems.config.subconfig.OkoYetiConfig;
import cc.dreamcode.magicitems.config.subconfig.SerceWardenaConfig;
import cc.dreamcode.magicitems.config.subconfig.SierscNiedzwiedziaConfig;
import cc.dreamcode.magicitems.config.subconfig.SmoczaSiekieraConfig;
import cc.dreamcode.magicitems.config.subconfig.SniezkaTeleportacjiConfig;
import cc.dreamcode.menu.bukkit.BukkitMenuBuilder;
import cc.dreamcode.platform.bukkit.component.configuration.Configuration;
import cc.dreamcode.utilities.builder.ListBuilder;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import com.cryptomorin.xseries.XMaterial;
import eu.okaeri.configs.OkaeriConfig;
import eu.okaeri.configs.annotation.Comment;
import eu.okaeri.configs.annotation.Header;
import eu.okaeri.configs.annotation.NameModifier;
import eu.okaeri.configs.annotation.NameStrategy;
import eu.okaeri.configs.annotation.Names;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;

import java.util.HashMap;
import java.util.List;

@Configuration(
        child = "config.yml"
)
@Header("## Dream-MagicItems (Main-Config) ##")
@Names(strategy = NameStrategy.HYPHEN_CASE, modifier = NameModifier.TO_LOWER_CASE)
public class PluginConfig extends OkaeriConfig {

    @Comment
    @Comment("Czy plugin ma uzywac custom resource-packa?")
    public boolean useResourcePack = false;

    @Comment
    @Comment("Podaj adres do zip paczki zasobow na zewnetrznym hostingu.")
    @Comment("Rekomendujemy uzywanie serwisu DropBox do hostowania pliku zip.")
    public String resourcePackUrl = "";
    public String resourcePackSha1 = "";

    @Comment
    @Comment("Jaki wyslac powod, gdy gracz odmowi pobieranie paczki lub gdy wyskoczy blad?")
    public String resourcePackError = "&cWystapil problem z uruchomieniem paczki zasobow. Sprobuj ponownie.";

    @Comment
    @Comment("Ponizej plugin przedstawia wszystkie aktywne magic-items.")
    @Comment("Plugin umozliwia nalozenie tekstury z resource-packa, wpisz id textury w magic-item-id. (custom model data)")
    @Comment("Dostepne type: (HAK, GRANAT_ODPYCHANIA, GRANAT_UWIEZIENIA, SMOCZA_SIEKIERA, SERCE_WARDENA, SNIEZKA_TELEPORTACJI, BUTY_SONICA, LAMPION, MIKSTURA_ODMLODZENIA, SIERSC_NIEDZWIEDZIA,  OKO_YETI, NOS_OLAFA, LODOWA_ROZDZKA)")
    public List<MagicItem> magicItems = new ListBuilder<MagicItem>()
            .add(new MagicItem(
                    MagicItemType.HAK,
                    new ItemBuilder(XMaterial.FISHING_ROD.parseItem())
                            .setName("&6Hak")
                            .setLore("",
                                    "&7Kliknij &fPPM&7, aby zaczepic sie!",
                                    "&7Zuzycie: &f&l{actual}/{total}")
                            .toItemStack(),
                    10010
            ))
            .add(new MagicItem(
                    MagicItemType.GRANAT_ODPYCHANIA,
                    new ItemBuilder(XMaterial.SNOWBALL.parseItem())
                            .setName("&6Granat odpychania")
                            .setLore("",
                                    "&7Kliknij &fPPM&7, aby rzucic granat!")
                            .toItemStack(),
                    10011
            ))
            .add(new MagicItem(
                    MagicItemType.GRANAT_UWIEZIENIA,
                    new ItemBuilder(XMaterial.SNOWBALL.parseItem())
                            .setName("&6Granat uwiezienia")
                            .setLore("",
                                    "&7Kliknij &fPPM&7, aby rzucic granat!")
                            .toItemStack(),
                    10012
            ))
            .add(new MagicItem(
                    MagicItemType.SMOCZA_SIEKIERA,
                    new ItemBuilder(XMaterial.DIAMOND_AXE.parseItem())
                            .setName("&cSmocza siekiera")
                            .setLore("",
                                    "&7Kopiac ja, masz szanse na ",
                                    "&7wydropienie &4&lSmoczych Odlamkow")
                            .addEnchant(Enchantment.DIG_SPEED, 5, true)
                            .addEnchant(Enchantment.DURABILITY, 3, true)
                            .toItemStack(),
                    10013
            ))
            .add(new MagicItem(
                    MagicItemType.SERCE_WARDENA,
                    new ItemBuilder(XMaterial.RED_DYE.parseItem())
                            .setName("&cSerce wardena")
                            .setLore("",
                                    "&7Kliknij &fPPM&7, aby oslepic kazdego wokol!")
                            .toItemStack(),
                    10014
            ))
            .add(new MagicItem(
                    MagicItemType.SNIEZKA_TELEPORTACJI,
                    new ItemBuilder(XMaterial.SNOWBALL.parseItem())
                            .setName("&6Sniezka teleportacji")
                            .setLore("",
                                    "&7Gdy trafisz sniezka w gracza, masz ",
                                    "&7szanse na teleport do niego z efektem spowolnienia!",
                                    "",
                                    "&7Kliknij &fPPM&7, aby rzucic sniezke!")
                            .addEnchant(Enchantment.DURABILITY, 1, true)
                            .addFlags(ItemFlag.HIDE_ENCHANTS)
                            .toItemStack(),
                    10015
            ))
            .add(new MagicItem(
                    MagicItemType.BUTY_SONICA,
                    new ItemBuilder(XMaterial.DIAMOND_BOOTS.parseItem())
                            .setName("&9Buty sonica")
                            .setLore("",
                                    "&7Zaloz je, aby uzyskac dodatkowe &fefekty&7!")
                            .addEnchant(Enchantment.PROTECTION_ENVIRONMENTAL, 4, true)
                            .addEnchant(Enchantment.DURABILITY, 3, true)
                            .toItemStack(),
                    10016
            ))
            .add(new MagicItem(
                    MagicItemType.LAMPION,
                    new ItemBuilder(XMaterial.YELLOW_DYE.parseItem())
                            .setName("&9Lampion")
                            .setLore("",
                                    "&7Kliknij &fPPM&7, aby uzyskac dodatkowe &fefekty&7!")
                            .toItemStack(),
                    10017
            ))
            .add(new MagicItem(
                    MagicItemType.MIKSTURA_ODMLODZENIA,
                    new ItemBuilder(XMaterial.POTION.parseItem())
                            .setName("&6Mikstura odmlodzenia")
                            .setLore("",
                                    "&7Wypij &fmiksture&7, aby zregenerowac &czycie&7!")
                            .toItemStack(),
                    10018
            ))
            .add(new MagicItem(
                    MagicItemType.SIERSC_NIEDZWIEDZIA,
                    new ItemBuilder(XMaterial.LEATHER.parseItem())
                            .setName("&3Siersc Niedzwiedzia Polarnego")
                            .setLore("",
                                    "&7Kliknij &fPPM&7, aby przez kilka sekund ",
                                    "&7tracic &7mniej &czycia&7!")
                            .toItemStack(),
                    10019
            ))
            .add(new MagicItem(
                    MagicItemType.OKO_YETI,
                    new ItemBuilder(XMaterial.WHITE_DYE.parseItem())
                            .setName("&fOko yeti")
                            .setLore("",
                                    "&7Kliknij &fPPM&7, aby nadac wokol ",
                                    "&7graczom &fefekt mdlosci&7!")
                            .toItemStack(),
                    10020
            ))
            .add(new MagicItem(
                    MagicItemType.NOS_OLAFA,
                    new ItemBuilder(XMaterial.STICK.parseItem())
                            .setName("&7Nos olafa")
                            .addEnchant(Enchantment.KNOCKBACK, 4, true)
                            .toItemStack(),
                    10021
            ))
            .add(new MagicItem(
                    MagicItemType.LODOWA_ROZDZKA,
                    new ItemBuilder(XMaterial.STICK.parseItem())
                            .setName("&3Lodowa rozdzka")
                            .setLore("&7Uzycie zabiera wszystkie ",
                                    "&fpozytywne efekty &7graczowi atakowanemu&7.")
                            .toItemStack(),
                    10022
            ))
            .build();

    @Comment
    @Comment("Jak ma wygladac menu od pobierania itemow dla administacji?")
    public BukkitMenuBuilder menuBuilder = new BukkitMenuBuilder("&8[&bM&8] Magic items", 2, new HashMap<>());

    @Comment
    @Comment("Konfiguracje poszczegolnych itemow:")
    public HakConfig hakConfig = new HakConfig();

    @Comment
    public GranatOdpychaniaConfig granatOdpychaniaConfig = new GranatOdpychaniaConfig();

    @Comment
    public GranatUwiezieniaConfig granatUwiezieniaConfig = new GranatUwiezieniaConfig();

    @Comment
    public SmoczaSiekieraConfig smoczaSiekieraConfig = new SmoczaSiekieraConfig();

    @Comment
    public SerceWardenaConfig serceWardenaConfig = new SerceWardenaConfig();

    @Comment
    public SniezkaTeleportacjiConfig sniezkaTeleportacjiConfig = new SniezkaTeleportacjiConfig();

    @Comment
    public ButySonicaConfig butySonicaConfig = new ButySonicaConfig();

    @Comment
    public LampionConfig lampionConfig = new LampionConfig();

    @Comment
    public MiksturaOdmlodzeniaConfig miksturaOdmlodzeniaConfig = new MiksturaOdmlodzeniaConfig();

    @Comment
    public SierscNiedzwiedziaConfig sierscNiedzwiedziaConfig = new SierscNiedzwiedziaConfig();

    @Comment
    public OkoYetiConfig okoYetiConfig = new OkoYetiConfig();

    @Comment
    public LodowaRozdzkaConfig lodowaRozdzkaConfig = new LodowaRozdzkaConfig();

}
