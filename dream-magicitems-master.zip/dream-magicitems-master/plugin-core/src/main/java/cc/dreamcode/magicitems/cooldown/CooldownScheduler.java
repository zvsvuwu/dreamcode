package cc.dreamcode.magicitems.cooldown;

import cc.dreamcode.magicitems.MagicItemsPlugin;
import cc.dreamcode.platform.bukkit.component.scheduler.Scheduler;
import eu.okaeri.injector.annotation.Inject;
import lombok.RequiredArgsConstructor;

@Scheduler(delay = 100, interval = 100)
@RequiredArgsConstructor(onConstructor_ = @Inject)
public class CooldownScheduler implements Runnable {

    private final MagicItemsPlugin magicItemsPlugin;
    private final CooldownCache cooldownCache;

    @Override
    public void run() {
        this.cooldownCache.checkAll(this.magicItemsPlugin.getServer().getOnlinePlayers());
    }
}
