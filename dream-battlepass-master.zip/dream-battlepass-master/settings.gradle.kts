rootProject.name = "dream-battlepass"

include(":plugin-core")