package cc.dreamcode.battlepass.expansion;

import cc.dreamcode.platform.bukkit.hook.PluginHook;
import cc.dreamcode.platform.bukkit.hook.annotation.Hook;
import lombok.NonNull;

@Hook(name = "PlaceholderAPI")
public class PlaceholderApiHook implements PluginHook {

    public void register(@NonNull PlaceholderExpansionWrapper placeholderExpansionWrapper) {
        placeholderExpansionWrapper.wrap().register();
    }
}
