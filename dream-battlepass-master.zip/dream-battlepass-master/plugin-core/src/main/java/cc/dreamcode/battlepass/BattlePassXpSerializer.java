package cc.dreamcode.battlepass;

import eu.okaeri.configs.schema.GenericsDeclaration;
import eu.okaeri.configs.serdes.DeserializationData;
import eu.okaeri.configs.serdes.ObjectSerializer;
import eu.okaeri.configs.serdes.SerializationData;
import lombok.NonNull;

public class BattlePassXpSerializer implements ObjectSerializer<BattlePassXp> {
    @Override
    public boolean supports(@NonNull Class<? super BattlePassXp> type) {
        return BattlePassXp.class.isAssignableFrom(type);
    }

    @Override
    public void serialize(@NonNull BattlePassXp object, @NonNull SerializationData data, @NonNull GenericsDeclaration generics) {
        data.add("min-value", object.getMinValue());
        data.add("max-value", object.getMaxValue());
    }

    @Override
    public BattlePassXp deserialize(@NonNull DeserializationData data, @NonNull GenericsDeclaration generics) {
        return new BattlePassXp(
                data.get("min-value", Integer.class),
                data.get("max-value", Integer.class)
        );
    }
}
