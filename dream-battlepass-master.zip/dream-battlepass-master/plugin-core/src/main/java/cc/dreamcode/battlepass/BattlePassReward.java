package cc.dreamcode.battlepass;

import lombok.Data;
import org.bukkit.inventory.ItemStack;

import java.util.List;

@Data
public class BattlePassReward {

    private final ItemStack displayItem;

    private final List<ItemStack> itemStacks;
    private final List<String> commands;

}
