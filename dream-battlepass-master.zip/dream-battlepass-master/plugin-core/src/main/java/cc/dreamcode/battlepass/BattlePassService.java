package cc.dreamcode.battlepass;

import cc.dreamcode.battlepass.config.PluginConfig;
import cc.dreamcode.battlepass.profile.Profile;
import cc.dreamcode.battlepass.profile.ProfileCache;
import cc.dreamcode.utilities.StringUtil;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import eu.okaeri.injector.annotation.Inject;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.bukkit.entity.HumanEntity;

import java.util.Map;
import java.util.Optional;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class BattlePassService {

    private final BattlePassPlugin battlePassPlugin;
    private final PluginConfig pluginConfig;
    private final ProfileCache profileCache;

    public void receiveReward(@NonNull HumanEntity humanEntity, @NonNull Profile profile, @NonNull BattlePassReward battlePassReward, int rewardLevel, boolean premium) {
        if (premium) {
            profile.getReceivedPremiumRewards().add(rewardLevel);
        }
        else {
            profile.getReceivedRewards().add(rewardLevel);
        }

        this.profileCache.markProfileToSave(profile);

        battlePassReward.getItemStacks().forEach(itemStack ->
                humanEntity.getInventory().addItem(ItemBuilder.of(itemStack).fixColors().toItemStack())
                        .forEach((i, item) -> humanEntity.getWorld().dropItem(humanEntity.getLocation(), item)));

        battlePassReward.getCommands().forEach(command ->
                this.battlePassPlugin.getServer().dispatchCommand(
                        this.battlePassPlugin.getServer().getConsoleSender(),
                        StringUtil.replace(command, "name", humanEntity.getName())
                ));
    }

    public int getLevel(@NonNull Profile profile) {
        return this.getLevel(profile.getXp());
    }

    public int getLevel(long xp) {
        if (this.pluginConfig.autoLevel) {
            LevelCounter levelCounter = new LevelCounter(this.pluginConfig);
            return levelCounter.countLevel(xp);
        }

        return this.pluginConfig.levelXp
                .entrySet()
                .stream()
                .filter(entry -> entry.getValue() <= xp)
                .map(Map.Entry::getKey)
                .min(new BattlePassLevelComparator())
                .orElse(0);
    }

    public int getNextLevel(long xp) {
        return this.getLevel(xp) + 1;
    }

    public Optional<Long> getXpByLevel(int level) {
        if (this.pluginConfig.autoLevel) {
            return Optional.of((long) (this.pluginConfig.startXp * (level * this.pluginConfig.multiply)));
        }

        return Optional.ofNullable(this.pluginConfig.levelXp.get(level));
    }

    public boolean hasPremium(@NonNull HumanEntity humanEntity) {
        if (humanEntity.hasPermission(this.pluginConfig.premiumPermission)) {
            return true;
        }

        return this.profileCache.getCachedProfile(humanEntity.getUniqueId())
                .map(Profile::isPremium)
                .orElse(false);
    }

    @RequiredArgsConstructor
    public static class LevelCounter {

        private final PluginConfig pluginConfig;

        private int level = 1;

        public int countLevel(long xp) {
            double check = this.pluginConfig.startXp * this.pluginConfig.multiply;
            check = check * this.level;

            if (xp <= check) {
                return this.level;
            }

            this.level++;
            return this.countLevel(xp);
        }
    }
}
