package cc.dreamcode.battlepass.config;

import cc.dreamcode.notice.adventure.BukkitNotice;
import cc.dreamcode.platform.bukkit.component.configuration.Configuration;
import eu.okaeri.configs.OkaeriConfig;
import eu.okaeri.configs.annotation.CustomKey;
import eu.okaeri.configs.annotation.Header;
import eu.okaeri.configs.annotation.Headers;

@Configuration(
        child = "message.yml"
)
@Headers({
        @Header("## Dream-BattlePass (Message-Config) ##"),
        @Header("Dostepne type: (DO_NOT_SEND, CHAT, ACTION_BAR, SUBTITLE, TITLE, TITLE_SUBTITLE)")
})
public class MessageConfig extends OkaeriConfig {

    @CustomKey("command-usage")
    public BukkitNotice usage = BukkitNotice.chat("&7Przyklady uzycia komendy: &c{label}");
    @CustomKey("command-usage-help")
    public BukkitNotice usagePath = BukkitNotice.chat("&f{usage} &8- &7{description}");

    @CustomKey("command-usage-not-found")
    public BukkitNotice usageNotFound = BukkitNotice.chat("&cNie znaleziono pasujacych do kryteriow komendy.");
    @CustomKey("command-path-not-found")
    public BukkitNotice pathNotFound = BukkitNotice.chat("&cTa komenda jest pusta lub nie posiadasz dostepu do niej.");
    @CustomKey("command-no-permission")
    public BukkitNotice noPermission = BukkitNotice.chat("&cNie posiadasz uprawnien.");
    @CustomKey("command-not-player")
    public BukkitNotice notPlayer = BukkitNotice.chat("&cTa komende mozna tylko wykonac z poziomu gracza.");
    @CustomKey("command-not-console")
    public BukkitNotice notConsole = BukkitNotice.chat("&cTa komende mozna tylko wykonac z poziomu konsoli.");
    @CustomKey("command-invalid-format")
    public BukkitNotice invalidFormat = BukkitNotice.chat("&cPodano nieprawidlowy format argumentu komendy. ({input})");

    @CustomKey("player-not-found")
    public BukkitNotice playerNotFound = BukkitNotice.chat("&cPodanego gracza nie znaleziono.");
    @CustomKey("world-not-found")
    public BukkitNotice worldNotFound = BukkitNotice.chat("&cPodanego swiata nie znaleziono.");
    @CustomKey("number-is-not-valid")
    public BukkitNotice numberIsNotValid = BukkitNotice.chat("&cPodana liczba nie jest cyfra.");
    @CustomKey("number-must-be-positive")
    public BukkitNotice numberMustBePositive = BukkitNotice.chat("&cPodana liczba nie moze byc negatywna.");
    @CustomKey("item-in-hand-not-found")
    public BukkitNotice itemInHandNotFound = BukkitNotice.chat("&cMusisz trzymac przedmiot w rece, aby to zrobic!");

    @CustomKey("config-reloaded")
    public BukkitNotice reloaded = BukkitNotice.chat("&aPrzeladowano! &7({time})");
    @CustomKey("config-reload-error")
    public BukkitNotice reloadError = BukkitNotice.chat("&cZnaleziono problem w konfiguracji: &6{error}");

    @CustomKey("reward-already-received")
    public BukkitNotice rewardAlreadyReceived = BukkitNotice.chat("&cOdebrano juz nagrode za ten poziom.");
    @CustomKey("reward-no-level")
    public BukkitNotice rewardNoLevel = BukkitNotice.chat("&cNie posiadasz odpowiedniego poziomu, aby odebrac nagrode.");
    @CustomKey("reward-received")
    public BukkitNotice rewardReceived = BukkitNotice.chat("&aNagroda zostala odebrana!");

    @CustomKey("level-not-found")
    public BukkitNotice levelNotFound = BukkitNotice.chat("&cNie znaleziono podanego levela.");
    @CustomKey("level-updated")
    public BukkitNotice levelUpdated = BukkitNotice.chat("&aZaaktualizowano level gracza {nick} do {level} poziomu.");
    @CustomKey("level-updated-customer")
    public BukkitNotice levelUpdatedCustomer = BukkitNotice.chat("&aZaaktualizowano tobie level do {level} poziomu.");
    @CustomKey("xp-updated")
    public BukkitNotice xpUpdated = BukkitNotice.chat("&aZaaktualizowano exp graczowi {nick} do {xp}XP.");
    @CustomKey("xp-updated-customer")
    public BukkitNotice xpUpdatedCustomer = BukkitNotice.chat("&aZaaktualizowano tobie exp do {xp}XP.");

    @CustomKey("premium-not-found")
    public BukkitNotice premiumNotFound = BukkitNotice.chat("&cNie posiadasz statusu premium!");
    @CustomKey("premium-given")
    public BukkitNotice premiumGiven = BukkitNotice.chat("&aNadano graczowi {nick} premium.");
    @CustomKey("premium-taken")
    public BukkitNotice premiumTaken = BukkitNotice.chat("&cOdebrano graczowi {nick} premium.");
    @CustomKey("premium-take-error")
    public BukkitNotice premiumTakeError = BukkitNotice.chat("&8(&7Gracz nadal posiada premium, musisz odebrac mu uprawnienia premium&8)");

    @CustomKey("item-added")
    public BukkitNotice itemAdded = BukkitNotice.chat("&aDodano przedmiot.");
    @CustomKey("item-removed")
    public BukkitNotice itemRemoved = BukkitNotice.chat("&cUsunieto przedmiot.");

    @CustomKey("reward-reset")
    public BukkitNotice rewardReset = BukkitNotice.chat("&aNagroda {level} gracza {nick} zostala usunieta z odebranych.");
    @CustomKey("reward-reset-all")
    public BukkitNotice rewardResetAll = BukkitNotice.chat("&aNagrody gracza {nick} zostala usunieta z odebranych.");
    @CustomKey("reward-reset-error")
    public BukkitNotice rewardResetError = BukkitNotice.chat("&cGracz nie odebral nagrody z tym poziomem.");
}
