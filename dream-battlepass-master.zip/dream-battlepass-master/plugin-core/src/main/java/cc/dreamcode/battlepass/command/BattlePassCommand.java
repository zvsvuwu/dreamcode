package cc.dreamcode.battlepass.command;

import cc.dreamcode.battlepass.BattlePassMenu;
import cc.dreamcode.battlepass.BattlePassPlugin;
import cc.dreamcode.battlepass.BattlePassReward;
import cc.dreamcode.battlepass.BattlePassService;
import cc.dreamcode.battlepass.config.MessageConfig;
import cc.dreamcode.battlepass.config.PluginConfig;
import cc.dreamcode.battlepass.profile.Profile;
import cc.dreamcode.battlepass.profile.ProfileCache;
import cc.dreamcode.command.CommandBase;
import cc.dreamcode.command.annotation.Arg;
import cc.dreamcode.command.annotation.Async;
import cc.dreamcode.command.annotation.Command;
import cc.dreamcode.command.annotation.Completion;
import cc.dreamcode.command.annotation.Executor;
import cc.dreamcode.command.annotation.Permission;
import cc.dreamcode.notice.adventure.BukkitNotice;
import cc.dreamcode.utilities.ParseUtil;
import cc.dreamcode.utilities.TimeUtil;
import cc.dreamcode.utilities.builder.MapBuilder;
import eu.okaeri.configs.exception.OkaeriException;
import eu.okaeri.injector.annotation.Inject;
import eu.okaeri.tasker.core.Tasker;
import lombok.RequiredArgsConstructor;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Optional;

@Command(name = "battlepass", aliases = "karnet")
@RequiredArgsConstructor(onConstructor_ = @Inject)
public class BattlePassCommand implements CommandBase {

    private final BattlePassPlugin battlePassPlugin;
    private final PluginConfig pluginConfig;
    private final MessageConfig messageConfig;
    private final ProfileCache profileCache;
    private final BattlePassService battlePassService;
    private final Tasker tasker;

    @Executor(description = "Otwiera menu karnetu.")
    void menu(Player player) {
        this.tasker.newChain()
                .supplyAsync(() -> this.battlePassPlugin.createInstance(BattlePassMenu.class).build(player))
                .acceptSync(bukkitMenu -> bukkitMenu.open(player))
                .execute();
    }

    @Permission("dream-battlepass.admin")
    @Completion(arg = "customer", value = "@allplayers")
    @Executor(path = "setlevel", description = "Ustawia level dla danego gracza.")
    void setLevel(CommandSender sender, @Arg Player customer, @Arg int level) {

        final Optional<Profile> profileOptional = this.profileCache.getCachedProfile(customer.getUniqueId());
        if (!profileOptional.isPresent()) {
            this.messageConfig.playerNotFound.send(sender);
            return;
        }

        if (level <= 0) {
            this.messageConfig.numberMustBePositive.send(sender);
            return;
        }

        final Optional<Long> optionalXp = this.battlePassService.getXpByLevel(level);
        if (!optionalXp.isPresent()) {
            this.messageConfig.levelNotFound.send(sender);
            return;
        }

        final long xp = optionalXp.get();
        final Profile profile = profileOptional.get();

        profile.setXp(xp);
        this.profileCache.markProfileToSave(profile);

        if (!sender.getName().equals(customer.getName())) {
            this.messageConfig.levelUpdatedCustomer.send(customer, new MapBuilder<String, Object>()
                    .put("admin", sender.getName())
                    .put("level", level)
                    .build());
        }

        this.messageConfig.levelUpdated.send(sender, new MapBuilder<String, Object>()
                .put("nick", customer.getName())
                .put("level", level)
                .build());
    }

    @Permission("dream-battlepass.admin")
    @Completion(arg = "customer", value = "@allplayers")
    @Executor(path = "setxp", description = "Ustawia xp dla danego gracza.")
    void setXp(CommandSender sender, @Arg Player customer, @Arg long xp) {

        final Optional<Profile> profileOptional = this.profileCache.getCachedProfile(customer.getUniqueId());
        if (!profileOptional.isPresent()) {
            this.messageConfig.playerNotFound.send(sender);
            return;
        }

        final Profile profile = profileOptional.get();

        profile.setXp(xp);
        this.profileCache.markProfileToSave(profile);

        if (!sender.getName().equals(customer.getName())) {
            this.messageConfig.xpUpdatedCustomer.send(customer, new MapBuilder<String, Object>()
                    .put("admin", sender.getName())
                    .put("xp", xp)
                    .build());
        }

        this.messageConfig.xpUpdated.send(sender, new MapBuilder<String, Object>()
                .put("nick", customer.getName())
                .put("xp", xp)
                .build());
    }

    @Permission("dream-battlepass.admin")
    @Completion(arg = "customer", value = "@allplayers")
    @Executor(path = "setpremium", description = "Ustawia status premium dla danego gracza.")
    void setPremium(CommandSender sender, @Arg Player customer) {

        final Optional<Profile> profileOptional = this.profileCache.getCachedProfile(customer.getUniqueId());
        if (!profileOptional.isPresent()) {
            this.messageConfig.playerNotFound.send(sender);
            return;
        }

        final Profile profile = profileOptional.get();
        profile.setPremium(!profile.isPremium());

        this.profileCache.markProfileToSave(profile);

        if (profile.isPremium()) {
            this.messageConfig.premiumGiven.send(sender, new MapBuilder<String, Object>()
                    .put("nick", customer.getName())
                    .build());
        }
        else {
            this.messageConfig.premiumTaken.send(sender, new MapBuilder<String, Object>()
                    .put("nick", customer.getName())
                    .build());

            if (customer.hasPermission(this.pluginConfig.premiumPermission)) {
                this.messageConfig.premiumTakeError.send(sender, new MapBuilder<String, Object>()
                        .put("nick", customer.getName())
                        .build());
            }
        }
    }

    @Permission("dream-battlepass.admin")
    @Completion(arg = "type", value = {"level", "all"})
    @Completion(arg = "customer", value = "@allplayers")
    @Executor(path = "reset", description = "Resetuje statystyki gracza.")
    void reset(CommandSender sender, @Arg Player customer, @Arg String type) {

        final Optional<Profile> profileOptional = this.profileCache.getCachedProfile(customer.getUniqueId());
        if (!profileOptional.isPresent()) {
            this.messageConfig.playerNotFound.send(sender);
            return;
        }

        final Profile profile = profileOptional.get();
        if (type.equalsIgnoreCase("all")) {
            profile.getReceivedRewards().clear();

            this.messageConfig.rewardResetAll.send(sender, new MapBuilder<String, Object>()
                    .put("nick", customer.getName())
                    .build());
        }
        else {
            final Optional<Integer> optionalInteger = ParseUtil.parseInteger(type);
            if (!optionalInteger.isPresent()) {
                this.messageConfig.numberIsNotValid.send(sender);
                return;
            }

            final int level = optionalInteger.get();
            if (level <= 0) {
                this.messageConfig.numberMustBePositive.send(sender);
                return;
            }

            if (!profile.getReceivedRewards().contains(level)) {
                this.messageConfig.rewardResetError.send(sender, new MapBuilder<String, Object>()
                        .put("level", level)
                        .build());
                return;
            }

            profile.getReceivedRewards().removeIf(integer -> integer == level);
            this.messageConfig.rewardReset.send(sender, new MapBuilder<String, Object>()
                    .put("level", level)
                    .put("nick", customer.getName())
                    .build());
        }

        this.profileCache.markProfileToSave(profile);
    }

    @Permission("dream-battlepass.admin")
    @Completion(arg = "type", value = {"level", "all"})
    @Completion(arg = "customer", value = "@allplayers")
    @Executor(path = "resetpremium", description = "Resetuje statystyki premium gracza.")
    void resetPremium(CommandSender sender, @Arg Player customer, @Arg String type) {

        final Optional<Profile> profileOptional = this.profileCache.getCachedProfile(customer.getUniqueId());
        if (!profileOptional.isPresent()) {
            this.messageConfig.playerNotFound.send(sender);
            return;
        }

        final Profile profile = profileOptional.get();
        if (type.equalsIgnoreCase("all")) {
            profile.getReceivedPremiumRewards().clear();

            this.messageConfig.rewardResetAll.send(sender, new MapBuilder<String, Object>()
                    .put("nick", customer.getName())
                    .build());
        }
        else {
            final Optional<Integer> optionalInteger = ParseUtil.parseInteger(type);
            if (!optionalInteger.isPresent()) {
                this.messageConfig.numberIsNotValid.send(sender);
                return;
            }

            final int level = optionalInteger.get();
            if (level <= 0) {
                this.messageConfig.numberMustBePositive.send(sender);
                return;
            }

            if (!profile.getReceivedPremiumRewards().contains(level)) {
                this.messageConfig.rewardResetError.send(sender, new MapBuilder<String, Object>()
                        .put("level", level)
                        .build());
                return;
            }

            profile.getReceivedPremiumRewards().removeIf(integer -> integer == level);
            this.messageConfig.rewardReset.send(sender, new MapBuilder<String, Object>()
                    .put("level", level)
                    .put("nick", customer.getName())
                    .build());
        }

        this.profileCache.markProfileToSave(profile);
    }

    @Async
    @Permission("dream-battlepass.admin")
    @Executor(path = "add", description = "Dodaje level do karnetu.")
    void add(Player player, @Arg int level) {

        if (level < 0) {
            this.messageConfig.numberMustBePositive.send(player);
            return;
        }

        if (!this.pluginConfig.autoLevel && !this.pluginConfig.levelXp.containsKey(level)) {
            this.messageConfig.levelNotFound.send(player);
            return;
        }

        final ItemStack itemInHand = player.getItemInHand();
        if (itemInHand == null || itemInHand.getType().equals(Material.AIR)) {
            this.messageConfig.itemInHandNotFound.send(player);
            return;
        }

        this.pluginConfig.battlePassRewards.put(level, new BattlePassReward(itemInHand, Collections.singletonList(itemInHand), new ArrayList<>()));
        this.pluginConfig.save();

        this.messageConfig.itemAdded.send(player);
    }

    @Async
    @Permission("dream-battlepass.admin")
    @Executor(path = "addpremium", description = "Dodaje level premium do karnetu.")
    void addPremium(Player player, @Arg int level) {

        if (level < 0) {
            this.messageConfig.numberMustBePositive.send(player);
            return;
        }

        if (!this.pluginConfig.autoLevel && !this.pluginConfig.levelXp.containsKey(level)) {
            this.messageConfig.levelNotFound.send(player);
            return;
        }

        final ItemStack itemInHand = player.getItemInHand();
        if (itemInHand == null || itemInHand.getType().equals(Material.AIR)) {
            this.messageConfig.itemInHandNotFound.send(player);
            return;
        }

        this.pluginConfig.battlePassPremiumRewards.put(level, new BattlePassReward(itemInHand, Collections.singletonList(itemInHand), new ArrayList<>()));
        this.pluginConfig.save();

        this.messageConfig.itemAdded.send(player);
    }

    @Async
    @Permission("dream-battlepass.admin")
    @Executor(path = "remove", description = "Usuwa level z karnetu.")
    void remove(CommandSender sender, @Arg int level) {

        if (level < 0) {
            this.messageConfig.numberMustBePositive.send(sender);
            return;
        }

        if (!this.pluginConfig.battlePassRewards.containsKey(level)) {
            this.messageConfig.levelNotFound.send(sender);
            return;
        }

        this.pluginConfig.battlePassRewards.remove(level);
        this.pluginConfig.save();

        this.messageConfig.itemRemoved.send(sender);
    }

    @Async
    @Permission("dream-battlepass.admin")
    @Executor(path = "removepremium", description = "Usuwa level premium z karnetu.")
    void removePremium(CommandSender sender, @Arg int level) {

        if (level < 0) {
            this.messageConfig.numberMustBePositive.send(sender);
            return;
        }

        if (!this.pluginConfig.battlePassPremiumRewards.containsKey(level)) {
            this.messageConfig.levelNotFound.send(sender);
            return;
        }

        this.pluginConfig.battlePassPremiumRewards.remove(level);
        this.pluginConfig.save();

        this.messageConfig.itemRemoved.send(sender);
    }

    @Async
    @Permission("dream-battlepass.reload")
    @Executor(path = "reload", description = "Przeladowuje konfiguracje.")
    BukkitNotice reload() {
        final long time = System.currentTimeMillis();

        try {
            this.messageConfig.load();
            this.pluginConfig.load();

            return this.messageConfig.reloaded
                    .with("time", TimeUtil.format(System.currentTimeMillis() - time));
        }
        catch (NullPointerException | OkaeriException e) {
            e.printStackTrace();

            return this.messageConfig.reloadError
                    .with("error", e.getMessage());
        }
    }
}
