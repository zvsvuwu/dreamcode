package cc.dreamcode.battlepass.expansion;

import cc.dreamcode.battlepass.BattlePassService;
import cc.dreamcode.battlepass.config.PluginConfig;
import cc.dreamcode.battlepass.profile.Profile;
import cc.dreamcode.battlepass.profile.ProfileCache;
import eu.okaeri.injector.annotation.Inject;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;

import java.util.Optional;

public class HeartShopExpansion extends PlaceholderExpansionWrapper {

    private final PluginConfig pluginConfig;
    private final ProfileCache profileCache;
    private final BattlePassService battlePassService;

    @Inject
    public HeartShopExpansion(PluginConfig pluginConfig, ProfileCache profileCache, BattlePassService battlePassService) {
        super("Dream-BattlePass", "1.1.7", "Ravis96");

        this.pluginConfig = pluginConfig;
        this.profileCache = profileCache;
        this.battlePassService = battlePassService;
    }

    @Override
    public String onWrappedRequest(OfflinePlayer offlinePlayer, String params) {

        if (params.equalsIgnoreCase("xp")) {

            final Player player = offlinePlayer.getPlayer();
            if (player == null) {
                return null;
            }

            final Optional<Profile> profileOptional = this.profileCache.getCachedProfile(player.getUniqueId());
            if (!profileOptional.isPresent()) {
                return "player-not-found";
            }

            final Profile profile = profileOptional.get();
            return String.valueOf(profile.getXp());
        }

        if (params.equalsIgnoreCase("next-xp")) {

            final Player player = offlinePlayer.getPlayer();
            if (player == null) {
                return null;
            }

            final Optional<Profile> profileOptional = this.profileCache.getCachedProfile(player.getUniqueId());
            if (!profileOptional.isPresent()) {
                return "player-not-found";
            }

            final Profile profile = profileOptional.get();
            return String.valueOf(this.battlePassService.getXpByLevel(this.battlePassService.getNextLevel(profile.getXp()))
                    .orElse(0L));
        }

        if (params.equalsIgnoreCase("level")) {

            final Player player = offlinePlayer.getPlayer();
            if (player == null) {
                return null;
            }

            final Optional<Profile> profileOptional = this.profileCache.getCachedProfile(player.getUniqueId());
            if (!profileOptional.isPresent()) {
                return "player-not-found";
            }

            final Profile profile = profileOptional.get();
            return String.valueOf(this.battlePassService.getLevel(profile));
        }

        if (params.equalsIgnoreCase("premium")) {

            final Player player = offlinePlayer.getPlayer();
            if (player == null) {
                return null;
            }

            return this.battlePassService.hasPremium(player)
                    ? this.pluginConfig.active
                    : this.pluginConfig.noActive;
        }

        return null;
    }
}
