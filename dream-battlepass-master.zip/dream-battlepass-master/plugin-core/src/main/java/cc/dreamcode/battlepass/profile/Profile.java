package cc.dreamcode.battlepass.profile;

import eu.okaeri.configs.annotation.CustomKey;
import eu.okaeri.persistence.document.Document;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Data
@EqualsAndHashCode(callSuper = false)
public class Profile extends Document {

    @CustomKey("premium")
    private boolean premium = false;
    @CustomKey("page")
    private int page = 1;
    @CustomKey("xp")
    private long xp = 0L;
    @CustomKey("received-rewards")
    private List<Integer> receivedRewards = new ArrayList<>();
    @CustomKey("received-premium-rewards")
    private List<Integer> receivedPremiumRewards = new ArrayList<>();

    public void incrementXp(long xp) {
        this.xp += xp;
    }

    public UUID getUuid() {
        return this.getPath().toUUID();
    }
}
