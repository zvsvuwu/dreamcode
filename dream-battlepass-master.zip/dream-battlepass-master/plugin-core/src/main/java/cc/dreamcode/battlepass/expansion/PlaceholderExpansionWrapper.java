package cc.dreamcode.battlepass.expansion;

import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;

@RequiredArgsConstructor
public abstract class PlaceholderExpansionWrapper {

    private final String identifier;
    private final String author;
    private final String version;

    public abstract String onWrappedRequest(OfflinePlayer player, String params);

    public PlaceholderExpansion wrap() {
        return new PlaceholderExpansion() {
            @Override
            public @NonNull String getIdentifier() {
                return identifier;
            }

            @Override
            public @NonNull String getAuthor() {
                return author;
            }

            @Override
            public @NonNull String getVersion() {
                return version;
            }

            @Override
            public String onRequest(OfflinePlayer player, @NonNull String params) {
                return onWrappedRequest(player, params);
            }
        };
    }
}