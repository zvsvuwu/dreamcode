package cc.dreamcode.battlepass;

import cc.dreamcode.battlepass.profile.Profile;
import cc.dreamcode.battlepass.profile.ProfileCache;
import cc.dreamcode.platform.bukkit.component.scheduler.Scheduler;
import eu.okaeri.injector.annotation.Inject;
import eu.okaeri.tasker.core.Tasker;
import lombok.RequiredArgsConstructor;

import java.util.concurrent.atomic.AtomicInteger;

@Scheduler(delay = 100, interval = 100)
@RequiredArgsConstructor(onConstructor_ = @Inject)
public class BattlePassScheduler implements Runnable {

    private final BattlePassPlugin battlePassPlugin;
    private final ProfileCache profileCache;
    private final Tasker tasker;

    @Override
    public void run() {
        AtomicInteger delay = new AtomicInteger();
        AtomicInteger players = new AtomicInteger();

        for (Profile profile : this.profileCache.getProfileToSave()) {
            if (players.get() >= 10) {
                delay.getAndIncrement();
                players.set(0);
            }

            this.battlePassPlugin.getServer().getScheduler().runTaskLater(this.battlePassPlugin, () ->
                    this.tasker.newSharedChain("dbops:" + profile.getUuid())
                            .supplyAsync(profile::save)
                            .execute(), delay.get());

            players.getAndIncrement();
        }

        this.profileCache.clearProfilesToSave();
    }
}
