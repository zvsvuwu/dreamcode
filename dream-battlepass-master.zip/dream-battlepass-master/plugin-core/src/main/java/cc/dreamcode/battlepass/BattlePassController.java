package cc.dreamcode.battlepass;

import cc.dreamcode.battlepass.config.PluginConfig;
import cc.dreamcode.battlepass.profile.Profile;
import cc.dreamcode.battlepass.profile.ProfileCache;
import com.cryptomorin.xseries.XMaterial;
import eu.okaeri.injector.annotation.Inject;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.projectiles.ProjectileSource;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicReference;
import java.util.stream.Stream;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class BattlePassController implements Listener {

    private final PluginConfig pluginConfig;
    private final ProfileCache profileCache;

    private final Map<UUID, Long> distance = new WeakHashMap<>();
    private final Map<String, String> lastKill = new HashMap<>();

    @EventHandler(priority = EventPriority.LOW)
    public void onPlayerDeath(PlayerDeathEvent event) {

        final Player victim = event.getEntity();
        final Player killer = event.getEntity().getKiller();

        if (killer == null) {
            return;
        }

        Optional.ofNullable(this.pluginConfig.activeActivities.get(BattlePassActivities.DEATH)).ifPresent(xp -> {

            if (victim.getAddress() != null && killer.getAddress() != null &&
                    !victim.getAddress().getAddress().equals(killer.getAddress().getAddress())) {

                if (this.lastKill.getOrDefault(victim.getName(), "").equals(killer.getName())) {
                    return;
                }

                if (Stream.concat(
                        this.pluginConfig.ignoredRegions.stream(),
                        this.pluginConfig.specialIgnoredRegions
                                .entrySet()
                                .stream()
                                .filter(entry -> entry.getKey().equals(BattlePassActivities.DEATH))
                                .map(Map.Entry::getValue)
                ).anyMatch(region -> region.contains(victim.getLocation()))) {
                    return;
                }

                this.lastKill.put(victim.getName(), killer.getName());
                this.applyChange(victim, xp);
            }
        });

        Optional.ofNullable(this.pluginConfig.activeActivities.get(BattlePassActivities.KILLING_PEOPLE)).ifPresent(xp -> {

            if (victim.getAddress() != null && killer.getAddress() != null &&
                    !victim.getAddress().getAddress().equals(killer.getAddress().getAddress())) {

                if (this.lastKill.getOrDefault(killer.getName(), "").equals(victim.getName())) {
                    return;
                }

                if (Stream.concat(
                        this.pluginConfig.ignoredRegions.stream(),
                        this.pluginConfig.specialIgnoredRegions
                                .entrySet()
                                .stream()
                                .filter(entry -> entry.getKey().equals(BattlePassActivities.KILLING_PEOPLE))
                                .map(Map.Entry::getValue)
                ).anyMatch(region -> region.contains(killer.getLocation()))) {
                    return;
                }

                this.lastKill.put(killer.getName(), victim.getName());
                this.applyChange(killer, xp);
            }
        });
    }

    @EventHandler(priority = EventPriority.LOW)
    public void onBlockBreak(BlockBreakEvent event) {
        final Player player = event.getPlayer();
        final Block block = event.getBlock();

        final AtomicReference<BattlePassXp> atomicReference = new AtomicReference<>();

        if (block.getType().equals(Material.STONE)) {

            if (Stream.concat(
                    this.pluginConfig.ignoredRegions.stream(),
                    this.pluginConfig.specialIgnoredRegions
                            .entrySet()
                            .stream()
                            .filter(entry -> entry.getKey().equals(BattlePassActivities.BREAKING_STONE))
                            .map(Map.Entry::getValue)
            ).anyMatch(region -> region.contains(block.getLocation()))) {
                return;
            }

            Optional.ofNullable(this.pluginConfig.activeActivities.get(BattlePassActivities.BREAKING_STONE))
                    .ifPresent(atomicReference::set);
        }
        else if (block.getType().name().contains("ORE")) {

            if (Stream.concat(
                    this.pluginConfig.ignoredRegions.stream(),
                    this.pluginConfig.specialIgnoredRegions
                            .entrySet()
                            .stream()
                            .filter(entry -> entry.getKey().equals(BattlePassActivities.MINED_ORES))
                            .map(Map.Entry::getValue)
            ).anyMatch(region -> region.contains(block.getLocation()))) {
                return;
            }

            Optional.ofNullable(this.pluginConfig.activeActivities.get(BattlePassActivities.MINED_ORES))
                    .ifPresent(atomicReference::set);
        }
        else {

            if (Stream.concat(
                    this.pluginConfig.ignoredRegions.stream(),
                    this.pluginConfig.specialIgnoredRegions
                            .entrySet()
                            .stream()
                            .filter(entry -> entry.getKey().equals(BattlePassActivities.BREAKING_BLOCKS))
                            .map(Map.Entry::getValue)
            ).anyMatch(region -> region.contains(block.getLocation()))) {
                return;
            }

            Optional.ofNullable(this.pluginConfig.activeActivities.get(BattlePassActivities.BREAKING_BLOCKS))
                    .ifPresent(atomicReference::set);
        }

        if (atomicReference.get() == null) {
            return;
        }

        this.applyChange(player, atomicReference.get());
    }

    @EventHandler(priority = EventPriority.LOW)
    public void onBlockPlace(BlockPlaceEvent event) {
        final Player player = event.getPlayer();
        final Block block = event.getBlockPlaced();

        final AtomicReference<BattlePassXp> atomicReference = new AtomicReference<>();

        if (block.getType().equals(Material.OBSIDIAN)) {

            if (Stream.concat(
                    this.pluginConfig.ignoredRegions.stream(),
                    this.pluginConfig.specialIgnoredRegions
                            .entrySet()
                            .stream()
                            .filter(entry -> entry.getKey().equals(BattlePassActivities.PLACED_OBSIDIAN))
                            .map(Map.Entry::getValue)
            ).anyMatch(region -> region.contains(block.getLocation()))) {
                return;
            }

            Optional.ofNullable(this.pluginConfig.activeActivities.get(BattlePassActivities.PLACED_OBSIDIAN))
                    .ifPresent(atomicReference::set);
        }
        else if (this.pluginConfig.woodenMaterials.contains(XMaterial.matchXMaterial(block.getType()))) {

            if (Stream.concat(
                    this.pluginConfig.ignoredRegions.stream(),
                    this.pluginConfig.specialIgnoredRegions
                            .entrySet()
                            .stream()
                            .filter(entry -> entry.getKey().equals(BattlePassActivities.PLACED_WOODS))
                            .map(Map.Entry::getValue)
            ).anyMatch(region -> region.contains(block.getLocation()))) {
                return;
            }

            Optional.ofNullable(this.pluginConfig.activeActivities.get(BattlePassActivities.PLACED_WOODS))
                    .ifPresent(atomicReference::set);
        }
        else {

            if (Stream.concat(
                    this.pluginConfig.ignoredRegions.stream(),
                    this.pluginConfig.specialIgnoredRegions
                            .entrySet()
                            .stream()
                            .filter(entry -> entry.getKey().equals(BattlePassActivities.PLACED_BLOCKS))
                            .map(Map.Entry::getValue)
            ).anyMatch(region -> region.contains(block.getLocation()))) {
                return;
            }

            Optional.ofNullable(this.pluginConfig.activeActivities.get(BattlePassActivities.PLACED_BLOCKS))
                    .ifPresent(atomicReference::set);
        }

        if (atomicReference.get() == null) {
            return;
        }

        this.applyChange(player, atomicReference.get());
    }

    @EventHandler(priority = EventPriority.LOW)
    public void onPlayerMove(PlayerMoveEvent event) {

        if (event.getTo() == null) {
            return;
        }

        final Player player = event.getPlayer();
        if (event.getFrom().getBlockX() != event.getTo().getBlockX() ||
                event.getFrom().getBlockZ() != event.getTo().getBlockZ()) {

            Optional.ofNullable(this.pluginConfig.activeActivities.get(BattlePassActivities.RUNNED_DISTANCE)).ifPresent(xp -> {

                if (Stream.concat(
                        this.pluginConfig.ignoredRegions.stream(),
                        this.pluginConfig.specialIgnoredRegions
                                .entrySet()
                                .stream()
                                .filter(entry -> entry.getKey().equals(BattlePassActivities.RUNNED_DISTANCE))
                                .map(Map.Entry::getValue)
                ).anyMatch(region -> region.contains(player.getLocation()))) {
                    return;
                }

                final long distance = this.distance.getOrDefault(player.getUniqueId(), 0L);
                if (distance >= 100) {
                    this.distance.put(player.getUniqueId(), 0L);

                    this.applyChange(player, xp);
                    return;
                }

                this.distance.put(player.getUniqueId(), distance + 1L);
            });
        }
    }

    @EventHandler(priority = EventPriority.LOW)
    public void onProjectileLaunch(ProjectileLaunchEvent event) {

        if (!event.getEntityType().equals(EntityType.ENDER_PEARL)) {
            return;
        }

        final Projectile projectile = event.getEntity();
        final ProjectileSource projectileSource = projectile.getShooter();
        if (!(projectileSource instanceof Player)) {
            return;
        }

        final Player player = (Player) projectileSource;
        Optional.ofNullable(this.pluginConfig.activeActivities.get(BattlePassActivities.THROWED_PEARLS)).ifPresent(xp -> {

            if (Stream.concat(
                    this.pluginConfig.ignoredRegions.stream(),
                    this.pluginConfig.specialIgnoredRegions
                            .entrySet()
                            .stream()
                            .filter(entry -> entry.getKey().equals(BattlePassActivities.THROWED_PEARLS))
                            .map(Map.Entry::getValue)
            ).anyMatch(region -> region.contains(projectile.getLocation()))) {
                return;
            }

            this.applyChange(player, xp);
        });
    }

    @EventHandler(priority = EventPriority.LOW)
    public void onPlayerFish(PlayerFishEvent event) {

        if (event.getCaught() == null || !(event.getCaught() instanceof Item)) {
            return;
        }

        final Player player = event.getPlayer();
        Optional.ofNullable(this.pluginConfig.activeActivities.get(BattlePassActivities.CAUGHT_FISH)).ifPresent(xp -> {

            if (Stream.concat(
                    this.pluginConfig.ignoredRegions.stream(),
                    this.pluginConfig.specialIgnoredRegions
                            .entrySet()
                            .stream()
                            .filter(entry -> entry.getKey().equals(BattlePassActivities.CAUGHT_FISH))
                            .map(Map.Entry::getValue)
            ).anyMatch(region -> region.contains(event.getCaught().getLocation()))) {
                return;
            }

            this.applyChange(player, xp);
        });
    }

    @EventHandler(priority = EventPriority.LOW)
    public void onPlayerItemConsume(PlayerItemConsumeEvent event) {
        final Player player = event.getPlayer();
        final ItemStack itemStack = event.getItem();
        final XMaterial xMaterial = XMaterial.matchXMaterial(itemStack.getType());

        final AtomicReference<BattlePassXp> atomicReference = new AtomicReference<>();

        if (xMaterial.equals(XMaterial.GOLDEN_APPLE)) {

            if (Stream.concat(
                    this.pluginConfig.ignoredRegions.stream(),
                    this.pluginConfig.specialIgnoredRegions
                            .entrySet()
                            .stream()
                            .filter(entry -> entry.getKey().equals(BattlePassActivities.EATEN_GAPPLE))
                            .map(Map.Entry::getValue)
            ).anyMatch(region -> region.contains(player.getLocation()))) {
                return;
            }

            Optional.ofNullable(this.pluginConfig.activeActivities.get(BattlePassActivities.EATEN_GAPPLE))
                    .ifPresent(atomicReference::set);
        }
        else if (xMaterial.equals(XMaterial.ENCHANTED_GOLDEN_APPLE)) {

            if (Stream.concat(
                    this.pluginConfig.ignoredRegions.stream(),
                    this.pluginConfig.specialIgnoredRegions
                            .entrySet()
                            .stream()
                            .filter(entry -> entry.getKey().equals(BattlePassActivities.EATEN_EGAPPLE))
                            .map(Map.Entry::getValue)
            ).anyMatch(region -> region.contains(player.getLocation()))) {
                return;
            }

            Optional.ofNullable(this.pluginConfig.activeActivities.get(BattlePassActivities.EATEN_EGAPPLE))
                    .ifPresent(atomicReference::set);
        }
        else if (xMaterial.equals(XMaterial.POTION)) {

            if (Stream.concat(
                    this.pluginConfig.ignoredRegions.stream(),
                    this.pluginConfig.specialIgnoredRegions
                            .entrySet()
                            .stream()
                            .filter(entry -> entry.getKey().equals(BattlePassActivities.DRUNKEN_POTIONS))
                            .map(Map.Entry::getValue)
            ).anyMatch(region -> region.contains(player.getLocation()))) {
                return;
            }

            Optional.ofNullable(this.pluginConfig.activeActivities.get(BattlePassActivities.DRUNKEN_POTIONS))
                    .ifPresent(atomicReference::set);
        }

        if (atomicReference.get() == null) {
            return;
        }

        this.applyChange(player, atomicReference.get());
    }

    private void applyChange(@NonNull Player player, @NonNull BattlePassXp battlePassXp) {
        final Optional<Profile> optionalProfile = this.profileCache.getCachedProfile(player.getUniqueId());
        if (!optionalProfile.isPresent()) {
            this.profileCache.createCachedProfile(player);
            return;
        }

        final Profile profile = optionalProfile.get();
        profile.incrementXp(battlePassXp.randomize());

        this.profileCache.markProfileToSave(profile);
    }
}
