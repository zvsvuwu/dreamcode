package cc.dreamcode.battlepass;

import eu.okaeri.configs.schema.GenericsDeclaration;
import eu.okaeri.configs.serdes.DeserializationData;
import eu.okaeri.configs.serdes.ObjectSerializer;
import eu.okaeri.configs.serdes.SerializationData;
import lombok.NonNull;
import org.bukkit.inventory.ItemStack;

public class BattlePassRewardSerializer implements ObjectSerializer<BattlePassReward> {
    @Override
    public boolean supports(@NonNull Class<? super BattlePassReward> type) {
        return BattlePassReward.class.isAssignableFrom(type);
    }

    @Override
    public void serialize(@NonNull BattlePassReward object, @NonNull SerializationData data, @NonNull GenericsDeclaration generics) {
        data.add("reward-display-item", object.getDisplayItem());
        data.add("reward-items", object.getItemStacks());
        data.add("reward-commands", object.getCommands());
    }

    @Override
    public BattlePassReward deserialize(@NonNull DeserializationData data, @NonNull GenericsDeclaration generics) {
        return new BattlePassReward(
                data.get("reward-display-item", ItemStack.class),
                data.getAsList("reward-items", ItemStack.class),
                data.getAsList("reward-commands", String.class)
        );
    }
}
