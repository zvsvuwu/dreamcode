package cc.dreamcode.battlepass.config;

import cc.dreamcode.battlepass.BattlePassActivities;
import cc.dreamcode.battlepass.BattlePassReward;
import cc.dreamcode.battlepass.BattlePassXp;
import cc.dreamcode.battlepass.region.Region;
import cc.dreamcode.menu.adventure.BukkitMenuBuilder;
import cc.dreamcode.platform.bukkit.component.configuration.Configuration;
import cc.dreamcode.platform.persistence.StorageConfig;
import cc.dreamcode.utilities.builder.ListBuilder;
import cc.dreamcode.utilities.builder.MapBuilder;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import com.cryptomorin.xseries.XMaterial;
import eu.okaeri.configs.OkaeriConfig;
import eu.okaeri.configs.annotation.Comment;
import eu.okaeri.configs.annotation.CustomKey;
import eu.okaeri.configs.annotation.Header;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Configuration(
        child = "config.yml"
)
@Header("## Dream-BattlePass (Main-Config) ##")
public class PluginConfig extends OkaeriConfig {

    @Comment
    @Comment("Debug pokazuje dodatkowe informacje do konsoli. Lepiej wylaczyc. :P")
    @CustomKey("debug")
    public boolean debug = true;

    @Comment
    @Comment("Jakie aktywnosci maja byc aktywne?")
    @Comment("W drugim parametrze uzupelnij ilosc xp za zrobiona rzecz.")
    @Comment("Dostepne typy: KILLING_PEOPLE, DEATH, BREAKING_BLOCKS, BREAKING_STONE, PLACED_BLOCKS, PLACED_OBSIDIAN, PLACED_WOODS, RUNNED_DISTANCE, THROWED_PEARLS, CAUGHT_FISH, MINED_ORES, EATEN_GAPPLE, EATEN_EGAPPLE, DRUNKEN_POTIONS")
    @CustomKey("active-activities")
    public Map<BattlePassActivities, BattlePassXp> activeActivities = new MapBuilder<BattlePassActivities, BattlePassXp>()
            .put(BattlePassActivities.KILLING_PEOPLE, new BattlePassXp(3, 6))
            .put(BattlePassActivities.DEATH, new BattlePassXp(3, 4))
            .put(BattlePassActivities.BREAKING_BLOCKS, new BattlePassXp(1, 2))
            .put(BattlePassActivities.BREAKING_STONE, new BattlePassXp(1, 1))
            .put(BattlePassActivities.PLACED_BLOCKS, new BattlePassXp(1, 1))
            .put(BattlePassActivities.PLACED_OBSIDIAN, new BattlePassXp(1, 2))
            .put(BattlePassActivities.PLACED_WOODS, new BattlePassXp(1, 2))
            .put(BattlePassActivities.RUNNED_DISTANCE, new BattlePassXp(1, 1))
            .put(BattlePassActivities.THROWED_PEARLS, new BattlePassXp(1, 2))
            .put(BattlePassActivities.CAUGHT_FISH, new BattlePassXp(1, 2))
            .put(BattlePassActivities.MINED_ORES, new BattlePassXp(1, 1))
            .put(BattlePassActivities.EATEN_GAPPLE, new BattlePassXp(1, 2))
            .put(BattlePassActivities.EATEN_EGAPPLE, new BattlePassXp(1, 3))
            .put(BattlePassActivities.DRUNKEN_POTIONS, new BattlePassXp(1, 2))
            .build();

    @Comment
    @Comment("Jakie przedmioty maja zaliczac sie do drewna?")
    @CustomKey("wooden-materials")
    public List<XMaterial> woodenMaterials = ListBuilder.of(XMaterial.OAK_LOG);

    @Comment
    @Comment("Jakie regiony maja byc ignorowane podczas nabijania statystyk?")
    @CustomKey("ignored-regions")
    public List<Region> ignoredRegions = ListBuilder.of(
            new Region(
                    new Location(Bukkit.getWorlds().get(0), 25.0D, 0.0D, 25.0D),
                    new Location(Bukkit.getWorlds().get(0), -25.0D, 255.0D, -25.0D)
            ),
            new Region(
                    new Location(Bukkit.getWorlds().get(0), 50.0D, 0.0D, 50.0D),
                    new Location(Bukkit.getWorlds().get(0), 45.0D, 255.0D, 45.0D)
            )
    );

    @Comment
    @Comment("Jakie regiony maja byc ignorowane podczas nabijania szczegolnych statystyk?")
    @CustomKey("special-ignored-regions")
    public Map<BattlePassActivities, Region> specialIgnoredRegions = MapBuilder.of(
            BattlePassActivities.BREAKING_BLOCKS, new Region(
                    new Location(Bukkit.getWorlds().get(0), 25.0D, 0.0D, 25.0D),
                    new Location(Bukkit.getWorlds().get(0), -25.0D, 255.0D, -25.0D)
            ),
            BattlePassActivities.BREAKING_STONE, new Region(
                    new Location(Bukkit.getWorlds().get(0), 50.0D, 0.0D, 50.0D),
                    new Location(Bukkit.getWorlds().get(0), 45.0D, 255.0D, 45.0D)
            )
    );

    @Comment
    @Comment("Czy exp ma byc ustawiany recznie czy ma byc obliczany za pomoca mnoznika?")
    @CustomKey("auto-level")
    public boolean autoLevel = false;

    @Comment
    @Comment("Jaki mnoznik ma byc dla automatycznego obliczania levela?")
    @CustomKey("start-xp")
    public long startXp = 100;
    @CustomKey("multiply")
    public double multiply = 1.0D;

    @Comment
    @Comment("Od jakiego xp ma byc dany poziom?")
    @CustomKey("level-xp")
    public Map<Integer, Long> levelXp = new MapBuilder<Integer, Long>()
            .put(1, 0L)
            .put(2, 100L)
            .put(3, 200L)
            .put(4, 300L)
            .put(5, 400L)
            .put(6, 500L)
            .put(7, 600L)
            .put(8, 700L)
            .put(9, 800L)
            .put(10, 900L)
            .put(11, 1000L)
            .put(12, 1200L)
            .put(13, 1300L)
            .put(14, 1400L)
            .put(15, 1500L)
            .put(16, 1600L)
            .put(17, 1700L)
            .put(18, 1800L)
            .put(19, 1900L)
            .put(20, 2000L)
            .put(21, 2100L)
            .put(22, 2200L)
            .put(23, 2300L)
            .put(24, 2400L)
            .put(25, 2500L)
            .put(26, 2600L)
            .put(27, 2700L)
            .build();

    @Comment
    @Comment("Ustaw nagrody dla danych poziomow:")
    @Comment("Placeholdery dla komend: ({nick})")
    @CustomKey("battle-pass-rewards")
    public Map<Integer, BattlePassReward> battlePassRewards = new MapBuilder<Integer, BattlePassReward>()
            .put(1, new BattlePassReward(new ItemStack(Material.DIAMOND, 1), ListBuilder.of(new ItemStack(Material.DIAMOND, 1)), new ArrayList<>()))
            .put(2, new BattlePassReward(new ItemStack(Material.DIAMOND, 2), ListBuilder.of(new ItemStack(Material.DIAMOND, 2)), new ArrayList<>()))
            .put(3, new BattlePassReward(new ItemStack(Material.DIAMOND, 3), ListBuilder.of(new ItemStack(Material.DIAMOND, 3)), new ArrayList<>()))
            .put(4, new BattlePassReward(new ItemStack(Material.DIAMOND, 4), ListBuilder.of(new ItemStack(Material.DIAMOND, 4)), new ArrayList<>()))
            .put(5, new BattlePassReward(new ItemStack(Material.DIAMOND, 5), ListBuilder.of(new ItemStack(Material.DIAMOND, 5)), new ArrayList<>()))
            .put(6, new BattlePassReward(new ItemStack(Material.DIAMOND, 6), ListBuilder.of(new ItemStack(Material.DIAMOND, 6)), new ArrayList<>()))
            .put(7, new BattlePassReward(new ItemStack(Material.DIAMOND, 7), ListBuilder.of(new ItemStack(Material.DIAMOND, 7)), new ArrayList<>()))
            .put(8, new BattlePassReward(new ItemStack(Material.DIAMOND, 8), ListBuilder.of(new ItemStack(Material.DIAMOND, 8)), new ArrayList<>()))
            .put(9, new BattlePassReward(new ItemStack(Material.DIAMOND, 9), ListBuilder.of(new ItemStack(Material.DIAMOND, 9)), new ArrayList<>()))
            .put(10, new BattlePassReward(new ItemStack(Material.DIAMOND, 10), ListBuilder.of(new ItemStack(Material.DIAMOND, 10)), new ArrayList<>()))
            .put(11, new BattlePassReward(new ItemStack(Material.DIAMOND, 11), ListBuilder.of(new ItemStack(Material.DIAMOND, 11)), new ArrayList<>()))
            .put(12, new BattlePassReward(new ItemStack(Material.DIAMOND, 12), ListBuilder.of(new ItemStack(Material.DIAMOND, 12)), new ArrayList<>()))
            .put(13, new BattlePassReward(new ItemStack(Material.DIAMOND, 13), ListBuilder.of(new ItemStack(Material.DIAMOND, 13)), new ArrayList<>()))
            .put(14, new BattlePassReward(new ItemStack(Material.DIAMOND, 14), ListBuilder.of(new ItemStack(Material.DIAMOND, 14)), new ArrayList<>()))
            .put(15, new BattlePassReward(new ItemStack(Material.DIAMOND, 15), ListBuilder.of(new ItemStack(Material.DIAMOND, 15)), new ArrayList<>()))
            .put(16, new BattlePassReward(new ItemStack(Material.DIAMOND, 16), ListBuilder.of(new ItemStack(Material.DIAMOND, 16)), new ArrayList<>()))
            .put(17, new BattlePassReward(new ItemStack(Material.DIAMOND, 17), ListBuilder.of(new ItemStack(Material.DIAMOND, 17)), new ArrayList<>()))
            .put(18, new BattlePassReward(new ItemStack(Material.DIAMOND, 18), ListBuilder.of(new ItemStack(Material.DIAMOND, 18)), new ArrayList<>()))
            .put(19, new BattlePassReward(new ItemStack(Material.DIAMOND, 19), ListBuilder.of(new ItemStack(Material.DIAMOND, 19)), new ArrayList<>()))
            .put(20, new BattlePassReward(new ItemStack(Material.DIAMOND, 20), ListBuilder.of(new ItemStack(Material.DIAMOND, 20)), new ArrayList<>()))
            .put(21, new BattlePassReward(new ItemStack(Material.DIAMOND, 21), ListBuilder.of(new ItemStack(Material.DIAMOND, 21)), new ArrayList<>()))
            .put(22, new BattlePassReward(new ItemStack(Material.DIAMOND, 22), ListBuilder.of(new ItemStack(Material.DIAMOND, 22)), new ArrayList<>()))
            .put(23, new BattlePassReward(new ItemStack(Material.DIAMOND, 23), ListBuilder.of(new ItemStack(Material.DIAMOND, 23)), new ArrayList<>()))
            .put(24, new BattlePassReward(new ItemStack(Material.DIAMOND, 24), ListBuilder.of(new ItemStack(Material.DIAMOND, 24)), new ArrayList<>()))
            .put(25, new BattlePassReward(new ItemStack(Material.DIAMOND, 25), ListBuilder.of(new ItemStack(Material.DIAMOND, 25)), new ArrayList<>()))
            .put(26, new BattlePassReward(new ItemStack(Material.DIAMOND, 26), ListBuilder.of(new ItemStack(Material.DIAMOND, 26)), new ArrayList<>()))
            .put(27, new BattlePassReward(new ItemStack(Material.DIAMOND, 27), ListBuilder.of(new ItemStack(Material.DIAMOND, 27)), new ArrayList<>()))
            .build();

    @Comment
    @Comment("Ustaw premium nagrody dla danych poziomow:")
    @Comment("Placeholdery dla komend: ({nick})")
    @CustomKey("battle-pass-premium-rewards")
    public Map<Integer, BattlePassReward> battlePassPremiumRewards = new MapBuilder<Integer, BattlePassReward>()
            .put(1, new BattlePassReward(new ItemStack(Material.EMERALD, 1), ListBuilder.of(new ItemStack(Material.EMERALD, 1)), new ArrayList<>()))
            .put(2, new BattlePassReward(new ItemStack(Material.EMERALD, 2), ListBuilder.of(new ItemStack(Material.EMERALD, 2)), new ArrayList<>()))
            .put(3, new BattlePassReward(new ItemStack(Material.EMERALD, 3), ListBuilder.of(new ItemStack(Material.EMERALD, 3)), new ArrayList<>()))
            .put(4, new BattlePassReward(new ItemStack(Material.EMERALD, 4), ListBuilder.of(new ItemStack(Material.EMERALD, 4)), new ArrayList<>()))
            .put(5, new BattlePassReward(new ItemStack(Material.EMERALD, 5), ListBuilder.of(new ItemStack(Material.EMERALD, 5)), new ArrayList<>()))
            .put(6, new BattlePassReward(new ItemStack(Material.EMERALD, 6), ListBuilder.of(new ItemStack(Material.EMERALD, 6)), new ArrayList<>()))
            .put(7, new BattlePassReward(new ItemStack(Material.EMERALD, 7), ListBuilder.of(new ItemStack(Material.EMERALD, 7)), new ArrayList<>()))
            .put(8, new BattlePassReward(new ItemStack(Material.EMERALD, 8), ListBuilder.of(new ItemStack(Material.EMERALD, 8)), new ArrayList<>()))
            .put(9, new BattlePassReward(new ItemStack(Material.EMERALD, 9), ListBuilder.of(new ItemStack(Material.EMERALD, 9)), new ArrayList<>()))
            .put(10, new BattlePassReward(new ItemStack(Material.EMERALD, 10), ListBuilder.of(new ItemStack(Material.EMERALD, 10)), new ArrayList<>()))
            .put(11, new BattlePassReward(new ItemStack(Material.EMERALD, 11), ListBuilder.of(new ItemStack(Material.EMERALD, 11)), new ArrayList<>()))
            .put(12, new BattlePassReward(new ItemStack(Material.EMERALD, 12), ListBuilder.of(new ItemStack(Material.EMERALD, 12)), new ArrayList<>()))
            .put(13, new BattlePassReward(new ItemStack(Material.EMERALD, 13), ListBuilder.of(new ItemStack(Material.EMERALD, 13)), new ArrayList<>()))
            .put(14, new BattlePassReward(new ItemStack(Material.EMERALD, 14), ListBuilder.of(new ItemStack(Material.EMERALD, 14)), new ArrayList<>()))
            .put(15, new BattlePassReward(new ItemStack(Material.EMERALD, 15), ListBuilder.of(new ItemStack(Material.EMERALD, 15)), new ArrayList<>()))
            .put(16, new BattlePassReward(new ItemStack(Material.EMERALD, 16), ListBuilder.of(new ItemStack(Material.EMERALD, 16)), new ArrayList<>()))
            .put(17, new BattlePassReward(new ItemStack(Material.EMERALD, 17), ListBuilder.of(new ItemStack(Material.EMERALD, 17)), new ArrayList<>()))
            .put(18, new BattlePassReward(new ItemStack(Material.EMERALD, 18), ListBuilder.of(new ItemStack(Material.EMERALD, 18)), new ArrayList<>()))
            .put(19, new BattlePassReward(new ItemStack(Material.EMERALD, 19), ListBuilder.of(new ItemStack(Material.EMERALD, 19)), new ArrayList<>()))
            .put(20, new BattlePassReward(new ItemStack(Material.EMERALD, 20), ListBuilder.of(new ItemStack(Material.EMERALD, 20)), new ArrayList<>()))
            .put(21, new BattlePassReward(new ItemStack(Material.EMERALD, 21), ListBuilder.of(new ItemStack(Material.EMERALD, 21)), new ArrayList<>()))
            .put(22, new BattlePassReward(new ItemStack(Material.EMERALD, 22), ListBuilder.of(new ItemStack(Material.EMERALD, 22)), new ArrayList<>()))
            .put(23, new BattlePassReward(new ItemStack(Material.EMERALD, 23), ListBuilder.of(new ItemStack(Material.EMERALD, 23)), new ArrayList<>()))
            .put(24, new BattlePassReward(new ItemStack(Material.EMERALD, 24), ListBuilder.of(new ItemStack(Material.EMERALD, 24)), new ArrayList<>()))
            .put(25, new BattlePassReward(new ItemStack(Material.EMERALD, 25), ListBuilder.of(new ItemStack(Material.EMERALD, 25)), new ArrayList<>()))
            .put(26, new BattlePassReward(new ItemStack(Material.EMERALD, 26), ListBuilder.of(new ItemStack(Material.EMERALD, 26)), new ArrayList<>()))
            .put(27, new BattlePassReward(new ItemStack(Material.EMERALD, 27), ListBuilder.of(new ItemStack(Material.EMERALD, 27)), new ArrayList<>()))
            .build();

    @Comment
    @Comment("Skonfiguruj menu dla karnetu bojowego:")
    @CustomKey("battle-pass-menu-builder")
    public BukkitMenuBuilder battlePassMenuBuilder = new BukkitMenuBuilder("&8[&bM&8] Karnet bojowy", 5, new MapBuilder<Integer, ItemStack>()
            .put(4, ItemBuilder.of(XMaterial.PAPER.parseItem())
                    .setName("&9&lTwoj Karnet")
                    .setLore("",
                            "&7Poziom karnetu: &a&l{level}LVL",
                            "&7Nastepny poziom: &f{xp}&8/&f{next_xp} &aXP",
                            "",
                            "&6Karnet permium: {premium}")
                    .toItemStack())
            .build());

    @Comment
    @Comment("Placeholdery dla aktywnego premium:")
    @CustomKey("active")
    public String active = "&aaktywny";
    @CustomKey("no-active")
    public String noActive = "&cnieaktywny";

    @Comment
    @Comment("Jakie ma byc uprawnienie do battlepass premium?")
    @CustomKey("premium-permission")
    public String premiumPermission = "dream.battlepass.premium";

    @Comment
    @Comment("W jakich slotach maja byc przedstawiane nagrody za level?")
    @CustomKey("slot-reward")
    public List<Integer> slotReward = ListBuilder.of(18, 19, 20, 21, 22, 23, 24, 25, 26);

    @Comment
    @Comment("Czy nad tymi slotami zwyklych nagrod ma byc szkielko z informacja czy odblokowano?")
    @CustomKey("glass-above-reward")
    public boolean glassAboveReward = true;

    @Comment
    @Comment("Jak ma szko wygladac z informacja zwyklych nagrod, gdy odblokowano?")
    @CustomKey("glass-above-reward-received")
    public ItemStack glassAboveRewardReceived = ItemBuilder.of(XMaterial.GREEN_STAINED_GLASS_PANE.parseItem())
            .setName("&aPoziom &f{level}")
            .setLore("",
                    "&aOdblokowano ten poziom!")
            .toItemStack();

    @Comment
    @Comment("Jak ma szko wygladac z informacja zwyklych nagrod, gdy jest do odblokowania?")
    @CustomKey("glass-above-reward-ready-to-receive")
    public ItemStack glassAboveRewardReadyToReceive = ItemBuilder.of(XMaterial.ORANGE_STAINED_GLASS_PANE.parseItem())
            .setName("&aPoziom &f{level}")
            .setLore("",
                    "&aMozesz odblokowac ten poziom!")
            .toItemStack();

    @Comment
    @Comment("Jak ma szko wygladac z informacja zwyklych nagrod, gdy nie odblokowano?")
    @CustomKey("glass-above-reward-not-received")
    public ItemStack glassAboveRewardNotReceived = ItemBuilder.of(XMaterial.RED_STAINED_GLASS_PANE.parseItem())
            .setName("&aPoziom &f{level}")
            .setLore("",
                    "&cNie odblokowano tego poziomu!")
            .toItemStack();

    @Comment
    @Comment("W jakich slotach maja byc przedstawiane premium nagrody za level?")
    @CustomKey("slot-premium-reward")
    public List<Integer> slotPremiumReward = ListBuilder.of(36, 37, 38, 39, 40, 41, 42, 43, 44);

    @Comment
    @Comment("Jaki ma byc slot na przycisk poprzedniej strony?")
    @CustomKey("previous-page-slot")
    public int previousPageSlot = 7;

    @Comment
    @Comment("Jak przycisk od poprzedniej strony ma wygladac?")
    @CustomKey("previous-page-item")
    public ItemStack previousPageItem = ItemBuilder.of(XMaterial.RED_WOOL.parseItem())
            .setName("&cPoprzednia strona.")
            .toItemStack();

    @Comment
    @Comment("Jaki ma byc slot na przycisk nastepnej strony?")
    @CustomKey("next-page-slot")
    public int nextPageSlot = 8;

    @Comment
    @Comment("Jak przycisk od nastepnej strony ma wygladac?")
    @CustomKey("next-page-item")
    public ItemStack nextPageItem = ItemBuilder.of(XMaterial.GREEN_WOOL.parseItem())
            .setName("&aNastepna strona.")
            .toItemStack();

    @Comment
    @Comment("Uzupelnij parametry do bazy danych.")
    @CustomKey("storage-config")
    public StorageConfig storageConfig = new StorageConfig("dreambattlepass");
}
