package cc.dreamcode.battlepass;

import cc.dreamcode.battlepass.command.BattlePassCommand;
import cc.dreamcode.battlepass.command.handler.InvalidInputHandlerImpl;
import cc.dreamcode.battlepass.command.handler.InvalidPermissionHandlerImpl;
import cc.dreamcode.battlepass.command.handler.InvalidSenderHandlerImpl;
import cc.dreamcode.battlepass.command.handler.InvalidUsageHandlerImpl;
import cc.dreamcode.battlepass.command.result.BukkitNoticeResolver;
import cc.dreamcode.battlepass.config.MessageConfig;
import cc.dreamcode.battlepass.config.PluginConfig;
import cc.dreamcode.battlepass.expansion.HeartShopExpansion;
import cc.dreamcode.battlepass.expansion.PlaceholderApiHook;
import cc.dreamcode.battlepass.profile.ProfileCache;
import cc.dreamcode.battlepass.profile.ProfileController;
import cc.dreamcode.battlepass.profile.ProfileRepository;
import cc.dreamcode.battlepass.region.RegionSerializer;
import cc.dreamcode.command.bukkit.BukkitCommandProvider;
import cc.dreamcode.menu.adventure.BukkitMenuProvider;
import cc.dreamcode.menu.adventure.serializer.MenuBuilderSerializer;
import cc.dreamcode.notice.adventure.BukkitNoticeProvider;
import cc.dreamcode.notice.adventure.serializer.BukkitNoticeSerializer;
import cc.dreamcode.platform.DreamVersion;
import cc.dreamcode.platform.bukkit.DreamBukkitConfig;
import cc.dreamcode.platform.bukkit.DreamBukkitPlatform;
import cc.dreamcode.platform.bukkit.component.ConfigurationResolver;
import cc.dreamcode.platform.bukkit.hook.PluginHookManager;
import cc.dreamcode.platform.bukkit.serializer.ItemMetaSerializer;
import cc.dreamcode.platform.bukkit.serializer.ItemStackSerializer;
import cc.dreamcode.platform.component.ComponentService;
import cc.dreamcode.platform.other.component.DreamCommandExtension;
import cc.dreamcode.platform.persistence.DreamPersistence;
import cc.dreamcode.platform.persistence.component.DocumentPersistenceResolver;
import cc.dreamcode.platform.persistence.component.DocumentRepositoryResolver;
import eu.okaeri.configs.serdes.OkaeriSerdesPack;
import eu.okaeri.configs.yaml.bukkit.serdes.SerdesBukkit;
import eu.okaeri.persistence.document.DocumentPersistence;
import eu.okaeri.tasker.bukkit.BukkitTasker;
import lombok.Getter;
import lombok.NonNull;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class BattlePassPlugin extends DreamBukkitPlatform implements DreamBukkitConfig, DreamPersistence {

    @Getter private static BattlePassPlugin battlePassPlugin;

    @Override
    public void load(@NonNull ComponentService componentService) {
        battlePassPlugin = this;
    }

    @Override
    public void enable(@NonNull ComponentService componentService) {
        componentService.setDebug(false);

        this.registerInjectable(BukkitTasker.newPool(this));
        this.registerInjectable(BukkitMenuProvider.create(this));
        this.registerInjectable(BukkitNoticeProvider.create(this));

        this.registerInjectable(BukkitCommandProvider.create(this));
        componentService.registerExtension(DreamCommandExtension.class);

        componentService.registerResolver(ConfigurationResolver.class);
        componentService.registerComponent(MessageConfig.class);

        componentService.registerComponent(BukkitNoticeResolver.class);
        componentService.registerComponent(InvalidInputHandlerImpl.class);
        componentService.registerComponent(InvalidPermissionHandlerImpl.class);
        componentService.registerComponent(InvalidSenderHandlerImpl.class);
        componentService.registerComponent(InvalidUsageHandlerImpl.class);

        componentService.registerComponent(PluginConfig.class, pluginConfig -> {
            // register persistence + repositories
            this.registerInjectable(pluginConfig.storageConfig);

            componentService.registerResolver(DocumentPersistenceResolver.class);
            componentService.registerComponent(DocumentPersistence.class);
            componentService.registerResolver(DocumentRepositoryResolver.class);

            // enable additional logs and debug messages
            componentService.setDebug(pluginConfig.debug);
        });

        componentService.registerComponent(PluginHookManager.class, pluginHookManager ->
                pluginHookManager.registerHook(PlaceholderApiHook.class));

        componentService.registerComponent(ProfileRepository.class);
        componentService.registerComponent(ProfileCache.class);
        componentService.registerComponent(ProfileController.class);

        componentService.registerComponent(BattlePassService.class);
        componentService.registerComponent(BattlePassController.class);
        componentService.registerComponent(BattlePassScheduler.class);
        componentService.registerComponent(BattlePassCommand.class);

        this.getInject(PluginHookManager.class)
                .flatMap(pluginHookManager -> pluginHookManager.get(PlaceholderApiHook.class))
                .ifPresent(placeholderApiHook -> placeholderApiHook.register(this.createInstance(HeartShopExpansion.class)));
    }

    @Override
    public void disable() {
        // features need to be call when server is stopping
    }

    @Override
    public @NonNull DreamVersion getDreamVersion() {
        return DreamVersion.create("Dream-BattlePass", "1.1.7", "Ravis96");
    }

    @Override
    public @NonNull OkaeriSerdesPack getConfigSerdesPack() {
        return registry -> {
            registry.register(new BukkitNoticeSerializer());
            registry.register(new MenuBuilderSerializer());

            registry.register(new BattlePassXpSerializer());
            registry.register(new BattlePassRewardSerializer());
            registry.register(new RegionSerializer());
        };
    }

    @Override
    public @NonNull OkaeriSerdesPack getPersistenceSerdesPack() {
        return registry -> {
            registry.register(new SerdesBukkit());

            registry.registerExclusive(ItemStack.class, new ItemStackSerializer());
            registry.registerExclusive(ItemMeta.class, new ItemMetaSerializer());
        };
    }

}
