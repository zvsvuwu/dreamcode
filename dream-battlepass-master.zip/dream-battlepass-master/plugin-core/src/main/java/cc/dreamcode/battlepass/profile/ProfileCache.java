package cc.dreamcode.battlepass.profile;

import eu.okaeri.injector.annotation.Inject;
import eu.okaeri.tasker.core.Tasker;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.bukkit.entity.HumanEntity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class ProfileCache {

    private final ProfileRepository profileRepository;
    private final Tasker tasker;

    private final Map<UUID, Profile> profileCache = new HashMap<>();
    private final List<UUID> profileToSave = new ArrayList<>();

    public Optional<Profile> getCachedProfile(@NonNull UUID playerUuid) {
        return Optional.ofNullable(this.profileCache.get(playerUuid));
    }

    public void createCachedProfile(@NonNull HumanEntity humanEntity) {
        final UUID playerUuid = humanEntity.getUniqueId();
        if (this.profileCache.containsKey(playerUuid)) {
            return;
        }

        this.tasker.newSharedChain("dbops:" + playerUuid)
                .supplyAsync(() -> this.profileRepository.findOrCreateByPath(playerUuid))
                .acceptSync(profile -> this.profileCache.put(playerUuid, profile))
                .execute();
    }

    public void removeCachedProfile(@NonNull UUID playerUuid) {
        if (!this.profileCache.containsKey(playerUuid)) {
            return;
        }

        this.profileCache.remove(playerUuid);
    }

    public List<Profile> getProfileToSave() {
        return this.profileToSave
                .stream()
                .map(uuid -> this.getCachedProfile(uuid).orElse(null))
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }

    public void markProfileToSave(@NonNull Profile profile) {
        if (this.profileToSave.contains(profile.getUuid())) {
            return;
        }

        this.profileToSave.add(profile.getUuid());
    }

    public void clearProfilesToSave() {
        this.profileToSave.clear();
    }
}
