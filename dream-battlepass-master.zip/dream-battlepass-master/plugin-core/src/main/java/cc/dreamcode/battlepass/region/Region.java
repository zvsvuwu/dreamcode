package cc.dreamcode.battlepass.region;

import lombok.Data;
import lombok.NonNull;
import org.bukkit.Location;
import org.bukkit.World;

import java.util.Objects;

@Data
public class Region {

    private final World world;
    private final Location firstCorner;
    private final Location secondCorner;

    public Region(@NonNull Location firstCorner, @NonNull Location secondCorner) {
        if (!Objects.equals(firstCorner.getWorld(), secondCorner.getWorld())) {
            throw new RuntimeException("Regions have diffrent worlds");
        }

        this.world = firstCorner.getWorld();
        this.firstCorner = firstCorner;
        this.secondCorner = secondCorner;
    }

    public int getUpperX() {
        return Math.max(this.secondCorner.getBlockX(), this.firstCorner.getBlockX());
    }

    public int getUpperY() {
        return Math.max(this.secondCorner.getBlockY(), this.firstCorner.getBlockY());
    }

    public int getUpperZ() {
        return Math.max(this.secondCorner.getBlockZ(), this.firstCorner.getBlockZ());
    }

    public int getLowerX() {
        return Math.min(this.firstCorner.getBlockX(), this.secondCorner.getBlockX());
    }

    public int getLowerY() {
        return Math.min(this.firstCorner.getBlockY(), this.secondCorner.getBlockY());
    }

    public int getLowerZ() {
        return Math.min(this.firstCorner.getBlockZ(), this.secondCorner.getBlockZ());
    }

    public boolean contains(double x, double y, double z) {
        return (x >= this.getLowerX()) && (x < this.getUpperX()) &&
                (y >= this.getLowerY()) && (y < this.getUpperY()) &&
                (z >= this.getLowerZ()) && (z < this.getUpperZ());
    }

    public boolean contains(@NonNull Location location) {

        if (!Objects.equals(location.getWorld(), this.world)) {
            return false;
        }

        return this.contains(location.getX(), location.getY(), location.getZ());
    }

}
