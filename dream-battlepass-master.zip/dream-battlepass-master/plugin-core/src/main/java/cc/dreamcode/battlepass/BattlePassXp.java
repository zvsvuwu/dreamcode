package cc.dreamcode.battlepass;

import cc.dreamcode.utilities.RandomUtil;
import lombok.Data;

@Data
public class BattlePassXp {

    private final int minValue;
    private final int maxValue;

    public int randomize() {

        if (this.minValue >= this.maxValue) {
            return this.minValue;
        }

        return RandomUtil.nextInteger(this.minValue, this.maxValue);
    }
}
