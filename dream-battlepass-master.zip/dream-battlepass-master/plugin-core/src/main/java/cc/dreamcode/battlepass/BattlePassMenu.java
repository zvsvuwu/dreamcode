package cc.dreamcode.battlepass;

import cc.dreamcode.battlepass.config.MessageConfig;
import cc.dreamcode.battlepass.config.PluginConfig;
import cc.dreamcode.battlepass.profile.Profile;
import cc.dreamcode.battlepass.profile.ProfileCache;
import cc.dreamcode.menu.adventure.BukkitMenuBuilder;
import cc.dreamcode.menu.adventure.BukkitMenuProvider;
import cc.dreamcode.menu.adventure.base.BukkitMenu;
import cc.dreamcode.menu.adventure.setup.BukkitMenuPlayerSetup;
import cc.dreamcode.utilities.builder.MapBuilder;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import eu.okaeri.injector.annotation.Inject;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.bukkit.Material;
import org.bukkit.entity.HumanEntity;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class BattlePassMenu implements BukkitMenuPlayerSetup {

    private final PluginConfig pluginConfig;
    private final MessageConfig messageConfig;
    private final ProfileCache profileCache;
    private final BattlePassService battlePassService;
    private final BukkitMenuProvider bukkitMenuProvider;

    @Override
    public BukkitMenu build(@NonNull HumanEntity humanEntity) {

        final Optional<Profile> profileOptional = this.profileCache.getCachedProfile(humanEntity.getUniqueId());
        if (!profileOptional.isPresent()) {
            return this.bukkitMenuProvider.createDefault("&cOtworz ponownie menu!", 1);
        }

        final Profile profile = profileOptional.get();
        final int level = this.battlePassService.getLevel(profile);

        final BukkitMenuBuilder menuBuilder = this.pluginConfig.battlePassMenuBuilder;
        final BukkitMenu bukkitMenu = menuBuilder.buildWithItems(new MapBuilder<String, Object>()
                .put("level", level)
                .put("xp", profile.getXp())
                .put("next_xp", this.battlePassService.getXpByLevel(this.battlePassService.getNextLevel(profile.getXp())).orElse(0L))
                .put("premium", this.battlePassService.hasPremium(humanEntity)
                        ? this.pluginConfig.active
                        : this.pluginConfig.noActive)
                .build());

        this.setupPage(bukkitMenu, profile, profile.getPage());

        return bukkitMenu;
    }

    private long countPage() {

        if (this.pluginConfig.battlePassPremiumRewards.size() > this.pluginConfig.battlePassRewards.size()) {
            return this.pluginConfig.battlePassPremiumRewards.size() / this.pluginConfig.slotPremiumReward.size();
        }

        return this.pluginConfig.battlePassRewards.size() / this.pluginConfig.slotReward.size();
    }

    private void setupPage(@NonNull BukkitMenu bukkitMenu, @NonNull Profile profile, int page) {
        final long totalPage = this.countPage();
        if (profile.getPage() != 1) {
            bukkitMenu.setItem(this.pluginConfig.previousPageSlot, ItemBuilder.of(this.pluginConfig.previousPageItem)
                            .setAmount(profile.getPage() - 1)
                            .fixColors()
                            .toItemStack(),
                    e -> {
                        profile.setPage(profile.getPage() - 1);
                        this.setupPage(bukkitMenu, profile, profile.getPage());
                    });
        }
        else {
            bukkitMenu.setItem(this.pluginConfig.previousPageSlot, new ItemStack(Material.AIR), e -> {});
        }

        if (profile.getPage() != totalPage) {
            bukkitMenu.setItem(this.pluginConfig.nextPageSlot, ItemBuilder.of(this.pluginConfig.nextPageItem)
                            .setAmount(profile.getPage() + 1)
                            .fixColors()
                            .toItemStack(),
                    e -> {
                        profile.setPage(profile.getPage() + 1);
                        this.setupPage(bukkitMenu, profile, profile.getPage());
                    });
        }
        else {
            bukkitMenu.setItem(this.pluginConfig.nextPageSlot, new ItemStack(Material.AIR), e -> {});
        }

        for (int slot = 0; slot < this.pluginConfig.slotReward.size(); slot++) {

            final int finalSlot = this.pluginConfig.slotReward.get(slot);
            final int glassSlot = finalSlot - 9;

            bukkitMenu.setItem(finalSlot, new ItemStack(Material.AIR), e -> {});
            bukkitMenu.setItem(glassSlot, new ItemStack(Material.AIR), e -> {});

            final int index = slot + this.pluginConfig.slotReward.size() * (page - 1);
            List<Integer> integerList = new ArrayList<>(this.pluginConfig.battlePassRewards.keySet());
            integerList.sort(Integer::compare);

            if (integerList.size() > index) {
                int level = integerList.get(index);

                Optional.ofNullable(this.pluginConfig.battlePassRewards.get(level)).ifPresent(battlePassReward -> {

                    if (this.pluginConfig.glassAboveReward) {
                        bukkitMenu.setItem(glassSlot, ItemBuilder.of(profile.getReceivedRewards().contains(level)
                                        ? this.pluginConfig.glassAboveRewardReceived
                                        : this.battlePassService.getLevel(profile) < level
                                                ? this.pluginConfig.glassAboveRewardNotReceived
                                                : this.pluginConfig.glassAboveRewardReadyToReceive)
                                .fixColors(new MapBuilder<String, Object>()
                                        .put("level", level)
                                        .build())
                                .toItemStack(), e -> this.receiveEvent(bukkitMenu, e.getWhoClicked(), profile, level, battlePassReward, glassSlot, false));
                    }

                    bukkitMenu.setItem(finalSlot, ItemBuilder.of(battlePassReward.getDisplayItem())
                            .fixColors(new MapBuilder<String, Object>()
                                    .put("level", level)
                                    .build())
                            .toItemStack(), e -> this.receiveEvent(bukkitMenu, e.getWhoClicked(), profile, level, battlePassReward, glassSlot, false));
                });
            }
        }

        for (int slot = 0; slot < this.pluginConfig.slotPremiumReward.size(); slot++) {

            final int finalSlot = this.pluginConfig.slotPremiumReward.get(slot);
            final int glassSlot = finalSlot - 9;

            bukkitMenu.setItem(finalSlot, new ItemStack(Material.AIR), e -> {});
            bukkitMenu.setItem(glassSlot, new ItemStack(Material.AIR), e -> {});

            final int index = slot + this.pluginConfig.slotPremiumReward.size() * (page - 1);
            List<Integer> integerList = new ArrayList<>(this.pluginConfig.battlePassPremiumRewards.keySet());
            integerList.sort(Integer::compare);
            
            if (integerList.size() > index) {
                int level = integerList.get(index);

                Optional.ofNullable(this.pluginConfig.battlePassPremiumRewards.get(level)).ifPresent(battlePassReward -> {

                    if (this.pluginConfig.glassAboveReward) {
                        bukkitMenu.setItem(glassSlot, ItemBuilder.of(profile.getReceivedPremiumRewards().contains(level)
                                        ? this.pluginConfig.glassAboveRewardReceived
                                        : this.battlePassService.getLevel(profile) < level
                                                ? this.pluginConfig.glassAboveRewardNotReceived
                                                : this.pluginConfig.glassAboveRewardReadyToReceive)
                                .fixColors(new MapBuilder<String, Object>()
                                        .put("level", level)
                                        .build())
                                .toItemStack(), e -> this.receiveEvent(bukkitMenu, e.getWhoClicked(), profile, level, battlePassReward, glassSlot, true));
                    }

                    bukkitMenu.setItem(finalSlot, ItemBuilder.of(battlePassReward.getDisplayItem())
                            .fixColors(new MapBuilder<String, Object>()
                                    .put("level", level)
                                    .build())
                            .toItemStack(), e -> this.receiveEvent(bukkitMenu, e.getWhoClicked(), profile, level, battlePassReward, glassSlot, true));
                });
            }
        }
    }

    private void receiveEvent(@NonNull BukkitMenu bukkitMenu, @NonNull HumanEntity humanEntity, @NonNull Profile profile, int rewardLevel, @NonNull BattlePassReward battlePassReward, int glassSlot, boolean premium) {
        final int level = this.battlePassService.getLevel(profile);

        if (premium && !this.battlePassService.hasPremium(humanEntity)) {
            this.messageConfig.premiumNotFound.send(humanEntity);
            return;
        }

        if (premium ? profile.getReceivedPremiumRewards().contains(rewardLevel) : profile.getReceivedRewards().contains(rewardLevel)) {
            this.messageConfig.rewardAlreadyReceived.send(humanEntity);
            return;
        }

        if (level < rewardLevel) {
            this.messageConfig.rewardNoLevel.send(humanEntity);
            return;
        }

        this.battlePassService.receiveReward(humanEntity, profile, battlePassReward, rewardLevel, premium);
        this.messageConfig.rewardReceived.send(humanEntity, new MapBuilder<String, Object>()
                .put("reward-level", rewardLevel)
                .build());

        if (this.pluginConfig.glassAboveReward) {
            bukkitMenu.setItem(glassSlot, ItemBuilder.of(this.pluginConfig.glassAboveRewardReceived)
                    .fixColors(new MapBuilder<String, Object>()
                            .put("level", rewardLevel)
                            .build())
                    .toItemStack(), e -> this.receiveEvent(bukkitMenu, e.getWhoClicked(), profile, rewardLevel, battlePassReward, glassSlot, premium));
        }
    }
}
