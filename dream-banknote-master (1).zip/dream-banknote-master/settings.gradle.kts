rootProject.name = "dream-banknote"

include(":plugin-core")