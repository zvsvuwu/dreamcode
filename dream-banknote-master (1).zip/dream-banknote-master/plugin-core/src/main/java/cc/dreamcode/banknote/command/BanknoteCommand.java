package cc.dreamcode.banknote.command;

import cc.dreamcode.banknote.BanknoteCache;
import cc.dreamcode.banknote.BanknotePlugin;
import cc.dreamcode.banknote.BanknoteService;
import cc.dreamcode.banknote.config.MessageConfig;
import cc.dreamcode.banknote.config.PluginConfig;
import cc.dreamcode.banknote.resourcepack.ResourcePackCache;
import cc.dreamcode.banknote.resourcepack.ResourcePackService;
import cc.dreamcode.command.CommandBase;
import cc.dreamcode.command.annotation.Arg;
import cc.dreamcode.command.annotation.Command;
import cc.dreamcode.command.annotation.Completion;
import cc.dreamcode.command.annotation.Executor;
import cc.dreamcode.command.annotation.Permission;
import cc.dreamcode.notice.adventure.BukkitNotice;
import cc.dreamcode.utilities.MathUtil;
import cc.dreamcode.utilities.TimeUtil;
import cc.dreamcode.utilities.builder.MapBuilder;
import eu.okaeri.configs.exception.OkaeriException;
import eu.okaeri.injector.annotation.Inject;
import lombok.RequiredArgsConstructor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.time.Duration;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;

@Command(name = "banknote", aliases = {"banknot", "czek"})
@RequiredArgsConstructor(onConstructor_ = @Inject)
public class BanknoteCommand implements CommandBase {

    private final BanknotePlugin banknotePlugin;
    private final PluginConfig pluginConfig;
    private final MessageConfig messageConfig;
    private final BanknoteCache banknoteCache;
    private final BanknoteService banknoteService;
    private final ResourcePackCache resourcePackCache;
    private final ResourcePackService resourcePackService;

    @Executor(description = "Tworzy czek z pieniedzy.")
    void banknote(Player player, @Arg double money) {

        if (this.pluginConfig.banknoteDisabled) {
            if (!this.pluginConfig.banknoteCheckAdmin || !player.hasPermission("dream-banknote.bypass")) {
                this.messageConfig.banknoteDisabled.send(player);
                return;
            }
        }

        final Optional<Double> optionalBalance = this.banknoteService.getBalance(player);
        if (!optionalBalance.isPresent()) {
            this.messageConfig.banknoteNoBank.send(player);
            return;
        }

        final double balance = optionalBalance.get();
        if (balance < money) {
            this.messageConfig.banknoteNoMoney.send(player);
            return;
        }

        if (money <= 0.0D || this.pluginConfig.banknoteMaxMoney < money) {
            this.messageConfig.banknoteMaxMoney.send(player, new MapBuilder<String, Object>()
                    .put("money", MathUtil.round(this.pluginConfig.banknoteMaxMoney, 3))
                    .build());
            return;
        }

        final Duration duration = this.banknoteCache.getCooldown(player.getUniqueId());
        if (!MathUtil.isNegative(duration)) {
            this.messageConfig.cooldown.send(player,
                    MapBuilder.of("time", TimeUtil.format(duration)));
            return;
        }

        this.banknoteCache.applyCooldown(player.getUniqueId());

        if (!this.banknoteService.withdraw(player, money)) {
            this.messageConfig.banknoteError.send(player);
            return;
        }

        this.banknoteService.addBanknote(player, money, player.getName());
    }

    @Permission("dream-banknote.create")
    @Completion(arg = "player", value = "@all-players")
    @Executor(path = "create", description = "Tworzy banknot graczowi.")
    void create(CommandSender commandSender, @Arg Player player, @Arg double money) {

        if (money <= 0.0D || this.pluginConfig.banknoteMaxMoney < money) {
            this.messageConfig.banknoteMaxMoney.send(player, new MapBuilder<String, Object>()
                    .put("money", MathUtil.round(this.pluginConfig.banknoteMaxMoney, 3))
                    .build());
            return;
        }

        this.banknoteService.addBanknote(player, money, commandSender.getName());
    }

    @Permission("dream-banknote.reload")
    @Executor(path = "reload", description = "Przeladowuje konfiguracje.")
    BukkitNotice reload(CommandSender sender) {
        final long time = System.currentTimeMillis();

        try {
            this.messageConfig.load();
            this.pluginConfig.load();

            if (this.pluginConfig.useResourcePack) {
                final AtomicInteger atomicInteger = new AtomicInteger();
                this.banknotePlugin.getServer().getOnlinePlayers().forEach(player ->
                        this.banknotePlugin.getServer().getScheduler().runTaskLater(this.banknotePlugin, () -> {

                            this.resourcePackCache.setLoadingScreen(player);
                            this.resourcePackService.setLoadingEffects(player);
                            this.resourcePackService.setResourcePack(player);

                        }, atomicInteger.getAndIncrement()));
            }

            return this.messageConfig.reloaded.with(new MapBuilder<String, Object>()
                    .put("time", TimeUtil.format(System.currentTimeMillis() - time))
                    .build());
        }
        catch (NullPointerException | OkaeriException e) {
            e.printStackTrace();

            return this.messageConfig.reloadError.with(new MapBuilder<String, Object>()
                    .put("error", e.getMessage())
                    .build());
        }
    }
}
