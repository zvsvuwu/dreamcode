package cc.dreamcode.banknote;

import cc.dreamcode.utilities.RandomUtil;
import lombok.experimental.UtilityClass;

@UtilityClass
public class BanknoteCode {

    public static String generate() {
        return RandomUtil.alphanumeric(8) + "-" + RandomUtil.alphanumeric(2);
    }
}
