package cc.dreamcode.banknote.resourcepack;

import cc.dreamcode.banknote.config.PluginConfig;
import cc.dreamcode.platform.DreamLogger;
import cc.dreamcode.utilities.bukkit.StringColorUtil;
import eu.okaeri.injector.annotation.Inject;
import lombok.RequiredArgsConstructor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.event.player.PlayerResourcePackStatusEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class ResourcePackController implements Listener {

    private final DreamLogger dreamLogger;
    private final PluginConfig pluginConfig;
    private final ResourcePackCache resourcePackCache;
    private final ResourcePackService resourcePackService;

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent e) {
        final Player player = e.getPlayer();

        if (this.pluginConfig.useResourcePack) {
            this.resourcePackCache.setLoadingScreen(player);
            this.resourcePackService.setLoadingEffects(player);
            this.resourcePackService.setResourcePack(player);
        }
    }

    @EventHandler
    public void onPlayerResourcePackLoad(PlayerResourcePackStatusEvent e) {
        final Player player = e.getPlayer();

        if (e.getStatus().equals(PlayerResourcePackStatusEvent.Status.DECLINED) ||
                e.getStatus().equals(PlayerResourcePackStatusEvent.Status.FAILED_DOWNLOAD)) {

            player.kickPlayer(StringColorUtil.fixColor(this.pluginConfig.resourcePackError));
            this.dreamLogger.info("Gracz " + player.getName() + " posiada problem z uruchomieniem paczki zasobow. (" + e.getStatus() + ")");
        }
        else if (e.getStatus().equals(PlayerResourcePackStatusEvent.Status.SUCCESSFULLY_LOADED)) {
            this.resourcePackService.unsetLoadingEffects(player);
            this.resourcePackCache.unsetLoadingScreen(player);
        }
    }

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent e) {
        final Player player = e.getPlayer();

        if (this.resourcePackCache.isLoadingScreen(player)) {
            if (e.getTo() != null && e.getFrom().distanceSquared(e.getTo()) != 0.0D) {
                e.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent e) {
        final Player player = e.getPlayer();

        if (this.resourcePackCache.isLoadingScreen(player)) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onPlayerItemDrop(PlayerDropItemEvent e) {
        final Player player = e.getPlayer();

        if (this.resourcePackCache.isLoadingScreen(player)) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onPlayerItemPickup(PlayerPickupItemEvent e) {
        final Player player = e.getPlayer();

        if (this.resourcePackCache.isLoadingScreen(player)) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onPlayerDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player)) {
            return;
        }

        final Player player = (Player) e.getEntity();

        if (this.resourcePackCache.isLoadingScreen(player)) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onPlayerTeleport(PlayerTeleportEvent e) {
        final Player player = e.getPlayer();

        if (this.resourcePackCache.isLoadingScreen(player)) {
            e.setCancelled(true);
        }
    }
}
