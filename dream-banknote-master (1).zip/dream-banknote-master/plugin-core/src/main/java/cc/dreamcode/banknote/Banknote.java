package cc.dreamcode.banknote;

import eu.okaeri.configs.annotation.CustomKey;
import eu.okaeri.persistence.document.Document;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.Instant;

@Data
@EqualsAndHashCode(callSuper = false)
public class Banknote extends Document {

    @CustomKey("money")
    private double money;
    @CustomKey("creator")
    private String creator;
    @CustomKey("date")
    private Instant date;

    public String getCode() {
        return this.getPath().getValue();
    }
}
