package cc.dreamcode.banknote.resourcepack;

import lombok.NoArgsConstructor;
import lombok.NonNull;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@NoArgsConstructor
public class ResourcePackCache {

    private final List<UUID> loadingScreen = new ArrayList<>();

    public boolean isLoadingScreen(@NonNull Player player) {
        return this.loadingScreen.contains(player.getUniqueId());
    }

    public void setLoadingScreen(@NonNull Player player) {
        if (this.loadingScreen.contains(player.getUniqueId())) {
            return;
        }

        this.loadingScreen.add(player.getUniqueId());
    }

    public void unsetLoadingScreen(@NonNull Player player) {
        if (!this.loadingScreen.contains(player.getUniqueId())) {
            return;
        }

        this.loadingScreen.remove(player.getUniqueId());
    }
}
