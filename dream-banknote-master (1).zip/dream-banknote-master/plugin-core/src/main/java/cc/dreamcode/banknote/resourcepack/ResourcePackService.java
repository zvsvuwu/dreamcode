package cc.dreamcode.banknote.resourcepack;

import cc.dreamcode.banknote.config.PluginConfig;
import eu.okaeri.injector.annotation.Inject;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class ResourcePackService {

    private final PluginConfig pluginConfig;

    public void setResourcePack(@NonNull Player player) {
        if (this.pluginConfig.resourcePackSha1 != null && !this.pluginConfig.resourcePackSha1.isEmpty()) {
            player.setResourcePack(this.pluginConfig.resourcePackUrl, this.decodeHexString(this.pluginConfig.resourcePackSha1));
            return;
        }

        player.setResourcePack(this.pluginConfig.resourcePackUrl);
    }

    public void setLoadingEffects(@NonNull Player player) {
        player.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 99999, 0));
    }

    public void unsetLoadingEffects(@NonNull Player player) {
        player.removePotionEffect(PotionEffectType.BLINDNESS);
    }

    private byte[] decodeHexString(String hexString) {
        if (hexString.length() % 2 == 1) {
            throw new IllegalArgumentException("Invalid hexadecimal String supplied.");
        }

        byte[] bytes = new byte[hexString.length() / 2];
        for (int i = 0; i < hexString.length(); i += 2) {
            bytes[i / 2] = this.hexToByte(hexString.substring(i, i + 2));
        }

        return bytes;
    }

    private byte hexToByte(String hexString) {
        int firstDigit = this.toDigit(hexString.charAt(0));
        int secondDigit = this.toDigit(hexString.charAt(1));

        return (byte) ((firstDigit << 4) + secondDigit);
    }

    private int toDigit(char hexChar) {
        int digit = Character.digit(hexChar, 16);
        if(digit == -1) {
            throw new IllegalArgumentException("Invalid Hexadecimal Character: "+ hexChar);
        }

        return digit;
    }
}
