package cc.dreamcode.banknote;

import eu.okaeri.injector.annotation.Inject;
import lombok.RequiredArgsConstructor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

import java.util.Objects;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class BanknoteController implements Listener {

    private final BanknoteService banknoteService;

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent e) {

        if (!Objects.equals(e.getHand(), EquipmentSlot.HAND)) {
            return;
        }

        final Player player = e.getPlayer();
        final ItemStack itemStack = e.getItem();

        if (itemStack == null ||
                !e.getAction().equals(Action.RIGHT_CLICK_BLOCK) &&
                !e.getAction().equals(Action.RIGHT_CLICK_AIR)) {
            return;
        }

        this.banknoteService.tryBanknote(player, itemStack);
    }
}
