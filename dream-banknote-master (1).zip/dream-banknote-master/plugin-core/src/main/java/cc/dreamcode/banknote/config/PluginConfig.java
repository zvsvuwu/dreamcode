package cc.dreamcode.banknote.config;

import cc.dreamcode.platform.bukkit.component.configuration.Configuration;
import cc.dreamcode.platform.persistence.StorageConfig;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import com.cryptomorin.xseries.XMaterial;
import eu.okaeri.configs.OkaeriConfig;
import eu.okaeri.configs.annotation.Comment;
import eu.okaeri.configs.annotation.CustomKey;
import eu.okaeri.configs.annotation.Header;
import org.bukkit.inventory.ItemStack;

import java.time.Duration;

@Configuration(
        child = "config.yml"
)
@Header("## Dream-Banknote (Main-Config) ##")
public class PluginConfig extends OkaeriConfig {

    @Comment
    @Comment("Debug pokazuje dodatkowe informacje do konsoli. Lepiej wylaczyc. :P")
    @CustomKey("debug")
    public boolean debug = true;

    @Comment
    @Comment("Czy plugin ma sprawdzac banknoty?")
    @Comment("Opcja przydatna, gdy serwer ma miec zablokowane banknoty.")
    @CustomKey("banknote-disabled")
    public boolean banknoteDisabled = false;

    @Comment
    @Comment("Czy admin ma prawo do uzycia banknotow, gdy te sa zablokowane?")
    @Comment("Uprawnienie do sprawdzania banknotow: (dream-banknote.bypass)")
    @CustomKey("banknote-check-admin")
    public boolean banknoteCheckAdmin = true;

    @Comment
    @Comment("Czy plugin ma uzywac custom resource-packa?")
    @CustomKey("use-resource-pack")
    public boolean useResourcePack = false;

    @Comment
    @Comment("Podaj adres do zip paczki zasobow na zewnetrznym hostingu.")
    @Comment("Rekomendujemy uzywanie serwisu DropBox do hostowania pliku zip.")
    @Comment("Przykladowy resource pack: https://repo.dreamcode.cc/files/banknote-example.zip")
    @CustomKey("resource-pack-url")
    public String resourcePackUrl = "";
    @CustomKey("resource-pack-sha1")
    public String resourcePackSha1 = "";

    @Comment
    @Comment("Jaki wyslac powod, gdy gracz odmowi pobieranie paczki lub gdy wyskoczy blad?")
    @CustomKey("resource-pack-error")
    public String resourcePackError = "&cWystapil problem z uruchomieniem paczki zasobow. Sprobuj ponownie.";

    @Comment
    @Comment("Jak ma wygladac item pieniadza?")
    @Comment("Item nie zapisuje danych w item-meta, tylko bezposrednio w data itemu.")
    @CustomKey("banknote-item")
    public ItemStack banknoteItem = ItemBuilder.of(XMaterial.PAPER.parseItem())
            .setName("&a&lCzek pieniężny - ${money}")
            .setLore("&8» &7Używając czeku otrzymasz na swoje",
                    "&8» &7konto &a+{money}$&7!",
                    "",
                    "&8» &7Wytworzył: &f{creator} ({ldt,medium,Europe/Warsaw#time})",
                    "&8» &7Unikalny kod: &b{code}",
                    "",
                    "&8» &aKliknij PRAWYM, aby wykorzystać.")
            .toItemStack();

    @Comment
    @Comment("Jakie id custom-model-data ma posiadac banknot?")
    @Comment("Jesli resource-pack nie jest uzywany, ponizsze id nie bedzie dodawane.")
    @CustomKey("banknote-custom-model-data")
    public int banknoteCustomModelData = 9384;

    @Comment
    @Comment("Jaka moze byc maksymalna kwota na banknocie?")
    @CustomKey("banknote-max-money")
    public double banknoteMaxMoney = 1000;

    @Comment
    @Comment("Jaki ma byc cooldown na tworzenie banknotow?")
    @CustomKey("banknote-cooldown")
    public Duration banknoteCooldown = Duration.ofSeconds(10L);

    @Comment
    @Comment("Uzupelnij dane do logowania bazy danych.")
    @CustomKey("storage-config")
    public StorageConfig storageConfig = new StorageConfig("dreambanknote");
}
