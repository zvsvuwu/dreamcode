package cc.dreamcode.banknote;

import eu.okaeri.persistence.repository.DocumentRepository;
import eu.okaeri.persistence.repository.annotation.DocumentCollection;
import lombok.NonNull;

import java.time.Instant;

@DocumentCollection(path = "banknotes", keyLength = 36)
public interface BanknoteRepository extends DocumentRepository<String, Banknote> {

    default Banknote create(double money, @NonNull String creator) {

        int attempt = 0;
        String code = BanknoteCode.generate();
        while (this.existsByPath(code)) {

            if (attempt >= 15) {
                throw new RuntimeException("Cannot generate unique code for banknote, remove some.");
            }

            attempt++;
            code = BanknoteCode.generate();
        }

        final Banknote banknote = this.findOrCreateByPath(code);
        banknote.setMoney(money);
        banknote.setCreator(creator);
        banknote.setDate(Instant.now());

        return banknote;
    }
}
