package cc.dreamcode.banknote;

import cc.dreamcode.banknote.config.MessageConfig;
import cc.dreamcode.banknote.config.PluginConfig;
import cc.dreamcode.banknote.vault.VaultHook;
import cc.dreamcode.platform.bukkit.hook.PluginHookManager;
import cc.dreamcode.utilities.MathUtil;
import cc.dreamcode.utilities.builder.MapBuilder;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import cc.dreamcode.utilities.bukkit.nbt.ItemNbtUtil;
import eu.okaeri.injector.annotation.Inject;
import eu.okaeri.persistence.document.Document;
import eu.okaeri.tasker.core.Tasker;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.Optional;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class BanknoteService {

    private final PluginConfig pluginConfig;
    private final MessageConfig messageConfig;
    private final BanknoteRepository banknoteRepository;
    private final PluginHookManager pluginHookManager;
    private final Tasker tasker;

    public Optional<Double> getBalance(@NonNull Player player) {
        return this.pluginHookManager.get(VaultHook.class)
                .flatMap(vaultHook -> vaultHook.getMoney(player));
    }

    public boolean withdraw(@NonNull Player player, double money) {
        return this.pluginHookManager.get(VaultHook.class)
                .map(vaultHook -> vaultHook.withdraw(player, money))
                .orElse(false);
    }

    public void tryBanknote(@NonNull Player player, @NonNull ItemStack itemStack) {

        if (this.pluginConfig.banknoteDisabled) {
            if (!this.pluginConfig.banknoteCheckAdmin || !player.hasPermission("dream-banknote.bypass")) {
                this.messageConfig.banknoteDisabled.send(player);
                return;
            }
        }

        final Optional<String> optionalCode = ItemNbtUtil.getValueByPlugin(itemStack, BanknoteVariable.NBT_KEY);
        if (!optionalCode.isPresent()) {
            return;
        }

        final Optional<VaultHook> optionalVaultHook = this.pluginHookManager.get(VaultHook.class);
        if (!optionalVaultHook.isPresent()) {
            this.messageConfig.banknoteNoBank.send(player);
            return;
        }

        final VaultHook vaultHook = optionalVaultHook.get();
        final String itemCode = optionalCode.get();
        this.tasker.newSharedChain("money-check")
                .supplyAsync(() -> this.banknoteRepository.findByPath(itemCode))
                .acceptAsync(optionalBanknote -> {

                    if (!optionalBanknote.isPresent()) {
                        return;
                    }

                    final Banknote banknote = optionalBanknote.get();
                    vaultHook.deposit(player, banknote.getMoney());
                })
                .acceptSync(optionalBanknote -> {

                    if (!optionalBanknote.isPresent()) {
                        return;
                    }

                    final Banknote banknote = optionalBanknote.get();
                    final ItemStack first = ItemBuilder.of(itemStack)
                            .setAmount(1)
                            .toItemStack();

                    player.getInventory().removeItem(first);

                    this.messageConfig.banknoteDeposit.send(player, new MapBuilder<String, Object>()
                            .put("money", MathUtil.round(banknote.getMoney(), 3))
                            .put("creator", banknote.getCreator())
                            .put("time", banknote.getDate())
                            .put("code", banknote.getCode())
                            .put("actual-money", vaultHook.getMoney(player).orElse(0.0D))
                            .build());
                })
                .async(() -> this.banknoteRepository.deleteByPath(itemCode))
                .execute();
    }

    public void addBanknote(@NonNull Player player, double money, @NonNull String creator) {
        this.tasker.newSharedChain("money-create")
                .supplyAsync(() -> this.banknoteRepository.create(money, creator))
                .acceptAsync(Document::save)
                .acceptSync(banknote -> {

                    final ItemStack item = ItemNbtUtil.setValue(ItemBuilder.of(this.pluginConfig.banknoteItem)
                            .fixColors(new MapBuilder<String, Object>()
                                    .put("money", MathUtil.round(banknote.getMoney(), 3))
                                    .put("creator", banknote.getCreator())
                                    .put("time", banknote.getDate())
                                    .put("code", banknote.getCode())
                                    .build())
                            .withCustomMeta(itemMeta -> {
                                if (this.pluginConfig.useResourcePack) {
                                    itemMeta.setCustomModelData(this.pluginConfig.banknoteCustomModelData);
                                }

                                return itemMeta;
                            })
                            .toItemStack(), "banknote-code", banknote.getCode());

                    player.getInventory().addItem(item).forEach(((integer, itemStack) ->
                            player.getWorld().dropItem(player.getLocation(), itemStack)));

                    this.messageConfig.banknoteAdded.send(player, new MapBuilder<String, Object>()
                            .put("money", MathUtil.round(banknote.getMoney(), 3))
                            .put("creator", banknote.getCreator())
                            .put("time", banknote.getDate())
                            .put("code", banknote.getCode())
                            .build());
                })
                .execute();
    }
}
