package cc.dreamcode.banknote;

public final class BanknoteVariable {
    public static final String NBT_KEY = "banknote-code";
}
