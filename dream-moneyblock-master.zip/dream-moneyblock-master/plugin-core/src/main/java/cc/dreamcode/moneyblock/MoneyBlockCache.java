package cc.dreamcode.moneyblock;

import cc.dreamcode.moneyblock.config.PluginConfig;
import cc.dreamcode.utilities.MathUtil;
import eu.okaeri.injector.annotation.Inject;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

import java.time.Duration;
import java.time.Instant;
import java.util.Map;
import java.util.UUID;
import java.util.WeakHashMap;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class MoneyBlockCache {

    private final PluginConfig pluginConfig;

    private final Map<UUID, Instant> cooldownMap = new WeakHashMap<>();

    public Duration getCooldown(@NonNull UUID uuid) {
        if (!this.cooldownMap.containsKey(uuid)) {
            return Duration.ZERO;
        }

        final Instant instant = this.cooldownMap.get(uuid);
        return MathUtil.difference(instant, this.pluginConfig.cooldown);
    }

    public void applyCooldown(@NonNull UUID uuid) {
        this.cooldownMap.put(uuid, Instant.now());
    }
}
