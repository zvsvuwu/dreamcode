package cc.dreamcode.moneyblock.turbo;

import cc.dreamcode.utilities.MathUtil;
import com.cryptomorin.xseries.XMaterial;
import lombok.Data;

import java.time.Duration;
import java.time.Instant;
import java.util.UUID;

@Data
public class Turbo {

    private final UUID doer;
    private final Instant instant;
    private final String sender;
    private final XMaterial material;
    private final Duration duration;
    private final double multiplier;

    public boolean isOnBlock() {
        return !this.material.equals(XMaterial.AIR);
    }

    public Duration getActualDuration() {
        return MathUtil.difference(this.instant, this.duration);
    }
}
