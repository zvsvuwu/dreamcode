package cc.dreamcode.moneyblock;

import cc.dreamcode.menu.adventure.BukkitMenuBuilder;
import cc.dreamcode.menu.adventure.base.BukkitMenu;
import cc.dreamcode.menu.adventure.setup.BukkitMenuPlayerSetup;
import cc.dreamcode.moneyblock.config.PluginConfig;
import cc.dreamcode.utilities.StringUtil;
import cc.dreamcode.utilities.builder.MapBuilder;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import eu.okaeri.injector.annotation.Inject;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.bukkit.entity.HumanEntity;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class MoneyBlockListMenu implements BukkitMenuPlayerSetup {

    private final PluginConfig pluginConfig;

    @Override
    public BukkitMenu build(@NonNull HumanEntity humanEntity) {

        final BukkitMenuBuilder menuBuilder = this.pluginConfig.blocksMenuBuilder;
        final BukkitMenu bukkitMenu = menuBuilder.buildEmpty();

        menuBuilder.getItems().forEach((slot, item) -> {

            if (this.pluginConfig.moneyBlockMenuCloseSlot == slot) {
                bukkitMenu.setItem(slot, ItemBuilder.of(item).fixColors().toItemStack(), event ->
                        event.getWhoClicked().closeInventory());
                return;
            }

            bukkitMenu.setItem(slot, ItemBuilder.of(item).fixColors().toItemStack());
        });

        final List<String> lore = new ArrayList<>();

        final ItemMeta itemMeta = this.pluginConfig.moneyBlockFortuneItem.getItemMeta();
        if (Objects.requireNonNull(itemMeta).hasLore()) {
            for (String text : Objects.requireNonNull(itemMeta.getLore())) {

                if (!text.contains("{fortune-list}")) {
                    lore.add(text);
                    continue;
                }

                this.pluginConfig.fortuneMultiplier.forEach((fortune, multiplier) ->
                        lore.add(StringUtil.replace(text, "fortune-list", StringUtil.replace(
                                this.pluginConfig.moneyBlockFortuneFormat, new MapBuilder<String, Object>()
                                        .put("level", fortune)
                                        .put("multiplier", multiplier)
                                        .build())
                        )));
            }
        }

        bukkitMenu.addItem(ItemBuilder.of(this.pluginConfig.moneyBlockFortuneItem)
                .setLore(lore)
                .fixColors()
                .toItemStack());

        this.pluginConfig.moneyBlocks.forEach(moneyBlock -> {

            final List<String> loreMaterial = new ArrayList<>();

            final ItemMeta itemMetaMaterial = this.pluginConfig.moneyBlockListItem.getItemMeta();
            if (Objects.requireNonNull(itemMetaMaterial).hasLore()) {
                for (String text : Objects.requireNonNull(itemMetaMaterial.getLore())) {

                    if (!text.contains("{fortune-list}")) {
                        loreMaterial.add(text);
                        continue;
                    }

                    moneyBlock.getFortuneMultiplier().forEach((fortune, multiplier) ->
                            loreMaterial.add(StringUtil.replace(text, "fortune-list", StringUtil.replace(
                                    this.pluginConfig.moneyBlockFortuneFormat, new MapBuilder<String, Object>()
                                            .put("level", fortune)
                                            .put("multiplier", multiplier)
                                            .build())
                            )));
                }
            }

            bukkitMenu.addItem(ItemBuilder.of(this.pluginConfig.moneyBlockListItem)
                    .setType(Objects.requireNonNull(moneyBlock.getMaterial().parseMaterial()))
                    .setLore(loreMaterial)
                    .fixColors(new MapBuilder<String, Object>()
                            .put("price", moneyBlock.getPrice())
                            .build())
                    .toItemStack());
        });

        return bukkitMenu;
    }
}
