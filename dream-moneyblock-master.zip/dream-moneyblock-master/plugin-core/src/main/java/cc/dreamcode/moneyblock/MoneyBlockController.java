package cc.dreamcode.moneyblock;

import eu.okaeri.injector.annotation.Inject;
import lombok.RequiredArgsConstructor;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerInteractEvent;

import java.util.Map;
import java.util.UUID;
import java.util.WeakHashMap;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class MoneyBlockController implements Listener {

    private final MoneyBlockService moneyBlockService;

    private final Map<UUID, Long> diggingSpeed = new WeakHashMap<>();

    @EventHandler
    public void onPlayerStartBreakingBlock(PlayerInteractEvent event) {

        if (!event.getAction().equals(Action.LEFT_CLICK_BLOCK)) {
            return;
        }

        final Player player = event.getPlayer();
        this.diggingSpeed.put(player.getUniqueId(), System.currentTimeMillis());
    }

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        final Player player = event.getPlayer();
        final Block block = event.getBlock();

        if (!this.diggingSpeed.containsKey(player.getUniqueId())) {
            return;
        }

        final long startBreaking = this.diggingSpeed.get(player.getUniqueId());
        final long endBreaking = System.currentTimeMillis();
        final long diffMills = endBreaking - startBreaking;

        this.moneyBlockService.tryWithBlock(player, block, diffMills == 0 ? 1 : diffMills);
    }

}
