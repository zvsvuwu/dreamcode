package cc.dreamcode.moneyblock.command.suggestion;

import cc.dreamcode.command.suggestion.supplier.SuggestionSupplier;
import cc.dreamcode.moneyblock.config.PluginConfig;
import cc.dreamcode.platform.other.component.annotation.SuggestionKey;
import eu.okaeri.injector.annotation.Inject;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

@SuggestionKey("@moneyblocks")
@RequiredArgsConstructor(onConstructor_ = @Inject)
public class MoneyBlockSuggestion implements SuggestionSupplier {

    private final PluginConfig pluginConfig;

    @Override
    public List<String> supply(@NonNull Class<?> paramType) {
        return this.pluginConfig.moneyBlocks
                .stream()
                .map(moneyBlock -> moneyBlock.getMaterial().name().toLowerCase(Locale.ROOT))
                .collect(Collectors.toList());
    }
}
