package cc.dreamcode.moneyblock.event;

import lombok.Getter;
import lombok.NonNull;
import lombok.Setter;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;
import org.jetbrains.annotations.NotNull;

import java.util.UUID;

@Getter
public class DropMultiplierEvent extends Event {

    private static final HandlerList handlers = new HandlerList();

    private final UUID playerUuid;
    @Setter private double multiplier;

    public DropMultiplierEvent(UUID playerUuid, double multiplier) {
        this.playerUuid = playerUuid;
        this.multiplier = multiplier;
    }

    @NonNull
    @Override
    public @NotNull HandlerList getHandlers() {
        return handlers;
    }

    public static HandlerList getHandlerList() {
        return handlers;
    }
}
