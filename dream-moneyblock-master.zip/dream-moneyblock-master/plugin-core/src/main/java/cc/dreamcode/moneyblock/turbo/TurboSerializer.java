package cc.dreamcode.moneyblock.turbo;

import com.cryptomorin.xseries.XMaterial;
import eu.okaeri.configs.schema.GenericsDeclaration;
import eu.okaeri.configs.serdes.DeserializationData;
import eu.okaeri.configs.serdes.ObjectSerializer;
import eu.okaeri.configs.serdes.SerializationData;
import lombok.NonNull;

import java.time.Duration;
import java.time.Instant;
import java.util.UUID;

public class TurboSerializer implements ObjectSerializer<Turbo> {
    @Override
    public boolean supports(@NonNull Class<? super Turbo> type) {
        return Turbo.class.isAssignableFrom(type);
    }

    @Override
    public void serialize(@NonNull Turbo object, @NonNull SerializationData data, @NonNull GenericsDeclaration generics) {
        data.add("turbo-doer", object.getDoer());
        data.add("turbo-instant", object.getInstant());
        data.add("turbo-sender", object.getSender());
        data.add("turbo-material", object.getMaterial());
        data.add("turbo-duration", object.getDuration());
        data.add("turbo-multiplier", object.getMultiplier());
    }

    @Override
    public Turbo deserialize(@NonNull DeserializationData data, @NonNull GenericsDeclaration generics) {
        return new Turbo(
                data.get("turbo-doer", UUID.class),
                data.get("turbo-instant", Instant.class),
                data.get("turbo-sender", String.class),
                data.get("turbo-material", XMaterial.class),
                data.get("turbo-duration", Duration.class),
                data.get("turbo-multiplier", Double.class)
        );
    }
}
