package cc.dreamcode.moneyblock.vault;

import cc.dreamcode.moneyblock.MoneyBlockPlugin;
import lombok.NonNull;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.ServicesManager;

public class VaultTopService {

    private final Economy economy;

    public VaultTopService(MoneyBlockPlugin moneyBlockPlugin) {

        final ServicesManager servicesManager = moneyBlockPlugin.getServer().getServicesManager();
        final RegisteredServiceProvider<Economy> rsp = servicesManager.getRegistration(Economy.class);

        if (rsp == null) {
            throw new RuntimeException("Cannot get economy class from Vault");
        }

        this.economy = rsp.getProvider();
    }

    public double getMoney(@NonNull OfflinePlayer player) {
        return this.economy.getBalance(player);
    }

    public boolean deposit(@NonNull OfflinePlayer player, double money) {
        return this.economy.depositPlayer(player, money).transactionSuccess();
    }

    public boolean withdraw(@NonNull OfflinePlayer player, double money) {
        return this.economy.withdrawPlayer(player, money).transactionSuccess();
    }
}
