package cc.dreamcode.moneyblock.config;

import cc.dreamcode.menu.adventure.BukkitMenuBuilder;
import cc.dreamcode.menu.utilities.MenuUtil;
import cc.dreamcode.moneyblock.MoneyBlock;
import cc.dreamcode.moneyblock.MoneyBlockNoticeDisplay;
import cc.dreamcode.notice.adventure.BukkitNotice;
import cc.dreamcode.platform.bukkit.component.configuration.Configuration;
import cc.dreamcode.utilities.builder.ListBuilder;
import cc.dreamcode.utilities.builder.MapBuilder;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import com.cryptomorin.xseries.XMaterial;
import eu.okaeri.configs.OkaeriConfig;
import eu.okaeri.configs.annotation.Comment;
import eu.okaeri.configs.annotation.CustomKey;
import eu.okaeri.configs.annotation.Header;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.inventory.ItemStack;

import java.time.Duration;
import java.util.List;
import java.util.Map;

@Configuration(child = "config.yml")
@Header("## Dream-MoneyBlock (Main-Config) ##")
public class PluginConfig extends OkaeriConfig {

    @Comment
    @Comment("Debug pokazuje dodatkowe informacje do konsoli. Lepiej wylaczyc. :P")
    @CustomKey("debug")
    public boolean debug = true;

    @Comment
    @Comment("Jaki ma byc cooldown na poszczegolne rzeczy?")
    @CustomKey("cooldown")
    public Duration cooldown = Duration.ofSeconds(1L);

    @Comment
    @Comment("Jakie bloki maja byc dostepne do wykopania?")
    @CustomKey("money-blocks")
    public List<MoneyBlock> moneyBlocks = new ListBuilder<MoneyBlock>()
            .add(new MoneyBlock(XMaterial.DIAMOND_ORE, 0.45D, MapBuilder.of(1, 0.25D, 2, 0.52, 3, 0.82)))
            .add(new MoneyBlock(XMaterial.DIAMOND_BLOCK, 1.20D, MapBuilder.of(1, 0.24D, 2, 0.54, 3, 0.85)))
            .add(new MoneyBlock(XMaterial.EMERALD_ORE, 0.74D, MapBuilder.of(1, 0.23D, 2, 0.56, 3, 0.87)))
            .add(new MoneyBlock(XMaterial.EMERALD_BLOCK, 1.84D, MapBuilder.of(1, 0.21D, 2, 0.58, 3, 0.89)))
            .build();

    @Comment
    @Comment("Jak ma byc wyswietlana wiadomosc o wykopaniu money block?")
    @Comment("Do wyboru: (NOTICE, BOSSBAR)")
    @CustomKey("money-block-notice-display")
    public MoneyBlockNoticeDisplay moneyBlockNoticeDisplay = MoneyBlockNoticeDisplay.BOSSBAR;

    @Comment
    @Comment("Opcja tyczy sie, jesli wyzej zostal ustawiony tryb BOSSBAR")
    @Comment("Jaki tekst ma wysylac plugin, gdy ktos wykopie money block?")
    @CustomKey("boss-bar-text")
    public String bossBarText = "&2⛏ &8| &aZarobiłeś &2${money} &8(&fmnożnik &6x{multiplier}&8) &aOkoło &2${estimates-min} &ana minutę oraz &2${estimates-hour} &ana godzinę &8| &aPosiadasz &2${cash}";

    @Comment
    @Comment("Jaki styl ma miec bossbar?")
    @CustomKey("boss-bar-style")
    public BarStyle bossBarStyle = BarStyle.SEGMENTED_20;

    @Comment
    @Comment("Jaki kolor ma miec bossbar?")
    @CustomKey("boss-bar-color")
    public BarColor bossBarColor = BarColor.GREEN;

    @Comment
    @Comment("Ile czasu ma byc wyswietlany bossbar?")
    @CustomKey("boss-bar-duration")
    public Duration bossBarDuration = Duration.ofSeconds(1L);

    @Comment
    @Comment("Opcja tyczy sie, jesli wyzej zostal ustawiony tryb NOTICE")
    @Comment("Jaki notice ma wysylac plugin, gdy ktos wykopie money block?")
    @CustomKey("notice-text")
    public BukkitNotice noticeText = BukkitNotice.actionBar("&2⛏ &8| &aZarobiłeś &2${money} &8(&fmnożnik &6x{multiplier}&8) &aOkoło &2${estimates-min} &ana minutę oraz &2${estimates-hour} &ana godzinę &8| &aPosiadasz &2${cash}");

    @Comment
    @Comment("Jaka fortunka nadaje mnoznik?")
    @CustomKey("fortune-multiplier")
    public Map<Integer, Double> fortuneMultiplier = MapBuilder.of(1, 0.2D, 2, 0.5, 3, 0.8);

    @Comment
    @Comment("Jaki mnoznik ma byc ustawiony dla poszczegolnych permisji?")
    @Comment("Gdy jest wartosc ustawiona jako default, wowczas jest ono uznawane jako podstawowa wartosc.")
    @Comment("Dana ranga powinna posiadac wszystkie uprawnienia (oprocz default), gdy rang jest wiecej niz 2.")
    @CustomKey("permission-multiplier")
    public Map<String, Double> permissionMultiplier = new MapBuilder<String, Double>()
            .put("default", 0.0D)
            .put("dream-moneyblock.vip", 0.5D)
            .build();

    @Comment
    @Comment("Jak ma wygladac podglad blokow z money-blokiem?")
    @CustomKey("money-block-menu-builder")
    public BukkitMenuBuilder blocksMenuBuilder = new BukkitMenuBuilder("&8[&bM&8] Podglad money-block", 5, new MapBuilder<Integer, ItemStack>()
            .put(MenuUtil.countSlot(5, 5), ItemBuilder.of(XMaterial.BARRIER.parseItem())
                    .setName("&cWyjdz z menu.")
                    .toItemStack())
            .build());

    @Comment
    @Comment("Pod jakim slotem ma sie znajdowac przycisk od wyjscia z menu?")
    @CustomKey("money-block-menu-close-slot")
    public int moneyBlockMenuCloseSlot = MenuUtil.countSlot(5, 5);

    @Comment
    @Comment("Jak ma wygladac podglad fortuny w liscie money-block?")
    @CustomKey("money-block-fortune-item")
    public ItemStack moneyBlockFortuneItem = ItemBuilder.of(XMaterial.PAPER.parseItem())
            .setName("&7Wszystkie bloki")
            .setLore("",
                    "&8» &7Lista fortune:",
                    "{fortune-list}")
            .toItemStack();

    @Comment
    @Comment("Jak ma wygladac podglad bloku w liscie money-block?")
    @CustomKey("money-block-list-item")
    public ItemStack moneyBlockListItem = ItemBuilder.of(XMaterial.PAPER.parseItem())
            .setLore("",
                    "&8» &7Cena: &a${price}",
                    "",
                    "&8» &7Lista fortune:",
                    "{fortune-list}")
            .toItemStack();

    @Comment
    @Comment("Jak ma wygladac poszczegolny element w liscie z fortuna?")
    @CustomKey("money-block-fortune-format")
    public String moneyBlockFortuneFormat = " &fFortune {level} &8- &6x{multiplier}";

    @Comment
    @Comment("Jak ma wygladac wiadomosc od turbodropu?")
    @CustomKey("turbodrop-notice")
    public BukkitNotice turboDropNotice = BukkitNotice.actionBar("<rainbow>TURBO DROP</rainbow> &faktywny przez &6{time} &8(&fmnożnik &6x{multiplier}&8)");

    @Comment
    @Comment("Jaka fraza ma byc zwraca dla wszystkich blokow?")
    public String allBlocksText = "wszystkie";

    @Comment
    @Comment("Jak ma wygladac menu od podgladu wszystkich tubrodropow gracza?")
    @CustomKey("turbo-menu-builder")
    public BukkitMenuBuilder turboMenuBuilder = new BukkitMenuBuilder("&8[&bM&8] Podglad turbo-drop", 5, new MapBuilder<Integer, ItemStack>()
            .put(MenuUtil.countSlot(5, 5), ItemBuilder.of(XMaterial.BARRIER.parseItem())
                    .setName("&cWyjdz z menu.")
                    .toItemStack())
            .build());

    @Comment
    @Comment("Pod jakim slotem ma sie znajdowac przycisk od wyjscia z menu?")
    @CustomKey("turbo-menu-close-slot")
    public int turboMenuCloseSlot = MenuUtil.countSlot(5, 5);

    @Comment
    @Comment("Jak ma wygladac item od nadanego turbo-dropa?")
    @CustomKey("turbo-menu-item")
    public ItemStack turboMenuItem =  ItemBuilder.of(XMaterial.PAPER.parseItem())
            .setName("&eTurbo-Drop")
            .setLore("",
                    "&8» &7Typ: &f{type}",
                    "&8» &7Nadano: &f{date}",
                    "&8» &7Nadano przez: &f{sender}",
                    "&8» &7Na czas: &f{duration}",
                    "&8» &7Z mnoznikiem: &6x{multiplier}",
                    "&8» &7Na blok(i): &f{material}",
                    "",
                    "&8» &7Pozostaly czas: &f{actual-duration}")
            .toItemStack();
}
