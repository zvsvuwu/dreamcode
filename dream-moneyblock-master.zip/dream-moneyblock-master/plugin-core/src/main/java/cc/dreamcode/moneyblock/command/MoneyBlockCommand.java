package cc.dreamcode.moneyblock.command;

import cc.dreamcode.command.CommandBase;
import cc.dreamcode.command.annotation.Arg;
import cc.dreamcode.command.annotation.Async;
import cc.dreamcode.command.annotation.Command;
import cc.dreamcode.command.annotation.Completion;
import cc.dreamcode.command.annotation.Executor;
import cc.dreamcode.command.annotation.OptArg;
import cc.dreamcode.command.annotation.Permission;
import cc.dreamcode.moneyblock.MoneyBlockCache;
import cc.dreamcode.moneyblock.MoneyBlockListMenu;
import cc.dreamcode.moneyblock.MoneyBlockPlugin;
import cc.dreamcode.moneyblock.MoneyBlockService;
import cc.dreamcode.moneyblock.config.MessageConfig;
import cc.dreamcode.moneyblock.config.PluginConfig;
import cc.dreamcode.moneyblock.turbo.TurboListMenu;
import cc.dreamcode.moneyblock.turbo.TurboService;
import cc.dreamcode.notice.adventure.BukkitNotice;
import cc.dreamcode.utilities.Formatter;
import cc.dreamcode.utilities.MathUtil;
import cc.dreamcode.utilities.builder.MapBuilder;
import com.cryptomorin.xseries.XMaterial;
import eu.okaeri.configs.exception.OkaeriException;
import eu.okaeri.injector.annotation.Inject;
import lombok.RequiredArgsConstructor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.time.Duration;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

@Command(name = "moneyblock")
@Permission("dream-moneyblock.admin")
@RequiredArgsConstructor(onConstructor_ = @Inject)
public class MoneyBlockCommand implements CommandBase {

    private final MoneyBlockPlugin moneyBlockPlugin;
    private final PluginConfig pluginConfig;
    private final MessageConfig messageConfig;
    private final MoneyBlockCache moneyBlockCache;
    private final MoneyBlockService moneyBlockService;
    private final TurboService turboService;

    @Async
    @Permission("dream-moneyblock.reload")
    @Executor(path = "reload", description = "Przeladowuje konfiguracje.")
    BukkitNotice reload() {
        final long time = System.currentTimeMillis();

        try {
            this.messageConfig.load();
            this.pluginConfig.load();

            return this.messageConfig.reloaded
                    .with("time", Formatter.format(System.currentTimeMillis() - time));
        }
        catch (NullPointerException | OkaeriException e) {
            e.printStackTrace();

            return this.messageConfig.reloadError
                    .with("error", e.getMessage());
        }
    }

    @Completion(arg = "material", value = "@enum")
    @Executor(path = "create", description = "Tworzy nowy blok z kasa.")
    BukkitNotice create(CommandSender sender, @Arg XMaterial material, @Arg double price) {
        this.moneyBlockService.addMaterial(material, price);

        return this.messageConfig.moneyBlockAdded;
    }

    @Completion(arg = "material", value = "@moneyblocks")
    @Executor(path = "remove", description = "Usuwa blok z kasa.")
    BukkitNotice remove(CommandSender sender, @Arg XMaterial material) {

        if (!this.moneyBlockService.removeMaterial(material)) {
            return this.messageConfig.moneyBlockNotFound;
        }

        return this.messageConfig.moneyBlockRemoved;
    }

    @Completion(arg = "material", value = "@enum")
    @Executor(path = "fortune", description = "Dodaje lub usuwa fortune.")
    BukkitNotice fortune(CommandSender sender, @Arg int fortune, @Arg double multiplier, @OptArg Optional<XMaterial> material) {

        if (material.isPresent()) {
            if (!this.moneyBlockService.modifyFortune(material.get(), fortune, multiplier)) {
                return this.messageConfig.moneyBlockNotFound;
            }
        }
        else {
            this.moneyBlockService.modifyFortune(fortune, multiplier);
        }

        return this.messageConfig.moneyBlockFortuneModify;
    }

    @Executor(path = "list", description = "Lista blokow z cenami.")
    void list(Player player) {

        final Duration duration = this.moneyBlockCache.getCooldown(player.getUniqueId());
        if (!MathUtil.isNegative(duration)) {
            this.messageConfig.cooldown.send(player,
                    MapBuilder.of("time", Formatter.format(duration)));
            return;
        }

        this.moneyBlockCache.applyCooldown(player.getUniqueId());

        this.moneyBlockPlugin.createInstance(MoneyBlockListMenu.class)
                .build(player)
                .open(player);
    }

    @Completion(arg = "nick", value = {"@all-players", "all"})
    @Completion(arg = "material", value = "@moneyblocks")
    @Executor(path = "turbo add", description = "Nadaje turbo-drop.")
    BukkitNotice turboAdd(CommandSender sender, @Arg String nick, @Arg Duration duration, @Arg double multiplier, @OptArg Optional<XMaterial> material) {

        if (material.isPresent() && this.pluginConfig.moneyBlocks
                .stream()
                .noneMatch(moneyBlock -> moneyBlock.getMaterial().equals(material.get()))) {
            return this.messageConfig.moneyBlockNotFound;
        }

        if (nick.equalsIgnoreCase("all")) {
            this.turboService.applyServerTurbo(sender.getName(), material, duration, multiplier);

            final Map<String, Object> placeholders = new MapBuilder<String, Object>()
                    .put("sender", sender.getName())
                    .put("time", Formatter.format(duration))
                    .put("multiplier", multiplier)
                    .put("material", material.map(xMaterial -> xMaterial.name().toLowerCase(Locale.ROOT))
                            .orElse(this.pluginConfig.allBlocksText))
                    .build();

            this.messageConfig.turboDropBroadcastAll.sendAll(placeholders);
            return this.messageConfig.turboDropAddedAll.with(placeholders);
        }

        final Player customer = this.moneyBlockPlugin.getServer().getPlayerExact(nick);
        if (customer == null) {
            return this.messageConfig.playerNotFound;
        }

        this.turboService.applyPlayerTurbo(customer.getUniqueId(), sender.getName(), material, duration, multiplier);

        final Map<String, Object> placeholders = new MapBuilder<String, Object>()
                .put("nick", customer.getName())
                .put("sender", sender.getName())
                .put("time", Formatter.format(duration))
                .put("multiplier", multiplier)
                .put("material", material.map(xMaterial -> xMaterial.name().toLowerCase(Locale.ROOT))
                        .orElse(this.pluginConfig.allBlocksText))
                .build();

        this.messageConfig.turboDropBroadcast.sendAll(placeholders);
        return this.messageConfig.turboDropAdded.with(placeholders);
    }

    @Completion(arg = "nick", value = {"@all-players", "all"})
    @Completion(arg = "material", value = "@moneyblocks")
    @Executor(path = "turbo remove", description = "Usuwa turbo-drop.")
    BukkitNotice turboRemove(CommandSender sender, @Arg String nick, @OptArg Optional<XMaterial> material) {

        if (material.isPresent() && this.pluginConfig.moneyBlocks
                .stream()
                .noneMatch(moneyBlock -> moneyBlock.getMaterial().equals(material.get()))) {
            return this.messageConfig.moneyBlockNotFound;
        }

        if (nick.equalsIgnoreCase("all")) {
            this.turboService.removeServerTurbo(material);

            return this.messageConfig.turboDropRemovedAll.with(new MapBuilder<String, Object>()
                    .put("sender", sender.getName())
                    .put("material", material.map(xMaterial -> xMaterial.name().toLowerCase(Locale.ROOT))
                            .orElse(this.pluginConfig.allBlocksText))
                    .build());
        }

        final Player customer = this.moneyBlockPlugin.getServer().getPlayerExact(nick);
        if (customer == null) {
            return this.messageConfig.playerNotFound;
        }

        this.turboService.removePlayerTurbo(customer.getUniqueId(), material);

        return this.messageConfig.turboDropRemoved.with(new MapBuilder<String, Object>()
                .put("nick", customer.getName())
                .put("sender", sender.getName())
                .put("material", material.map(xMaterial -> xMaterial.name().toLowerCase(Locale.ROOT))
                        .orElse(this.pluginConfig.allBlocksText))
                .build());
    }

    @Completion(arg = "customer", value = "@offline-players")
    @Executor(path = "turbo info", description = "Sprawdza turbo-drop gracza.")
    void turboInfo(Player player, @Arg OfflinePlayer customer) {

        final Duration duration = this.moneyBlockCache.getCooldown(player.getUniqueId());
        if (!MathUtil.isNegative(duration)) {
            this.messageConfig.cooldown.send(player,
                    MapBuilder.of("time", Formatter.format(duration)));
            return;
        }

        this.moneyBlockCache.applyCooldown(player.getUniqueId());

        TurboListMenu turboListMenu = this.moneyBlockPlugin.createInstance(TurboListMenu.class);
        turboListMenu.setUuid(customer.getUniqueId());

        turboListMenu.build().open(player);
    }
}
