package cc.dreamcode.moneyblock.turbo;

import cc.dreamcode.moneyblock.MoneyBlockService;
import com.cryptomorin.xseries.XMaterial;
import eu.okaeri.injector.annotation.Inject;
import lombok.RequiredArgsConstructor;
import org.bukkit.block.Block;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerQuitEvent;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class TurboController implements Listener {

    private final TurboCache turboCache;
    private final MoneyBlockService moneyBlockService;

    @EventHandler
    public void onBlockBreak(BlockBreakEvent event) {
        final Block block = event.getBlock();

        if (!this.moneyBlockService.matchMoneyBlock(XMaterial.matchXMaterial(block.getType())).isPresent()) {
            return;
        }

        this.turboCache.applyMining(event.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        this.turboCache.remove(event.getPlayer().getUniqueId());
    }
}
