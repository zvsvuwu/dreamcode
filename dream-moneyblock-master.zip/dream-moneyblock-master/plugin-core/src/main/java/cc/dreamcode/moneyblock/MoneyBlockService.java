package cc.dreamcode.moneyblock;

import cc.dreamcode.moneyblock.bossbar.BossBarCache;
import cc.dreamcode.moneyblock.config.PluginConfig;
import cc.dreamcode.moneyblock.event.DropMultiplierEvent;
import cc.dreamcode.moneyblock.turbo.Turbo;
import cc.dreamcode.moneyblock.turbo.TurboService;
import cc.dreamcode.moneyblock.vault.VaultHook;
import cc.dreamcode.platform.DreamLogger;
import cc.dreamcode.platform.bukkit.hook.PluginHookManager;
import cc.dreamcode.utilities.builder.MapBuilder;
import cc.dreamcode.utilities.bukkit.StringColorUtil;
import com.cryptomorin.xseries.XMaterial;
import eu.okaeri.injector.annotation.Inject;
import eu.okaeri.tasker.core.Tasker;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.bukkit.block.Block;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class MoneyBlockService {

    private final MoneyBlockPlugin moneyBlockPlugin;
    private final DreamLogger dreamLogger;
    private final PluginConfig pluginConfig;
    private final PluginHookManager pluginHookManager;
    private final TurboService turboService;
    private final BossBarCache bossBarCache;
    private final Tasker tasker;

    public Optional<MoneyBlock> matchMoneyBlock(@NonNull XMaterial xMaterial) {
        return this.pluginConfig.moneyBlocks
                .stream()
                .filter(moneyBlock -> moneyBlock.getMaterial().equals(xMaterial))
                .findAny();
    }

    public void tryWithBlock(@NonNull Player player, @NonNull Block block, long digMills) {
        final XMaterial xMaterial = XMaterial.matchXMaterial(block.getType());
        final Optional<MoneyBlock> optionalMoneyBlock = this.matchMoneyBlock(xMaterial);

        if (!optionalMoneyBlock.isPresent()) {
            return;
        }

        final MoneyBlock moneyBlock = optionalMoneyBlock.get();
        final Optional<VaultHook> optionalVaultHook = this.pluginHookManager.get(VaultHook.class);

        if (!optionalVaultHook.isPresent()) {
            this.dreamLogger.warning("Plugin requires Vault and his economy plugin to deposit money");
            return;
        }

        final VaultHook vaultHook = optionalVaultHook.get();

        final int fortuneLevel = player.getInventory().getItemInMainHand().getEnchantmentLevel(Enchantment.LOOT_BONUS_BLOCKS);
        final double multiplier = this.pluginConfig.fortuneMultiplier
                .entrySet()
                .stream()
                .filter(entry -> entry.getKey().equals(fortuneLevel))
                .map(Map.Entry::getValue)
                .findAny()
                .orElse(0.0D) + moneyBlock.getFortuneMultiplier()
                .entrySet()
                .stream()
                .filter(entry -> entry.getKey().equals(fortuneLevel))
                .map(Map.Entry::getValue)
                .findAny()
                .orElse(0.0D) + this.pluginConfig.permissionMultiplier
                .entrySet()
                .stream()
                .filter(entry -> entry.getKey().equalsIgnoreCase("default") ||
                        player.hasPermission(entry.getKey()))
                .map(Map.Entry::getValue)
                .max(Comparator.comparingDouble(value -> value))
                .orElse(0.0D) + this.turboService.getTurbo(player.getUniqueId(), xMaterial)
                .map(Turbo::getMultiplier)
                .orElse(0.0D);

        final DropMultiplierEvent dropMultiplierEvent = new DropMultiplierEvent(player.getUniqueId(), multiplier);
        this.moneyBlockPlugin.getServer().getPluginManager().callEvent(dropMultiplierEvent);

        final double cash;
        if (dropMultiplierEvent.getMultiplier() == 0.0D) {
            cash = moneyBlock.getPrice();
        }
        else {
            cash = moneyBlock.getPrice() + (moneyBlock.getPrice() * dropMultiplierEvent.getMultiplier());
        }

        vaultHook.deposit(player, cash);

        AtomicInteger blocks = new AtomicInteger();
        AtomicLong mills = new AtomicLong(digMills);

        while (mills.get() > 1000) {
            blocks.addAndGet(1);
            mills.addAndGet(-1000);
        }

        final long blockPerSeconds = (blocks.get() + (1000 / mills.get())) * 60;
        final double estimatesMinutes = cash * blockPerSeconds;

        final double blockPerHour = blockPerSeconds * 60;
        final double estimatesHours = cash * blockPerHour;

        final double blockPerDay = blockPerHour * 24;
        final double estimatesDays = cash * blockPerDay;

        final Map<String, Object> placeholders = new MapBuilder<String, Object>()
                .put("money", cash)
                .put("multiplier", dropMultiplierEvent.getMultiplier())
                .put("estimates-min", estimatesMinutes)
                .put("estimates-hour", estimatesHours)
                .put("estimates-day", estimatesDays)
                .put("cash", vaultHook.getMoney(player).orElse(0.0D))
                .build();

        switch (this.pluginConfig.moneyBlockNoticeDisplay) {
            case BOSSBAR: {
                this.bossBarCache.sendBossBar(player, StringColorUtil.fixColor(this.pluginConfig.bossBarText, placeholders));
                break;
            }
            case NOTICE: {
                this.pluginConfig.noticeText.send(player, placeholders);
                break;
            }
            default:
                throw new RuntimeException("Unknown notice-display type " + this.pluginConfig.moneyBlockNoticeDisplay);
        }
    }

    public void addMaterial(@NonNull XMaterial xMaterial, double price) {
        this.removeMaterial(xMaterial);

        final MoneyBlock moneyBlock = new MoneyBlock(xMaterial, price, new HashMap<>());
        this.pluginConfig.moneyBlocks.add(moneyBlock);

        this.tasker.newSharedChain("config-ops")
                .async(this.pluginConfig::save)
                .execute();
    }

    public boolean removeMaterial(@NonNull XMaterial xMaterial) {
        return this.pluginConfig.moneyBlocks.removeIf(moneyBlock ->
                moneyBlock.getMaterial().equals(xMaterial));
    }

    public void modifyFortune(int fortune, double multiplier) {

        if (this.pluginConfig.fortuneMultiplier.containsKey(fortune)) {
            this.pluginConfig.fortuneMultiplier.remove(fortune);
        }
        else {
            this.pluginConfig.fortuneMultiplier.put(fortune, multiplier);
        }

        this.tasker.newSharedChain("config-ops")
                .async(this.pluginConfig::save)
                .execute();
    }

    public boolean modifyFortune(@NonNull XMaterial material, int fortune, double multiplier) {
        final Optional<MoneyBlock> optionalMoneyBlock = this.pluginConfig.moneyBlocks
                .stream()
                .filter(moneyBlock -> moneyBlock.getMaterial().equals(material))
                .findAny();

        if (!optionalMoneyBlock.isPresent()) {
            return false;
        }

        final MoneyBlock moneyBlock = optionalMoneyBlock.get();

        if (moneyBlock.getFortuneMultiplier().containsKey(fortune)) {
            moneyBlock.getFortuneMultiplier().remove(fortune);
        }
        else {
            moneyBlock.getFortuneMultiplier().put(fortune, multiplier);
        }

        this.tasker.newSharedChain("config-ops")
                .async(this.pluginConfig::save)
                .execute();

        return true;
    }
}
