package cc.dreamcode.moneyblock.turbo;

import cc.dreamcode.utilities.MathUtil;
import lombok.NonNull;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class TurboCache {

    private static final Duration MINING_TIME = Duration.ofSeconds(10L);

    private final Map<UUID, Long> mining = new HashMap<>();

    public boolean isMining(@NonNull UUID uuid) {

        if (!this.mining.containsKey(uuid)) {
            return false;
        }

        final long time = this.mining.get(uuid);
        final Duration duration = MathUtil.difference(time, MINING_TIME);

        if (MathUtil.isNegative(duration)) {
            this.mining.remove(uuid);
            return false;
        }

        return true;
    }

    public void applyMining(@NonNull UUID uuid) {
        this.mining.put(uuid, System.currentTimeMillis());
    }

    public void remove(@NonNull UUID uuid) {
        this.mining.remove(uuid);
    }

}
