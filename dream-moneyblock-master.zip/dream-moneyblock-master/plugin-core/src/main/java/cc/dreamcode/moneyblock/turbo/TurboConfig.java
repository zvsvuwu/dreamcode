package cc.dreamcode.moneyblock.turbo;

import cc.dreamcode.platform.bukkit.component.configuration.Configuration;
import eu.okaeri.configs.OkaeriConfig;
import eu.okaeri.configs.annotation.Comment;
import eu.okaeri.configs.annotation.CustomKey;
import eu.okaeri.configs.annotation.Header;

import java.util.ArrayList;
import java.util.List;

@Configuration(child = "turbo.yml")
@Header("## Dream-MoneyBlock (TurboDrop) ##")
public class TurboConfig extends OkaeriConfig {

    @Comment
    @Comment("Ponizej znajduje sie dostepny serwerowy turbodrop:")
    @CustomKey("server-turbos")
    public List<Turbo> serverTurbos = new ArrayList<>();

    @Comment
    @Comment("Ponizej znajduje sie dostepny dla graczy turbodrop:")
    @CustomKey("player-turbos")
    public List<Turbo> playerTurbos = new ArrayList<>();
}
