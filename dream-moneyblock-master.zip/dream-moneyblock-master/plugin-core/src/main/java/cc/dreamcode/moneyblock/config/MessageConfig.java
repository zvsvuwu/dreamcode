package cc.dreamcode.moneyblock.config;

import cc.dreamcode.notice.adventure.BukkitNotice;
import cc.dreamcode.platform.bukkit.component.configuration.Configuration;
import eu.okaeri.configs.OkaeriConfig;
import eu.okaeri.configs.annotation.CustomKey;
import eu.okaeri.configs.annotation.Header;
import eu.okaeri.configs.annotation.Headers;

@Configuration(child = "message.yml")
@Headers({
        @Header("## Dream-MoneyBlock (Message-Config) ##"),
        @Header("Dostepne type: (DO_NOT_SEND, CHAT, ACTION_BAR, SUBTITLE, TITLE, TITLE_SUBTITLE)")
})
public class MessageConfig extends OkaeriConfig {

    @CustomKey("command-usage")
    public BukkitNotice usage = BukkitNotice.chat("&7Przyklady uzycia komendy: &c{label}");
    @CustomKey("command-usage-help")
    public BukkitNotice usagePath = BukkitNotice.chat("&f{usage} &8- &7{description}");

    @CustomKey("command-usage-not-found")
    public BukkitNotice usageNotFound = BukkitNotice.chat("&cNie znaleziono pasujacych do kryteriow komendy.");
    @CustomKey("command-path-not-found")
    public BukkitNotice pathNotFound = BukkitNotice.chat("&cTa komenda jest pusta lub nie posiadasz dostepu do niej.");
    @CustomKey("command-no-permission")
    public BukkitNotice noPermission = BukkitNotice.chat("&cNie posiadasz uprawnien.");
    @CustomKey("command-not-player")
    public BukkitNotice notPlayer = BukkitNotice.chat("&cTa komende mozna tylko wykonac z poziomu gracza.");
    @CustomKey("command-not-console")
    public BukkitNotice notConsole = BukkitNotice.chat("&cTa komende mozna tylko wykonac z poziomu konsoli.");
    @CustomKey("command-invalid-format")
    public BukkitNotice invalidFormat = BukkitNotice.chat("&cPodano nieprawidlowy format argumentu komendy. ({input})");

    @CustomKey("cooldown")
    public BukkitNotice cooldown = BukkitNotice.chat("&cPrzed nastepnym uzyciem tego poczekaj: &7{time}");
    @CustomKey("player-not-found")
    public BukkitNotice playerNotFound = BukkitNotice.chat("&cPodanego gracza nie znaleziono.");
    @CustomKey("world-not-found")
    public BukkitNotice worldNotFound = BukkitNotice.chat("&cPodanego swiata nie znaleziono.");

    @CustomKey("config-reloaded")
    public BukkitNotice reloaded = BukkitNotice.chat("&aPrzeladowano! &7({time})");
    @CustomKey("config-reload-error")
    public BukkitNotice reloadError = BukkitNotice.chat("&cZnaleziono problem w konfiguracji: &6{error}");

    @CustomKey("money-block-added")
    public BukkitNotice moneyBlockAdded = BukkitNotice.chat("&aDodano blok do listy money-block.");
    @CustomKey("money-block-removed")
    public BukkitNotice moneyBlockRemoved = BukkitNotice.chat("&cUsunieto blok z listy money-block.");
    @CustomKey("money-block-not-found")
    public BukkitNotice moneyBlockNotFound = BukkitNotice.chat("&cPodanego bloku nie znaleziono.");
    @CustomKey("money-block-fortune-modify")
    public BukkitNotice moneyBlockFortuneModify = BukkitNotice.chat("&aFortune zostalo zmodyfikowane.");

    @CustomKey("turbo-drop-added")
    public BukkitNotice turboDropAdded = BukkitNotice.chat("&aNadano turbo-drop graczowi {nick} na blok(i) {material}.");
    @CustomKey("turbo-drop-added-all")
    public BukkitNotice turboDropAddedAll = BukkitNotice.chat("&aNadano turbo-drop wszystkim gracza na blok(i) {material}.");
    @CustomKey("turbo-drop-removed")
    public BukkitNotice turboDropRemoved = BukkitNotice.chat("&cUsunieto turbo-drop graczowi {nick} na blok(i) {material}.");
    @CustomKey("turbo-drop-removed-all")
    public BukkitNotice turboDropRemovedAll = BukkitNotice.chat("&cUsunieto turbo-drop wszystkim gracza na blok(i) {material}.");
    @CustomKey("turbo-drop-broadcast")
    public BukkitNotice turboDropBroadcast = BukkitNotice.chat("&aOtrzymano turbo drop na czas {time} z mnoznikiem x{multiplier} na blok(i) {material}");
    @CustomKey("turbo-drop-broadcast-all")
    public BukkitNotice turboDropBroadcastAll = BukkitNotice.chat("&aKazdy otrzymal turbo drop na czas {time} z mnoznikiem x{multiplier} na blok(i) {material}");

}
