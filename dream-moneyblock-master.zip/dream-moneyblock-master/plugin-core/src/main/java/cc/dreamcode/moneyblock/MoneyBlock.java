package cc.dreamcode.moneyblock;

import com.cryptomorin.xseries.XMaterial;
import lombok.Data;

import java.util.Map;

@Data
public class MoneyBlock {

    private final XMaterial material;
    private final double price;
    private final Map<Integer, Double> fortuneMultiplier;

}
