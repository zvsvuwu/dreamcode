package cc.dreamcode.moneyblock.bossbar;

import cc.dreamcode.moneyblock.MoneyBlockPlugin;
import cc.dreamcode.moneyblock.config.PluginConfig;
import eu.okaeri.injector.annotation.Inject;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.bukkit.Bukkit;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Map;
import java.util.UUID;
import java.util.WeakHashMap;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class BossBarCache {

    private final MoneyBlockPlugin moneyBlockPlugin;
    private final PluginConfig pluginConfig;

    private final Map<UUID, Long> bossBarsStart = new WeakHashMap<>();
    private final Map<UUID, BossBar> bossBars = new WeakHashMap<>();

    public void sendBossBar(@NonNull Player player, @NonNull String text) {
        this.bossBarsStart.put(player.getUniqueId(), System.currentTimeMillis());

        final BossBar bossBar;
        if (this.bossBars.containsKey(player.getUniqueId())) {
            bossBar = this.bossBars.get(player.getUniqueId());
        }
        else {
            bossBar = Bukkit.createBossBar(text, this.pluginConfig.bossBarColor, this.pluginConfig.bossBarStyle);
            this.bossBars.put(player.getUniqueId(), bossBar);

            long duration = this.pluginConfig.bossBarDuration.toMillis();
            new BukkitRunnable() {
                @Override
                public void run() {

                    long diff = System.currentTimeMillis() - bossBarsStart.get(player.getUniqueId());
                    if (!bossBar.isVisible() || diff > duration) {
                        this.cancel();
                        removeBossBar(player.getUniqueId());
                        return;
                    }

                    bossBar.setProgress(1.0F - ((float) diff / (float) duration));
                }
            }.runTaskTimer(this.moneyBlockPlugin, 1L, 1L);
        }

        bossBar.setTitle(text);

        if (!bossBar.isVisible()) {
            bossBar.setVisible(true);
        }

        if (!bossBar.getPlayers().contains(player)) {
            bossBar.addPlayer(player);
        }
    }

    public void removeBossBar(@NonNull UUID uuid) {
        if (!this.bossBars.containsKey(uuid)) {
            return;
        }

        final BossBar bossBar = this.bossBars.get(uuid);
        bossBar.setVisible(false);
        bossBar.removeAll();

        this.bossBars.remove(uuid);
        this.bossBarsStart.remove(uuid);
    }
}
