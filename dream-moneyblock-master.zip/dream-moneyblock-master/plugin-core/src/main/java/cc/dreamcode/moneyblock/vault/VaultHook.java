package cc.dreamcode.moneyblock.vault;

import cc.dreamcode.moneyblock.MoneyBlockPlugin;
import cc.dreamcode.platform.bukkit.hook.PluginHook;
import cc.dreamcode.platform.bukkit.hook.annotation.Hook;
import eu.okaeri.injector.annotation.Inject;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.bukkit.entity.Player;

import java.util.Optional;

@Hook(name = "Vault")
@RequiredArgsConstructor(onConstructor_ = @Inject)
public class VaultHook implements PluginHook {

    private final MoneyBlockPlugin moneyBlockPlugin;

    private VaultTopService vaultTopService;

    @Override
    public void onInit() {
        this.vaultTopService = new VaultTopService(this.moneyBlockPlugin);
    }

    public Optional<Double> getMoney(@NonNull Player player) {
        if (this.vaultTopService == null) {
            return Optional.empty();
        }

        return Optional.of(this.vaultTopService.getMoney(player));
    }

    public boolean deposit(@NonNull Player player, double money) {
        if (this.vaultTopService == null) {
            return false;
        }

        return this.vaultTopService.deposit(player, money);
    }

    public boolean withdraw(@NonNull Player player, double money) {
        if (this.vaultTopService == null) {
            return false;
        }

        return this.vaultTopService.withdraw(player, money);
    }
}
