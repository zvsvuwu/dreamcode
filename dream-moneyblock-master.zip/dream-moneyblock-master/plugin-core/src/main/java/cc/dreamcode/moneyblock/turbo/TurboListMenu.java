package cc.dreamcode.moneyblock.turbo;

import cc.dreamcode.menu.adventure.BukkitMenuBuilder;
import cc.dreamcode.menu.adventure.base.BukkitMenu;
import cc.dreamcode.menu.adventure.setup.BukkitMenuSetup;
import cc.dreamcode.moneyblock.config.PluginConfig;
import cc.dreamcode.utilities.Formatter;
import cc.dreamcode.utilities.builder.MapBuilder;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import eu.okaeri.injector.annotation.Inject;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import java.util.Locale;
import java.util.UUID;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class TurboListMenu implements BukkitMenuSetup {

    private final PluginConfig pluginConfig;
    private final TurboService turboService;

    @Setter private UUID uuid;

    @Override
    public BukkitMenu build() {

        final BukkitMenuBuilder menuBuilder = this.pluginConfig.turboMenuBuilder;
        final BukkitMenu bukkitMenu = menuBuilder.buildEmpty();

        menuBuilder.getItems().forEach((slot, item) -> {

            if (this.pluginConfig.turboMenuCloseSlot == slot) {
                bukkitMenu.setItem(slot, ItemBuilder.of(item).fixColors().toItemStack(), event ->
                        event.getWhoClicked().closeInventory());
                return;
            }

            bukkitMenu.setItem(slot, ItemBuilder.of(item).fixColors().toItemStack());
        });

        this.turboService.getTurbos(this.uuid).forEach(turbo ->
                bukkitMenu.addItem(ItemBuilder.of(this.pluginConfig.turboMenuItem)
                        .fixColors(new MapBuilder<String, Object>()
                                .put("type", this.turboService.getServerUuid().equals(turbo.getDoer())
                                        ? "server"
                                        : "player")
                                .put("date", Formatter.format(turbo.getInstant()))
                                .put("sender", turbo.getSender())
                                .put("duration", Formatter.formatSec(turbo.getDuration()))
                                .put("multiplier", turbo.getMultiplier())
                                .put("actual-duration", Formatter.formatSec(turbo.getActualDuration()))
                                .put("material", turbo.isOnBlock()
                                        ? turbo.getMaterial().name().toLowerCase(Locale.ROOT)
                                        : this.pluginConfig.allBlocksText)
                                .build())
                        .toItemStack()));

        return bukkitMenu;
    }
}
