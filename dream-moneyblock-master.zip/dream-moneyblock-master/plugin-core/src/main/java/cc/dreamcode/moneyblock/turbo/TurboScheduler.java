package cc.dreamcode.moneyblock.turbo;

import cc.dreamcode.moneyblock.MoneyBlockPlugin;
import cc.dreamcode.moneyblock.config.PluginConfig;
import cc.dreamcode.platform.bukkit.component.scheduler.Scheduler;
import cc.dreamcode.utilities.Formatter;
import cc.dreamcode.utilities.builder.MapBuilder;
import eu.okaeri.injector.annotation.Inject;
import lombok.RequiredArgsConstructor;

import java.util.Locale;

@Scheduler(delay = 20, interval = 20)
@RequiredArgsConstructor(onConstructor_ = @Inject)
public class TurboScheduler implements Runnable {

    private final MoneyBlockPlugin moneyBlockPlugin;
    private final PluginConfig pluginConfig;
    private final TurboCache turboCache;
    private final TurboService turboService;

    @Override
    public void run() {
        this.turboService.cleanup();

        this.moneyBlockPlugin.getServer().getOnlinePlayers().forEach(player -> {
            if (!this.turboCache.isMining(player.getUniqueId())) {
                return;
            }

            this.turboService.getTurbo(player.getUniqueId()).ifPresent(turbo ->
                    this.pluginConfig.turboDropNotice.send(player, new MapBuilder<String, Object>()
                            .put("time", Formatter.formatSec(turbo.getActualDuration()))
                            .put("multiplier", turbo.getMultiplier())
                            .put("material", turbo.getMaterial().name().toLowerCase(Locale.ROOT))
                            .put("sender", turbo.getSender())
                            .build()));
        });
    }
}
