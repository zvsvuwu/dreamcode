package cc.dreamcode.moneyblock.turbo;

import cc.dreamcode.utilities.MathUtil;
import cc.dreamcode.utilities.option.Option;
import com.cryptomorin.xseries.XMaterial;
import eu.okaeri.injector.annotation.Inject;
import eu.okaeri.tasker.core.Tasker;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class TurboService {

    private final TurboConfig turboConfig;
    private final Tasker tasker;

    public Optional<Turbo> getTurbo(@NonNull UUID uuid) {

        final Turbo playerTurbo = this.turboConfig.playerTurbos
                .stream()
                .filter(turbo -> turbo.getDoer().equals(uuid))
                .findAny()
                .orElse(null);

        final Turbo serverTurbo = this.turboConfig.serverTurbos
                .stream()
                .findAny()
                .orElse(null);

        if (playerTurbo == null && serverTurbo == null) {
            return Optional.empty();
        }

        if (playerTurbo != null && serverTurbo == null) {
            return Optional.of(playerTurbo);
        }

        if (playerTurbo == null) {
            return Optional.of(serverTurbo);
        }

        return playerTurbo.getMultiplier() > serverTurbo.getMultiplier()
                ? Optional.of(playerTurbo)
                : Optional.of(serverTurbo);
    }

    public Optional<Turbo> getTurbo(@NonNull UUID uuid, @NonNull XMaterial material) {

        final Turbo playerTurbo = this.turboConfig.playerTurbos
                .stream()
                .filter(turbo -> turbo.getDoer().equals(uuid))
                .filter(turbo -> turbo.isOnBlock() || turbo.getMaterial().equals(material))
                .findAny()
                .orElse(null);

        final Turbo serverTurbo = this.turboConfig.serverTurbos
                .stream()
                .filter(turbo -> turbo.isOnBlock() || turbo.getMaterial().equals(material))
                .findAny()
                .orElse(null);

        if (playerTurbo == null && serverTurbo == null) {
            return Optional.empty();
        }

        if (playerTurbo != null && serverTurbo == null) {
            return Optional.of(playerTurbo);
        }

        if (playerTurbo == null) {
            return Optional.of(serverTurbo);
        }

        return playerTurbo.getMultiplier() > serverTurbo.getMultiplier()
                ? Optional.of(playerTurbo)
                : Optional.of(serverTurbo);
    }

    public List<Turbo> getTurbos(@NonNull UUID uuid) {

        final List<Turbo> turboList = new ArrayList<>(this.turboConfig.serverTurbos);

        this.turboConfig.playerTurbos
                .stream()
                .filter(turbo -> turbo.getDoer().equals(uuid))
                .forEach(turboList::add);

        return turboList;
    }

    public void applyPlayerTurbo(@NonNull UUID uuid, @NonNull String admin, @NonNull Optional<XMaterial> optionalMaterial, @NonNull Duration duration, double multiplier) {
        Option.ofOptional(this.turboConfig.playerTurbos
                .stream()
                .filter(turbo -> turbo.getDoer().equals(uuid))
                .filter(turbo -> turbo.getMaterial().equals(optionalMaterial.orElse(XMaterial.AIR)))
                .findAny())
                .acceptOrElse(existingTurbo -> {
                    final Turbo turbo = new Turbo(
                            uuid,
                            existingTurbo.getInstant(),
                            admin,
                            optionalMaterial.orElse(XMaterial.AIR),
                            existingTurbo.getDuration().plus(duration),
                            Math.max(existingTurbo.getMultiplier(), multiplier)
                    );

                    this.tasker.newSharedChain("turbo-ops")
                            .sync(() -> {
                                this.turboConfig.playerTurbos.remove(existingTurbo);
                                this.turboConfig.playerTurbos.add(turbo);
                            })
                            .async(this.turboConfig::save)
                            .execute();
                }, () -> {
                    final Turbo turbo = new Turbo(
                            uuid,
                            Instant.now(),
                            admin,
                            optionalMaterial.orElse(XMaterial.AIR),
                            duration,
                            multiplier
                    );

                    this.tasker.newSharedChain("turbo-ops")
                            .sync(() -> {
                                this.turboConfig.playerTurbos.add(turbo);
                            })
                            .async(this.turboConfig::save)
                            .execute();
                });
    }

    public void applyServerTurbo(@NonNull String admin, @NonNull Optional<XMaterial> optionalMaterial, @NonNull Duration duration, double multiplier) {

        final UUID uuid = this.getServerUuid();

        Option.ofOptional(this.turboConfig.serverTurbos
                        .stream()
                        .filter(turbo -> turbo.getDoer().equals(uuid))
                        .filter(turbo -> turbo.getMaterial().equals(optionalMaterial.orElse(XMaterial.AIR)))
                        .findAny())
                .acceptOrElse(existingTurbo -> {
                    final Turbo turbo = new Turbo(
                            uuid,
                            existingTurbo.getInstant(),
                            admin,
                            optionalMaterial.orElse(XMaterial.AIR),
                            existingTurbo.getDuration().plus(duration),
                            Math.max(existingTurbo.getMultiplier(), multiplier)
                    );

                    this.tasker.newSharedChain("turbo-ops")
                            .sync(() -> {
                                this.turboConfig.serverTurbos.remove(existingTurbo);
                                this.turboConfig.serverTurbos.add(turbo);
                            })
                            .async(this.turboConfig::save)
                            .execute();
                }, () -> {
                    final Turbo turbo = new Turbo(
                            uuid,
                            Instant.now(),
                            admin,
                            optionalMaterial.orElse(XMaterial.AIR),
                            duration,
                            multiplier
                    );

                    this.tasker.newSharedChain("turbo-ops")
                            .sync(() -> {
                                this.turboConfig.serverTurbos.add(turbo);
                            })
                            .async(this.turboConfig::save)
                            .execute();
                });
    }

    public void removePlayerTurbo(@NonNull UUID uuid, @NonNull Optional<XMaterial> optionalMaterial) {

        if (this.turboConfig.playerTurbos.removeIf(turbo ->
                turbo.getDoer().equals(uuid) &&
                        turbo.getMaterial().equals(optionalMaterial.orElse(XMaterial.AIR)))) {

            this.tasker.newSharedChain("turbo-ops")
                    .async(this.turboConfig::save)
                    .execute();
        }
    }

    public void removeServerTurbo(@NonNull Optional<XMaterial> optionalMaterial) {

        if (this.turboConfig.serverTurbos.removeIf(turbo ->
                turbo.getMaterial().equals(optionalMaterial.orElse(XMaterial.AIR)))) {

            this.tasker.newSharedChain("turbo-ops")
                    .async(this.turboConfig::save)
                    .execute();
        }
    }

    public void cleanup() {
        boolean saveServer = this.turboConfig.serverTurbos.removeIf(serverTurbo -> {
            final Duration duration = serverTurbo.getActualDuration();

            return MathUtil.isNegative(duration);
        });

        boolean savePlayer = this.turboConfig.playerTurbos.removeIf(playerTurbo -> {
            final Duration duration = playerTurbo.getActualDuration();

            return MathUtil.isNegative(duration);
        });

        if (saveServer || savePlayer) {
            this.tasker.newSharedChain("turbo-ops")
                    .async(this.turboConfig::save)
                    .execute();
        }
    }

    public UUID getServerUuid() {
        final UUID uuid;

        if (this.turboConfig.serverTurbos.isEmpty()) {
            uuid = UUID.randomUUID();
        }
        else {
            uuid = this.turboConfig.serverTurbos.get(0).getDoer();
        }

        return uuid;
    }
}
