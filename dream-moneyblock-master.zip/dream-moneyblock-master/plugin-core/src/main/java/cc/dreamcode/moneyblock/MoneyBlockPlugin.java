package cc.dreamcode.moneyblock;

import cc.dreamcode.command.bukkit.BukkitCommandProvider;
import cc.dreamcode.menu.adventure.BukkitMenuProvider;
import cc.dreamcode.menu.adventure.serializer.MenuBuilderSerializer;
import cc.dreamcode.moneyblock.bossbar.BossBarCache;
import cc.dreamcode.moneyblock.command.MoneyBlockCommand;
import cc.dreamcode.moneyblock.command.handler.InvalidInputHandlerImpl;
import cc.dreamcode.moneyblock.command.handler.InvalidPermissionHandlerImpl;
import cc.dreamcode.moneyblock.command.handler.InvalidSenderHandlerImpl;
import cc.dreamcode.moneyblock.command.handler.InvalidUsageHandlerImpl;
import cc.dreamcode.moneyblock.command.result.BukkitNoticeResolver;
import cc.dreamcode.moneyblock.command.suggestion.MoneyBlockSuggestion;
import cc.dreamcode.moneyblock.config.MessageConfig;
import cc.dreamcode.moneyblock.config.PluginConfig;
import cc.dreamcode.moneyblock.turbo.TurboCache;
import cc.dreamcode.moneyblock.turbo.TurboConfig;
import cc.dreamcode.moneyblock.turbo.TurboController;
import cc.dreamcode.moneyblock.turbo.TurboScheduler;
import cc.dreamcode.moneyblock.turbo.TurboSerializer;
import cc.dreamcode.moneyblock.turbo.TurboService;
import cc.dreamcode.moneyblock.vault.VaultHook;
import cc.dreamcode.notice.adventure.BukkitNoticeProvider;
import cc.dreamcode.notice.adventure.serializer.BukkitNoticeSerializer;
import cc.dreamcode.platform.DreamVersion;
import cc.dreamcode.platform.bukkit.DreamBukkitConfig;
import cc.dreamcode.platform.bukkit.DreamBukkitPlatform;
import cc.dreamcode.platform.bukkit.component.ConfigurationResolver;
import cc.dreamcode.platform.bukkit.hook.PluginHookManager;
import cc.dreamcode.platform.component.ComponentService;
import cc.dreamcode.platform.other.component.DreamCommandExtension;
import eu.okaeri.configs.serdes.OkaeriSerdesPack;
import eu.okaeri.tasker.bukkit.BukkitTasker;
import lombok.Getter;
import lombok.NonNull;

public final class MoneyBlockPlugin extends DreamBukkitPlatform implements DreamBukkitConfig {

    @Getter private static MoneyBlockPlugin instance;

    @Override
    public void load(@NonNull ComponentService componentService) {
        instance = this;
    }

    @Override
    public void enable(@NonNull ComponentService componentService) {
        componentService.setDebug(false);

        this.registerInjectable(BukkitTasker.newPool(this));
        this.registerInjectable(BukkitMenuProvider.create(this));
        this.registerInjectable(BukkitNoticeProvider.create(this));

        this.registerInjectable(BukkitCommandProvider.create(this));
        componentService.registerExtension(DreamCommandExtension.class);

        componentService.registerResolver(ConfigurationResolver.class);
        componentService.registerComponent(MessageConfig.class);

        componentService.registerComponent(BukkitNoticeResolver.class);
        componentService.registerComponent(InvalidInputHandlerImpl.class);
        componentService.registerComponent(InvalidPermissionHandlerImpl.class);
        componentService.registerComponent(InvalidSenderHandlerImpl.class);
        componentService.registerComponent(InvalidUsageHandlerImpl.class);

        componentService.registerComponent(PluginConfig.class, pluginConfig -> {
            // enable additional logs and debug messages
            componentService.setDebug(pluginConfig.debug);
        });
        componentService.registerComponent(TurboConfig.class);

        componentService.registerComponent(MoneyBlockSuggestion.class);

        componentService.registerComponent(PluginHookManager.class, dreamHookManager ->
                dreamHookManager.registerHook(VaultHook.class));

        componentService.registerComponent(BossBarCache.class);

        componentService.registerComponent(TurboCache.class);
        componentService.registerComponent(TurboService.class);
        componentService.registerComponent(MoneyBlockCache.class);
        componentService.registerComponent(MoneyBlockService.class);

        componentService.registerComponent(TurboScheduler.class);
        componentService.registerComponent(TurboController.class);
        componentService.registerComponent(MoneyBlockController.class);
        componentService.registerComponent(MoneyBlockCommand.class);
    }

    @Override
    public void disable() {
        // features need to be call when server is stopping
    }

    @Override
    public @NonNull DreamVersion getDreamVersion() {
        return DreamVersion.create("Dream-MoneyBlock", "1.0.1", "Ravis96");
    }

    @Override
    public @NonNull OkaeriSerdesPack getConfigSerdesPack() {
        return registry -> {
            registry.register(new BukkitNoticeSerializer());
            registry.register(new MenuBuilderSerializer());

            registry.register(new MoneyBlockSerializer());
            registry.register(new TurboSerializer());
        };
    }
}
