package cc.dreamcode.moneyblock;

public enum MoneyBlockNoticeDisplay {
    NOTICE, BOSSBAR
}
