package cc.dreamcode.moneyblock;

import com.cryptomorin.xseries.XMaterial;
import eu.okaeri.configs.schema.GenericsDeclaration;
import eu.okaeri.configs.serdes.DeserializationData;
import eu.okaeri.configs.serdes.ObjectSerializer;
import eu.okaeri.configs.serdes.SerializationData;
import lombok.NonNull;

public class MoneyBlockSerializer implements ObjectSerializer<MoneyBlock> {
    @Override
    public boolean supports(@NonNull Class<? super MoneyBlock> type) {
        return MoneyBlock.class.isAssignableFrom(type);
    }

    @Override
    public void serialize(@NonNull MoneyBlock object, @NonNull SerializationData data, @NonNull GenericsDeclaration generics) {
        data.add("money-block-type", object.getMaterial());
        data.add("money-block-price", object.getPrice());
        data.addAsMap("money-block-fortune-multiplier", object.getFortuneMultiplier(), Integer.class, Double.class);
    }

    @Override
    public MoneyBlock deserialize(@NonNull DeserializationData data, @NonNull GenericsDeclaration generics) {
        return new MoneyBlock(
                data.get("money-block-type", XMaterial.class),
                data.get("money-block-price", Double.class),
                data.getAsMap("money-block-fortune-multiplier", Integer.class, Double.class)
        );
    }
}
