rootProject.name = "dream-moneyblock"

include(":plugin-core")