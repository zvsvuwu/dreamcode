package cc.dreamcode.upgrader.config;

import cc.dreamcode.menu.adventure.BukkitMenuBuilder;
import cc.dreamcode.menu.utilities.MenuUtil;
import cc.dreamcode.platform.bukkit.component.configuration.Configuration;
import cc.dreamcode.upgrader.UpgradeItem;
import cc.dreamcode.upgrader.UpgraderMenuItem;
import cc.dreamcode.utilities.builder.ListBuilder;
import cc.dreamcode.utilities.builder.MapBuilder;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import com.cryptomorin.xseries.XMaterial;
import eu.okaeri.configs.OkaeriConfig;
import eu.okaeri.configs.annotation.Comment;
import eu.okaeri.configs.annotation.CustomKey;
import eu.okaeri.configs.annotation.Header;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;

import java.time.Duration;
import java.util.List;
import java.util.Map;

@Configuration(
        child = "config.yml"
)
@Header("## Dream-Upgrader (Main-Config) ##")
public class PluginConfig extends OkaeriConfig {

    @Comment("Debug pokazuje dodatkowe informacje do konsoli. Lepiej wylaczyc. :P")
    @CustomKey("debug")
    public boolean debug = true;

    @Comment
    @Comment("Jakie maja byc zniszki dla poszczegolnych uprawnien?")
    public Map<XMaterial, Map<String, Double>> discounts = new MapBuilder<XMaterial, Map<String, Double>>()
            .put(XMaterial.ELYTRA, MapBuilder.of("dream.upgrader.plus", 1.0D, "dream.upgrader.doubleplus", 2.0D))
            .put(XMaterial.DIAMOND_LEGGINGS, MapBuilder.of("dream.upgrader.plus", 1.0D, "dream.upgrader.doubleplus", 2.0D))
            .build();

    @Comment
    @Comment("Uzupelnij cala liste przedmiotow dostepnych do ulepszenia.")
    @CustomKey("upgrade-items")
    public List<UpgradeItem> upgradeItems = new ListBuilder<UpgradeItem>()
            .add(new UpgradeItem(
                    XMaterial.ELYTRA,
                    1,
                    "nazwa1",
                    50.0D,
                    MapBuilder.of("dream.upgrader.vip", 5.0D),
                    MapBuilder.of(Enchantment.PROTECTION_ENVIRONMENTAL, 1, Enchantment.DURABILITY, 1)
            ))
            .add(new UpgradeItem(
                    XMaterial.ELYTRA,
                    2,
                    "nazwa2",
                    60.0D,
                    MapBuilder.of("dream.upgrader.vip", 8.0D),
                    MapBuilder.of(Enchantment.PROTECTION_ENVIRONMENTAL, 2, Enchantment.DURABILITY, 2)
            ))
            .add(new UpgradeItem(
                    XMaterial.ELYTRA,
                    3,
                    "nazwa3",
                    70.0D,
                    MapBuilder.of("dream.upgrader.vip", 11.0D),
                    MapBuilder.of(Enchantment.PROTECTION_ENVIRONMENTAL, 3, Enchantment.DURABILITY, 3)
            ))
            .add(new UpgradeItem(
                    XMaterial.DIAMOND_LEGGINGS,
                    1,
                    "nazwa-leg1",
                    50.0D,
                    MapBuilder.of("dream.upgrader.vip", 6.0D),
                    MapBuilder.of(Enchantment.PROTECTION_ENVIRONMENTAL, 1, Enchantment.DURABILITY, 1)
            ))
            .add(new UpgradeItem(
                    XMaterial.DIAMOND_LEGGINGS,
                    2,
                    "nazwa-leg2",
                    60.0D,
                    MapBuilder.of("dream.upgrader.vip", 10.0D),
                    MapBuilder.of(Enchantment.PROTECTION_ENVIRONMENTAL, 2, Enchantment.DURABILITY, 2)
            ))
            .add(new UpgradeItem(
                    XMaterial.DIAMOND_LEGGINGS,
                    3,
                    "nazwa-leg3",
                    70.0D,
                    MapBuilder.of("dream.upgrader.vip", 14.0D),
                    MapBuilder.of(Enchantment.PROTECTION_ENVIRONMENTAL, 3, Enchantment.DURABILITY, 3)
            ))
            .build();

    @Comment
    @Comment("Czy uprawnienia maja byc podanawane w formie procentow do ceny regularnej, czy jako zastepcze?")
    public boolean discountsPercentUse = true;

    @Comment
    @Comment("Jaki ma byc cooldown na upgrade?")
    @CustomKey("cooldown")
    public Duration cooldown = Duration.ofSeconds(1L);

    @Comment
    @Comment("Uzupelnij formatowanie danych ulepszen itemow:")
    @CustomKey("enchantments-display-text")
    public Map<Enchantment, String> enchantmentsDisplayText = new MapBuilder<Enchantment, String>()
            .put(Enchantment.DURABILITY, "&6[\uD83D\uDEE1] Ochrona {level}")
            .put(Enchantment.PROTECTION_ENVIRONMENTAL, "&b[❤︎] Niezniszczalnosc {level}")
            .build();

    @Comment
    @Comment("Pod jakim slotem ma sie znajdowac przycisk od zamykania menu?")
    @CustomKey("close-menu-slot")
    public int closeMenuSlot = MenuUtil.countSlot(5, 5);

    @Comment
    @Comment("Jak ma wygladac format strzalki?")
    @CustomKey("arrow-text")
    public String arrowText = " -> ";

    @Comment
    @Comment("Pod jakim slotem maja sie znajdowac przyciski od ulepszenia?")
    @CustomKey("upgrader-menu-items")
    public List<UpgraderMenuItem> upgraderMenuItems = new ListBuilder<UpgraderMenuItem>()
            .add(new UpgraderMenuItem(
                    XMaterial.ELYTRA,
                    MenuUtil.countSlot(3, 5),
                    ItemBuilder.of(XMaterial.ELYTRA.parseItem())
                            .setName("&eUlepszanie elytry")
                            .setLore("",
                                    "&8- &7Maksymalny poziom: {max-level-name}",
                                    "",
                                    "&8- &7Kupujesz: {actual-level-name}{actual-level-arrow}{upgrade-level-name}",
                                    "&8- &7Koszt: &a{upgrade-regular-cost} &a{upgrade-cost}",
                                    "",
                                    "&8- &7Enchanty:",
                                    "{upgrade-enchants}",
                                    "",
                                    "&8- &aKliknij LPM, aby ulepszyc!",
                                    "&8- &6Kliknij PPM, aby zobaczyc wszystkie!")
                            .toItemStack(),
                    ItemBuilder.of(XMaterial.ELYTRA.parseItem())
                            .setName("&eUlepszanie elytry")
                            .setLore("",
                                    "&8- &7Maksymalny poziom: {max-level-name}",
                                    "",
                                    "&8- &aOsiagnieto maksymalny poziom!",
                                    "&8- &6Kliknij PPM, aby zobaczyc wszystkie!")
                            .toItemStack(),
                    ItemBuilder.of(XMaterial.ELYTRA.parseItem())
                            .setName("&eUlepszanie elytry")
                            .setLore("",
                                    "&8- &7Poziom: {upgrade-level-name}",
                                    "&8- &7Koszt: &a{upgrade-regular-cost} &a{upgrade-cost}",
                                    "",
                                    "&8- &7Enchanty:",
                                    "{upgrade-enchants}")
                            .toItemStack()
            ))
            .add(new UpgraderMenuItem(
                    XMaterial.DIAMOND_LEGGINGS,
                    MenuUtil.countSlot(3, 6),
                    ItemBuilder.of(XMaterial.DIAMOND_LEGGINGS.parseItem())
                            .setName("&eUlepszanie nogawic")
                            .setLore("",
                                    "&8- &7Maksymalny poziom: {max-level-name}",
                                    "",
                                    "&8- &7Kupujesz: {actual-level-name}{actual-level-arrow}{upgrade-level-name}",
                                    "&8- &7Koszt: &a{upgrade-regular-cost} &a{upgrade-cost}",
                                    "",
                                    "&8- &7Enchanty:",
                                    "{upgrade-enchants}",
                                    "",
                                    "&8- &aKliknij LPM, aby ulepszyc!",
                                    "&8- &6Kliknij PPM, aby zobaczyc wszystkie!")
                            .toItemStack(),
                    ItemBuilder.of(XMaterial.DIAMOND_LEGGINGS.parseItem())
                            .setName("&eUlepszanie nogawic")
                            .setLore("",
                                    "&8- &7Maksymalny poziom: {max-level-name}",
                                    "",
                                    "&8- &aOsiagnieto maksymalny poziom!",
                                    "&8- &6Kliknij PPM, aby zobaczyc wszystkie!")
                            .toItemStack(),
                    ItemBuilder.of(XMaterial.DIAMOND_LEGGINGS.parseItem())
                            .setName("&eUlepszanie nogawic")
                            .setLore("",
                                    "&8- &7Poziom: {upgrade-level-name}",
                                    "&8- &7Koszt: &a{upgrade-regular-cost} &a{upgrade-cost}",
                                    "",
                                    "&8- &7Enchanty:",
                                    "{upgrade-enchants}")
                            .toItemStack()
            ))
            .build();

    @Comment
    @Comment("Jak ma wygladac menu od upgradera?")
    @CustomKey("upgrader-menu")
    public BukkitMenuBuilder menuBuilder = new BukkitMenuBuilder("&8[&bM&8] Upgrader", 5, new MapBuilder<Integer, ItemStack>()
            .put(MenuUtil.countSlot(1, 5), ItemBuilder.of(XMaterial.BOOK.parseItem())
                    .setName("&eInformacje")
                    .setLore("&7W tym miejscu mozesz",
                            "&7ulepszyc swoje itemy za",
                            "&7odpowiednia oplata podana przy",
                            "&7danym typie przedmiotu.")
                    .toItemStack())
            .put(MenuUtil.countSlot(5, 5), ItemBuilder.of(XMaterial.BARRIER.parseItem())
                    .setName("&cWyjdz z menu.")
                    .toItemStack())
            .build());

    @Comment
    @Comment("Pod jakim slotem ma sie znajdowac przycisk od zamykania preview-menu?")
    @CustomKey("close-preview-menu-slot")
    public int closePreviewMenuSlot = MenuUtil.countSlot(3, 9);

    @Comment
    @Comment("Jak ma wygladac menu od podgladu?")
    @CustomKey("upgrader-menu-preview")
    public BukkitMenuBuilder menuBuilderPreview = new BukkitMenuBuilder("&8[&bM&8] Podglad ulepszen", 3, new MapBuilder<Integer, ItemStack>()
            .put(MenuUtil.countSlot(3, 9), ItemBuilder.of(XMaterial.BARRIER.parseItem())
                    .setName("&cPowrot do menu.")
                    .toItemStack())
            .build());
}
