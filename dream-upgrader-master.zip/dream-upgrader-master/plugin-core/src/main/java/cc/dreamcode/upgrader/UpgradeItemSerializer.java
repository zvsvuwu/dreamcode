package cc.dreamcode.upgrader;

import com.cryptomorin.xseries.XMaterial;
import eu.okaeri.configs.schema.GenericsDeclaration;
import eu.okaeri.configs.serdes.DeserializationData;
import eu.okaeri.configs.serdes.ObjectSerializer;
import eu.okaeri.configs.serdes.SerializationData;
import lombok.NonNull;
import org.bukkit.enchantments.Enchantment;

public class UpgradeItemSerializer implements ObjectSerializer<UpgradeItem> {
    @Override
    public boolean supports(@NonNull Class<? super UpgradeItem> type) {
        return UpgradeItem.class.isAssignableFrom(type);
    }

    @Override
    public void serialize(@NonNull UpgradeItem object, @NonNull SerializationData data, @NonNull GenericsDeclaration generics) {
        data.add("upgrade-material", object.getMaterial());
        data.add("upgrade-level", object.getLevel());
        data.add("upgrade-level-name", object.getLevelName());
        data.add("upgrade-cost", object.getRegularCost());
        data.addAsMap("upgrade-permission-cost", object.getPermissionCost(), String.class, Double.class);
        data.addAsMap("upgrade-enchantments", object.getEnchantments(), Enchantment.class, Integer.class);
    }

    @Override
    public UpgradeItem deserialize(@NonNull DeserializationData data, @NonNull GenericsDeclaration generics) {
        return new UpgradeItem(
                data.get("upgrade-material", XMaterial.class),
                data.get("upgrade-level", Integer.class),
                data.get("upgrade-level-name", String.class),
                data.get("upgrade-cost", Double.class),
                data.getAsMap("upgrade-permission-cost", String.class, Double.class),
                data.getAsMap("upgrade-enchantments", Enchantment.class, Integer.class)
        );
    }
}
