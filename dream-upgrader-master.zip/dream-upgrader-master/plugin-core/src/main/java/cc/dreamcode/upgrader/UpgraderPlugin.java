package cc.dreamcode.upgrader;

import cc.dreamcode.command.bukkit.BukkitCommandProvider;
import cc.dreamcode.menu.adventure.BukkitMenuProvider;
import cc.dreamcode.menu.adventure.serializer.MenuBuilderSerializer;
import cc.dreamcode.notice.adventure.BukkitNoticeProvider;
import cc.dreamcode.notice.adventure.serializer.BukkitNoticeSerializer;
import cc.dreamcode.platform.DreamVersion;
import cc.dreamcode.platform.bukkit.DreamBukkitConfig;
import cc.dreamcode.platform.bukkit.DreamBukkitPlatform;
import cc.dreamcode.platform.bukkit.component.ConfigurationResolver;
import cc.dreamcode.platform.component.ComponentService;
import cc.dreamcode.platform.exception.PlatformException;
import cc.dreamcode.platform.other.component.DreamCommandExtension;
import cc.dreamcode.upgrader.command.UpgraderCommand;
import cc.dreamcode.upgrader.command.handler.InvalidInputHandlerImpl;
import cc.dreamcode.upgrader.command.handler.InvalidPermissionHandlerImpl;
import cc.dreamcode.upgrader.command.handler.InvalidSenderHandlerImpl;
import cc.dreamcode.upgrader.command.handler.InvalidUsageHandlerImpl;
import cc.dreamcode.upgrader.command.result.BukkitNoticeResolver;
import cc.dreamcode.upgrader.config.MessageConfig;
import cc.dreamcode.upgrader.config.PluginConfig;
import eu.okaeri.configs.serdes.OkaeriSerdesPack;
import eu.okaeri.tasker.bukkit.BukkitTasker;
import lombok.Getter;
import lombok.NonNull;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.plugin.RegisteredServiceProvider;

public final class UpgraderPlugin extends DreamBukkitPlatform implements DreamBukkitConfig {

    @Getter private static UpgraderPlugin upgraderPlugin;

    @Override
    public void load(@NonNull ComponentService componentService) {
        upgraderPlugin = this;
    }

    @Override
    public void enable(@NonNull ComponentService componentService) {
        componentService.setDebug(false);

        this.registerInjectable(BukkitTasker.newPool(this));
        this.registerInjectable(BukkitMenuProvider.create(this));
        this.registerInjectable(BukkitNoticeProvider.create(this));

        this.registerInjectable(BukkitCommandProvider.create(this));
        componentService.registerExtension(DreamCommandExtension.class);

        componentService.registerResolver(ConfigurationResolver.class);
        componentService.registerComponent(MessageConfig.class);

        componentService.registerComponent(BukkitNoticeResolver.class);
        componentService.registerComponent(InvalidInputHandlerImpl.class);
        componentService.registerComponent(InvalidPermissionHandlerImpl.class);
        componentService.registerComponent(InvalidSenderHandlerImpl.class);
        componentService.registerComponent(InvalidUsageHandlerImpl.class);

        componentService.registerComponent(PluginConfig.class, pluginConfig -> {
            // enable additional logs and debug messages
            componentService.setDebug(pluginConfig.debug);
        });

        this.registerInjectable(this.setupEconomy());

        componentService.registerComponent(UpgraderCache.class);
        componentService.registerComponent(UpgraderService.class);
        componentService.registerComponent(UpgraderCommand.class);
    }

    @Override
    public void disable() {
        // features need to be call when server is stopping
    }

    @Override
    public @NonNull DreamVersion getDreamVersion() {
        return DreamVersion.create("Dream-Upgrader", "1.1.6", "Ravis96");
    }

    @Override
    public @NonNull OkaeriSerdesPack getConfigSerdesPack() {
        return registry -> {
            registry.register(new BukkitNoticeSerializer());
            registry.register(new MenuBuilderSerializer());
            registry.register(new UpgradeItemSerializer());
            registry.register(new UpgraderMenuItemSerializer());
        };
    }

    private Economy setupEconomy() {
        if (getServer().getPluginManager().getPlugin("Vault") == null) {
            throw new PlatformException("Vault not found");
        }

        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) {
            throw new PlatformException("Vault not found");
        }

        return rsp.getProvider();
    }
}
