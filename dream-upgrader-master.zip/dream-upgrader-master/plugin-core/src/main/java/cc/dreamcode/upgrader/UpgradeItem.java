package cc.dreamcode.upgrader;

import cc.dreamcode.utilities.builder.MapBuilder;
import com.cryptomorin.xseries.XMaterial;
import com.google.common.util.concurrent.AtomicDouble;
import lombok.Data;
import lombok.NonNull;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.permissions.Permissible;

import java.util.Comparator;
import java.util.Map;

@Data
public class UpgradeItem {

    private final XMaterial material;

    private final int level;
    private final String levelName;
    private final double regularCost;
    private final Map<String, Double> permissionCost;

    private final Map<Enchantment, Integer> enchantments;

    public double getCost(@NonNull Permissible permissible, boolean percentUse, @NonNull Map<String, Double> discounts) {

        if (percentUse) {

            final AtomicDouble atomicCost = new AtomicDouble(this.regularCost);

            new MapBuilder<String, Double>()
                    .putAll(this.permissionCost)
                    .putAll(discounts)
                    .build()
                    .entrySet()
                    .stream()
                    .filter(entry -> permissible.hasPermission(entry.getKey()))
                    .map(Map.Entry::getValue)
                    .forEach(percent -> atomicCost.addAndGet(-(atomicCost.get() * percent / 100)));

            return atomicCost.get();
        }

        return this.permissionCost.entrySet()
                .stream()
                .filter(entry -> permissible.hasPermission(entry.getKey()))
                .map(Map.Entry::getValue)
                .min(Comparator.comparingDouble(value -> value))
                .orElse(this.regularCost);
    }
}
