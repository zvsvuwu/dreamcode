package cc.dreamcode.upgrader;

import cc.dreamcode.menu.adventure.BukkitMenuBuilder;
import cc.dreamcode.menu.adventure.base.BukkitMenu;
import cc.dreamcode.menu.adventure.setup.BukkitMenuPlayerSetup;
import cc.dreamcode.upgrader.config.MessageConfig;
import cc.dreamcode.upgrader.config.PluginConfig;
import cc.dreamcode.utilities.MathUtil;
import cc.dreamcode.utilities.TimeUtil;
import cc.dreamcode.utilities.builder.MapBuilder;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import com.cryptomorin.xseries.XMaterial;
import eu.okaeri.injector.annotation.Inject;
import eu.okaeri.tasker.core.Tasker;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.HumanEntity;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.inventory.ItemStack;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class UpgraderMenu implements BukkitMenuPlayerSetup {

    private final UpgraderPlugin upgraderPlugin;
    private final PluginConfig pluginConfig;
    private final MessageConfig messageConfig;
    private final UpgraderService upgraderService;
    private final UpgraderCache upgraderCache;
    private final Tasker tasker;

    @Override
    public BukkitMenu build(@NonNull HumanEntity humanEntity) {
        final BukkitMenuBuilder menuBuilder = this.pluginConfig.menuBuilder;
        final BukkitMenu bukkitMenu = menuBuilder.buildEmpty();

        menuBuilder.getItems().forEach((slot, item) -> {

            if (this.pluginConfig.closeMenuSlot == slot) {
                bukkitMenu.setItem(slot, ItemBuilder.of(item).fixColors().toItemStack(), e ->
                        e.getWhoClicked().closeInventory());
                return;
            }

            bukkitMenu.setItem(slot, ItemBuilder.of(item).fixColors().toItemStack());
        });

        this.pluginConfig.upgraderMenuItems.forEach(upgraderMenuItem ->
                this.setSlot(humanEntity, bukkitMenu, upgraderMenuItem));

        return bukkitMenu;
    }

    public void setSlot(@NonNull HumanEntity humanEntity, @NonNull BukkitMenu bukkitMenu, @NonNull UpgraderMenuItem upgraderMenuItem) {
        final Optional<Map<Enchantment, Integer>> peekEnchantments = this.pluginConfig.upgradeItems
                .stream()
                .filter(upgradeItem -> upgradeItem.getMaterial().equals(upgraderMenuItem.getMaterial()))
                .map(UpgradeItem::getEnchantments)
                .sorted(Comparator.comparingInt((Map<Enchantment, Integer> value) -> {
                    final AtomicInteger atomic = new AtomicInteger();

                    value.forEach(((enchantment, integer) ->
                            atomic.addAndGet(integer)));

                    return atomic.get();
                }).reversed())
                .findAny();

        if (!peekEnchantments.isPresent()) {
            throw new RuntimeException("Cannot resolve enchantments for item " + upgraderMenuItem.getMaterial());
        }

        final Map<Enchantment, Integer> enchantments = peekEnchantments.get();
        final Optional<ItemStack> optionalItemStack = this.upgraderService.getBestItem(humanEntity, enchantments, upgraderMenuItem.getMaterial());

        final ItemStack itemStack;
        final UpgradeItem upgradeItem;
        final UpgradeItem nextUpgradeItem;
        if (!optionalItemStack.isPresent()) {
            Optional<UpgradeItem> optionalUpgradeItem = this.upgraderService.getMinUpgradeItem(upgraderMenuItem.getMaterial());
            if (!optionalUpgradeItem.isPresent()) {
                throw new RuntimeException("Cannot resolve min item-upgrade item: " + upgraderMenuItem.getMaterial());
            }

            upgradeItem = null;
            nextUpgradeItem = optionalUpgradeItem.get();

            itemStack = this.upgraderService.applyAndGet(Objects.requireNonNull(upgraderMenuItem.getMaterial().parseItem()), nextUpgradeItem);
        }
        else {
            itemStack = optionalItemStack.get();

            Optional<UpgradeItem> optionalUpgradeItem = this.upgraderService.getUpgradeItem(optionalItemStack.get(), false);
            if (!optionalUpgradeItem.isPresent()) {
                throw new RuntimeException("Cannot resolve item-upgrade for item: " + upgraderMenuItem.getMaterial());
            }

            upgradeItem = optionalUpgradeItem.get();

            final Optional<UpgradeItem> optionalNextUpgradeItem = this.upgraderService.getUpgradeItem(optionalItemStack.get(), true);
            if (optionalNextUpgradeItem.isPresent()) {
                nextUpgradeItem = optionalNextUpgradeItem.get();
            }
            else {
                // no next-level item
                bukkitMenu.setItem(upgraderMenuItem.getSlotInMenu(), ItemBuilder.of(upgraderMenuItem.getDisplayMaxItem())
                        .fixColors(new MapBuilder<String, Object>()
                                .put("max-level", upgradeItem.getLevel())
                                .put("max-level-name", upgradeItem.getLevelName())
                                .put("max-level-cost", MathUtil.round(upgradeItem.getRegularCost(), 2) + "$")
                                .put("actual-level", upgradeItem.getLevel())
                                .put("actual-level-name", upgradeItem.getLevelName())
                                .put("actual-cost", MathUtil.round(upgradeItem.getRegularCost(), 2) + "$")
                                .build())
                        .toItemStack(), e -> {

                    if (e.getAction().equals(InventoryAction.PICKUP_ALL)) {
                        this.messageConfig.maxLevelReached.send(humanEntity);
                        return;
                    }

                    if (e.getAction().equals(InventoryAction.PICKUP_HALF)) {
                        this.tasker.newSharedChain("menu:" + humanEntity.getUniqueId())
                                .supplyAsync(() -> this.buildPreview(humanEntity, upgraderMenuItem.getMaterial()))
                                .acceptSync(previewMenu -> previewMenu.open(humanEntity))
                                .execute();
                    }
                });
                return;
            }
        }

        final Optional<UpgradeItem> optionalMaxItemUpgrade = this.upgraderService.getMaxUpgradeItem(upgraderMenuItem.getMaterial());
        if (!optionalMaxItemUpgrade.isPresent()) {
            throw new RuntimeException("Cannot resolve max item-upgrade item: " + upgraderMenuItem.getMaterial());
        }

        final UpgradeItem maxItemUpgrade = optionalMaxItemUpgrade.get();

        final List<String> lore = new ArrayList<>();
        if (upgraderMenuItem.getDisplayItem().hasItemMeta() && upgraderMenuItem.getDisplayItem().getItemMeta().hasLore()) {
            Objects.requireNonNull(upgraderMenuItem.getDisplayItem().getItemMeta().getLore()).forEach(text -> {

                if (text.contains("{upgrade-enchants}")) {
                    nextUpgradeItem.getEnchantments().entrySet()
                            .stream()
                            .map(entry -> this.upgraderService.getFormattedEnchantments(entry.getKey(), entry.getValue()))
                            .filter(Optional::isPresent)
                            .map(Optional::get)
                            .forEach(lore::add);
                    return;
                }

                lore.add(text);
            });
        }

        final double price = nextUpgradeItem.getCost(humanEntity, this.pluginConfig.discountsPercentUse, this.pluginConfig.discounts.getOrDefault(upgraderMenuItem.getMaterial(), new HashMap<>()));
        bukkitMenu.setItem(upgraderMenuItem.getSlotInMenu(), ItemBuilder.of(upgraderMenuItem.getDisplayItem())
                .setLore(lore)
                .fixColors(new MapBuilder<String, Object>()
                        .put("max-level", maxItemUpgrade.getLevel())
                        .put("max-level-name", maxItemUpgrade.getLevelName())
                        .put("max-level-cost", MathUtil.round(maxItemUpgrade.getRegularCost(), 2) + "$")
                        .put("actual-level", upgradeItem == null ? 0 : upgradeItem.getLevel())
                        .put("actual-level-name", upgradeItem == null ? "" : upgradeItem.getLevelName())
                        .put("actual-cost", upgradeItem == null ? "" : MathUtil.round(upgradeItem.getRegularCost(), 2) + "$")
                        .put("actual-level-arrow", upgradeItem == null ? "" : this.pluginConfig.arrowText)
                        .put("upgrade-level", nextUpgradeItem.getLevel())
                        .put("upgrade-level-name", nextUpgradeItem.getLevelName())
                        .put("upgrade-regular-cost", price != nextUpgradeItem.getRegularCost()
                                ? "&c&m" + MathUtil.round(nextUpgradeItem.getRegularCost(), 2) + "$&r"
                                : MathUtil.round(nextUpgradeItem.getRegularCost(), 2) + "$")
                        .put("upgrade-cost", price != nextUpgradeItem.getRegularCost() ? MathUtil.round(price, 2) + "$" : "")
                        .build())
                .toItemStack(), e -> {

            if (e.getAction().equals(InventoryAction.PICKUP_ALL)) {

                final Duration duration = this.upgraderCache.getCooldown(humanEntity.getUniqueId());
                if (!MathUtil.isNegative(duration)) {
                    this.messageConfig.cooldown.send(humanEntity,
                            MapBuilder.of("time", TimeUtil.format(duration)));
                    return;
                }

                this.upgraderService.upgrade(humanEntity, itemStack, nextUpgradeItem, !optionalItemStack.isPresent());
                this.setSlot(humanEntity, bukkitMenu, upgraderMenuItem);
                return;
            }

            if (e.getAction().equals(InventoryAction.PICKUP_HALF)) {
                this.tasker.newSharedChain("menu:" + humanEntity.getUniqueId())
                        .supplyAsync(() -> this.buildPreview(humanEntity, upgraderMenuItem.getMaterial()))
                        .acceptSync(previewMenu -> previewMenu.open(humanEntity))
                        .execute();
            }
        });
    }

    public BukkitMenu buildPreview(@NonNull HumanEntity humanEntity, @NonNull XMaterial material) {
        final BukkitMenuBuilder builder = this.pluginConfig.menuBuilderPreview;
        final BukkitMenu bukkitPreviewMenu = builder.buildEmpty();

        builder.getItems().forEach((slot, item) -> {

            if (slot == this.pluginConfig.closePreviewMenuSlot) {
                bukkitPreviewMenu.setItem(slot, ItemBuilder.of(item).fixColors().toItemStack(), e ->
                        this.tasker.newSharedChain("menu:" + e.getWhoClicked().getUniqueId())
                                .supplyAsync(() -> {
                                    final UpgraderMenu upgraderMenu = this.upgraderPlugin.createInstance(UpgraderMenu.class);
                                    return upgraderMenu.build(e.getWhoClicked());
                                })
                                .acceptSync(bukkitMenu -> bukkitMenu.open(e.getWhoClicked()))
                                .execute());
                return;
            }

            bukkitPreviewMenu.setItem(slot, ItemBuilder.of(item).fixColors().toItemStack());
        });

        final Optional<UpgraderMenuItem> optionalUpgraderMenuItem = this.pluginConfig.upgraderMenuItems
                .stream()
                .filter(upgraderMenuItem -> upgraderMenuItem.getMaterial().equals(material))
                .findAny();

        if (!optionalUpgraderMenuItem.isPresent()) {
            throw new RuntimeException("Cannot find upgrader-menu-item for " + material);
        }

        final UpgraderMenuItem upgraderMenuItem = optionalUpgraderMenuItem.get();
        this.pluginConfig.upgradeItems
                .stream()
                .filter(upgradeItem -> upgradeItem.getMaterial().equals(material))
                .sorted(Comparator.comparingInt(UpgradeItem::getLevel))
                .forEach(upgradeItem -> {

                    final List<String> lore = new ArrayList<>();
                    if (upgraderMenuItem.getDisplayPreviewItem().hasItemMeta() && upgraderMenuItem.getDisplayPreviewItem().getItemMeta().hasLore()) {
                        Objects.requireNonNull(upgraderMenuItem.getDisplayPreviewItem().getItemMeta().getLore()).forEach(text -> {

                            if (text.contains("{upgrade-enchants}")) {
                                upgradeItem.getEnchantments().entrySet()
                                        .stream()
                                        .map(entry -> this.upgraderService.getFormattedEnchantments(entry.getKey(), entry.getValue()))
                                        .filter(Optional::isPresent)
                                        .map(Optional::get)
                                        .forEach(lore::add);
                                return;
                            }

                            lore.add(text);
                        });
                    }

                    final double price = upgradeItem.getCost(humanEntity, this.pluginConfig.discountsPercentUse, this.pluginConfig.discounts.getOrDefault(upgradeItem.getMaterial(), new HashMap<>()));
                    bukkitPreviewMenu.addItem(ItemBuilder.of(upgraderMenuItem.getDisplayPreviewItem())
                            .setLore(lore)
                            .fixColors(new MapBuilder<String, Object>()
                                    .put("upgrade-level", upgradeItem.getLevel())
                                    .put("upgrade-level-name", upgradeItem.getLevelName())
                                    .put("upgrade-regular-cost", (price != upgradeItem.getRegularCost()
                                            ? "&c&m" + MathUtil.round(upgradeItem.getRegularCost(), 2)
                                            : MathUtil.round(upgradeItem.getRegularCost(), 2)) + "$&r")
                                    .put("upgrade-cost", price == MathUtil.round(upgradeItem.getRegularCost(), 2) ? "" : MathUtil.round(price, 2) + "$")
                                    .build())
                            .toItemStack());
                });

        return bukkitPreviewMenu;
    }

}
