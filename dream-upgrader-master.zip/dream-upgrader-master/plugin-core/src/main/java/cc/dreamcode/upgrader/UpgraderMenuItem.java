package cc.dreamcode.upgrader;

import com.cryptomorin.xseries.XMaterial;
import lombok.Data;
import org.bukkit.inventory.ItemStack;

@Data
public class UpgraderMenuItem {

    private final XMaterial material;
    private final int slotInMenu;
    private final ItemStack displayItem;
    private final ItemStack displayMaxItem;
    private final ItemStack displayPreviewItem;
}
