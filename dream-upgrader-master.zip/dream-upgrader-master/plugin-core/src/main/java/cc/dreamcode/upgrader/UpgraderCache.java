package cc.dreamcode.upgrader;

import cc.dreamcode.upgrader.config.PluginConfig;
import cc.dreamcode.utilities.MathUtil;
import eu.okaeri.injector.annotation.Inject;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

import java.time.Duration;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class UpgraderCache {

    private final PluginConfig pluginConfig;

    private final Map<UUID, Instant> cooldownMap = new HashMap<>();

    public Duration getCooldown(@NonNull UUID uuid) {
        if (!this.cooldownMap.containsKey(uuid)) {
            return Duration.ZERO;
        }

        final Instant instant = this.cooldownMap.get(uuid);
        return MathUtil.difference(instant, this.pluginConfig.cooldown);
    }

    public void applyCooldown(@NonNull UUID uuid) {
        this.cooldownMap.put(uuid, Instant.now());
    }
}
