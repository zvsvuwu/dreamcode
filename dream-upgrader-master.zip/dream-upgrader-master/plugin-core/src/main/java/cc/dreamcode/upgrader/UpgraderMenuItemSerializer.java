package cc.dreamcode.upgrader;

import com.cryptomorin.xseries.XMaterial;
import eu.okaeri.configs.schema.GenericsDeclaration;
import eu.okaeri.configs.serdes.DeserializationData;
import eu.okaeri.configs.serdes.ObjectSerializer;
import eu.okaeri.configs.serdes.SerializationData;
import lombok.NonNull;
import org.bukkit.inventory.ItemStack;

public class UpgraderMenuItemSerializer implements ObjectSerializer<UpgraderMenuItem> {
    @Override
    public boolean supports(@NonNull Class<? super UpgraderMenuItem> type) {
        return UpgraderMenuItem.class.isAssignableFrom(type);
    }

    @Override
    public void serialize(@NonNull UpgraderMenuItem object, @NonNull SerializationData data, @NonNull GenericsDeclaration generics) {
        data.add("upgrader-menu-material", object.getMaterial());
        data.add("upgrader-menu-slot", object.getSlotInMenu());
        data.add("upgrader-menu-display-item", object.getDisplayItem());
        data.add("upgrader-menu-display-max-item", object.getDisplayMaxItem());
        data.add("upgrader-menu-display-preview-item", object.getDisplayPreviewItem());
    }

    @Override
    public UpgraderMenuItem deserialize(@NonNull DeserializationData data, @NonNull GenericsDeclaration generics) {
        return new UpgraderMenuItem(
                data.get("upgrader-menu-material", XMaterial.class),
                data.get("upgrader-menu-slot", Integer.class),
                data.get("upgrader-menu-display-item", ItemStack.class),
                data.get("upgrader-menu-display-max-item", ItemStack.class),
                data.get("upgrader-menu-display-preview-item", ItemStack.class)
        );
    }
}
