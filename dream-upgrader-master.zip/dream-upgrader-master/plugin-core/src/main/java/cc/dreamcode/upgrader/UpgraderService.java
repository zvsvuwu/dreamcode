package cc.dreamcode.upgrader;

import cc.dreamcode.upgrader.config.MessageConfig;
import cc.dreamcode.upgrader.config.PluginConfig;
import cc.dreamcode.utilities.StringUtil;
import cc.dreamcode.utilities.builder.MapBuilder;
import cc.dreamcode.utilities.bukkit.StringColorUtil;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import com.cryptomorin.xseries.XMaterial;
import eu.okaeri.injector.annotation.Inject;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.OfflinePlayer;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.HumanEntity;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class UpgraderService {

    private final UpgraderPlugin upgraderPlugin;
    private final PluginConfig pluginConfig;
    private final MessageConfig messageConfig;
    private final UpgraderCache upgraderCache;
    private final Economy economy;

    public Optional<ItemStack> getBestItem(@NonNull HumanEntity humanEntity, @NonNull Map<Enchantment, Integer> enchantments, @NonNull XMaterial material) {

        final Optional<ItemStack> armorPart = Arrays.stream(humanEntity.getInventory().getArmorContents())
                .filter(Objects::nonNull)
                .filter(material::isSimilar)
                .filter(item -> {

                    final AtomicBoolean result = new AtomicBoolean(false);

                    item.getEnchantments().forEach((enchantment, integer) -> {
                        if (item.getEnchantments().containsKey(enchantment)) {
                            result.set(true);
                        }
                    });

                    return result.get();
                })
                .findAny();

        if (armorPart.isPresent()) {
            return armorPart;
        }

        return Arrays.stream(humanEntity.getInventory().getStorageContents())
                .filter(Objects::nonNull)
                .filter(material::isSimilar)
                .filter(item -> {

                    final AtomicBoolean result = new AtomicBoolean(false);

                    item.getEnchantments().forEach((enchantment, integer) -> {
                        if (item.getEnchantments().containsKey(enchantment)) {
                            result.set(true);
                        }
                    });

                    return result.get();
                })
                .sorted((o1, o2) -> {

                    final AtomicInteger o1Level = new AtomicInteger();
                    final AtomicInteger o2Level = new AtomicInteger();

                    enchantments.keySet().forEach(enchantment -> {
                        o1Level.addAndGet(o1.getEnchantmentLevel(enchantment));
                        o2Level.addAndGet(o2.getEnchantmentLevel(enchantment));
                    });

                    return o2Level.get() - o1Level.get();
                })
                .findAny();
    }

    public Optional<UpgradeItem> getUpgradeItem(@NonNull ItemStack itemStack) {
        return this.pluginConfig.upgradeItems
                .stream()
                .filter(upgradeItem -> upgradeItem.getMaterial().isSimilar(itemStack) &&
                        upgradeItem.getEnchantments()
                                .entrySet()
                                .stream()
                                .allMatch(entry -> itemStack.getEnchantmentLevel(entry.getKey()) == entry.getValue()))
                .findAny();
    }

    public Optional<UpgradeItem> getUpgradeItem(@NonNull ItemStack itemStack, boolean nextLevel) {
        final Optional<UpgradeItem> upgradeItemOptional = this.getUpgradeItem(itemStack);
        if (!upgradeItemOptional.isPresent()) {
            throw new RuntimeException("Cannot resolve upgrade-item object by itemstack");
        }

        final int nextLevelNumber = upgradeItemOptional.get().getLevel() + (nextLevel ? 1 : 0);
        return this.pluginConfig.upgradeItems
                .stream()
                .filter(upgradeItem -> upgradeItem.getMaterial().isSimilar(itemStack) &&
                        upgradeItem.getLevel() == nextLevelNumber)
                .findAny();
    }

    public Optional<UpgradeItem> getMinUpgradeItem(@NonNull XMaterial material) {
        return this.pluginConfig.upgradeItems
                .stream()
                .filter(upgradeItem -> upgradeItem.getMaterial().equals(material))
                .sorted(Comparator.comparingInt(UpgradeItem::getLevel))
                .findAny();
    }

    public Optional<UpgradeItem> getMaxUpgradeItem(@NonNull XMaterial material) {
        return this.pluginConfig.upgradeItems
                .stream()
                .filter(upgradeItem -> upgradeItem.getMaterial().equals(material))
                .sorted(Comparator.comparingInt(UpgradeItem::getLevel).reversed())
                .findAny();
    }

    public ItemStack applyAndGet(@NonNull ItemStack itemStack, @NonNull UpgradeItem upgradeItem) {
        itemStack.addUnsafeEnchantments(upgradeItem.getEnchantments());
        ItemBuilder itemBuilder = ItemBuilder.manipulate(itemStack)
                .addFlags(ItemFlag.HIDE_ENCHANTS);

        itemBuilder.setName(StringColorUtil.fixColor(upgradeItem.getLevelName()));
        itemBuilder.setLore(new ArrayList<>());

        upgradeItem.getEnchantments().forEach((enchantment, level) -> {
            itemBuilder.addEnchant(enchantment, level);

            this.getFormattedEnchantments(enchantment, level).ifPresent(itemBuilder::appendLore);
        });

        return itemBuilder.toItemStack();
    }

    public Optional<String> getFormattedEnchantments(@NonNull Enchantment enchantment, int level) {
        return this.pluginConfig.enchantmentsDisplayText.entrySet()
                .stream()
                .filter(entry -> entry.getKey().equals(enchantment))
                .map(Map.Entry::getValue)
                .map(text -> StringUtil.replace(text, MapBuilder.of("level", level)))
                .findAny();
    }

    public void upgrade(@NonNull HumanEntity humanEntity, @NonNull ItemStack itemStack, @NonNull UpgradeItem upgradeItem, boolean addItem) {

        final OfflinePlayer offlinePlayer = this.upgraderPlugin.getServer().getOfflinePlayer(humanEntity.getUniqueId());
        final double cost = upgradeItem.getCost(humanEntity, this.pluginConfig.discountsPercentUse, this.pluginConfig.discounts.getOrDefault(upgradeItem.getMaterial(), new HashMap<>()));
        if (!this.economy.has(offlinePlayer, cost)) {
            this.messageConfig.upgraderCannotAfford.send(humanEntity, new MapBuilder<String, Object>()
                    .put("cost", cost)
                    .build());
            return;
        }

        Optional<UpgradeItem> nextUpgradeItemOptional = this.getUpgradeItem(itemStack, true);
        if (!nextUpgradeItemOptional.isPresent()) {
            this.messageConfig.maxLevelReached.send(humanEntity);
            return;
        }

        if (addItem) {
            humanEntity.getInventory().addItem(itemStack).forEach((i, item) ->
                    humanEntity.getWorld().dropItem(humanEntity.getLocation(), item));
        }

        final UpgradeItem nextUpgradeItem = nextUpgradeItemOptional.get();
        this.applyAndGet(itemStack, nextUpgradeItem);

        this.upgraderCache.applyCooldown(humanEntity.getUniqueId());
        this.economy.withdrawPlayer(offlinePlayer, cost);

        this.messageConfig.upgraderUpgrade.send(humanEntity);
    }
}
