rootProject.name = "dream-upgrader"

include(":plugin-core")