rootProject.name = "dream-kowal"

include(":plugin-core")