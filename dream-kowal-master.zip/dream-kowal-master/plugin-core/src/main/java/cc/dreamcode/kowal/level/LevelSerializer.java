package cc.dreamcode.kowal.level;

import eu.okaeri.configs.schema.GenericsDeclaration;
import eu.okaeri.configs.serdes.DeserializationData;
import eu.okaeri.configs.serdes.ObjectSerializer;
import eu.okaeri.configs.serdes.SerializationData;
import lombok.NonNull;
import org.bukkit.Material;

public class LevelSerializer implements ObjectSerializer<Level> {
    @Override
    public boolean supports(@NonNull Class<? super Level> type) {
        return Level.class.isAssignableFrom(type);
    }

    @Override
    public void serialize(@NonNull Level object, @NonNull SerializationData data, @NonNull GenericsDeclaration generics) {
        data.add("upgrade-items", object.getUpgradeItems());
        data.add("upgrade-items-lore", object.getUpgradeItemsLore());
        data.add("cost-lore", object.getCostLore());
        data.add("money-upgrade", object.getMoneyUpgrade());
        data.add("display-lore", object.getItemLoreDisplay());
        data.add("hp-reduce", object.getHpReduce());
        data.add("chance", object.getChance());
    }

    @Override
    public Level deserialize(@NonNull DeserializationData data, @NonNull GenericsDeclaration generics) {
        return new Level(
                data.getAsMap("upgrade-items", Material.class, Integer.class),
                data.get("upgrade-items-lore", String.class),
                data.get("cost-lore", String.class),
                data.get("money-upgrade", Double.class),
                data.get("display-lore", String.class),
                data.get("hp-reduce", Double.class),
                data.get("chance", Integer.class)
        );
    }
}
