package cc.dreamcode.kowal.config;

import cc.dreamcode.kowal.effect.Effect;
import cc.dreamcode.kowal.effect.EffectType;
import cc.dreamcode.kowal.level.Level;
import cc.dreamcode.menu.adventure.BukkitMenuBuilder;
import cc.dreamcode.platform.bukkit.component.configuration.Configuration;
import cc.dreamcode.utilities.builder.MapBuilder;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import eu.okaeri.configs.OkaeriConfig;
import eu.okaeri.configs.annotation.Comment;
import eu.okaeri.configs.annotation.CustomKey;
import eu.okaeri.configs.annotation.Header;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.ItemStack;

import java.util.Collections;
import java.util.Map;

@Configuration(child = "config.yml")
@Header("## Dream-Kowal (Main-Config) ##")
public class PluginConfig extends OkaeriConfig {
    @Comment
    @Comment("Jak ma wygladac gui kowala?")
    @CustomKey("kowal-menu")
    public BukkitMenuBuilder kowalMenu = new BukkitMenuBuilder("&8Kowal", 3, new MapBuilder<Integer, ItemStack>()
            .put(11, ItemBuilder.of(Material.RED_DYE).setName("&cAnuluj").toItemStack())
            .put(15, ItemBuilder.of(Material.LIME_DYE).setName("&2Zwieksz poziom").setLore("&7Ulepszenie: &a+{level} → &a+{new}", " ",
                    "&7Wymagane ulepszacze:", "{items}", "{cost}", " ", "{status}").toItemStack())
            .build());

    @Comment
    @Comment("Jak ma wygladac informacja o zmianie trybu na kamien kowalski?")
    @CustomKey("kowal-menu-mode-metal")
    public ItemStack modeMetal = ItemBuilder.of(Material.LEVER).setName("&9Ulepszanie kamieniem kowalskim").setLore("&7Gdy ulepszasz przedmiot &fKamieniem Kowalskim",
            "&7masz pewnosc, ze gdy ulepszenie sie", "&7nie powiedzie poziom przedmiotu nie", "&7zostanie obnizony", " ",
            "&aKliknij aby przelaczyc!").toItemStack();

    @Comment
    @Comment("Jak ma wygladac informacja o zmianie trybu na metal?")
    @CustomKey("kowal-menu-mode-kamien")
    public ItemStack modeKamien = ItemBuilder.of(Material.REDSTONE_TORCH).setName("&5Ulepszasz metalem!").setLore("&7Ulepszasz przedmiotem specjalnym",
            "&7metalem, ktory zabezpiecza przed", "&7obnizeniem poziomu przedmiotu.", " ", "&dKliknij aby przelaczyc!").toItemStack();

    @Comment
    @Comment("Na ktorym slocie znajduje sie przycisk od zmiany trybu kowala?")
    @CustomKey("kowal-menu-mode-slot")
    public int modeSlot = 22;

    @Comment
    @Comment("Na ktorym slocie ma sie znajdowac przycisk od anulowania ulepszenia?")
    @CustomKey("kowal-menu-upgrade-cancel-slot")
    public int upgradeCancelSlot = 11;

    @Comment
    @Comment("Na ktorym slocie ma sie znajdowac przedmiot do ulepszenia?")
    @CustomKey("kowal-menu-upgrade-item-slot")
    public int upgradeItemSlot = 13;

    @Comment
    @Comment("Na ktorym slocie ma sie znajdowac przycisk od potwierdzenia ulepszenia?")
    @CustomKey("kowal-menu-upgrade-accept-slot")
    public int upgradeAcceptSlot = 15;

    @Comment
    @Comment("Jak ma wygladac informacja w gui, gdy przedmiot w lapce nie jest do ulepszenia?")
    @CustomKey("kowal-menu-not-upgradeable")
    public ItemStack notUpgradeable = ItemBuilder.of(Material.BARRIER).setName("&cNiepoprawny przedmiot!")
            .setLore("&7Przedmiot, ktory trzymasz w rece nie posiada", "&7mozliwosci ulepszenia badz jest ulepszony juz", "&7na &fmaksymalny &7poziom",
                    " ", "&7Dostepne przedmioty do ulepszenia:", "&8» &bDiamentowe uzbrojenie", "&8» &cNetherytowe uzbrojenie").toItemStack();

    @Comment
    @Comment("Jak ma wygladac informacja w lore gdy gracz nie posiada przedmiotow do ulepszenia uzbrojenia?")
    @CustomKey("upgrade-status-false")
    public String cannotUpgradeStatus = "&cUzbieraj wymagane przedmioty!";

    @Comment
    @Comment("Jak ma wygladac informacja w lore gdy gracz posiada przedmioty do ulepszenia uzbrojenia?")
    @CustomKey("upgrade-status-true")
    public String canUpgradeStatus = "&eKliknij, aby ulepszyc!";

    @Comment
    @Comment("Jak ma wygladac gui z potwierdzeniem ulepszenia przedmiotu?")
    @CustomKey("kowal-confirm-menu")
    public BukkitMenuBuilder confirmMenu = new BukkitMenuBuilder(InventoryType.HOPPER, "&8Czy chcesz kontynuowac?", new MapBuilder<Integer, ItemStack>()
            .put(1, ItemBuilder.of(Material.RED_DYE).setName("&cNIE").setLore("&7Nie chce ryzykowac. Wole zostac", "&7przy aktualnym poziomie ulepszenia.").toItemStack())
            .build());

    @Comment
    @Comment("Jak ma wygladac przedmiot gdy gracz uzywa metalu?")
    @CustomKey("kowal-confirm-menu-metal-item")
    public ItemStack confirmModeMetal = ItemBuilder.of(Material.LIME_DYE).setName("&aTAK").setLore("&7Szansa na ulepszenie: &f{chance}%", " ",
            "&7Jestes swiadomy, ze przy nieudanej", "&7probie &eulepszenia poziom &7przedmiotu zostanie zostanie", "&7obnizony o jeden.").toItemStack();

    @Comment
    @Comment("Jak ma wygladac przedmiot gdy gracz uzywa kamienia kowalskiego?")
    @CustomKey("kowal-config-menu-kamien-item")
    public ItemStack confirmModeKamien = ItemBuilder.of(Material.LIME_DYE).setName("&aTAK").setLore("&7Szansa na ulepszenie: &f{chance}%", " ",
            "&7Te ulepszenie jest &ezabezpieczone", "&7przed obnizeniem poziomu przedmiotu.").toItemStack();

    @Comment
    @Comment("Na ktorym slocie znajduje sie przycisk od anulowania ulepszenia?")
    @CustomKey("kowal-confirm-menu-cancel-slot")
    public int confirmCancelSlot = 1;

    @Comment
    @Comment("Na ktorym slocie znajduje sie przycisk od ulepszenia?")
    @CustomKey("kowal-confirm-menu-accept-slot")
    public int confirmAcceptSlot = 3;

    @Comment
    @Comment("Lista poziomow kowala")
    @CustomKey("kowal-levels")
    public Map<Integer, Level> kowalLevels = new MapBuilder<Integer, Level>()
            .put(1, new Level(Collections.singletonMap(Material.COAL, 10), "&8» &aWegiel x10", "&8» &a35$", 35D,
                    "&b+0.5 odpornosc na obrazenia", 0.0015D, 80))
            .put(2, new Level(Collections.singletonMap(Material.IRON_INGOT, 8), "&8» &aSztabka zelaza x8", "&8» &a50$", 50D,
                    "&b+1.0 odpornosc na obrazenia", 0.002D, 70))
            .put(3, new Level(Collections.singletonMap(Material.STRING, 16), "&8» &aNić x16", "&8» &a75$", 75D,
                    "&b+1.5 odpornosc na obrazenia", 0.0025D, 60))
            .put(4, new Level(Collections.singletonMap(Material.EMERALD, 2), "&8» &aEmeraldy x2", "&8» &a90$", 90D,
                    "&b+2.0 odpornosc na obrazenia", 0.003D, 50))
            .put(5, new Level(Collections.singletonMap(Material.IRON_INGOT, 16), "&8» &aSztabka zelaza x16", "&8» &a105$", 105D,
                    "&b+3.0 odpornosc na obrazenia", 0.0035D, 40))
            .put(6, new Level(Collections.singletonMap(Material.EMERALD, 6), "&8» &aEmeraldy x6", "&8» &a120$", 120D,
                    "&b+4.0 odpornosc na obrazenia", 0.004D, 30))
            .put(7, new Level(Collections.singletonMap(Material.DIAMOND, 6), "&8» &aDiamenty x6", "&8» &a145$", 145D,
                    "&b+5.0 odpornosc na obrazenia", 0.0045D, 20))
            .build();

    @Comment
    @Comment("Jaka nazwe maja posiadac przedmioty po ulepszeniu?")
    @CustomKey("kowal-items-name")
    public Map<Material, String> kowalItems = new MapBuilder<Material, String>()
            .put(Material.DIAMOND_HELMET, "&3Diamentowy helm &b+{level}")
            .put(Material.DIAMOND_CHESTPLATE, "&3Diamentowa klata &b+{level}")
            .put(Material.DIAMOND_LEGGINGS, "&3Diamentowe spodnie &b+{level}")
            .put(Material.DIAMOND_BOOTS, "&3Diamentowe buty &b+{level}")
            .put(Material.NETHERITE_HELMET, "&cNetherytowy helm &4+{level}")
            .put(Material.NETHERITE_CHESTPLATE, "&cNetherytowa klata &4+{level}")
            .put(Material.NETHERITE_LEGGINGS, "&cNetherytowe spodnie &4+{level}")
            .put(Material.NETHERITE_BOOTS, "&cNetherytowe buty &4+{level}")
            .build();

    @Comment
    @Comment("Jak ma wygladac kamien kowalski?")
    @CustomKey("kamien-kowalski-item")
    public ItemStack kamienKowalski = ItemBuilder.of(Material.GRAY_DYE).setName("&cKamien kowalski").setLore("&8» &7Powoduje, ze przedmiot po ulepszeniu",
            "&8» &7u &fKowala &7nie cofa swojego poziomu w", "&8» &7przypadku &eniepodowdzenia&7!").toItemStack();

    @Comment
    @Comment("Lista efektow, ktore gracz dostaje losowo na 7 poziomie ulepszenia.")
    @CustomKey("effect-list")
    public Map<EffectType, Effect> effects = new MapBuilder<EffectType, Effect>()
            .put(EffectType.ARMOR_DAMAGE, new Effect("&6{chance}% wolniejsze niszczenie seta", 12))
            .put(EffectType.POTION_DURATION, new Effect("&9{chance}% wydluzenia efektu wypitych mikstur", 12))
            .put(EffectType.DAMAGE, new Effect("&a{chance}% szansy na odbicie ciosu", 3))
            .put(EffectType.ARROW, new Effect("&d{chance}% szansy na odbicie strzaly", 10))
            .build();

    @Comment
    @Comment("Jaki ma sie odtworzyc dzwiek gdy ulepszenie sie uda?")
    @CustomKey("upgrade-success-sound")
    public Sound upgradeSuccess = Sound.BLOCK_ANVIL_DESTROY;

    @Comment
    @Comment("Jaki ma sie odtworzyc dzwiek gdy ulepszenie sie nie uda?")
    @CustomKey("upgrade-failure-sound")
    public Sound upgradeFailure = Sound.ENTITY_ITEM_BREAK;

    @Comment
    @Comment("Jakie maja byc particle gdy gracz ma pelny set 6 lub 7 poziomu?")
    @CustomKey("particles")
    public Particle particle = Particle.VILLAGER_HAPPY;
}
