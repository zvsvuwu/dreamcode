package cc.dreamcode.kowal;

import cc.dreamcode.kowal.config.PluginConfig;
import cc.dreamcode.utilities.bukkit.nbt.ItemNbtUtil;
import eu.okaeri.injector.annotation.Inject;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class ParticleCache {
    private final KowalPlugin plugin;
    private final PluginConfig pluginConfig;
    private final List<UUID> particleEffect = new ArrayList<>();

    public void add(@NonNull UUID uuid) {
        if (this.particleEffect.contains(uuid)) {
            return;
        }

        this.particleEffect.add(uuid);
    }

    public void remove(@NonNull UUID uuid) {
        if (!this.particleEffect.contains(uuid)) {
            return;
        }

        this.particleEffect.remove(uuid);
    }

    public boolean hasArmor(@NonNull Player player, int level) {
        AtomicBoolean check = new AtomicBoolean(true);

        for (ItemStack armor : player.getInventory().getArmorContents()) {
            if (armor == null) {
                check.set(false);
                break;
            }

            if (!this.pluginConfig.kowalItems.containsKey(armor.getType())) {
                check.set(false);
                break;
            }

            String levelString = ItemNbtUtil.getValueByPlugin(this.plugin, armor, "upgrade-level").orElse("0");
            final int currentLevel = Integer.parseInt(levelString);

            if (currentLevel < level) {
                check.set(false);
            }
        }

        return check.get();
    }

    public void check(@NonNull Player player) {
        boolean has = this.hasArmor(player, 6);

        if (has) {
            this.add(player.getUniqueId());
        }
        else {
            this.remove(player.getUniqueId());
        }
    }

    public void checkOnline() {
        Bukkit.getOnlinePlayers().forEach(this::check);
    }

    public Collection<UUID> values() {
        return Collections.unmodifiableCollection(this.particleEffect);
    }
}
