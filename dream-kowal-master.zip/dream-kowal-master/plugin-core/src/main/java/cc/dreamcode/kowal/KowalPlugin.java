package cc.dreamcode.kowal;

import cc.dreamcode.command.bukkit.BukkitCommandProvider;
import cc.dreamcode.kowal.command.KowalCommand;
import cc.dreamcode.kowal.command.handler.InvalidInputHandlerImpl;
import cc.dreamcode.kowal.command.handler.InvalidPermissionHandlerImpl;
import cc.dreamcode.kowal.command.handler.InvalidSenderHandlerImpl;
import cc.dreamcode.kowal.command.handler.InvalidUsageHandlerImpl;
import cc.dreamcode.kowal.command.result.BukkitNoticeResolver;
import cc.dreamcode.kowal.config.MessageConfig;
import cc.dreamcode.kowal.config.PluginConfig;
import cc.dreamcode.kowal.controller.ArmorEquipController;
import cc.dreamcode.kowal.controller.DamageController;
import cc.dreamcode.kowal.controller.EffectController;
import cc.dreamcode.kowal.controller.PlayerController;
import cc.dreamcode.kowal.effect.EffectSerializer;
import cc.dreamcode.kowal.hook.VaultHook;
import cc.dreamcode.kowal.level.LevelSerializer;
import cc.dreamcode.kowal.tasks.ParticleTask;
import cc.dreamcode.menu.adventure.BukkitMenuProvider;
import cc.dreamcode.menu.adventure.serializer.MenuBuilderSerializer;
import cc.dreamcode.notice.adventure.BukkitNoticeProvider;
import cc.dreamcode.notice.adventure.serializer.BukkitNoticeSerializer;
import cc.dreamcode.platform.DreamVersion;
import cc.dreamcode.platform.bukkit.DreamBukkitConfig;
import cc.dreamcode.platform.bukkit.DreamBukkitPlatform;
import cc.dreamcode.platform.bukkit.component.ConfigurationResolver;
import cc.dreamcode.platform.bukkit.hook.PluginHookManager;
import cc.dreamcode.platform.component.ComponentService;
import cc.dreamcode.platform.other.component.DreamCommandExtension;
import cc.dreamcode.utilities.bukkit.VersionUtil;
import eu.okaeri.configs.serdes.OkaeriSerdesPack;
import eu.okaeri.tasker.bukkit.BukkitTasker;
import lombok.Getter;
import lombok.NonNull;

public final class KowalPlugin extends DreamBukkitPlatform implements DreamBukkitConfig {

    @Getter private static KowalPlugin instance;

    @Override
    public void load(@NonNull ComponentService componentService) {
        instance = this;
    }

    @Override
    public void enable(@NonNull ComponentService componentService) {
        if (!VersionUtil.isPaper()) {
            throw new RuntimeException("Plugin works only on paper fork.");
        }

        componentService.setDebug(false);

        this.registerInjectable(BukkitTasker.newPool(this));
        this.registerInjectable(BukkitMenuProvider.create(this));
        this.registerInjectable(BukkitNoticeProvider.create(this));

        this.registerInjectable(BukkitCommandProvider.create(this));
        componentService.registerExtension(DreamCommandExtension.class);

        componentService.registerResolver(ConfigurationResolver.class);
        componentService.registerComponent(MessageConfig.class);

        componentService.registerComponent(BukkitNoticeResolver.class);
        componentService.registerComponent(InvalidInputHandlerImpl.class);
        componentService.registerComponent(InvalidPermissionHandlerImpl.class);
        componentService.registerComponent(InvalidSenderHandlerImpl.class);
        componentService.registerComponent(InvalidUsageHandlerImpl.class);

        componentService.registerComponent(PluginConfig.class);

        componentService.registerComponent(PluginHookManager.class, pluginHookManager ->
                pluginHookManager.registerHook(VaultHook.class));

        componentService.registerComponent(ParticleCache.class, ParticleCache::checkOnline);
        componentService.registerComponent(ParticleTask.class);

        componentService.registerComponent(DamageController.class);
        componentService.registerComponent(ArmorEquipController.class);
        componentService.registerComponent(PlayerController.class);
        componentService.registerComponent(EffectController.class);

        componentService.registerComponent(KowalCommand.class);
    }

    @Override
    public void disable() {

    }

    @Override
    public @NonNull DreamVersion getDreamVersion() {
        return DreamVersion.create("Dream-Kowal", "1.0.6", "Sebt");
    }

    @Override
    public @NonNull OkaeriSerdesPack getConfigSerdesPack() {
        return registry -> {
            registry.register(new BukkitNoticeSerializer());
            registry.register(new MenuBuilderSerializer());

            registry.register(new LevelSerializer());
            registry.register(new EffectSerializer());
        };
    }

}
