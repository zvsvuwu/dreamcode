package cc.dreamcode.kowal.tasks;

import cc.dreamcode.kowal.ParticleCache;
import cc.dreamcode.kowal.config.PluginConfig;
import cc.dreamcode.platform.bukkit.component.scheduler.Scheduler;
import eu.okaeri.injector.annotation.Inject;
import lombok.RequiredArgsConstructor;
import org.bukkit.Bukkit;
import org.bukkit.Particle;
import org.bukkit.entity.Player;

@Scheduler(delay = 20, interval = 20)
@RequiredArgsConstructor(onConstructor_ = @Inject)
public class ParticleTask implements Runnable {
    private final PluginConfig pluginConfig;
    private final ParticleCache particleCache;

    @Override
    public void run() {
        this.particleCache.values().forEach(uuid -> {
            Player player = Bukkit.getPlayer(uuid);

            player.getWorld().spawnParticle(this.pluginConfig.particle,
                    player.getLocation().add(0.0D, 2.0D, 0.0D), 4, 0.5D, 1.0D, 0.5D);
        });
    }
}
