package cc.dreamcode.kowal.menu;

import cc.dreamcode.kowal.KowalPlugin;
import cc.dreamcode.kowal.config.MessageConfig;
import cc.dreamcode.kowal.config.PluginConfig;
import cc.dreamcode.kowal.effect.Effect;
import cc.dreamcode.kowal.effect.EffectType;
import cc.dreamcode.kowal.hook.VaultHook;
import cc.dreamcode.kowal.level.Level;
import cc.dreamcode.menu.adventure.BukkitMenuBuilder;
import cc.dreamcode.menu.adventure.base.BukkitMenu;
import cc.dreamcode.menu.adventure.setup.BukkitMenuPlayerSetup;
import cc.dreamcode.platform.bukkit.hook.PluginHookManager;
import cc.dreamcode.utilities.RandomUtil;
import cc.dreamcode.utilities.builder.MapBuilder;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import cc.dreamcode.utilities.bukkit.nbt.ItemNbtUtil;
import eu.okaeri.injector.annotation.Inject;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

import java.util.Collections;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class KowalConfirmMenu implements BukkitMenuPlayerSetup {
    private final KowalPlugin plugin;
    private final PluginConfig pluginConfig;
    private final MessageConfig messageConfig;
    private final PluginHookManager pluginHookManager;

    @Setter private Level level;
    @Setter private KowalMenuMode mode;

    @Override
    public BukkitMenu build(@NonNull HumanEntity humanEntity) {
        if (!(humanEntity instanceof Player)) {
            throw new RuntimeException("humanEntity must be Player");
        }

        BukkitMenuBuilder builder = this.pluginConfig.confirmMenu;
        BukkitMenu bukkitMenu = builder.buildEmpty();

        bukkitMenu.setDisposeWhenClose(true);

        builder.getItems().forEach((slot, item) -> {
            if (this.pluginConfig.confirmCancelSlot == slot) {
                bukkitMenu.setItem(slot, ItemBuilder.of(item).fixColors().toItemStack(), event -> event.getWhoClicked().closeInventory());
                return;
            }

            bukkitMenu.setItem(slot, ItemBuilder.of(item).fixColors().toItemStack());
        });

        if (this.mode.equals(KowalMenuMode.METAL)) {
            bukkitMenu.setItem(this.pluginConfig.confirmAcceptSlot, ItemBuilder.of(this.pluginConfig.confirmModeMetal)
                    .fixColors(Collections.singletonMap("chance", this.level.getChance())).toItemStack(), this::handleClick);
        }
        else {
            bukkitMenu.setItem(this.pluginConfig.confirmAcceptSlot, ItemBuilder.of(this.pluginConfig.confirmModeKamien)
                    .fixColors(Collections.singletonMap("chance", this.level.getChance())).toItemStack(), this::handleClick);
        }

        return bukkitMenu;
    }

    private void handleClick(InventoryClickEvent event) {
        Player clicked = (Player) event.getWhoClicked();
        clicked.closeInventory();

        this.removeItems(clicked);

        ItemStack hand = clicked.getInventory().getItemInMainHand();

        String levelString = ItemNbtUtil.getValueByPlugin(this.plugin, hand, "upgrade-level").orElse("0");
        final int currentLevel = Integer.parseInt(levelString);

        boolean success = RandomUtil.chance(this.level.getChance());

        final int newLevel = (success ? currentLevel + 1 : currentLevel - 1);

        if (success) {
            this.messageConfig.upgradeSuccess.send(clicked);
            clicked.playSound(clicked.getLocation(), this.pluginConfig.upgradeSuccess, 1, 1);
        }
        else {
            this.messageConfig.upgradeFailure.send(clicked);
            clicked.playSound(clicked.getLocation(), this.pluginConfig.upgradeFailure, 1, 1);
        }

        if (this.mode.equals(KowalMenuMode.KAMIEN_KOWALSKI)) {
            clicked.getInventory().removeItem(ItemBuilder.of(this.pluginConfig.kamienKowalski).setAmount(1).fixColors().toItemStack());

            if (!success) {
                return;
            }
        }

        if (newLevel < 0) {
            return;
        }

        String currentLore = this.level.getItemLoreDisplay();
        String previousLore = (newLevel > 0 ? this.pluginConfig.kowalLevels.get(newLevel).getItemLoreDisplay() : "");

        ItemBuilder newItem = ItemBuilder.of(hand)
                .setName((newLevel == 0 ? "" : this.pluginConfig.kowalItems.get(hand.getType())))
                .setLore((success ? currentLore : previousLore))
                .withNbt(this.plugin, "upgrade-level", String.valueOf(newLevel));

        if (newLevel >= 7) {
            EffectType[] effects = EffectType.values();
            EffectType random = effects[RandomUtil.nextInteger(effects.length)];
            Effect randomEffect = this.pluginConfig.effects.get(random);

            newItem.withNbt(this.plugin, "upgrade-effect", random.getData())
                    .appendLore(randomEffect.getLore())
                    .fixColors(new MapBuilder<String, Object>()
                            .put("level", newLevel)
                            .put("chance", randomEffect.getAmplifierChance())
                            .build());
        }
        else {
            newItem.fixColors(Collections.singletonMap("level", newLevel));
        }

        clicked.getInventory().setItemInMainHand(newItem.toItemStack());
    }

    private void removeItems(Player player) {
        this.pluginHookManager.get(VaultHook.class)
                .map(vaultHook -> vaultHook.withdraw(player, this.level.getMoneyUpgrade()));

        this.level.getUpgradeItems().forEach((item, amount) -> player.getInventory().removeItem(new ItemStack(item, amount)));
    }
}
