package cc.dreamcode.kowal.controller;

import cc.dreamcode.kowal.ParticleCache;
import eu.okaeri.injector.annotation.Inject;
import lombok.RequiredArgsConstructor;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class PlayerController implements Listener {
    private final ParticleCache particleCache;

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        this.particleCache.check(event.getPlayer());
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        this.particleCache.remove(event.getPlayer().getUniqueId());
    }
}
