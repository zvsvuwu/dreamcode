package cc.dreamcode.kowal.controller;

import cc.dreamcode.kowal.KowalPlugin;
import cc.dreamcode.kowal.config.MessageConfig;
import cc.dreamcode.kowal.config.PluginConfig;
import cc.dreamcode.kowal.effect.EffectType;
import cc.dreamcode.utilities.RandomUtil;
import cc.dreamcode.utilities.bukkit.nbt.ItemNbtUtil;
import com.google.common.util.concurrent.AtomicDouble;
import eu.okaeri.injector.annotation.Inject;
import lombok.RequiredArgsConstructor;
import org.bukkit.Material;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerItemDamageEvent;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.Arrays;
import java.util.concurrent.atomic.AtomicInteger;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class EffectController implements Listener {
    private final KowalPlugin plugin;
    private final PluginConfig pluginConfig;
    private final MessageConfig messageConfig;

    @EventHandler
    public void onArmorDamage(PlayerItemDamageEvent event) {
        Player player = event.getPlayer();

        if (!this.pluginConfig.kowalItems.containsKey(event.getItem().getType())) {
            return;
        }

        if (event.getPlayer().getInventory().getChestplate() == null) {
            return;
        }

        AtomicInteger chance = new AtomicInteger();

        Arrays.stream(player.getInventory().getArmorContents()).forEach(armor -> {
            if (armor == null) {
                return;
            }

            String upgrade = ItemNbtUtil.getValueByPlugin(this.plugin, armor, "upgrade-effect").orElse("none");

            if (upgrade.equals(EffectType.ARMOR_DAMAGE.getData())) {
                chance.getAndAdd(this.pluginConfig.effects.get(EffectType.ARMOR_DAMAGE).getAmplifierChance());
            }
        });

        if (RandomUtil.chance(chance.get())) {
            event.setDamage(0);
        }
    }

    @EventHandler
    public void onPotionConsume(PlayerItemConsumeEvent event) {
        Player player = event.getPlayer();

        if (!event.getItem().getType().equals(Material.POTION)) {
            return;
        }

        AtomicDouble amplifier = new AtomicDouble(1.0D);

        Arrays.stream(player.getInventory().getArmorContents()).forEach(armor -> {
            if (armor == null) {
                return;
            }

            String upgrade = ItemNbtUtil.getValueByPlugin(this.plugin, armor, "upgrade-effect").orElse("none");

            if (upgrade.equals(EffectType.POTION_DURATION.getData())) {
                amplifier.getAndAdd((double) this.pluginConfig.effects.get(EffectType.POTION_DURATION).getAmplifierChance() / 100);
            }
        });

        PotionMeta meta = (PotionMeta) event.getItem().getItemMeta();

        PotionEffectType type = meta.getBasePotionData().getType().getEffectType();

        if (type == null) {
            return;
        }

        this.plugin.getServer().getScheduler().runTaskLater(this.plugin, () -> {
            PotionEffect activeEffect = player.getPotionEffect(type);

            if (activeEffect != null) {
                int newDuration = (int) (activeEffect.getDuration() * amplifier.get());

                player.removePotionEffect(type);
                player.addPotionEffect(new PotionEffect(type, newDuration, activeEffect.getAmplifier()));
            }
        }, 20L);
    }

    @EventHandler
    public void onArrowDamage(EntityDamageByEntityEvent event) {
        if (!event.getEntityType().equals(EntityType.PLAYER) && !event.getDamager().getType().equals(EntityType.ARROW)) {
            return;
        }

        Player player = (Player) event.getEntity();

        AtomicInteger chance = new AtomicInteger();

        Arrays.stream(player.getInventory().getArmorContents()).forEach(armor -> {
            if (armor == null) {
                return;
            }

            String upgrade = ItemNbtUtil.getValueByPlugin(this.plugin, armor, "upgrade-effect").orElse("none");

            if (upgrade.equals(EffectType.ARROW.getData())) {
                chance.getAndAdd(this.pluginConfig.effects.get(EffectType.ARROW).getAmplifierChance());
            }
        });

        if (RandomUtil.chance(chance.get())) {
            this.messageConfig.arrowUse.send(player);
            event.setCancelled(true);
        }
    }
}
