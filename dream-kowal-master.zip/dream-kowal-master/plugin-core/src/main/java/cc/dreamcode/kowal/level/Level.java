package cc.dreamcode.kowal.level;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import org.bukkit.Material;

import java.util.List;
import java.util.Map;

@Data
public class Level {

    private final Map<Material, Integer> upgradeItems;
    private final String upgradeItemsLore;
    private final String costLore;
    private final double moneyUpgrade;
    private final String itemLoreDisplay;
    private final double hpReduce;
    private final int chance;

}
