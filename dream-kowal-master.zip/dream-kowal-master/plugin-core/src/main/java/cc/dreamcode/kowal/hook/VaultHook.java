package cc.dreamcode.kowal.hook;

import cc.dreamcode.kowal.KowalPlugin;
import cc.dreamcode.platform.bukkit.hook.PluginHook;
import cc.dreamcode.platform.bukkit.hook.annotation.Hook;
import eu.okaeri.injector.annotation.Inject;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.bukkit.entity.Player;

import java.util.Optional;

@Hook(name = "vault")
@RequiredArgsConstructor(onConstructor_ = @Inject)
public class VaultHook implements PluginHook {
    private final KowalPlugin kowalPlugin;

    private VaultHookService vaultHookService;

    @Override
    public void onInit() {
        this.vaultHookService = new VaultHookService(this.kowalPlugin);
    }

    public Optional<Double> getMoney(@NonNull Player player) {
        if (this.vaultHookService == null) {
            return Optional.empty();
        }

        return Optional.of(this.vaultHookService.getMoney(player));
    }

    public boolean withdraw(@NonNull Player player, double money) {
        if (this.vaultHookService == null) {
            return false;
        }

        return this.vaultHookService.withdraw(player, money);
    }
}
