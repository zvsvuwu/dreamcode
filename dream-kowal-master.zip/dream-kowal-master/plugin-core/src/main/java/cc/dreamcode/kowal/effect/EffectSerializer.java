package cc.dreamcode.kowal.effect;

import eu.okaeri.configs.schema.GenericsDeclaration;
import eu.okaeri.configs.serdes.DeserializationData;
import eu.okaeri.configs.serdes.ObjectSerializer;
import eu.okaeri.configs.serdes.SerializationData;
import lombok.NonNull;

public class EffectSerializer implements ObjectSerializer<Effect> {
    @Override
    public boolean supports(@NonNull Class<? super Effect> type) {
        return Effect.class.isAssignableFrom(type);
    }

    @Override
    public void serialize(@NonNull Effect object, @NonNull SerializationData data, @NonNull GenericsDeclaration generics) {
        data.add("lore-display", object.getLore());
        data.add("amplifier-or-chance", object.getAmplifierChance());
    }

    @Override
    public Effect deserialize(@NonNull DeserializationData data, @NonNull GenericsDeclaration generics) {
        return new Effect(
                data.get("lore-display", String.class),
                data.get("amplifier-or-chance", Integer.class)
        );
    }
}
