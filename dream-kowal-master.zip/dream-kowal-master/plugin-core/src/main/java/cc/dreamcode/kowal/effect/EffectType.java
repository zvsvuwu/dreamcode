package cc.dreamcode.kowal.effect;

import lombok.Getter;

@Getter
public enum EffectType {
    POTION_DURATION("potion"),
    DAMAGE("damage"),
    ARMOR_DAMAGE("armor"),
    ARROW("arrow");

    final String data;

    EffectType(String data) {
        this.data = data;
    }
}
