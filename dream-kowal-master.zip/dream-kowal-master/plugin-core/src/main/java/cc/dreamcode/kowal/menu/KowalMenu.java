package cc.dreamcode.kowal.menu;

import cc.dreamcode.kowal.KowalPlugin;
import cc.dreamcode.kowal.config.MessageConfig;
import cc.dreamcode.kowal.config.PluginConfig;
import cc.dreamcode.kowal.hook.VaultHook;
import cc.dreamcode.kowal.level.Level;
import cc.dreamcode.menu.adventure.BukkitMenuBuilder;
import cc.dreamcode.menu.adventure.base.BukkitMenu;
import cc.dreamcode.menu.adventure.setup.BukkitMenuPlayerSetup;
import cc.dreamcode.platform.bukkit.hook.PluginHookManager;
import cc.dreamcode.utilities.builder.MapBuilder;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import cc.dreamcode.utilities.bukkit.nbt.ItemNbtUtil;
import eu.okaeri.injector.annotation.Inject;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.bukkit.Material;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.concurrent.atomic.AtomicBoolean;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class KowalMenu implements BukkitMenuPlayerSetup {
    private final KowalPlugin plugin;
    private final PluginConfig pluginConfig;
    private final MessageConfig messageConfig;
    private final PluginHookManager pluginHookManager;

    private KowalMenuMode mode = KowalMenuMode.METAL;

    @Override
    public BukkitMenu build(@NonNull HumanEntity humanEntity) {
        if (!(humanEntity instanceof Player)) {
            throw new RuntimeException("humanEntity must be Player");
        }

        Player player = (Player) humanEntity;

        BukkitMenuBuilder builder = this.pluginConfig.kowalMenu;
        BukkitMenu bukkitMenu = builder.buildEmpty();

        bukkitMenu.setDisposeWhenClose(true);

        ItemStack hand = humanEntity.getInventory().getItemInMainHand();

        String levelString = ItemNbtUtil.getValueByPlugin(this.plugin, hand, "upgrade-level").orElse("0");
        final int currentLevel = Integer.parseInt(levelString);

        if (hand.getType().equals(Material.AIR) || !this.pluginConfig.kowalItems.containsKey(hand.getType()) || currentLevel >= 7) {
            bukkitMenu.setItem(this.pluginConfig.upgradeItemSlot, ItemBuilder.of(this.pluginConfig.notUpgradeable).fixColors().toItemStack());
            return bukkitMenu;
        }

        if (this.mode.equals(KowalMenuMode.METAL)) {
            bukkitMenu.setItem(this.pluginConfig.modeSlot, ItemBuilder.of(this.pluginConfig.modeMetal).fixColors().toItemStack(), event -> {
                if (!event.getWhoClicked().getInventory().containsAtLeast(ItemBuilder.of(this.pluginConfig.kamienKowalski).fixColors().toItemStack(), 1)) {
                    event.getWhoClicked().closeInventory();
                    this.messageConfig.kamienRequired.send(event.getWhoClicked());
                    return;
                }

                this.mode = KowalMenuMode.KAMIEN_KOWALSKI;
                this.build(event.getWhoClicked()).open(event.getWhoClicked());
            });
        }
        else {
            bukkitMenu.setItem(this.pluginConfig.modeSlot, ItemBuilder.of(this.pluginConfig.modeKamien).fixColors().toItemStack(), event -> {
                this.mode = KowalMenuMode.METAL;
                this.build(event.getWhoClicked()).open(event.getWhoClicked());
            });
        }

        Level level = this.pluginConfig.kowalLevels.get(currentLevel + 1);

        builder.getItems().forEach((slot, item) -> {
            if (this.pluginConfig.upgradeCancelSlot == slot) {
                bukkitMenu.setItem(slot, ItemBuilder.of(item).fixColors().toItemStack(), event -> event.getWhoClicked().closeInventory());
                return;
            }

            if (this.pluginConfig.upgradeAcceptSlot == slot) {
                bukkitMenu.setItem(slot, ItemBuilder.of(item).fixColors(new MapBuilder<String, Object>()
                        .put("level", currentLevel)
                        .put("new", currentLevel + 1)
                        .put("items", level.getUpgradeItemsLore())
                        .put("cost", level.getCostLore())
                        .put("status", (this.canAfford(player, level) ? this.pluginConfig.canUpgradeStatus : this.pluginConfig.cannotUpgradeStatus))
                        .build()).toItemStack(), event -> {
                    if (!this.canAfford(player, level)) {
                        player.closeInventory();
                        this.messageConfig.cannotAfford.send(player);
                    }
                    else {
                        KowalConfirmMenu kowalConfirmMenu = this.plugin.createInstance(KowalConfirmMenu.class);

                        kowalConfirmMenu.setLevel(level);
                        kowalConfirmMenu.setMode(this.mode);

                        kowalConfirmMenu.build(event.getWhoClicked()).open(event.getWhoClicked());
                    }
                });
                return;
            }

            bukkitMenu.setItem(slot, ItemBuilder.of(item).fixColors().toItemStack());
        });

        bukkitMenu.setItem(this.pluginConfig.upgradeItemSlot, humanEntity.getInventory().getItemInMainHand());

        return bukkitMenu;
    }

    private boolean canAfford(Player player, Level level) {
        AtomicBoolean afford = new AtomicBoolean(true);

        level.getUpgradeItems().forEach((item, amount) -> {
            if (!player.getInventory().containsAtLeast(new ItemStack(item), amount)) {
                afford.set(false);
            }
        });

        double money = this.pluginHookManager.get(VaultHook.class)
                .map(vaultHook -> vaultHook.getMoney(player).orElse(0.0D))
                .orElse(0.0D);

        if (money < level.getMoneyUpgrade()) {
            afford.set(false);
        }

        return afford.get();
    }
}
