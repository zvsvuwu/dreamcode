package cc.dreamcode.kowal.effect;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
public class Effect {

    private final String lore;
    private final int amplifierChance;

}
