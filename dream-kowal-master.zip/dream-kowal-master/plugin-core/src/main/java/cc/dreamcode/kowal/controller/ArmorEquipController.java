package cc.dreamcode.kowal.controller;

import cc.dreamcode.kowal.ParticleCache;
import com.destroystokyo.paper.event.player.PlayerArmorChangeEvent;
import eu.okaeri.injector.annotation.Inject;
import lombok.RequiredArgsConstructor;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class ArmorEquipController implements Listener {
    private final ParticleCache particleCache;

    @EventHandler
    public void onArmorEquip(PlayerArmorChangeEvent event) {
        this.particleCache.check(event.getPlayer());
    }
}
