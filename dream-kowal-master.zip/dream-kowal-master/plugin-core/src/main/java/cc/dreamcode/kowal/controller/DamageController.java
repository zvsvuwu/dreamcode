package cc.dreamcode.kowal.controller;

import cc.dreamcode.kowal.KowalPlugin;
import cc.dreamcode.kowal.config.MessageConfig;
import cc.dreamcode.kowal.config.PluginConfig;
import cc.dreamcode.kowal.effect.EffectType;
import cc.dreamcode.utilities.RandomUtil;
import cc.dreamcode.utilities.bukkit.nbt.ItemNbtUtil;
import com.google.common.util.concurrent.AtomicDouble;
import eu.okaeri.injector.annotation.Inject;
import lombok.RequiredArgsConstructor;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

import java.util.Arrays;
import java.util.concurrent.atomic.AtomicInteger;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class DamageController implements Listener {
    private final KowalPlugin plugin;
    private final PluginConfig pluginConfig;
    private final MessageConfig messageConfig;

    @EventHandler
    public void onEntityDamage(EntityDamageByEntityEvent event) {
        if (!event.getEntityType().equals(EntityType.PLAYER)) {
            return;
        }

        Player player = (Player) event.getEntity();

        AtomicDouble reduce = new AtomicDouble(0.0D);
        AtomicInteger chance = new AtomicInteger();

        Arrays.stream(player.getInventory().getArmorContents()).forEach(armor -> {
            if (armor == null) {
                return;
            }

            String levelString = ItemNbtUtil.getValueByPlugin(this.plugin, armor, "upgrade-level").orElse("0");
            String upgrade = ItemNbtUtil.getValueByPlugin(this.plugin, armor, "upgrade-effect").orElse("none");
            final int currentLevel = Integer.parseInt(levelString);

            if (currentLevel >= 1) {
                reduce.getAndAdd(this.pluginConfig.kowalLevels.get(currentLevel).getHpReduce());
            }

            if (upgrade.equals(EffectType.DAMAGE.getData())) {
                chance.getAndAdd(this.pluginConfig.effects.get(EffectType.DAMAGE).getAmplifierChance());
            }
        });

        if (RandomUtil.chance(chance.get()) && event.getDamager().getType().equals(EntityType.PLAYER)) {
            Player damager = (Player) event.getDamager();
            damager.setHealth(damager.getHealth() - event.getDamage());

            this.messageConfig.damageUsePlayer.send(player);
            this.messageConfig.damageUseDamager.send(damager);
        }
        else {
            event.setDamage(event.getDamage() - reduce.get());
        }
    }
}
