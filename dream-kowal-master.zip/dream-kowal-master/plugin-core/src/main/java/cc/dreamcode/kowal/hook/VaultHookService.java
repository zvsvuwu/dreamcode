package cc.dreamcode.kowal.hook;

import cc.dreamcode.kowal.KowalPlugin;
import lombok.NonNull;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.ServicesManager;

public class VaultHookService {
    private final Economy economy;

    public VaultHookService(KowalPlugin kowalPlugin) {
        ServicesManager servicesManager = kowalPlugin.getServer().getServicesManager();
        RegisteredServiceProvider<Economy> rsp = servicesManager.getRegistration(Economy.class);

        if (rsp == null) {
            throw new RuntimeException("Cannot hook into Economy from Vault.");
        }

        this.economy = rsp.getProvider();
    }

    public double getMoney(@NonNull OfflinePlayer offlinePlayer) {
        return this.economy.getBalance(offlinePlayer);
    }

    public boolean withdraw(@NonNull OfflinePlayer offlinePlayer, double amount) {
        return this.economy.withdrawPlayer(offlinePlayer, amount).transactionSuccess();
    }
}
