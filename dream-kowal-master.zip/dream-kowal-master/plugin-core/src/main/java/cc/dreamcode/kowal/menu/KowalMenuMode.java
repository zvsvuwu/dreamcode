package cc.dreamcode.kowal.menu;

public enum KowalMenuMode {
    METAL, KAMIEN_KOWALSKI
}
