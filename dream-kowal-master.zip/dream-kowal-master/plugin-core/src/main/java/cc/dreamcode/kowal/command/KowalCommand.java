package cc.dreamcode.kowal.command;

import cc.dreamcode.command.CommandBase;
import cc.dreamcode.command.annotation.Arg;
import cc.dreamcode.command.annotation.Async;
import cc.dreamcode.command.annotation.Command;
import cc.dreamcode.command.annotation.Completion;
import cc.dreamcode.command.annotation.Executor;
import cc.dreamcode.command.annotation.Permission;
import cc.dreamcode.kowal.KowalPlugin;
import cc.dreamcode.kowal.config.MessageConfig;
import cc.dreamcode.kowal.config.PluginConfig;
import cc.dreamcode.kowal.effect.Effect;
import cc.dreamcode.kowal.effect.EffectType;
import cc.dreamcode.kowal.level.Level;
import cc.dreamcode.kowal.menu.KowalMenu;
import cc.dreamcode.notice.adventure.BukkitNotice;
import cc.dreamcode.utilities.RandomUtil;
import cc.dreamcode.utilities.TimeUtil;
import cc.dreamcode.utilities.builder.MapBuilder;
import cc.dreamcode.utilities.bukkit.InventoryUtil;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import eu.okaeri.configs.exception.OkaeriException;
import eu.okaeri.injector.annotation.Inject;
import lombok.RequiredArgsConstructor;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.Collections;

@Command(name = "kowal")
@RequiredArgsConstructor(onConstructor_ = @Inject)
public class KowalCommand implements CommandBase {
    private final KowalPlugin plugin;
    private final PluginConfig pluginConfig;
    private final MessageConfig messageConfig;

    @Executor(description = "Otwiera gui kowala.")
    void gui(Player sender) {
        final KowalMenu kowalMenu = this.plugin.createInstance(KowalMenu.class);
        kowalMenu.build(sender).open(sender);
    }

    @Async
    @Permission("dream-kowal.give")
    @Completion(arg = "target", value = {"all", "@all-players"})
    @Executor(path = "give", description = "Nadaje kamien kowalski.")
    void give(CommandSender sender, @Arg String target, @Arg int amount) {
        if (target.equals("all")) {
            this.plugin.getServer().getOnlinePlayers().forEach(player -> {
                InventoryUtil.giveItem(player, ItemBuilder.of(this.pluginConfig.kamienKowalski).setAmount(amount).fixColors().toItemStack());
                this.messageConfig.giveAllPlayer.send(player, Collections.singletonMap("amount", amount));
            });

            this.messageConfig.giveAll.send(sender, Collections.singletonMap("amount", amount));
            return;
        }

        Player targetPlayer = this.plugin.getServer().getPlayerExact(target);

        if (targetPlayer == null) {
            this.messageConfig.playerNotFound.send(sender);
            return;
        }

        InventoryUtil.giveItem(targetPlayer, ItemBuilder.of(this.pluginConfig.kamienKowalski).setAmount(amount).fixColors().toItemStack());
        this.messageConfig.givePlayer.send(targetPlayer, Collections.singletonMap("amount", amount));
        this.messageConfig.give.send(sender, new MapBuilder<String, Object>()
                .put("player", targetPlayer.getName())
                .put("amount", amount)
                .build());
    }

    @Async
    @Permission("dream-kowal.set")
    @Executor(path = "set", description = "Ustawia przedmiot kamienia kowalskiego.")
    BukkitNotice set(Player sender) {
        sender.getInventory().getItemInMainHand();
        if (sender.getInventory().getItemInMainHand().getType().equals(Material.AIR)) {
            return this.messageConfig.kamienAir;
        }

        this.pluginConfig.kamienKowalski = ItemBuilder.of(sender.getInventory().getItemInMainHand()).breakColors().toItemStack();
        this.pluginConfig.save();

        return this.messageConfig.kamienSet;
    }

    @Async
    @Permission("dream-kowal.upgrade")
    @Executor(path = "ulepsz", description = "Ulepsza przedmiot w rece na podany poziom.")
    BukkitNotice ulepsz(Player sender, @Arg int level) {
        ItemStack item = sender.getInventory().getItemInMainHand();

        if (item.getType().equals(Material.AIR)) {
            return this.messageConfig.commandUpgradeAir;
        }

        if (!this.pluginConfig.kowalItems.containsKey(item.getType())) {
            return this.messageConfig.commandUpgradeNotArmor;
        }

        if (level > 7 || level <= 0) {
            return this.messageConfig.commandUpgradeLevelError;
        }

        Level found = this.pluginConfig.kowalLevels.get(level);

        ItemBuilder newItem = ItemBuilder.of(item.getType())
                .setName(this.pluginConfig.kowalItems.get(item.getType()))
                .setLore(found.getItemLoreDisplay())
                .withNbt(this.plugin, "upgrade-level", String.valueOf(level));

        if (level == 7) {
            EffectType[] effects = EffectType.values();
            EffectType random = effects[RandomUtil.nextInteger(effects.length)];
            Effect randomEffect = this.pluginConfig.effects.get(random);

            newItem.withNbt(this.plugin, "upgrade-effect", random.getData())
                    .appendLore(randomEffect.getLore())
                    .fixColors(new MapBuilder<String, Object>()
                            .put("level", level)
                            .put("chance", randomEffect.getAmplifierChance())
                            .build());
        }
        else {
            newItem.fixColors(Collections.singletonMap("level", level));
        }

        sender.getInventory().setItemInMainHand(newItem.toItemStack());

        return this.messageConfig.commandUpgradeSuccess
                .with("level", level);
    }

    @Async
    @Permission("dream-kowal.reload")
    @Executor(path = "reload", description = "Przeladowuje konfiguracje.")
    BukkitNotice reload() {
        final long time = System.currentTimeMillis();

        try {
            this.messageConfig.load();
            this.pluginConfig.load();

            return this.messageConfig.reloaded
                    .with("time", TimeUtil.format(System.currentTimeMillis() - time));
        }
        catch (NullPointerException | OkaeriException e) {
            e.printStackTrace();

            return this.messageConfig.reloadError
                    .with("error", e.getMessage());
        }
    }
}
