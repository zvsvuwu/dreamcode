package cc.dreamcode.kowal.config;

import cc.dreamcode.notice.adventure.BukkitNotice;
import cc.dreamcode.platform.bukkit.component.configuration.Configuration;
import eu.okaeri.configs.OkaeriConfig;
import eu.okaeri.configs.annotation.CustomKey;
import eu.okaeri.configs.annotation.Header;
import eu.okaeri.configs.annotation.Headers;

@Configuration(child = "message.yml")
@Headers({
        @Header("## Dream-Kowal (Message-Config) ##"),
        @Header("Dostepne type: (DO_NOT_SEND, CHAT, ACTION_BAR, SUBTITLE, TITLE, TITLE_SUBTITLE)")
})
public class MessageConfig extends OkaeriConfig {

    @CustomKey("command-usage")
    public BukkitNotice usage = BukkitNotice.chat("&7Przyklady uzycia komendy: &c{label}");
    @CustomKey("command-usage-help")
    public BukkitNotice usagePath = BukkitNotice.chat("&f{usage} &8- &7{description}");

    @CustomKey("command-usage-not-found")
    public BukkitNotice usageNotFound = BukkitNotice.chat("&cNie znaleziono pasujacych do kryteriow komendy.");
    @CustomKey("command-path-not-found")
    public BukkitNotice pathNotFound = BukkitNotice.chat("&cTa komenda jest pusta lub nie posiadasz dostepu do niej.");
    @CustomKey("command-no-permission")
    public BukkitNotice noPermission = BukkitNotice.chat("&cNie posiadasz uprawnien.");
    @CustomKey("command-not-player")
    public BukkitNotice notPlayer = BukkitNotice.chat("&cTa komende mozna tylko wykonac z poziomu gracza.");
    @CustomKey("command-not-console")
    public BukkitNotice notConsole = BukkitNotice.chat("&cTa komende mozna tylko wykonac z poziomu konsoli.");
    @CustomKey("command-invalid-format")
    public BukkitNotice invalidFormat = BukkitNotice.chat("&cPodano nieprawidlowy format argumentu komendy. ({input})");

    @CustomKey("player-not-found")
    public BukkitNotice playerNotFound = BukkitNotice.chat("&cPodanego gracza nie znaleziono.");
    @CustomKey("world-not-found")
    public BukkitNotice worldNotFound = BukkitNotice.chat("&cPodanego swiata nie znaleziono.");

    @CustomKey("config-reloaded")
    public BukkitNotice reloaded = BukkitNotice.chat("&aPrzeladowano! &7({time})");
    @CustomKey("config-reload-error")
    public BukkitNotice reloadError = BukkitNotice.chat("&cZnaleziono problem w konfiguracji: &6{error}");

    @CustomKey("upgrade-success")
    public BukkitNotice upgradeSuccess = BukkitNotice.titleSubtitle("&aUlepszono!", "&7Udalo Ci sie ulepszyc przedmiot!");
    @CustomKey("upgrade-failure")
    public BukkitNotice upgradeFailure = BukkitNotice.titleSubtitle("&cNie ulepszono!", "&7Tym razem nie udalo Ci sie ulepszyc przedmiotu!");
    @CustomKey("kamien-kowalski-required")
    public BukkitNotice kamienRequired = BukkitNotice.titleSubtitle("&cNie posiadasz magicznego kamienia!", "&7Aby ulepszyc przedmiot, musisz posiadac magiczny kamien!");
    @CustomKey("upgrade-cannot-afford")
    public BukkitNotice cannotAfford = BukkitNotice.chat("&cNie stac cie na to ulepszenie!");

    @CustomKey("command-set-kamien-air")
    public BukkitNotice kamienAir = BukkitNotice.chat("&cMusisz trzymac przedmiot w rece.");
    @CustomKey("command-set-kamien-success")
    public BukkitNotice kamienSet = BukkitNotice.chat("&aUstawiono przedmiot kamienia kowalskiego.");

    @CustomKey("command-kamien-give-all-player")
    public BukkitNotice giveAllPlayer = BukkitNotice.chat("&aOtrzymales kamien kowalski w ilosci &2x{amount}&a.");
    @CustomKey("command-kamien-give-all")
    public BukkitNotice giveAll = BukkitNotice.chat("&aNadales kamien kowalski wszystkim graczom w ilosci &2{amount}&a.");
    @CustomKey("command-kamien-give-player")
    public BukkitNotice givePlayer = BukkitNotice.chat("&aOtrzymales kamien kowalski w ilosci &2x{amount}&a.");
    @CustomKey("command-kamien-give")
    public BukkitNotice give = BukkitNotice.chat("&aNadales kamien kowalski graczowi &2{player} &aw ilosci &2x{amount}&a.");

    @CustomKey("command-upgrade-air")
    public BukkitNotice commandUpgradeAir = BukkitNotice.chat("&cMusisz trzymac przedmiot w rece.");
    @CustomKey("command-upgrade-not-armor")
    public BukkitNotice commandUpgradeNotArmor = BukkitNotice.chat("&cTego przedmiotu nie da sie ulepszyc.");
    @CustomKey("command-upgrade-level-not-exists")
    public BukkitNotice commandUpgradeLevelError = BukkitNotice.chat("&cPoziom ulepszenia nie moze byc wyzszy niz 7.");
    @CustomKey("command-upgrade-success")
    public BukkitNotice commandUpgradeSuccess = BukkitNotice.chat("&aUlepszono przedmiot w rece na poziom &2{level}&a.");

    @CustomKey("effect-arrow-use")
    public BukkitNotice arrowUse = BukkitNotice.chat("&aStrzala zostala odbita!");
    @CustomKey("effect-damage-use-player")
    public BukkitNotice damageUsePlayer = BukkitNotice.chat("&aZadane obrazenia zostaly odbite!");
    @CustomKey("effect-damage-use-damger")
    public BukkitNotice damageUseDamager = BukkitNotice.chat("&cGracz odbil zadane obrazenia!");
}
