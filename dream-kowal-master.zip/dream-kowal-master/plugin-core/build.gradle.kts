import com.github.jengelman.gradle.plugins.shadow.tasks.ShadowJar

repositories {
    maven("https://repo.codemc.io/repository/nms")
    maven("https://repo.papermc.io/repository/maven-public/")
    maven("https://oss.sonatype.org/content/repositories/snapshots")
    maven("https://jitpack.io")
}

dependencies {
    // -- spigot api -- (base)
    compileOnly("com.destroystokyo.paper:paper-api:1.16.5-R0.1-SNAPSHOT")

    // -- dream-platform --
    implementation("cc.dreamcode.platform:core:1.12.8")
    implementation("cc.dreamcode.platform:bukkit:1.12.8")
    implementation("cc.dreamcode.platform:bukkit-config:1.12.8")
    implementation("cc.dreamcode.platform:bukkit-hook:1.12.8")
    implementation("cc.dreamcode.platform:dream-command:1.12.8")

    // -- dream-utilities --
    implementation("cc.dreamcode:utilities:1.4.5")
    implementation("cc.dreamcode:utilities-bukkit-adventure:1.4.5")

    // -- dream-notice --
    implementation("cc.dreamcode.notice:core:1.5.7")
    implementation("cc.dreamcode.notice:minecraft:1.5.7")
    implementation("cc.dreamcode.notice:minecraft-adventure:1.5.7")
    implementation("cc.dreamcode.notice:bukkit-adventure:1.5.7")
    implementation("cc.dreamcode.notice:bukkit-adventure-serializer:1.5.7")

    // -- notice mini-messages --
    implementation("net.kyori:adventure-text-minimessage:4.17.0")

    // -- dream-command --
    implementation("cc.dreamcode.command:core:2.1.2")
    implementation("cc.dreamcode.command:bukkit:2.1.2")

    // -- dream-menu --
    implementation("cc.dreamcode.menu:core:1.3.6")
    implementation("cc.dreamcode.menu:bukkit-adventure:1.3.6")
    implementation("cc.dreamcode.menu:bukkit-adventure-serializer:1.3.6")

    // -- configs--
    implementation("eu.okaeri:okaeri-configs-yaml-bukkit:5.0.2")
    implementation("eu.okaeri:okaeri-configs-serdes-bukkit:5.0.2")
    implementation("eu.okaeri:okaeri-configs-serdes-commons:5.0.2")

    // -- injector --
    implementation("eu.okaeri:okaeri-injector:2.1.0")

    // -- placeholders --
    implementation("eu.okaeri:okaeri-placeholders-core:5.0.1")

    // -- tasker (easy sync/async scheduler) --
    implementation("eu.okaeri:okaeri-tasker-bukkit:2.1.0-beta.3")

    // -- Multi-Version Items helper --
    implementation("com.github.cryptomorin:XSeries:9.10.0")

    compileOnly("com.github.MilkBowl:VaultAPI:1.7.1")
}

tasks.withType<ShadowJar> {

    archiveFileName.set("Dream-Kowal-${project.version}.jar")

    minimize()

    relocate("com.cryptomorin", "cc.dreamcode.kowal.libs.com.cryptomorin")
    relocate("eu.okaeri", "cc.dreamcode.kowal.libs.eu.okaeri")
    relocate("net.kyori", "cc.dreamcode.kowal.libs.net.kyori")

    relocate("cc.dreamcode.platform", "cc.dreamcode.kowal.libs.cc.dreamcode.platform")
    relocate("cc.dreamcode.utilities", "cc.dreamcode.kowal.libs.cc.dreamcode.utilities")
    relocate("cc.dreamcode.menu", "cc.dreamcode.kowal.libs.cc.dreamcode.menu")
    relocate("cc.dreamcode.command", "cc.dreamcode.kowal.libs.cc.dreamcode.command")
    relocate("cc.dreamcode.notice", "cc.dreamcode.kowal.libs.cc.dreamcode.notice")
}