import com.github.jengelman.gradle.plugins.shadow.tasks.ShadowJar

repositories {
    maven("https://repo.papermc.io/repository/maven-public/")
}

dependencies {
    // -- spigot api -- (base)
    compileOnly("org.spigotmc:spigot-api:1.8.8-R0.1-SNAPSHOT")

    // -- dream-platform --
    implementation("cc.dreamcode.platform:core:1.12.8")
    implementation("cc.dreamcode.platform:bukkit:1.12.8")
    implementation("cc.dreamcode.platform:bukkit-config:1.12.8")
    implementation("cc.dreamcode.platform:dream-command:1.12.8")
    implementation("cc.dreamcode.platform:persistence:1.12.8")

    // -- dream-utilities --
    implementation("cc.dreamcode:utilities:1.4.5")
    implementation("cc.dreamcode:utilities-bukkit-adventure:1.4.5")

    // -- dream-notice --
    implementation("cc.dreamcode.notice:core:1.5.7")
    implementation("cc.dreamcode.notice:minecraft:1.5.7")
    implementation("cc.dreamcode.notice:minecraft-adventure:1.5.7")
    implementation("cc.dreamcode.notice:bukkit-adventure:1.5.7")
    implementation("cc.dreamcode.notice:bukkit-adventure-serializer:1.5.7")

    // -- notice mini-messages --
    implementation("net.kyori:adventure-text-minimessage:4.17.0")

    // -- dream-command --
    implementation("cc.dreamcode.command:core:2.1.2")
    implementation("cc.dreamcode.command:bukkit:2.1.2")

    // -- dream-menu --
    implementation("cc.dreamcode.menu:core:1.3.6")
    implementation("cc.dreamcode.menu:bukkit-adventure:1.3.6")
    implementation("cc.dreamcode.menu:bukkit-adventure-serializer:1.3.6")

    // -- configs--
    implementation("eu.okaeri:okaeri-configs-yaml-bukkit:5.0.2")
    implementation("eu.okaeri:okaeri-configs-serdes-bukkit:5.0.2")
    implementation("eu.okaeri:okaeri-configs-serdes-commons:5.0.2")

    // -- persistence data --
    implementation("eu.okaeri:okaeri-persistence-flat:2.0.4")
    implementation("eu.okaeri:okaeri-persistence-jdbc:2.0.4")
    implementation("eu.okaeri:okaeri-persistence-mongo:2.0.4")

    // -- persistence data configure --
    implementation("eu.okaeri:okaeri-configs-json-gson:5.0.2")
    implementation("eu.okaeri:okaeri-configs-json-simple:5.0.2")

    // -- injector --
    implementation("eu.okaeri:okaeri-injector:2.1.0")

    // -- placeholders --
    implementation("eu.okaeri:okaeri-placeholders-core:5.0.1")

    // -- tasker (easy sync/async scheduler) --
    implementation("eu.okaeri:okaeri-tasker-bukkit:2.1.0-beta.3")

    // -- Multi-Version Items helper --
    implementation("com.github.cryptomorin:XSeries:9.10.0")
}

tasks.withType<ShadowJar> {

    archiveFileName.set("Dream-DailyTasks-${project.version}.jar")

    relocate("com.cryptomorin", "cc.dreamcode.dailytasks.libs.com.cryptomorin")
    relocate("eu.okaeri", "cc.dreamcode.dailytasks.libs.eu.okaeri")
    relocate("net.kyori", "cc.dreamcode.dailytasks.libs.net.kyori")

    relocate("cc.dreamcode.platform", "cc.dreamcode.dailytasks.libs.cc.dreamcode.platform")
    relocate("cc.dreamcode.utilities", "cc.dreamcode.dailytasks.libs.cc.dreamcode.utilities")
    relocate("cc.dreamcode.menu", "cc.dreamcode.dailytasks.libs.cc.dreamcode.menu")
    relocate("cc.dreamcode.command", "cc.dreamcode.dailytasks.libs.cc.dreamcode.command")
    relocate("cc.dreamcode.notice", "cc.dreamcode.dailytasks.libs.cc.dreamcode.notice")

    relocate("org.bson", "cc.dreamcode.dailytasks.libs.org.bson")
    relocate("com.mongodb", "cc.dreamcode.dailytasks.libs.com.mongodb")
    relocate("com.zaxxer", "cc.dreamcode.dailytasks.libs.com.zaxxer")
    relocate("org.slf4j", "cc.dreamcode.dailytasks.libs.org.slf4j")
    relocate("org.json", "cc.dreamcode.dailytasks.libs.org.json")
    relocate("com.google.gson", "cc.dreamcode.dailytasks.libs.com.google.gson")

    minimize()
}