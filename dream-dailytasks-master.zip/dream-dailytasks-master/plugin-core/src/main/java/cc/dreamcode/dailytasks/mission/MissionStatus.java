package cc.dreamcode.dailytasks.mission;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.Instant;

@Data
@AllArgsConstructor
public class MissionStatus {
    private String id;
    private boolean finished;
    private boolean rewardReceived;
    private long progress;
    private Instant updateTime;
}
