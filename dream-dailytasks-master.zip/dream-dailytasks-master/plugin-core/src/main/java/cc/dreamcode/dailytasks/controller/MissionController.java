package cc.dreamcode.dailytasks.controller;

import cc.dreamcode.dailytasks.config.PluginConfig;
import cc.dreamcode.dailytasks.mission.MissionService;
import cc.dreamcode.dailytasks.mission.MissionType;
import com.cryptomorin.xseries.XMaterial;
import eu.okaeri.injector.annotation.Inject;
import lombok.RequiredArgsConstructor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class MissionController implements Listener {

    private final PluginConfig pluginConfig;
    private final MissionService missionService;

    @EventHandler(ignoreCancelled = true)
    public void onItemConsume(PlayerItemConsumeEvent event) {
        final Player player = event.getPlayer();
        final XMaterial material = XMaterial.matchXMaterial(event.getItem().getType());

        this.missionService.getPlayerMission(player).ifPresent(mission -> {
            if (mission.getType() == MissionType.EAT && this.pluginConfig.foodList.contains(material)) {
                this.missionService.updateMissionProgress(player, mission, 1);
            }
        });
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        final Player player = event.getPlayer();
        final XMaterial material = XMaterial.matchXMaterial(event.getBlock().getType());

        this.missionService.getPlayerMission(player).ifPresent(mission -> {
            switch (mission.getType()) {
                case BREAK_WOOL:
                    if(this.pluginConfig.woolList.contains(material)) {
                        this.missionService.updateMissionProgress(player, mission, 1);
                    }
                    break;
                case BREAK_BLOCKS:
                    this.missionService.updateMissionProgress(player, mission, 1);
                    break;
                case BREAK_ORES:
                    if(this.pluginConfig.oreList.contains(material)) {
                        this.missionService.updateMissionProgress(player, mission, 1);
                    }
                    break;
            }
        });
    }

    @EventHandler(ignoreCancelled = true)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if(!(event.getEntity() instanceof Player) || !(event.getDamager() instanceof Player)) {
            return;
        }

        final Player player = (Player) event.getDamager();
        final double damage = event.getDamage();

        this.missionService.getPlayerMission(player).ifPresent(mission -> {
            if(mission.getType() == MissionType.DEAL_DAMAGE) {
                this.missionService.updateMissionProgress(player, mission, (long) damage);
            }
        });
    }
}
