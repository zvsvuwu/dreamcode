package cc.dreamcode.dailytasks.config;

import cc.dreamcode.dailytasks.mission.Mission;
import cc.dreamcode.dailytasks.mission.MissionType;
import cc.dreamcode.menu.adventure.BukkitMenuBuilder;
import cc.dreamcode.platform.bukkit.component.configuration.Configuration;
import cc.dreamcode.platform.persistence.StorageConfig;
import cc.dreamcode.utilities.builder.ListBuilder;
import cc.dreamcode.utilities.builder.MapBuilder;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import com.cryptomorin.xseries.XMaterial;
import eu.okaeri.configs.OkaeriConfig;
import eu.okaeri.configs.annotation.Comment;
import eu.okaeri.configs.annotation.Header;
import eu.okaeri.configs.annotation.NameModifier;
import eu.okaeri.configs.annotation.NameStrategy;
import eu.okaeri.configs.annotation.Names;
import org.bukkit.inventory.ItemStack;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@Configuration(
        child = "config.yml"
)
@Header("## Dream-DailyMissions (Main-Config) ##")
@Names(strategy = NameStrategy.HYPHEN_CASE, modifier = NameModifier.TO_LOWER_CASE)
public class PluginConfig extends OkaeriConfig {

    @Comment("")
    @Comment("Debug pokazuje dodatkowe informacje do konsoli. Lepiej wylaczyc. :P")
    public boolean debug = true;

    public BukkitMenuBuilder missionsMenu = new BukkitMenuBuilder(
            "&3&lCodzienne Misje",
            5,
            new MapBuilder<Integer, ItemStack>()
                    .put(new Integer[]{0, 8, 36, 44}, new ItemBuilder(XMaterial.LIGHT_BLUE_STAINED_GLASS_PANE.parseMaterial()).setName(" ").toItemStack())
                    .put(new Integer[]{1, 7, 9, 17, 27, 35, 37, 43}, new ItemBuilder(XMaterial.BLUE_STAINED_GLASS_PANE.parseMaterial()).setName(" ").toItemStack())
                    .put(new Integer[]{2, 3, 5, 6, 18, 26, 38, 39, 41, 42}, new ItemBuilder(XMaterial.WHITE_STAINED_GLASS_PANE.parseMaterial()).setName(" ").toItemStack())
                    .build()
    );

    public int missionSlot = 22;

    public List<Mission> missions = new ListBuilder<Mission>()
            .add(new Mission(
                    32,
                    MissionType.EAT,
                    "goldenapple",
                    new ItemBuilder(XMaterial.GOLDEN_APPLE.parseMaterial())
                            .setName("&a&lTwoja Dzisiejsza Misja")
                            .setLore(
                                    "&8&l| &7Zjedz 32 refile",
                                    "&8&l| &7Postęp: &f{user_progress}&8/&f{required_progress}",
                                    "",
                                    "{message}"
                            )
                            .toItemStack(),
                    Collections.singletonList("give {player} diamond 1")
            ))
            .add(new Mission(
                    500,
                    MissionType.DEAL_DAMAGE,
                    "damage",
                    new ItemBuilder(XMaterial.IRON_SWORD.parseMaterial())
                            .setName("&a&lTwoja Dzisiejsza Misja")
                            .setLore(
                                    "&8&l| &7Zadaj 500 damage",
                                    "&8&l| &7Postęp: &f{user_progress}&8/&f{required_progress}",
                                    "",
                                    "{message}"
                            )
                            .toItemStack(),
                    Collections.singletonList("give {player} diamond_sword 1")
            ))
            .add(new Mission(
                    1500,
                    MissionType.BREAK_ORES,
                    "ores",
                    new ItemBuilder(XMaterial.DIAMOND_BLOCK.parseMaterial())
                            .setName("&a&lTwoja Dzisiejsza Misja")
                            .setLore(
                                    "&8&l| &7Zniszcz 1500 rud",
                                    "&8&l| &7Postęp: &f{user_progress}&8/&f{required_progress}",
                                    "",
                                    "{message}"
                            )
                            .toItemStack(),
                    Collections.singletonList("give {player} diamond_pickaxe 1")
            ))
            .add(new Mission(
                    10000,
                    MissionType.BREAK_BLOCKS,
                    "blocks",
                    new ItemBuilder(XMaterial.STONE.parseMaterial())
                            .setName("&a&lTwoja Dzisiejsza Misja")
                            .setLore(
                                    "&8&l| &7Zniszcz 10000 bloków",
                                    "&8&l| &7Postęp: &f{user_progress}&8/&f{required_progress}",
                                    "",
                                    "{message}"
                            )
                            .toItemStack(),
                    Collections.singletonList("give {player} diamond_block 1")
            ))
            .add(new Mission(
                    200,
                    MissionType.BREAK_WOOL,
                    "wool",
                    new ItemBuilder(XMaterial.WHITE_WOOL.parseMaterial())
                            .setName("&a&lTwoja Dzisiejsza Misja")
                            .setLore(
                                    "&8&l| &7Zniszcz 200 wełny",
                                    "&8&l| &7Postęp: &f{user_progress}&8/&f{required_progress}",
                                    "",
                                    "{message}"
                            )
                            .toItemStack(),
                    Collections.singletonList("give {player} shears 1")
            ))
            .build();

    public String missionResetTime = "00:00";
    public String missionNotFinished = "&cMisja nadal nie została wykonana!";
    public String missionFinished = "&aKliknij, aby odebrać nagrodę";
    public ItemStack missionFinishedItem = new ItemBuilder(XMaterial.BARRIER.parseMaterial())
            .setName("&c&lWykonałeś już dzisiejszą misję")
            .setLore("&8&l| &7Misje resetują się codziennie o godzinie &f00:00")
            .toItemStack();
    public List<XMaterial> oreList = Arrays.asList(
            XMaterial.DIAMOND_ORE,
            XMaterial.DIAMOND_BLOCK,
            XMaterial.DEEPSLATE_DIAMOND_ORE,
            XMaterial.GOLD_ORE,
            XMaterial.GOLD_BLOCK,
            XMaterial.DEEPSLATE_GOLD_ORE,
            XMaterial.IRON_ORE,
            XMaterial.IRON_BLOCK,
            XMaterial.DEEPSLATE_IRON_ORE,
            XMaterial.EMERALD_ORE,
            XMaterial.EMERALD_BLOCK,
            XMaterial.DEEPSLATE_EMERALD_ORE,
            XMaterial.LAPIS_ORE,
            XMaterial.LAPIS_BLOCK,
            XMaterial.DEEPSLATE_LAPIS_ORE,
            XMaterial.REDSTONE_ORE,
            XMaterial.REDSTONE_BLOCK,
            XMaterial.DEEPSLATE_REDSTONE_ORE,
            XMaterial.COAL_ORE,
            XMaterial.COAL_BLOCK,
            XMaterial.DEEPSLATE_COAL_ORE
    );

    public List<XMaterial> woolList = Arrays.asList(
            XMaterial.WHITE_WOOL,
            XMaterial.ORANGE_WOOL,
            XMaterial.MAGENTA_WOOL,
            XMaterial.LIGHT_BLUE_WOOL,
            XMaterial.YELLOW_WOOL,
            XMaterial.LIME_WOOL,
            XMaterial.PINK_WOOL,
            XMaterial.GRAY_WOOL,
            XMaterial.LIGHT_GRAY_WOOL,
            XMaterial.CYAN_WOOL,
            XMaterial.PURPLE_WOOL,
            XMaterial.BLUE_WOOL,
            XMaterial.BROWN_WOOL,
            XMaterial.GREEN_WOOL,
            XMaterial.RED_WOOL,
            XMaterial.BLACK_WOOL
    );
    public List<XMaterial> foodList = Collections.singletonList(XMaterial.GOLDEN_APPLE);

    @Comment("")
    @Comment("Uzupelnij ponizsze menu danymi.")
    public StorageConfig storageConfig = new StorageConfig("dreamdailymissions");
}
