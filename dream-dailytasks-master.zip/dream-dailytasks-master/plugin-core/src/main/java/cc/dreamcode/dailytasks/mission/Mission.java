package cc.dreamcode.dailytasks.mission;

import cc.dreamcode.utilities.StringUtil;
import lombok.Data;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.bukkit.Bukkit;
import org.bukkit.entity.HumanEntity;
import org.bukkit.inventory.ItemStack;

import java.util.Collections;
import java.util.List;

@Data
@RequiredArgsConstructor
public class Mission {

    private final long requiredProgress;
    private final MissionType type;
    private final String id;
    private final ItemStack item;
    private final List<String> rewardCommands;

    public void giveReward(@NonNull HumanEntity player) {
        for (String command : this.getRewardCommands()) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), StringUtil.replace(command, Collections.singletonMap("player", player.getName())));
        }
    }
}
