package cc.dreamcode.dailytasks.mission;

import cc.dreamcode.dailytasks.config.MessageConfig;
import cc.dreamcode.dailytasks.config.PluginConfig;
import cc.dreamcode.dailytasks.user.User;
import cc.dreamcode.dailytasks.user.UserManager;
import cc.dreamcode.menu.adventure.base.BukkitMenu;
import cc.dreamcode.platform.DreamLogger;
import cc.dreamcode.utilities.builder.MapBuilder;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import eu.okaeri.injector.annotation.Inject;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.List;
import java.util.Optional;
import java.util.Random;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class MissionService {

    private final DreamLogger logger;
    private final UserManager userManager;
    private final PluginConfig pluginConfig;
    private final MessageConfig messageConfig;

    public Optional<Mission> getPlayerMission(@NonNull Player player) {
        final User user = this.userManager.getUserByPlayer(player);
        return this.getMissionById(user.getMissionStatus().getId());
    }

    public Optional<Mission> getMissionById(@NonNull String id) {
        return this.pluginConfig.missions.stream().filter(mission -> mission.getId().equals(id)).findAny();
    }

    public void updateMissionProgress(@NonNull Player player, @NonNull Mission mission, long progress) {
        final User user = this.userManager.getUserByPlayer(player);

        final MissionStatus missionStatus = user.getMissionStatus();

        if(missionStatus.isFinished() || missionStatus.isRewardReceived()) {
            return;
        }

        final long nextProgress = missionStatus.getProgress() + progress;

        if(nextProgress >= mission.getRequiredProgress()) {
            missionStatus.setProgress(mission.getRequiredProgress());
            missionStatus.setFinished(true);
        } else {
            missionStatus.setProgress(nextProgress);
        }

        if(missionStatus.isFinished()) {
            this.messageConfig.missionFinish.send(player);
        }

        user.setMissionStatus(missionStatus);
    }

    public void addMissionToMenu(@NonNull Player player, @NonNull BukkitMenu bukkitMenu, int slot) {
        final User user = this.userManager.getUserByPlayer(player);
        final MissionStatus missionStatus = user.getMissionStatus();

        this.getMissionById(missionStatus.getId()).ifPresent(mission -> bukkitMenu.setItem(slot, this.buildMissionItem(missionStatus, mission), event -> {
            final HumanEntity humanEntity = event.getWhoClicked();

            humanEntity.closeInventory();

            if(!missionStatus.getId().equals(mission.getId())) {
                this.messageConfig.missionChanged.send(humanEntity);
                return;
            }

            if(missionStatus.isRewardReceived()) {
                this.messageConfig.missionRewardAlreadyReceived.send(humanEntity);
                return;
            }

            if(!missionStatus.isFinished()) {
                this.messageConfig.missionNotFinished.send(humanEntity);
                return;
            }

            missionStatus.setRewardReceived(true);

            user.setMissionStatus(missionStatus);

            mission.giveReward(humanEntity);

            bukkitMenu.setItem(slot, this.buildMissionItem(missionStatus, mission));

            this.messageConfig.missionRewardReceive.send(humanEntity);
        }));
    }

    public ItemStack buildMissionItem(@NonNull MissionStatus missionStatus, @NonNull Mission mission) {
        if(missionStatus.isRewardReceived()) {
            return ItemBuilder.of(this.pluginConfig.missionFinishedItem).fixColors().toItemStack();
        } else {
            return ItemBuilder.of(mission.getItem())
                    .fixColors(new MapBuilder<String, Object>()
                            .put("user_progress", missionStatus.getProgress())
                            .put("required_progress", mission.getRequiredProgress())
                            .put("message", missionStatus.isFinished() ? this.pluginConfig.missionFinished : this.pluginConfig.missionNotFinished)
                            .build())
                    .toItemStack();
        }
    }

    public boolean refreshMission(@NonNull User user) {
        final MissionStatus missionStatus = user.getMissionStatus();

        if(missionStatus == null || missionStatus.getUpdateTime() == null) {
            this.resetMission(user);
            return true;
        }

        final String[] resetSplit = this.pluginConfig.missionResetTime.split(":");

        final int hour = Integer.parseInt(resetSplit[0]);
        final int minute = Integer.parseInt(resetSplit[1]);

        final LocalDateTime now = LocalDateTime.now();

        final LocalTime resetTime = LocalTime.of(hour, minute);

        final LocalDateTime lastUpdate = LocalDateTime.ofInstant(missionStatus.getUpdateTime(), ZoneId.systemDefault());

        if (lastUpdate.isAfter(now.with(resetTime))) {
            this.resetMission(user);
            return true;
        }

        return false;
    }

    public void resetMission(@NonNull User user) {
        final Mission randomMission = this.getRandomMission();

        final MissionStatus missionStatus = new MissionStatus(randomMission.getId(), false, false, 0, Instant.now());

        user.setMissionStatus(missionStatus);

        if(this.pluginConfig.debug) {
            this.logger.info("Mission reset for " + user.getName() + " to " + randomMission.getId());
        }
    }

    public List<Mission> getMissionList() {
        return this.pluginConfig.missions;
    }

    public Mission getRandomMission() {
        final List<Mission> missionList = this.getMissionList();

        final Random random = new Random();

        final int index = random.nextInt(missionList.size());

        return missionList.get(index);
    }
}
