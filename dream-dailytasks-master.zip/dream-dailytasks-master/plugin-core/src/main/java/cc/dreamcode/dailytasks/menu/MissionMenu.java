package cc.dreamcode.dailytasks.menu;

import cc.dreamcode.dailytasks.config.MessageConfig;
import cc.dreamcode.dailytasks.config.PluginConfig;
import cc.dreamcode.dailytasks.mission.MissionService;
import cc.dreamcode.dailytasks.user.User;
import cc.dreamcode.dailytasks.user.UserManager;
import cc.dreamcode.menu.adventure.base.BukkitMenu;
import cc.dreamcode.menu.adventure.setup.BukkitMenuPlayerSetup;
import eu.okaeri.injector.annotation.Inject;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class MissionMenu implements BukkitMenuPlayerSetup {

    private final PluginConfig pluginConfig;
    private final MessageConfig messageConfig;
    private final UserManager userManager;
    private final MissionService missionService;

    @Override
    public BukkitMenu build(@NonNull HumanEntity humanEntity) {
        final Player player = (Player) humanEntity;
        final User user = this.userManager.getUserByPlayer(player);

        final BukkitMenu bukkitMenu = this.pluginConfig.missionsMenu.buildWithItems();

        bukkitMenu.setCancelInventoryClick(true);
        bukkitMenu.setDisposeWhenClose(true);

        if (this.missionService.refreshMission(user)) {
            this.messageConfig.newMission.send(player);
        }

        this.missionService.addMissionToMenu(player, bukkitMenu, this.pluginConfig.missionSlot);

        return bukkitMenu;
    }
}
