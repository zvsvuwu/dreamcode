package cc.dreamcode.dailytasks;

import cc.dreamcode.command.bukkit.BukkitCommandProvider;
import cc.dreamcode.dailytasks.command.AdminDailyMissionCommand;
import cc.dreamcode.dailytasks.command.DailyMissionCommand;
import cc.dreamcode.dailytasks.command.handler.InvalidInputHandlerImpl;
import cc.dreamcode.dailytasks.command.handler.InvalidPermissionHandlerImpl;
import cc.dreamcode.dailytasks.command.handler.InvalidSenderHandlerImpl;
import cc.dreamcode.dailytasks.command.handler.InvalidUsageHandlerImpl;
import cc.dreamcode.dailytasks.command.result.BukkitNoticeResolver;
import cc.dreamcode.dailytasks.config.MessageConfig;
import cc.dreamcode.dailytasks.config.PluginConfig;
import cc.dreamcode.dailytasks.config.serializer.MissionSerializer;
import cc.dreamcode.dailytasks.config.serializer.MissionStatusSerializer;
import cc.dreamcode.dailytasks.controller.MissionController;
import cc.dreamcode.dailytasks.mission.MissionService;
import cc.dreamcode.dailytasks.user.UserController;
import cc.dreamcode.dailytasks.user.UserManager;
import cc.dreamcode.dailytasks.user.UserRepository;
import cc.dreamcode.menu.adventure.BukkitMenuProvider;
import cc.dreamcode.menu.adventure.serializer.MenuBuilderSerializer;
import cc.dreamcode.notice.adventure.BukkitNoticeProvider;
import cc.dreamcode.notice.adventure.serializer.BukkitNoticeSerializer;
import cc.dreamcode.platform.DreamVersion;
import cc.dreamcode.platform.bukkit.DreamBukkitConfig;
import cc.dreamcode.platform.bukkit.DreamBukkitPlatform;
import cc.dreamcode.platform.bukkit.component.ConfigurationResolver;
import cc.dreamcode.platform.bukkit.serializer.ItemMetaSerializer;
import cc.dreamcode.platform.bukkit.serializer.ItemStackSerializer;
import cc.dreamcode.platform.component.ComponentService;
import cc.dreamcode.platform.other.component.DreamCommandExtension;
import cc.dreamcode.platform.persistence.DreamPersistence;
import cc.dreamcode.platform.persistence.component.DocumentPersistenceResolver;
import cc.dreamcode.platform.persistence.component.DocumentRepositoryResolver;
import eu.okaeri.configs.serdes.OkaeriSerdesPack;
import eu.okaeri.configs.yaml.bukkit.serdes.SerdesBukkit;
import eu.okaeri.persistence.document.DocumentPersistence;
import eu.okaeri.tasker.bukkit.BukkitTasker;
import lombok.Getter;
import lombok.NonNull;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class DailyTasksPlugin extends DreamBukkitPlatform implements DreamBukkitConfig, DreamPersistence {

    @Getter private static DailyTasksPlugin dailyTasksPlugin;

    @Override
    public void load(@NonNull ComponentService componentService) {
        dailyTasksPlugin = this;
    }

    @Override
    public void enable(@NonNull ComponentService componentService) {
        componentService.setDebug(false);

        this.registerInjectable(BukkitTasker.newPool(this));
        this.registerInjectable(BukkitMenuProvider.create(this));
        this.registerInjectable(BukkitNoticeProvider.create(this));

        this.registerInjectable(BukkitCommandProvider.create(this));
        componentService.registerExtension(DreamCommandExtension.class);

        componentService.registerResolver(ConfigurationResolver.class);
        componentService.registerComponent(MessageConfig.class);

        componentService.registerComponent(BukkitNoticeResolver.class);
        componentService.registerComponent(InvalidInputHandlerImpl.class);
        componentService.registerComponent(InvalidPermissionHandlerImpl.class);
        componentService.registerComponent(InvalidSenderHandlerImpl.class);
        componentService.registerComponent(InvalidUsageHandlerImpl.class);

        componentService.registerComponent(PluginConfig.class, pluginConfig -> {
            // register persistence + repositories
            this.registerInjectable(pluginConfig.storageConfig);

            componentService.registerResolver(DocumentPersistenceResolver.class);
            componentService.registerComponent(DocumentPersistence.class);
            componentService.registerResolver(DocumentRepositoryResolver.class);

            // enable additional logs and debug messages
            componentService.setDebug(pluginConfig.debug);
        });

        componentService.registerComponent(UserRepository.class);
        componentService.registerComponent(UserManager.class, UserManager::readUsers);
        componentService.registerComponent(UserController.class);

        componentService.registerComponent(MissionService.class);

        componentService.registerComponent(MissionController.class);

        componentService.registerComponent(DailyMissionCommand.class);
        componentService.registerComponent(AdminDailyMissionCommand.class);
    }

    @Override
    public void disable() {
        this.getInject(UserManager.class).ifPresent(UserManager::saveUsers);
    }

    @Override
    public @NonNull DreamVersion getDreamVersion() {
        return DreamVersion.create("Dream-DailyMissions", "1.0.0", "Kajteh_");
    }

    @Override
    public @NonNull OkaeriSerdesPack getConfigSerdesPack() {
        return registry -> {
            registry.register(new BukkitNoticeSerializer());
            registry.register(new MenuBuilderSerializer());
            registry.register(new MissionSerializer());
        };
    }

    @Override
    public @NonNull OkaeriSerdesPack getPersistenceSerdesPack() {
        return registry -> {
            registry.register(new SerdesBukkit());
            registry.register(new MissionStatusSerializer());

            registry.registerExclusive(ItemStack.class, new ItemStackSerializer());
            registry.registerExclusive(ItemMeta.class, new ItemMetaSerializer());
        };
    }

}
