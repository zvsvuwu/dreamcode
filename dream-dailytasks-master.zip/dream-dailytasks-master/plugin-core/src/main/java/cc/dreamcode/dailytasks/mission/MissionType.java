package cc.dreamcode.dailytasks.mission;

public enum MissionType {
    EAT,
    BREAK_BLOCKS,
    BREAK_ORES,
    BREAK_WOOL,
    DEAL_DAMAGE,
}
