package cc.dreamcode.dailytasks.config.serializer;

import cc.dreamcode.dailytasks.mission.MissionStatus;
import eu.okaeri.configs.schema.GenericsDeclaration;
import eu.okaeri.configs.serdes.DeserializationData;
import eu.okaeri.configs.serdes.ObjectSerializer;
import eu.okaeri.configs.serdes.SerializationData;
import lombok.NonNull;

import java.time.Instant;

public class MissionStatusSerializer implements ObjectSerializer<MissionStatus> {

    @Override
    public boolean supports(@NonNull Class<? super MissionStatus> type) {
        return MissionStatus.class.isAssignableFrom(type);
    }

    @Override
    public void serialize(@NonNull MissionStatus object, @NonNull SerializationData data, @NonNull GenericsDeclaration generics) {
        data.add("id", object.getId());
        data.add("finished", object.isFinished());
        data.add("reward-received", object.isRewardReceived());
        data.add("progress", object.getProgress());
        data.add("update-time", object.getUpdateTime());
    }

    @Override
    public MissionStatus deserialize(@NonNull DeserializationData data, @NonNull GenericsDeclaration generics) {
        return new MissionStatus(
                data.get("id", String.class),
                data.get("finished", Boolean.class),
                data.get("reward-received", Boolean.class),
                data.get("progress", Long.class),
                data.get("update-time", Instant.class)
        );
    }
}
