package cc.dreamcode.dailytasks.command;

import cc.dreamcode.command.CommandBase;
import cc.dreamcode.command.annotation.Command;
import cc.dreamcode.command.annotation.Executor;
import cc.dreamcode.dailytasks.DailyTasksPlugin;
import cc.dreamcode.dailytasks.menu.MissionMenu;
import eu.okaeri.injector.annotation.Inject;
import eu.okaeri.tasker.core.Tasker;
import lombok.RequiredArgsConstructor;
import org.bukkit.entity.Player;

@Command(name = "dailymissions", aliases = {"dailymission", "codziennemisje"})
@RequiredArgsConstructor(onConstructor_ = @Inject)
public class DailyMissionCommand implements CommandBase {

    private final DailyTasksPlugin dailyTasksPlugin;
    private final Tasker tasker;

    @Executor(description = "Otwiera menu codziennych misji.")
    void menu(Player player) {
        this.tasker.newChain()
                .supplyAsync(() -> this.dailyTasksPlugin.createInstance(MissionMenu.class).build(player))
                .acceptSync(bukkitMenu -> bukkitMenu.open(player))
                .execute();
    }
}
