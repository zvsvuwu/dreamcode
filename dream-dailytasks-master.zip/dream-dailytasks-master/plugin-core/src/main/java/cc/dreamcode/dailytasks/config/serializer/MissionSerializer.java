package cc.dreamcode.dailytasks.config.serializer;

import cc.dreamcode.dailytasks.mission.Mission;
import cc.dreamcode.dailytasks.mission.MissionType;
import eu.okaeri.configs.schema.GenericsDeclaration;
import eu.okaeri.configs.serdes.DeserializationData;
import eu.okaeri.configs.serdes.ObjectSerializer;
import eu.okaeri.configs.serdes.SerializationData;
import lombok.NonNull;
import org.bukkit.inventory.ItemStack;

public class MissionSerializer implements ObjectSerializer<Mission> {
    @Override
    public boolean supports(@NonNull Class<? super Mission> type) {
        return Mission.class.isAssignableFrom(type);
    }

    @Override
    public void serialize(@NonNull Mission object, @NonNull SerializationData data, @NonNull GenericsDeclaration generics) {
        data.add("id", object.getId());
        data.add("type", object.getType());
        data.add("required-progress", object.getRequiredProgress());
        data.add("reward-commands", object.getRewardCommands());
        data.add("item", object.getItem());
    }

    @Override
    public Mission deserialize(@NonNull DeserializationData data, @NonNull GenericsDeclaration generics) {
        return new Mission(
                data.get("required-progress", Long.class),
                data.get("type", MissionType.class),
                data.get("id", String.class),
                data.get("item", ItemStack.class),
                data.getAsList("reward-commands", String.class)
        );
    }
}
