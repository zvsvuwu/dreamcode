package cc.dreamcode.dailytasks.user;

import cc.dreamcode.dailytasks.config.PluginConfig;
import cc.dreamcode.platform.DreamLogger;
import cc.dreamcode.utilities.TimeUtil;
import eu.okaeri.injector.annotation.Inject;
import eu.okaeri.persistence.document.Document;
import eu.okaeri.tasker.core.Tasker;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.bukkit.entity.HumanEntity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class UserManager {

    private final DreamLogger dreamLogger;
    private final PluginConfig pluginConfig;
    private final UserRepository userRepository;
    private final Tasker tasker;

    private final Map<UUID, User> userMap = new HashMap<>();

    /**
     * Import from database all users into cached user-map.
     */
    public void readUsers() {
        final long startTime = System.currentTimeMillis();

        this.tasker.newChain()
                .supplyAsync(this.userRepository::findAll)
                .acceptAsync(users -> {
                    this.userMap.clear();
                    users.forEach(user -> this.userMap.put(user.getUniqueId(), user));

                    final long endTime = System.currentTimeMillis();
                    this.dreamLogger.debug(new DreamLogger.Builder()
                            .type("Read database")
                            .name("users")
                            .meta("size", this.userMap.size())
                            .meta("time", TimeUtil.format(endTime - startTime))
                            .build());
                })
                .execute();
    }

    public void saveUsers() {
        this.getUserList().forEach(Document::save);
    }

    public void saveUser(@NonNull User user) {
        final long start = System.currentTimeMillis();
        this.tasker.newSharedChain("dbops:" + user.getUniqueId())
                .async(user::save)
                .sync(() -> {
                    if(this.pluginConfig.debug) {
                        this.dreamLogger.debug(new DreamLogger.Builder()
                                .type("Save document")
                                .name("User")
                                .meta("uuid", user.getUniqueId().toString())
                                .meta("name", user.getName())
                                .meta("time", TimeUtil.format(System.currentTimeMillis() - start))
                                .build());
                    }
                })
                .execute();
    }

    public List<User> getUserList() {
        return new ArrayList<>(this.userMap.values());
    }

    public Optional<User> getUserByUuid(@NonNull UUID uuid) {
        return Optional.ofNullable(this.userMap.get(uuid));
    }

    public Optional<User> getUserByName(@NonNull String name, boolean ignoreCase) {
        return this.userMap.values()
                .stream()
                .filter(user -> ignoreCase
                        ? user.getName().equalsIgnoreCase(name)
                        : user.getName().equals(name))
                .findAny();
    }

    public Optional<User> getUserByName(@NonNull String name) {
        return this.getUserByName(name, false);
    }

    public User getUserByPlayer(@NonNull HumanEntity entity) {
        final Optional<User> optionalUser = this.getUserByUuid(entity.getUniqueId());
        if (optionalUser.isPresent()) {
            return optionalUser.get();
        }

        this.createUser(entity);
        return this.getUserByPlayer(entity);
    }

    public Optional<User> getOptionalUserByPlayer(@NonNull HumanEntity entity) {
        return this.getUserByUuid(entity.getUniqueId());
    }

    public void createUser(@NonNull HumanEntity entity) {
        this.createUser(entity.getUniqueId(), entity.getName());
    }

    public void createUser(@NonNull UUID uuid, @NonNull String name) {
        if (this.userMap.containsKey(uuid)) {
            return;
        }

        // shared-chain with dbops key is queue for reading and writing document into database (async)
        this.tasker.newSharedChain("dbops:" + uuid)
                .supplyAsync(() -> this.userRepository.findOrCreate(uuid, name))
                .acceptSync(user -> {
                    user.setName(name);
                    this.userMap.put(user.getUniqueId(), user);

                    if (this.pluginConfig.debug) {
                        this.dreamLogger.debug(new DreamLogger.Builder()
                                .type("Create document")
                                .name("User")
                                .meta("uuid", user.getUniqueId().toString())
                                .meta("name", user.getName())
                                .build());
                    }
                })
                .execute();
    }
}