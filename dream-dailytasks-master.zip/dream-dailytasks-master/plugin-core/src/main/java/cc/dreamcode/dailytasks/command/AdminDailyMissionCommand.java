package cc.dreamcode.dailytasks.command;

import cc.dreamcode.command.CommandBase;
import cc.dreamcode.command.annotation.Arg;
import cc.dreamcode.command.annotation.Async;
import cc.dreamcode.command.annotation.Command;
import cc.dreamcode.command.annotation.Completion;
import cc.dreamcode.command.annotation.Executor;
import cc.dreamcode.command.annotation.Permission;
import cc.dreamcode.dailytasks.config.MessageConfig;
import cc.dreamcode.dailytasks.config.PluginConfig;
import cc.dreamcode.dailytasks.mission.MissionService;
import cc.dreamcode.dailytasks.user.User;
import cc.dreamcode.dailytasks.user.UserManager;
import cc.dreamcode.notice.adventure.BukkitNotice;
import cc.dreamcode.utilities.TimeUtil;
import cc.dreamcode.utilities.builder.MapBuilder;
import eu.okaeri.configs.exception.OkaeriException;
import eu.okaeri.injector.annotation.Inject;
import lombok.RequiredArgsConstructor;

import java.util.Optional;

@Command(name = "adailymissions", aliases = "adailymission")
@RequiredArgsConstructor(onConstructor_ = @Inject)
public class AdminDailyMissionCommand implements CommandBase {

    private final PluginConfig pluginConfig;
    private final MessageConfig messageConfig;
    private final UserManager userManager;
    private final MissionService missionService;

    @Permission("dream-dailytasks.reset")
    @Completion(arg = "name", value = "@offlineplayers")
    @Executor(path = "reset", description = "Resetuje codzinene misje.")
    BukkitNotice reset(@Arg String name) {

        final Optional<User> optionalUser = this.userManager.getUserByName(name);

        if (!optionalUser.isPresent()) {
            return this.messageConfig.userNotFound;
        }

        final User user = optionalUser.get();
        this.missionService.resetMission(user);

        return this.messageConfig.userMissionProgressReset.with(new MapBuilder<String, Object>()
                .put("user", user.getName())
                .build());
    }

    @Async
    @Permission("dream-dailytasks.reload")
    @Executor(path = "reload", description = "Przeladowuje konfiguracje.")
    BukkitNotice reload() {
        final long time = System.currentTimeMillis();

        try {
            this.messageConfig.load();
            this.pluginConfig.load();

            return this.messageConfig.reloaded
                    .with("time", TimeUtil.format(System.currentTimeMillis() - time));
        }
        catch (NullPointerException | OkaeriException e) {
            e.printStackTrace();

            return this.messageConfig.reloadError
                    .with("error", e.getMessage());
        }
    }
}
