rootProject.name = "dream-dailytasks"

include(":plugin-core")