package cc.dreamcode.tiktok;

import cc.dreamcode.command.bukkit.BukkitCommandProvider;
import cc.dreamcode.notice.adventure.BukkitNoticeProvider;
import cc.dreamcode.notice.adventure.serializer.BukkitNoticeSerializer;
import cc.dreamcode.platform.DreamVersion;
import cc.dreamcode.platform.bukkit.DreamBukkitConfig;
import cc.dreamcode.platform.bukkit.DreamBukkitPlatform;
import cc.dreamcode.platform.bukkit.component.ConfigurationResolver;
import cc.dreamcode.platform.component.ComponentService;
import cc.dreamcode.platform.other.component.DreamCommandExtension;
import cc.dreamcode.tiktok.command.TiktokCommand;
import cc.dreamcode.tiktok.command.handler.InvalidInputHandlerImpl;
import cc.dreamcode.tiktok.command.handler.InvalidPermissionHandlerImpl;
import cc.dreamcode.tiktok.command.handler.InvalidSenderHandlerImpl;
import cc.dreamcode.tiktok.command.handler.InvalidUsageHandlerImpl;
import cc.dreamcode.tiktok.command.result.BukkitNoticeResolver;
import cc.dreamcode.tiktok.config.MessageConfig;
import cc.dreamcode.tiktok.config.PluginConfig;
import eu.okaeri.configs.serdes.OkaeriSerdesPack;
import eu.okaeri.tasker.bukkit.BukkitTasker;
import lombok.Getter;
import lombok.NonNull;

public final class TikTokPlugin extends DreamBukkitPlatform implements DreamBukkitConfig {

    @Getter private static TikTokPlugin tikTokPlugin;

    @Override
    public void load(@NonNull ComponentService componentService) {
        tikTokPlugin = this;
    }

    @Override
    public void enable(@NonNull ComponentService componentService) {
        componentService.setDebug(false);

        this.registerInjectable(BukkitTasker.newPool(this));
        this.registerInjectable(BukkitNoticeProvider.create(this));

        this.registerInjectable(BukkitCommandProvider.create(this));
        componentService.registerExtension(DreamCommandExtension.class);

        componentService.registerResolver(ConfigurationResolver.class);
        componentService.registerComponent(MessageConfig.class);

        componentService.registerComponent(BukkitNoticeResolver.class);
        componentService.registerComponent(InvalidInputHandlerImpl.class);
        componentService.registerComponent(InvalidPermissionHandlerImpl.class);
        componentService.registerComponent(InvalidSenderHandlerImpl.class);
        componentService.registerComponent(InvalidUsageHandlerImpl.class);

        componentService.registerComponent(PluginConfig.class, pluginConfig ->
                componentService.setDebug(pluginConfig.debug));

        componentService.registerComponent(HeartService.class);
        componentService.registerComponent(TikTokService.class);

        componentService.registerComponent(TikTokController.class);
        componentService.registerComponent(TiktokCommand.class);
    }

    @Override
    public void disable() {
        // features need to be call when server is stopping
    }

    @Override
    public @NonNull DreamVersion getDreamVersion() {
        return DreamVersion.create("Dream-TikTok", "1.1.5", "Ravis96");
    }

    @Override
    public @NonNull OkaeriSerdesPack getConfigSerdesPack() {
        return registry -> {
            registry.register(new BukkitNoticeSerializer());
        };
    }

    public void debug(@NonNull String message) {
        if (this.getComponentService().isDebug()) {
            this.getDreamLogger().debug(message);
        }
    }
}
