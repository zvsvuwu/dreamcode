package cc.dreamcode.tiktok;

import cc.dreamcode.tiktok.config.PluginConfig;
import eu.okaeri.injector.annotation.Inject;
import io.github.jwdeveloper.tiktok.TikTokLive;
import io.github.jwdeveloper.tiktok.live.LiveClient;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.util.concurrent.atomic.AtomicInteger;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class TikTokService {

    private final TikTokPlugin tikTokPlugin;
    private final PluginConfig pluginConfig;

    private LiveClient liveClient;

    @Getter private final AtomicInteger deaths = new AtomicInteger();

    public void connect() {
        if (this.liveClient != null) {
            this.disconnect();
        }

        this.liveClient = TikTokLive.newClient(this.pluginConfig.tiktokHost)
                .onGift(this.tikTokPlugin.createInstance(TikTokGiftController.class))
                .onComment(this.tikTokPlugin.createInstance(TikTokChatController.class))
                .onLike(this.tikTokPlugin.createInstance(TikTokLikeController.class))
                .onFollow(this.tikTokPlugin.createInstance(TikTokFollowController.class))
                .buildAndConnect();
    }

    public void disconnect() {
        if (this.liveClient == null) {
            return;
        }

        this.liveClient.disconnect();
        this.liveClient = null;
    }

    public LiveClient getLiveClient() {
        if (this.liveClient == null) {
            this.connect();
        }

        return this.liveClient;
    }
}
