package cc.dreamcode.tiktok;

import cc.dreamcode.tiktok.config.PluginConfig;
import cc.dreamcode.utilities.builder.MapBuilder;
import cc.dreamcode.utilities.bukkit.StringColorUtil;
import eu.okaeri.injector.annotation.Inject;
import eu.okaeri.tasker.core.Tasker;
import io.github.jwdeveloper.tiktok.data.events.TikTokCommentEvent;
import io.github.jwdeveloper.tiktok.live.LiveClient;
import io.github.jwdeveloper.tiktok.live.builder.EventConsumer;
import lombok.RequiredArgsConstructor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Ageable;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class TikTokChatController implements EventConsumer<TikTokCommentEvent> {

    private final TikTokPlugin tikTokPlugin;
    private final PluginConfig pluginConfig;
    private final Tasker tasker;

    @Override
    public void onEvent(LiveClient liveClient, TikTokCommentEvent event) {

        final String profileName = event.getUser().getProfileName().equalsIgnoreCase(event.getUser().getName())
                ? event.getUser().getName()
                : event.getUser().getName() + " (" + event.getUser().getProfileName() + ")";

        this.tikTokPlugin.getServer().getScheduler().runTask(this.tikTokPlugin, () -> {

            final Player player = this.tikTokPlugin.getServer().getPlayerExact(this.pluginConfig.playerName);
            if (player == null) {
                return;
            }

            this.pluginConfig.chatMessage.send(player, new MapBuilder<String, Object>()
                    .put("nick", profileName)
                    .put("text", event.getText())
                    .build());

            if (!this.pluginConfig.entityChatSpawn) {
                return;
            }

            player.playSound(player.getLocation(), this.pluginConfig.commentSound, 1.0F, 1.0F);

            Location frontLocation = player.getEyeLocation().add(player.getLocation().getDirection().multiply(3));
            if (!frontLocation.getBlock().getType().equals(Material.AIR)) {
                frontLocation = player.getLocation();
            }

            Entity entity = player.getWorld().spawnEntity(frontLocation, this.pluginConfig.entityChatType);
            entity.setCustomName(StringColorUtil.fixColor(this.pluginConfig.entityChatTextFormat, new MapBuilder<String, Object>()
                    .put("nick", profileName)
                    .put("text", event.getText())
                    .build()));
            entity.setCustomNameVisible(true);

            this.tasker.newDelayer(this.pluginConfig.entityDuration)
                    .delayed(entity::remove)
                    .executeSync();

            if (this.pluginConfig.entityChatBaby) {
                if (!(entity instanceof Ageable ageable)) {
                    return;
                }

                ageable.setBaby();
            }
        });
    }
}
