package cc.dreamcode.tiktok.command;

import cc.dreamcode.command.CommandBase;
import cc.dreamcode.command.annotation.Async;
import cc.dreamcode.command.annotation.Command;
import cc.dreamcode.command.annotation.Executor;
import cc.dreamcode.command.annotation.Permission;
import cc.dreamcode.notice.adventure.BukkitNotice;
import cc.dreamcode.tiktok.TikTokService;
import cc.dreamcode.tiktok.config.MessageConfig;
import cc.dreamcode.tiktok.config.PluginConfig;
import cc.dreamcode.utilities.TimeUtil;
import cc.dreamcode.utilities.builder.MapBuilder;
import eu.okaeri.configs.exception.OkaeriException;
import eu.okaeri.injector.annotation.Inject;
import lombok.RequiredArgsConstructor;
import org.bukkit.command.CommandSender;

@Command(name = "tiktok")
@RequiredArgsConstructor(onConstructor_ = @Inject)
public class TiktokCommand implements CommandBase {

    private final PluginConfig pluginConfig;
    private final MessageConfig messageConfig;
    private final TikTokService tikTokService;

    @Permission("dream-tiktok.connect")
    @Executor(path = "connect", description = "Podlacza plugin do live.")
    void connect(CommandSender sender) {
        this.tikTokService.connect();

        this.messageConfig.tiktokConnected.send(sender, new MapBuilder<String, Object>()
                .put("nick", this.pluginConfig.tiktokHost)
                .build());
    }

    @Permission("dream-tiktok.disconnect")
    @Executor(path = "disconnect", description = "Odlacza plugin od live.")
    void disconnect(CommandSender sender) {
        this.tikTokService.disconnect();

        this.messageConfig.tiktokDisconnected.send(sender, new MapBuilder<String, Object>()
                .put("nick", this.pluginConfig.tiktokHost)
                .build());
    }

    @Async
    @Permission("dream-tiktok.reload")
    @Executor(path = "reload", description = "Przeladowuje konfiguracje.")
    BukkitNotice reload() {
        final long time = System.currentTimeMillis();

        try {
            this.messageConfig.load();
            this.pluginConfig.load();

            return this.messageConfig.reloaded
                    .with("time", TimeUtil.format(System.currentTimeMillis() - time));
        }
        catch (NullPointerException | OkaeriException e) {
            e.printStackTrace();

            return this.messageConfig.reloadError
                    .with("error", e.getMessage());
        }
    }
}
