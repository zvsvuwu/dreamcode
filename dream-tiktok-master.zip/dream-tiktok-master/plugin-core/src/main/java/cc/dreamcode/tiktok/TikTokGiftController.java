package cc.dreamcode.tiktok;

import cc.dreamcode.notice.adventure.BukkitNotice;
import cc.dreamcode.tiktok.config.PluginConfig;
import cc.dreamcode.utilities.MathUtil;
import cc.dreamcode.utilities.StringUtil;
import cc.dreamcode.utilities.TicksUtil;
import cc.dreamcode.utilities.builder.MapBuilder;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import com.google.common.util.concurrent.AtomicDouble;
import eu.okaeri.injector.annotation.Inject;
import eu.okaeri.tasker.core.Tasker;
import io.github.jwdeveloper.tiktok.data.events.gift.TikTokGiftEvent;
import io.github.jwdeveloper.tiktok.live.LiveClient;
import io.github.jwdeveloper.tiktok.live.builder.EventConsumer;
import lombok.RequiredArgsConstructor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;

import java.util.Map;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class TikTokGiftController implements EventConsumer<TikTokGiftEvent> {

    private final TikTokPlugin tikTokPlugin;
    private final PluginConfig pluginConfig;
    private final HeartService heartService;
    private final Tasker tasker;

    @Override
    public void onEvent(LiveClient liveClient, TikTokGiftEvent event) {

        this.tikTokPlugin.getServer().getScheduler().runTask(this.tikTokPlugin, () -> {
            final String profileName = event.getUser().getProfileName().equalsIgnoreCase(event.getUser().getName())
                    ? event.getUser().getName()
                    : event.getUser().getName() + " (" + event.getUser().getProfileName() + ")";
            this.tikTokPlugin.debug(profileName + " gifted " + event.getGift().getName() + "(ID:" + event.getGift().getId() + ") (combo:" + event.getCombo() + "x)");

            final int giftId = event.getGift().getId();
            final Optional<BukkitNotice> optionalNotice = this.pluginConfig.giftNoticeMap
                    .entrySet()
                    .stream()
                    .filter(entry -> entry.getKey().equals(giftId))
                    .map(Map.Entry::getValue)
                    .findAny();

            final Player player = this.tikTokPlugin.getServer().getPlayerExact(this.pluginConfig.playerName);
            if (player == null) {
                return;
            }

            this.pluginConfig.giftCommandMap.entrySet()
                    .stream()
                    .filter(entry -> entry.getKey().equals(giftId))
                    .map(Map.Entry::getValue)
                    .findAny()
                    .ifPresent(texts -> texts.forEach(text ->
                        this.tikTokPlugin.getServer().dispatchCommand(
                                this.tikTokPlugin.getServer().getConsoleSender(),
                                StringUtil.replace(text, "name", player.getName())
                        )));

            final AtomicInteger tntAmount = new AtomicInteger();
            this.pluginConfig.giftTntMap.entrySet()
                    .stream()
                    .filter(entry -> entry.getKey().equals(giftId))
                    .map(Map.Entry::getValue)
                    .findAny()
                    .ifPresent(amount -> {
                        int finalAmount = amount * event.getCombo();
                        tntAmount.set(finalAmount);

                        for (int index = 0; index < finalAmount; index++) {
                            this.tikTokPlugin.getServer().getScheduler().runTaskLater(
                                    this.tikTokPlugin,
                                    () -> {
                                        player.playSound(player.getLocation(), this.pluginConfig.giftSound, 1.0F, 1.0F);

                                        TNTPrimed tntPrimed = (TNTPrimed) player.getWorld().spawnEntity(
                                                player.getLocation().add(0.0D, 0.5D, 0.0D), EntityType.PRIMED_TNT);
                                        tntPrimed.setFuseTicks(TicksUtil.ticksOf(this.pluginConfig.tntFuseDuration));
                                    },
                                    index
                            );
                        }
                    });

            final AtomicInteger mobAmount = new AtomicInteger();
            this.pluginConfig.giftMobsMap.entrySet()
                    .stream()
                    .filter(entry -> entry.getKey().equals(giftId))
                    .map(Map.Entry::getValue)
                    .findAny()
                    .ifPresent(entityMap -> entityMap.forEach((entityType, amount) -> {
                        int finalAmount = amount * event.getCombo();
                        mobAmount.set(finalAmount);

                        for (int index = 0; index < finalAmount; index++) {
                            this.tikTokPlugin.getServer().getScheduler().runTaskLater(
                                    this.tikTokPlugin,
                                    () -> {

                                        Location frontLocation = player.getEyeLocation().add(player.getLocation().getDirection());
                                        if (!frontLocation.getBlock().getType().equals(Material.AIR)) {
                                            frontLocation = player.getLocation();
                                        }

                                        player.playSound(player.getLocation(), this.pluginConfig.giftSound, 1.0F, 1.0F);
                                        Entity entity = player.getWorld().spawnEntity(frontLocation, entityType);

                                        this.tasker.newDelayer(this.pluginConfig.mobDuration)
                                                .delayed(entity::remove)
                                                .executeSync();
                                    },
                                    index
                            );
                        }
                    }));

            final AtomicInteger heartAmount = new AtomicInteger();
            this.pluginConfig.giftHeartMap.entrySet()
                    .stream()
                    .filter(entry -> entry.getKey().equals(giftId))
                    .map(Map.Entry::getValue)
                    .findAny()
                    .ifPresent(amount -> {
                        int finalAmount = amount * event.getCombo();
                        heartAmount.set(finalAmount);

                        int heartModify = this.heartService.getPlayerHeart(player) + finalAmount;
                        this.heartService.setPlayerHeart(player, heartModify);
                    });

            final AtomicInteger itemAmount = new AtomicInteger();
            this.pluginConfig.giftItemsMap.entrySet()
                    .stream()
                    .filter(entry -> entry.getKey().equals(giftId))
                    .map(Map.Entry::getValue)
                    .findAny()
                    .ifPresent(items -> {
                        itemAmount.set(event.getCombo());

                        items.forEach(item -> player.getInventory().addItem(ItemBuilder.of(item).setAmount(item.getAmount() * event.getCombo()).fixColors().toItemStack())
                                .forEach((i, itemDrop) -> player.getWorld().dropItem(player.getLocation(), itemDrop)));
                    });

            this.pluginConfig.giftWaterSkill
                    .stream()
                    .filter(id -> id.equals(giftId))
                    .findAny()
                    .ifPresent(id -> player.teleport(player.getLocation().add(0.0D, this.pluginConfig.waterSkillHeight, 0.0D)));

            this.pluginConfig.giftEnd
                    .stream()
                    .filter(id -> id.equals(giftId))
                    .findAny()
                    .ifPresent(id -> {

                        World world = this.tikTokPlugin.getServer().getWorlds()
                                .stream()
                                .filter(scan -> scan.getName().contains("end"))
                                .findAny()
                                .orElseThrow(() -> new RuntimeException("Cannot find end world."));
                        Location location = world.getSpawnLocation();

                        player.teleport(location);
                    });

            this.pluginConfig.giftResetInventory
                    .stream()
                    .filter(id -> id.equals(giftId))
                    .findAny()
                    .ifPresent(id -> player.getInventory().clear());

            final AtomicDouble damageAmount = new AtomicDouble();
            this.pluginConfig.giftDamageMap.entrySet()
                    .stream()
                    .filter(entry -> entry.getKey().equals(giftId))
                    .map(Map.Entry::getValue)
                    .findAny()
                    .ifPresent(amount -> {
                        double finalAmount = amount * event.getCombo();
                        damageAmount.set(finalAmount);

                        player.damage(finalAmount);
                    });

            this.pluginConfig.giftDaySet
                    .stream()
                    .filter(id -> id.equals(giftId))
                    .findAny()
                    .ifPresent(id -> player.getWorld().setTime(0L));

            this.pluginConfig.giftNightSet
                    .stream()
                    .filter(id -> id.equals(giftId))
                    .findAny()
                    .ifPresent(id -> player.getWorld().setTime(12000L));

            this.pluginConfig.giftWeatherSet
                    .stream()
                    .filter(id -> id.equals(giftId))
                    .findAny()
                    .ifPresent(id -> player.getWorld().setStorm(true));

            this.pluginConfig.giftWeatherClear
                    .stream()
                    .filter(id -> id.equals(giftId))
                    .findAny()
                    .ifPresent(id -> player.getWorld().setStorm(false));

            if (optionalNotice.isEmpty()) {
                return;
            }

            final BukkitNotice adventurePaperNotice = optionalNotice.get();
            adventurePaperNotice.send(player, new MapBuilder<String, Object>()
                    .put("nick", event.getUser().getName())
                    .put("combo", event.getCombo())
                    .put("tnt-amount", tntAmount.get())
                    .put("mob-amount", mobAmount.get())
                    .put("heart-amount", heartAmount.get())
                    .put("item-amount", itemAmount.get())
                    .put("damage-amount", MathUtil.round(damageAmount.get(), 2))
                    .build());
        });
    }
}
