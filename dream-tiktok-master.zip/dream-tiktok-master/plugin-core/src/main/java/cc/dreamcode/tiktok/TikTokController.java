package cc.dreamcode.tiktok;

import cc.dreamcode.tiktok.config.MessageConfig;
import cc.dreamcode.tiktok.config.PluginConfig;
import cc.dreamcode.utilities.RandomUtil;
import cc.dreamcode.utilities.builder.MapBuilder;
import cc.dreamcode.utilities.bukkit.StringColorUtil;
import eu.okaeri.injector.annotation.Inject;
import lombok.RequiredArgsConstructor;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.event.player.PlayerRespawnEvent;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class TikTokController implements Listener {

    private final TikTokPlugin tikTokPlugin;
    private final PluginConfig pluginConfig;
    private final MessageConfig messageConfig;
    private final TikTokService tikTokService;

    @EventHandler
    public void onPlayerLogin(PlayerLoginEvent e) {
        final Player player = e.getPlayer();

        if (this.pluginConfig.kickOtherPlayers) {
            if (this.pluginConfig.playerName.equals(player.getName())) {
                return;
            }

            e.disallow(PlayerLoginEvent.Result.KICK_WHITELIST, StringColorUtil.fixColor(this.pluginConfig.kickMessage));
        }
    }

    @EventHandler
    public void onPlayerRespawn(PlayerRespawnEvent e) {

        if (!this.pluginConfig.respawnRandomLocation) {
            return;
        }

        final Player player = e.getPlayer();
        this.messageConfig.respawnNotice.send(player, MapBuilder.of("death", this.tikTokService.getDeaths().incrementAndGet()));

        final int newX = RandomUtil.nextInteger(this.pluginConfig.minCord, this.pluginConfig.maxCord);
        final int newZ = RandomUtil.nextInteger(this.pluginConfig.minCord, this.pluginConfig.maxCord);
        final int newY = player.getWorld().getHighestBlockYAt(newX, newZ);

        final Location newLocation = new Location(player.getWorld(), newX, newY, newZ);
        this.tikTokPlugin.getServer().getScheduler().runTaskLater(this.tikTokPlugin, () -> player.teleport(newLocation), 1L);
    }
}
