package cc.dreamcode.tiktok;

import cc.dreamcode.tiktok.config.PluginConfig;
import eu.okaeri.injector.annotation.Inject;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.entity.Player;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class HeartService {

    private final PluginConfig pluginConfig;

    public int getPlayerHeart(@NonNull Player player) {

        AttributeInstance attributeInstance = player.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        if (attributeInstance == null) {
            throw new RuntimeException("Cannot resolve player hearts.");
        }

        if (this.pluginConfig.splitHeart){
            return (int) (attributeInstance.getBaseValue() / 2);
        }

        return (int) (attributeInstance.getBaseValue());
    }

    public void setPlayerHeart(@NonNull Player player, int amount) {
        AttributeInstance attributeInstance = player.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        if (attributeInstance == null) {
            return;
        }

        if (this.pluginConfig.splitHeart) {
            if (amount <= 2) {
                attributeInstance.setBaseValue(2);
                return;
            }

            attributeInstance.setBaseValue(amount * 2);
            return;
        }

        if (amount <= 1) {
            attributeInstance.setBaseValue(1);
            return;
        }

        attributeInstance.setBaseValue(amount);
    }
}
