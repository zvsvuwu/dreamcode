package cc.dreamcode.tiktok.config;

import cc.dreamcode.notice.adventure.BukkitNotice;
import cc.dreamcode.platform.bukkit.component.configuration.Configuration;
import cc.dreamcode.utilities.builder.ListBuilder;
import cc.dreamcode.utilities.builder.MapBuilder;
import eu.okaeri.configs.OkaeriConfig;
import eu.okaeri.configs.annotation.Comment;
import eu.okaeri.configs.annotation.CustomKey;
import eu.okaeri.configs.annotation.Header;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.EntityType;
import org.bukkit.inventory.ItemStack;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Configuration(
        child = "config.yml"
)
@Header("## Dream-TikTok (Main-Config) ##")
@Header("# Zalecam nie sugerowac sie lista ID na stronie, gdyz wyswietla ona nieprawdziwe id.")
@Header("# Prawdziwe ID poznacie po wyslaniu gifta i wyswietleniu go przez debug!")
public class PluginConfig extends OkaeriConfig {

    @Comment("Debug pokazuje dodatkowe informacje do konsoli. Lepiej wylaczyc. :P")
    @CustomKey("debug")
    public boolean debug = true;

    @Comment
    @Comment("Czy plugin ma blokowac innych graczy na serwerze niz ten podany?")
    @CustomKey("kick-other-players")
    public boolean kickOtherPlayers = true;

    @Comment
    @Comment("Jaka wiadomosc ma wyslac, gdy inny gracz probuje wejsc na serwer?")
    @CustomKey("kick-message")
    public String kickMessage = "&cNa ten serwer moze wejsc tylko owner.";

    @Comment
    @Comment("Podaj nazwe hosta:")
    @CustomKey("tiktok-host")
    public String tiktokHost = "";

    @Comment
    @Comment("Jak gracz bedzie sie nazywac?")
    @Comment("Ten gracz bedzie otrzymywal wszystkie alerty:")
    @CustomKey("player-name")
    public String playerName = "";

    @Comment
    @Comment("Jaki dzwiek ma byc puszczony na znak gifta?")
    @CustomKey("gift-sound")
    public Sound giftSound = Sound.ENTITY_EXPERIENCE_ORB_PICKUP;

    @Comment
    @Comment("Jaki dzwiek ma byc puszczony na znak comment?")
    @CustomKey("comment-sound")
    public Sound commentSound = Sound.ENTITY_EXPERIENCE_ORB_PICKUP;

    @Comment
    @Comment("Jaki dzwiek ma byc puszczony na znak dobitych like?")
    @CustomKey("like-sound")
    public Sound likeSound = Sound.ENTITY_EXPERIENCE_ORB_PICKUP;

    @Comment
    @Comment("Jaki dzwiek ma byc puszczony na znak dobitych follow?")
    @CustomKey("follow-sound")
    public Sound followSound = Sound.ENTITY_EXPERIENCE_ORB_PICKUP;

    @Comment
    @Comment("Czy serca maja byc dzielone przez polowki?")
    @CustomKey("split-sound")
    public boolean splitHeart = true;

    @Comment
    @Comment("Jakie komendy ma wysylac, gdy przyjdzie gift?")
    @Comment("Placeholdery: ({name})")
    @Comment("Lista ID: https://streamdps.com/tiktok-widgets/gifts/")
    @CustomKey("gift-command-map")
    public Map<Integer, List<String>> giftCommandMap = new MapBuilder<Integer, List<String>>()
            .put(5655, ListBuilder.of("/time set day"))
            .build();

    @Comment
    @Comment("Jakie wiadomosci ma wysylac, gdy przyjdzie gift?")
    @Comment("Lista ID: https://streamdps.com/tiktok-widgets/gifts/")
    @CustomKey("gift-notice-map")
    public Map<Integer, BukkitNotice> giftNoticeMap = new MapBuilder<Integer, BukkitNotice>()
            .put(5655, BukkitNotice.subtitle("&c&l{nick} &fSend &e{tnt-amount} TNT"))
            .build();

    @Comment
    @Comment("Jakie ID ma stawiac tnt pod siebie?")
    @Comment("Lista ID: https://streamdps.com/tiktok-widgets/gifts/")
    @CustomKey("gift-tnt-map")
    public Map<Integer, Integer> giftTntMap = new MapBuilder<Integer, Integer>()
            .put(5655, 1)
            .build();

    @Comment
    @Comment("Jakie ID ma stawiac moba w lokalizacji gracza?")
    @Comment("Lista ID: https://streamdps.com/tiktok-widgets/gifts/")
    @CustomKey("gift-mobs-map")
    public Map<Integer, Map<EntityType, Integer>> giftMobsMap = new MapBuilder<Integer, Map<EntityType, Integer>>()
            .put(5655, MapBuilder.of(EntityType.ZOMBIE, 1))
            .build();

    @Comment
    @Comment("Jakie ID ma dodawac/odejmowac serca gracza?")
    @Comment("Lista ID: https://streamdps.com/tiktok-widgets/gifts/")
    @CustomKey("gift-heart-map")
    public Map<Integer, Integer> giftHeartMap = new MapBuilder<Integer, Integer>()
            .put(5655, 1)
            .put(5657, -1)
            .build();

    @Comment
    @Comment("Jakie ID ma nadawac graczowi itemy?")
    @Comment("Lista ID: https://streamdps.com/tiktok-widgets/gifts/")
    @CustomKey("gift-items-map")
    public Map<Integer, List<ItemStack>> giftItemsMap = new MapBuilder<Integer, List<ItemStack>>()
            .put(5655, ListBuilder.of(new ItemStack(Material.DIAMOND)))
            .build();

    @Comment
    @Comment("Jakie ID ma teleportowac gracza do water skilla?")
    @Comment("Lista ID: https://streamdps.com/tiktok-widgets/gifts/")
    @CustomKey("gift-water-skill")
    public List<Integer> giftWaterSkill = ListBuilder.of(23423);

    @Comment
    @Comment("Ile graczowi ma dodawac kratek do gory, gdy robi water skilla?")
    @CustomKey("water-skill-height")
    public double waterSkillHeight = 100;

    @Comment
    @Comment("Jakie ID ma teleportowac gracza do endu?")
    @Comment("Lista ID: https://streamdps.com/tiktok-widgets/gifts/")
    @CustomKey("gift-teleport-end")
    public List<Integer> giftEnd = ListBuilder.of(23423);

    @Comment
    @Comment("Jakie ID ma resetowac graczowi eq?")
    @Comment("Lista ID: https://streamdps.com/tiktok-widgets/gifts/")
    @CustomKey("gift-reset-inventory")
    public List<Integer> giftResetInventory = ListBuilder.of(23423);

    @Comment
    @Comment("Jakie ID ma zadawac damage graczowi (lub zabijac)?")
    @Comment("Lista ID: https://streamdps.com/tiktok-widgets/gifts/")
    @CustomKey("gift-damage-map")
    public Map<Integer, Double> giftDamageMap = MapBuilder.of(23423, 999.9D);

    @Comment
    @Comment("Jakie ID ma nadawac dzien?")
    @Comment("Lista ID: https://streamdps.com/tiktok-widgets/gifts/")
    @CustomKey("gift-day-set")
    public List<Integer> giftDaySet = ListBuilder.of(23423);

    @Comment
    @Comment("Jakie ID ma nadawac noc?")
    @Comment("Lista ID: https://streamdps.com/tiktok-widgets/gifts/")
    @CustomKey("gift-night-set")
    public List<Integer> giftNightSet = ListBuilder.of(23423);

    @Comment
    @Comment("Jakie ID ma nadawac wyczyszczenie deszczu?")
    @Comment("Lista ID: https://streamdps.com/tiktok-widgets/gifts/")
    @CustomKey("gift-weather-set")
    public List<Integer> giftWeatherSet = ListBuilder.of(23423);

    @Comment
    @Comment("Jakie ID ma nadawac deszcz na swiecie?")
    @Comment("Lista ID: https://streamdps.com/tiktok-widgets/gifts/")
    @CustomKey("gift-weather-clear")
    public List<Integer> giftWeatherClear = ListBuilder.of(23423);

    @Comment
    @Comment("Po jakim czasie tnt ma wybuchac?")
    @CustomKey("tnt-fuse-duration")
    public Duration tntFuseDuration = Duration.ofSeconds(3L);

    @Comment
    @Comment("Po jakim czasie ma usuwac moby?")
    @CustomKey("mob-duration")
    public Duration mobDuration = Duration.ofMinutes(2L);

    @Comment
    @Comment("Jaka wiadomosc ma wyslac plugin, gdy ktos napisze na chat?")
    @CustomKey("tiktok-chat-message")
    public BukkitNotice chatMessage = BukkitNotice.chat("&c{nick} wyslal: &7{text}");

    @Comment
    @Comment("Czy entity ma sie respic, gdy ktos napisze cos na chat?")
    @CustomKey("entity-chat-spawn")
    public boolean entityChatSpawn = true;

    @Comment
    @Comment("Jakie entity ma sie respic, gdy ktos napisze cos na chat?")
    @CustomKey("entity-chat-type")
    public EntityType entityChatType = EntityType.SHEEP;

    @Comment
    @Comment("Czy entity ma byc zmieniane do dzieciecej postaci?")
    @CustomKey("entity-chat-baby")
    public boolean entityChatBaby = true;

    @Comment
    @Comment("Format nametaga, gdy ktos wysle cos na chat:")
    @CustomKey("entity-chat-text-format")
    public String entityChatTextFormat = "&e{text}";

    @Comment
    @Comment("Po jakim czasie ma usuwac chat-entity?")
    @CustomKey("entity-duration")
    public Duration entityDuration = Duration.ofSeconds(10L);

    @Comment
    @Comment("Czy gracz ma sie respic randomowo?")
    @CustomKey("respawn-random-location")
    public boolean respawnRandomLocation = true;

    @Comment
    @Comment("W jakim zakresie ma sie respic gracz?")
    @CustomKey("respawn-min-cord")
    public int minCord = -2000;
    @CustomKey("repsawn-max-cord")
    public int maxCord = 2000;

    @Comment
    @Comment("Czy plugin ma liczyc like?")
    @CustomKey("count-like")
    public boolean countLike = true;

    @Comment
    @Comment("Ile like ma byc nabije, aby odblokowac opcje ponizej?")
    @CustomKey("required-likes")
    public int requiredLikes = 40;

    @Comment
    @Comment("Ile tnt ma byc zrespione, gdy gracz nabije like?")
    @CustomKey("like-spawn-tnt")
    public int likeSpawnTnt = 0;

    @Comment
    @Comment("Jakie moby maja byc zrespione, gdy gracz nabije like?")
    @CustomKey("like-spawn-mobs")
    public Map<EntityType, Integer> likeSpawnMobs = new MapBuilder<EntityType, Integer>()
            .put(EntityType.COW, 1)
            .build();

    @Comment
    @Comment("Ile serc ma byc dodane/odjete, gdy gracz nabije like?")
    @CustomKey("like-spawn-heart")
    public int likeSpawnHeart = 0;

    @Comment
    @Comment("Jakie itemy ma dostac gracz, gdy gracz nabije like?")
    @CustomKey("like-spawn-items")
    public List<ItemStack> likeSpawnItems = new ArrayList<>();

    @Comment
    @Comment("Czy plugin ma liczyc obserwacje?")
    @CustomKey("count-follow")
    public boolean countFollow = true;

    @Comment
    @Comment("Jaka komenda ma byc wpisana, gdy gracz zaobserwuje?")
    @Comment("Placeholdery: ({name})")
    @CustomKey("follow-commands")
    public List<String> followCommands = ListBuilder.of("give {name} diamond");

    @Comment
    @Comment("Jakie itemy ma dostac gracz, gdy gracz zaobserwuje?")
    @CustomKey("follow-items")
    public List<ItemStack> followItems = new ArrayList<>();

    @Comment
    @Comment("Ile tnt ma byc zrespione, gdy gracz zaobserwuje?")
    @CustomKey("follow-spawn-tnt")
    public int followSpawnTnt = 0;

    @Comment
    @Comment("Jakie moby maja byc zrespione, gdy gracz zaobserwuje?")
    @CustomKey("follow-spawn-mobs")
    public Map<EntityType, Integer> followSpawnMobs = new MapBuilder<EntityType, Integer>()
            .put(EntityType.COW, 1)
            .build();

    @Comment
    @Comment("Ile serc ma byc dodane/odjete, gdy gracz zaobserwuje?")
    @CustomKey("follow-spawn-heart")
    public int followSpawnHeart = 0;
}
