package cc.dreamcode.tiktok;

import cc.dreamcode.tiktok.config.MessageConfig;
import cc.dreamcode.tiktok.config.PluginConfig;
import cc.dreamcode.utilities.StringUtil;
import cc.dreamcode.utilities.TicksUtil;
import cc.dreamcode.utilities.builder.MapBuilder;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import eu.okaeri.injector.annotation.Inject;
import eu.okaeri.tasker.core.Tasker;
import io.github.jwdeveloper.tiktok.data.events.social.TikTokFollowEvent;
import io.github.jwdeveloper.tiktok.live.LiveClient;
import io.github.jwdeveloper.tiktok.live.builder.EventConsumer;
import lombok.RequiredArgsConstructor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class TikTokFollowController implements EventConsumer<TikTokFollowEvent> {

    private final TikTokPlugin tikTokPlugin;
    private final PluginConfig pluginConfig;
    private final MessageConfig messageConfig;
    private final HeartService heartService;
    private final Tasker tasker;

    @Override
    public void onEvent(LiveClient liveClient, TikTokFollowEvent event) {

        if (!this.pluginConfig.countFollow) {
            return;
        }

        this.tikTokPlugin.getServer().getScheduler().runTask(this.tikTokPlugin, () -> {

            final Player player = this.tikTokPlugin.getServer().getPlayerExact(this.pluginConfig.playerName);
            if (player == null) {
                return;
            }

            final String profileName = event.getUser().getProfileName().equalsIgnoreCase(event.getUser().getName())
                    ? event.getUser().getName()
                    : event.getUser().getName() + " (" + event.getUser().getProfileName() + ")";

            this.messageConfig.followNotice.send(player, new MapBuilder<String, Object>()
                    .put("nick", profileName)
                    .build());

            for (int tntIndex = 0; tntIndex < this.pluginConfig.followSpawnTnt; tntIndex++) {
                this.tikTokPlugin.getServer().getScheduler().runTaskLater(
                        this.tikTokPlugin,
                        () -> {
                            player.playSound(player.getLocation(), this.pluginConfig.followSound, 1.0F, 1.0F);

                            TNTPrimed tntPrimed = (TNTPrimed) player.getWorld().spawnEntity(
                                    player.getLocation().add(0.0D, 0.5D, 0.0D), EntityType.PRIMED_TNT);
                            tntPrimed.setFuseTicks(TicksUtil.ticksOf(this.pluginConfig.tntFuseDuration));
                        },
                        tntIndex
                );
            }

            this.pluginConfig.followSpawnMobs.forEach((entityType, amount) -> {
                for (int mobIndex = 0; mobIndex < amount; mobIndex++) {

                    this.tikTokPlugin.getServer().getScheduler().runTaskLater(
                            this.tikTokPlugin,
                            () -> {
                                Location frontLocation = player.getEyeLocation().add(player.getLocation().getDirection());
                                if (!frontLocation.getBlock().getType().equals(Material.AIR)) {
                                    frontLocation = player.getLocation();
                                }

                                player.playSound(player.getLocation(), this.pluginConfig.followSound, 1.0F, 1.0F);
                                Entity entity = player.getWorld().spawnEntity(frontLocation, entityType);

                                this.tasker.newDelayer(this.pluginConfig.mobDuration)
                                        .delayed(entity::remove)
                                        .executeSync();
                            },
                            mobIndex
                    );
                }
            });

            if (this.pluginConfig.followSpawnHeart != 0) {
                player.playSound(player.getLocation(), this.pluginConfig.followSound, 1.0F, 1.0F);

                int heartModify = this.heartService.getPlayerHeart(player) + this.pluginConfig.followSpawnHeart;
                this.heartService.setPlayerHeart(player, heartModify);
            }

            this.pluginConfig.followItems.forEach(item -> {
                player.playSound(player.getLocation(), this.pluginConfig.followSound, 1.0F, 1.0F);

                player.getInventory().addItem(ItemBuilder.of(item).fixColors().toItemStack())
                        .forEach((i, itemDrop) -> player.getWorld().dropItem(player.getLocation(), itemDrop));
            });

            this.pluginConfig.followCommands.forEach(text ->
                    this.tikTokPlugin.getServer().dispatchCommand(
                            this.tikTokPlugin.getServer().getConsoleSender(),
                            StringUtil.replace(text, "name", player.getName())
                    ));
        });
    }
}
