package cc.dreamcode.tiktok;

import cc.dreamcode.tiktok.config.MessageConfig;
import cc.dreamcode.tiktok.config.PluginConfig;
import cc.dreamcode.utilities.TicksUtil;
import cc.dreamcode.utilities.builder.MapBuilder;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import eu.okaeri.injector.annotation.Inject;
import eu.okaeri.tasker.core.Tasker;
import io.github.jwdeveloper.tiktok.data.events.social.TikTokLikeEvent;
import io.github.jwdeveloper.tiktok.live.LiveClient;
import io.github.jwdeveloper.tiktok.live.builder.EventConsumer;
import lombok.RequiredArgsConstructor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.entity.TNTPrimed;

import java.util.concurrent.atomic.AtomicInteger;

@RequiredArgsConstructor(onConstructor_ = @Inject)
public class TikTokLikeController implements EventConsumer<TikTokLikeEvent> {

    private final TikTokPlugin tikTokPlugin;
    private final PluginConfig pluginConfig;
    private final MessageConfig messageConfig;
    private final HeartService heartService;
    private final Tasker tasker;

    private final AtomicInteger likes = new AtomicInteger();

    @Override
    public void onEvent(LiveClient liveClient, TikTokLikeEvent event) {

        if (!this.pluginConfig.countLike) {
            return;
        }

        this.tikTokPlugin.getServer().getScheduler().runTask(this.tikTokPlugin, () -> {

            final int actualLikes = this.likes.incrementAndGet();

            if (actualLikes < this.pluginConfig.requiredLikes) {
                return;
            }

            this.likes.set(0);

            final Player player = this.tikTokPlugin.getServer().getPlayerExact(this.pluginConfig.playerName);
            if (player == null) {
                return;
            }

            final String profileName = event.getUser().getProfileName().equalsIgnoreCase(event.getUser().getName())
                    ? event.getUser().getName()
                    : event.getUser().getName() + " (" + event.getUser().getProfileName() + ")";

            this.messageConfig.likeCompleteNotice.send(player, new MapBuilder<String, Object>()
                    .put("likes", this.pluginConfig.requiredLikes)
                    .put("last-like", profileName)
                    .build());

            for (int tntIndex = 0; tntIndex < this.pluginConfig.likeSpawnTnt; tntIndex++) {
                this.tikTokPlugin.getServer().getScheduler().runTaskLater(
                        this.tikTokPlugin,
                        () -> {
                            player.playSound(player.getLocation(), this.pluginConfig.likeSound, 1.0F, 1.0F);

                            TNTPrimed tntPrimed = (TNTPrimed) player.getWorld().spawnEntity(
                                    player.getLocation().add(0.0D, 0.5D, 0.0D), EntityType.PRIMED_TNT);
                            tntPrimed.setFuseTicks(TicksUtil.ticksOf(this.pluginConfig.tntFuseDuration));
                        },
                        tntIndex
                );
            }

            this.pluginConfig.likeSpawnMobs.forEach((entityType, amount) -> {
                for (int mobIndex = 0; mobIndex < amount; mobIndex++) {

                    this.tikTokPlugin.getServer().getScheduler().runTaskLater(
                            this.tikTokPlugin,
                            () -> {
                                Location frontLocation = player.getEyeLocation().add(player.getLocation().getDirection());
                                if (!frontLocation.getBlock().getType().equals(Material.AIR)) {
                                    frontLocation = player.getLocation();
                                }

                                player.playSound(player.getLocation(), this.pluginConfig.likeSound, 1.0F, 1.0F);
                                Entity entity = player.getWorld().spawnEntity(frontLocation, entityType);

                                this.tasker.newDelayer(this.pluginConfig.mobDuration)
                                        .delayed(entity::remove)
                                        .executeSync();
                            },
                            mobIndex
                    );
                }
            });

            if (this.pluginConfig.likeSpawnHeart != 0) {
                player.playSound(player.getLocation(), this.pluginConfig.likeSound, 1.0F, 1.0F);

                int heartModify = this.heartService.getPlayerHeart(player) + this.pluginConfig.likeSpawnHeart;
                this.heartService.setPlayerHeart(player, heartModify);
            }

            this.pluginConfig.likeSpawnItems.forEach(item -> {
                player.playSound(player.getLocation(), this.pluginConfig.likeSound, 1.0F, 1.0F);

                player.getInventory().addItem(ItemBuilder.of(item).fixColors().toItemStack())
                        .forEach((i, itemDrop) -> player.getWorld().dropItem(player.getLocation(), itemDrop));
            });
        });
    }
}
