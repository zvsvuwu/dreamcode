import com.github.jengelman.gradle.plugins.shadow.tasks.ShadowJar

repositories {
    maven("https://repo.papermc.io/repository/maven-public/")
    maven("https://oss.sonatype.org/content/repositories/snapshots")
    maven("https://jitpack.io")
}

dependencies {
    // -- tiktok adapter --
    implementation("com.github.jwdeveloper.TikTok-Live-Java:Client:1.8.4-Release")

    // -- paper api -- (base)
    compileOnly("io.papermc.paper:paper-api:1.20.4-R0.1-SNAPSHOT")

    // -- dream-platform --
    implementation("cc.dreamcode.platform:core:1.12.8")
    implementation("cc.dreamcode.platform:bukkit:1.12.8")
    implementation("cc.dreamcode.platform:bukkit-config:1.12.8")
    implementation("cc.dreamcode.platform:dream-command:1.12.8")

    // -- dream-utilities --
    implementation("cc.dreamcode:utilities:1.4.5")
    implementation("cc.dreamcode:utilities-bukkit-adventure:1.4.5")

    // -- dream-notice --
    implementation("cc.dreamcode.notice:core:1.5.7")
    implementation("cc.dreamcode.notice:minecraft:1.5.7")
    implementation("cc.dreamcode.notice:minecraft-adventure:1.5.7")
    implementation("cc.dreamcode.notice:bukkit-adventure:1.5.7")
    implementation("cc.dreamcode.notice:bukkit-adventure-serializer:1.5.7")

    // -- notice mini-messages --
    implementation("net.kyori:adventure-text-minimessage:4.17.0")

    // -- dream-command --
    implementation("cc.dreamcode.command:core:2.1.2")
    implementation("cc.dreamcode.command:bukkit:2.1.2")

    // -- configs--
    implementation("eu.okaeri:okaeri-configs-yaml-bukkit:5.0.2")
    implementation("eu.okaeri:okaeri-configs-serdes-bukkit:5.0.2")
    implementation("eu.okaeri:okaeri-configs-serdes-commons:5.0.2")

    // -- injector --
    implementation("eu.okaeri:okaeri-injector:2.1.0")

    // -- placeholders --
    implementation("eu.okaeri:okaeri-placeholders-core:5.0.1")

    // -- tasker (easy sync/async scheduler) --
    implementation("eu.okaeri:okaeri-tasker-bukkit:2.1.0-beta.3")

    // -- Multi-Version Items helper --
    implementation("com.github.cryptomorin:XSeries:9.10.0")

    // -- gson --
    implementation("com.google.code.gson:gson:2.10.1")
}

tasks.withType<ShadowJar> {

    archiveFileName.set("Dream-TikTok-${project.version}.jar")

    minimize()

    relocate("com.cryptomorin", "cc.dreamcode.tiktok.libs.com.cryptomorin")
    relocate("eu.okaeri", "cc.dreamcode.tiktok.libs.eu.okaeri")

    relocate("cc.dreamcode.platform", "cc.dreamcode.tiktok.libs.cc.dreamcode.platform")
    relocate("cc.dreamcode.utilities", "cc.dreamcode.tiktok.libs.cc.dreamcode.utilities")
    relocate("cc.dreamcode.menu", "cc.dreamcode.tiktok.libs.cc.dreamcode.menu")
    relocate("cc.dreamcode.command", "cc.dreamcode.tiktok.libs.cc.dreamcode.command")
    relocate("cc.dreamcode.notice", "cc.dreamcode.tiktok.libs.cc.dreamcode.notice")

    relocate("com.google.gson", "cc.dreamcode.tiktok.libs.com.google.gson")
}