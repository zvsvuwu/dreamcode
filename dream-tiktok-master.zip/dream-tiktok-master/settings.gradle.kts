rootProject.name = "dream-tiktok"

include(":plugin-core")