package cc.dreamcode.clearmap.wandselection;

import lombok.AllArgsConstructor;
import lombok.Data;
import org.bukkit.Location;

@Data
@AllArgsConstructor
public class WandSelection {

    private Location position1;
    private Location position2;
}
