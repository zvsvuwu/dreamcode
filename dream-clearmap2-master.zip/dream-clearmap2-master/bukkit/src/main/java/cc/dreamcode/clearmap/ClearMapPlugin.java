package cc.dreamcode.clearmap;

import cc.dreamcode.clearmap.command.ClearMapCommand;
import cc.dreamcode.clearmap.command.completion.IdCompletion;
import cc.dreamcode.clearmap.command.handler.InvalidInputHandlerImpl;
import cc.dreamcode.clearmap.command.handler.InvalidPermissionHandlerImpl;
import cc.dreamcode.clearmap.command.handler.InvalidSenderHandlerImpl;
import cc.dreamcode.clearmap.command.handler.InvalidUsageHandlerImpl;
import cc.dreamcode.clearmap.config.MessageConfig;
import cc.dreamcode.clearmap.config.PluginConfig;
import cc.dreamcode.clearmap.controller.ClearMapController;
import cc.dreamcode.clearmap.controller.WandController;
import cc.dreamcode.clearmap.hook.PluginHookManager;
import cc.dreamcode.clearmap.hook.placeholderapi.PlaceholderApiHook;
import cc.dreamcode.clearmap.hook.placeholderapi.Placeholders;
import cc.dreamcode.clearmap.manager.ClearMapManager;
import cc.dreamcode.clearmap.rawlocation.RawLocationSerdes;
import cc.dreamcode.clearmap.region.RegionSerdes;
import cc.dreamcode.clearmap.runnable.ClearMapRunnable;
import cc.dreamcode.command.bukkit.BukkitCommandProvider;
import cc.dreamcode.notice.adventure.BukkitNoticeProvider;
import cc.dreamcode.notice.adventure.serializer.BukkitNoticeSerializer;
import cc.dreamcode.platform.DreamVersion;
import cc.dreamcode.platform.bukkit.DreamBukkitConfig;
import cc.dreamcode.platform.bukkit.DreamBukkitPlatform;
import cc.dreamcode.platform.bukkit.component.ConfigurationResolver;
import cc.dreamcode.platform.component.ComponentService;
import cc.dreamcode.platform.other.component.DreamCommandExtension;
import eu.okaeri.configs.serdes.OkaeriSerdesPack;
import eu.okaeri.tasker.bukkit.BukkitTasker;
import lombok.Getter;
import lombok.NonNull;

public final class ClearMapPlugin extends DreamBukkitPlatform implements DreamBukkitConfig {

    @Getter private static ClearMapPlugin clearMapPlugin;

    @Override
    public void load(@NonNull ComponentService componentService) {
        clearMapPlugin = this;
    }

    @Override
    public void enable(@NonNull ComponentService componentService) {
        componentService.setDebug(false);

        this.registerInjectable(BukkitTasker.newPool(this));
        this.registerInjectable(BukkitNoticeProvider.create(this));

        this.registerInjectable(BukkitCommandProvider.create(this));
        componentService.registerExtension(DreamCommandExtension.class);

        componentService.registerResolver(ConfigurationResolver.class);
        componentService.registerComponent(MessageConfig.class);

        componentService.registerComponent(InvalidInputHandlerImpl.class);
        componentService.registerComponent(InvalidPermissionHandlerImpl.class);
        componentService.registerComponent(InvalidSenderHandlerImpl.class);
        componentService.registerComponent(InvalidUsageHandlerImpl.class);

        componentService.registerComponent(PluginConfig.class, pluginConfig -> {
            componentService.setDebug(pluginConfig.debug);

            componentService.registerComponent(ClearMapManager.class, clearMapManager ->
                    clearMapManager.registerRegions(pluginConfig));
        });

        componentService.registerComponent(IdCompletion.class);
        componentService.registerComponent(ClearMapController.class);
        componentService.registerComponent(WandController.class);
        componentService.registerComponent(ClearMapRunnable.class);
        componentService.registerComponent(ClearMapCommand.class);

        componentService.registerComponent(PluginHookManager.class, PluginHookManager::registerHooks);
        this.getInject(PluginHookManager.class)
                .flatMap(pluginHookManager -> pluginHookManager.get(PlaceholderApiHook.class))
                .ifPresent(placeholderApiHook -> componentService.registerComponent(Placeholders.class, Placeholders::register));
    }

    @Override
    public void disable() {
        // features need to be call when server is stopping
    }

    @Override
    public @NonNull DreamVersion getDreamVersion() {
        return DreamVersion.create("Dream-ClearMap", "1.0.0", "torobolin");
    }

    @Override
    public @NonNull OkaeriSerdesPack getConfigSerdesPack() {
        return registry -> {
            registry.register(new BukkitNoticeSerializer());
            registry.register(new RegionSerdes());
            registry.register(new RawLocationSerdes());
        };
    }

}
