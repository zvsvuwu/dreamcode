package cc.dreamcode.clearmap.controller;

import cc.dreamcode.clearmap.ClearMapPlugin;
import cc.dreamcode.clearmap.config.PluginConfig;
import cc.dreamcode.clearmap.list.ListType;
import cc.dreamcode.clearmap.manager.ClearMapManager;
import cc.dreamcode.clearmap.region.Region;
import eu.okaeri.injector.annotation.Inject;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;

import java.util.ArrayList;
import java.util.List;

public class ClearMapController implements Listener {
    private @Inject ClearMapPlugin clearMapPlugin;
    private @Inject ClearMapManager clearMapManager;
    private @Inject PluginConfig pluginConfig;

    @EventHandler(priority = EventPriority.MONITOR)
    public void onBlockPlace(BlockPlaceEvent event) {
        Player player = event.getPlayer();

        this.regionCheck(player, event.getBlockPlaced());
    }

    @EventHandler
    public void onPlayerBucketEmpty(PlayerBucketEmptyEvent event) {
        Player player = event.getPlayer();
        Block block = player.getWorld().getBlockAt(event.getBlockClicked().getX(), event.getBlockClicked().getY() + 1, event.getBlockClicked().getZ());

        this.regionCheck(player, block);
    }

    private void regionCheck(Player player, Block block) {
        if (player.hasPermission("dream-clearmap.bypass")) return;

        List<Region> regions = Region.getRegionsFromLocation(block.getLocation(), this.pluginConfig);

        if (regions.isEmpty()) return;

        if (this.pluginConfig.listType == ListType.WHITELIST) {
            if (!this.pluginConfig.blockList.contains(block.getType())) return;

            this.addBlock(regions, block);
            return;
        }

        if (this.pluginConfig.listType == ListType.BLACKLIST) {
            if (this.pluginConfig.blockList.contains(block.getType())) return;

            this.addBlock(regions, block);
        }
    }

    private void addBlock(List<Region> regions, Block block) {
        regions.forEach(region -> {
            List<Block> newBlocks = new ArrayList<>();

            if (!this.clearMapManager.getBlocksPlaced().get(region.getId()).isEmpty()) {
                newBlocks.addAll(this.clearMapManager.getBlocksPlaced().get(region.getId()));
            }

            newBlocks.add(block);

            this.clearMapManager.getBlocksPlaced().put(region.getId(), newBlocks);
        });
    }
}
