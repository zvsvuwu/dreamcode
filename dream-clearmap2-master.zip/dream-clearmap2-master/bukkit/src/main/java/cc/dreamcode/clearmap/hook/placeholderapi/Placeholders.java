package cc.dreamcode.clearmap.hook.placeholderapi;

import cc.dreamcode.clearmap.config.PluginConfig;
import cc.dreamcode.clearmap.manager.ClearMapManager;
import cc.dreamcode.utilities.TimeUtil;
import eu.okaeri.injector.annotation.Inject;
import lombok.AllArgsConstructor;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.concurrent.atomic.AtomicReference;

@AllArgsConstructor(onConstructor_ = @Inject)
public class Placeholders extends PlaceholderExpansion {
    private final ClearMapManager clearMapManager;
    private final PluginConfig pluginConfig;

    @Override
    public String getIdentifier() {
        return "dream-clearmap";
    }

    @Override
    public String getAuthor() {
        return "torobolin";
    }

    @Override
    public String getVersion() {
        return "1.0";
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public boolean canRegister() {
        return true;
    }

    @Override
    public String onPlaceholderRequest(Player player, @NotNull String params) {

        if (params.startsWith("time-")) {
            AtomicReference<String> timeLeft = new AtomicReference<>("-");
            this.pluginConfig.regions.forEach(region -> {
                if(!params.endsWith(region.getId())) return;

                timeLeft.set(TimeUtil.formatSec(this.clearMapManager.getRegionsTime().get(region.getId())));
            });

            return timeLeft.get();
        }
        return null;
    }
}
