package cc.dreamcode.clearmap.hook.placeholderapi;


import cc.dreamcode.clearmap.hook.PluginHook;
import cc.dreamcode.clearmap.hook.PluginHookType;

public class PlaceholderApiHook implements PluginHook {

    @Override
    public PluginHookType getPluginHookType() {
        return PluginHookType.PLACEHOLDER_API;
    }
}
