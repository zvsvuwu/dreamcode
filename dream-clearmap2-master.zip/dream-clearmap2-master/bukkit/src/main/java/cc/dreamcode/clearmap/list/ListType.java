package cc.dreamcode.clearmap.list;

public enum ListType {

    WHITELIST,
    BLACKLIST
}
