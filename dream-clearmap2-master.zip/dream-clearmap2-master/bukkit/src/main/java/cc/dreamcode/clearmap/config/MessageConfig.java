package cc.dreamcode.clearmap.config;

import cc.dreamcode.notice.adventure.BukkitNotice;
import cc.dreamcode.platform.bukkit.component.configuration.Configuration;
import eu.okaeri.configs.OkaeriConfig;
import eu.okaeri.configs.annotation.Comment;
import eu.okaeri.configs.annotation.CustomKey;
import eu.okaeri.configs.annotation.Header;
import eu.okaeri.configs.annotation.Headers;

@Configuration(child = "message.yml")
@Headers({
        @Header("## Dream-ClearMap (Message-Config) ##"),
        @Header("Dostepne type: (DO_NOT_SEND, CHAT, ACTION_BAR, SUBTITLE, TITLE, TITLE_SUBTITLE)")
})
public class MessageConfig extends OkaeriConfig {
    @CustomKey("command-usage")
    public BukkitNotice usage = BukkitNotice.chat("&7Przyklady uzycia komendy: &c{label}");
    @CustomKey("command-usage-help")
    public BukkitNotice usagePath = BukkitNotice.chat("&f{usage} &8- &7{description}");

    @CustomKey("command-usage-not-found")
    public BukkitNotice usageNotFound = BukkitNotice.chat("&cNie znaleziono pasujacych do kryteriow komendy.");
    @CustomKey("command-path-not-found")
    public BukkitNotice pathNotFound = BukkitNotice.chat("&cTa komenda jest pusta lub nie posiadasz dostepu do niej.");
    @CustomKey("command-no-permission")
    public BukkitNotice noPermission = BukkitNotice.chat("&cNie posiadasz uprawnien.");
    @CustomKey("command-not-player")
    public BukkitNotice notPlayer = BukkitNotice.chat("&cTa komende mozna tylko wykonac z poziomu gracza.");
    @CustomKey("command-not-console")
    public BukkitNotice notConsole = BukkitNotice.chat("&cTa komende mozna tylko wykonac z poziomu konsoli.");
    @CustomKey("command-invalid-format")
    public BukkitNotice invalidFormat = BukkitNotice.chat("&cPodano nieprawidlowy format argumentu komendy. ({input})");

    @CustomKey("player-not-found")
    public BukkitNotice playerNotFound = BukkitNotice.chat("&cPodanego gracza nie znaleziono.");
    @CustomKey("world-not-found")
    public BukkitNotice worldNotFound = BukkitNotice.chat("&cPodanego swiata nie znaleziono.");

    @CustomKey("configs-reloaded")
    public BukkitNotice configsReloaded = BukkitNotice.chat("&aPomyslnie przeladowano pliki konfiguracyjne ({time})");
    @CustomKey("reload-error")
    public BukkitNotice reloadError = BukkitNotice.chat("&cZnaleziono problem w konfiguracji: &6{error}");

    @CustomKey("map-cleared")
    public BukkitNotice mapCleared = BukkitNotice.chat("&aMapa zostala wyczyszczona");
    @CustomKey("wand-given")
    public BukkitNotice wandGiven = BukkitNotice.chat("&aOtrzymales rozdzke");
    @CustomKey("set-region-first")
    public BukkitNotice setRegionFirst = BukkitNotice.chat("&cNajpierw ustaw region");
    @CustomKey("region-saved")
    public BukkitNotice regionSaved = BukkitNotice.chat("&aPomyslnie zapisales nowy region");
    @CustomKey("position-set")
    public BukkitNotice positionSet = BukkitNotice.chat("&aPomyslnie ustawiono pozycje");
    @CustomKey("region-already-exists")
    public BukkitNotice regionAlreadyExists = BukkitNotice.chat("&cRegion o tej nazwie juz istnieje");
    @CustomKey("no-such-region")
    public BukkitNotice noSuchRegion = BukkitNotice.chat("&cRegion o tej nazwie nie istnieje");
    @CustomKey("region-removed")
    public BukkitNotice regionRemoved = BukkitNotice.chat("&aRegion zostal pomyslnie usuniety");
    @CustomKey("map-clear-notice")
    public BukkitNotice mapClearNotice = BukkitNotice.chat("&aMapa zostanie wyczyszczona za {time}s");
    @CustomKey("clear-map-list")
    public BukkitNotice clearMapList = BukkitNotice.chat("&a&lLista regionow:" +
            "%NEWLINE% {regions}");
    @CustomKey("no-regions-exist")
    public BukkitNotice noRegionsExist = BukkitNotice.chat("&cNa serwerze nie ma zadnych regionow");
    @CustomKey("no-such-material")
    public BukkitNotice noSuchMaterial = BukkitNotice.chat("&cNie ma takiego bloku");
    @CustomKey("block-already-added")
    public BukkitNotice blockAlreadyAdded = BukkitNotice.chat("&cTen blok znajduje sie juz na liscie");
    @CustomKey("block-not-added")
    public BukkitNotice blockNotAdded = BukkitNotice.chat("&cTen blok nie znajduje sie na liscie");
    @CustomKey("material-not-a-block")
    public BukkitNotice materialNotABlock = BukkitNotice.chat("&cTen material nie jest blokiem");
    @CustomKey("block-added")
    public BukkitNotice blockAdded = BukkitNotice.chat("&aPomyslnie dodano blok do listy");
    @CustomKey("block-removed")
    public BukkitNotice blockRemoved = BukkitNotice.chat("&aPomyslnie usunieto blok z listy");
    @CustomKey("time-changed")
    public BukkitNotice timeChanged = BukkitNotice.chat("&aPomyslnie zmieniono czas dla regionu {id}");


    @Comment("Ustaw jak bedzie wygladala informacja o regionie")
    public String regionInfoTemplate = "&eID: {id}" +
            "%NEWLINE%&2Pozycja 1: {minX}, {minY}, {minZ}" +
            "%NEWLINE%&2Pozycja 2: {maxX}, {maxY}, {maxZ}";
}
