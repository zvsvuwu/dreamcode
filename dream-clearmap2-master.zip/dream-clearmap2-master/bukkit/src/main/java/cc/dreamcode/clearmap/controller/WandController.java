package cc.dreamcode.clearmap.controller;

import cc.dreamcode.clearmap.ClearMapPlugin;
import cc.dreamcode.clearmap.config.MessageConfig;
import cc.dreamcode.clearmap.config.PluginConfig;
import cc.dreamcode.clearmap.manager.ClearMapManager;
import cc.dreamcode.clearmap.wandselection.WandSelection;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import eu.okaeri.injector.annotation.Inject;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

import java.util.Map;
import java.util.UUID;

public class WandController implements Listener {
    private @Inject ClearMapPlugin clearMapPlugin;
    private @Inject ClearMapManager clearMapManager;
    private @Inject PluginConfig pluginConfig;
    private @Inject MessageConfig messageConfig;

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        ItemStack itemInHand = event.getItem();

        Map<UUID, WandSelection> wandSelections = this.clearMapManager.getWandSelections();

        if (itemInHand == null || itemInHand.getItemMeta() == null || event.getClickedBlock() == null) return;

        if (!itemInHand.getItemMeta().getDisplayName().equals(new ItemBuilder(this.pluginConfig.wandItemStack, true).fixColors().toItemStack().getItemMeta().getDisplayName())) return;

        if (!player.hasPermission("dream-clearmap.wand")) return;

        if (event.getAction() == Action.LEFT_CLICK_BLOCK) {

            if (wandSelections.containsKey(player.getUniqueId())) {
                wandSelections.get(player.getUniqueId()).setPosition1(event.getClickedBlock().getLocation());
            } else {
                wandSelections.put(player.getUniqueId(), new WandSelection(event.getClickedBlock().getLocation(), null));
            }
        }

        if (event.getAction() == Action.RIGHT_CLICK_BLOCK) {

            if (wandSelections.containsKey(player.getUniqueId())) {
                wandSelections.get(player.getUniqueId()).setPosition2(event.getClickedBlock().getLocation());
            } else {
                wandSelections.put(player.getUniqueId(), new WandSelection(null, event.getClickedBlock().getLocation()));
            }
        }

        this.messageConfig.positionSet.send(player);

        event.setCancelled(true);

    }
}
