package cc.dreamcode.clearmap.command;

import cc.dreamcode.clearmap.ClearMapPlugin;
import cc.dreamcode.clearmap.config.MessageConfig;
import cc.dreamcode.clearmap.config.PluginConfig;
import cc.dreamcode.clearmap.manager.ClearMapManager;
import cc.dreamcode.clearmap.region.Region;
import cc.dreamcode.clearmap.runnable.ClearMapRunnable;
import cc.dreamcode.command.CommandBase;
import cc.dreamcode.command.annotation.*;
import cc.dreamcode.utilities.TimeUtil;
import cc.dreamcode.utilities.builder.MapBuilder;
import cc.dreamcode.utilities.bukkit.InventoryUtil;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import com.cryptomorin.xseries.XMaterial;
import eu.okaeri.configs.exception.OkaeriException;
import eu.okaeri.injector.annotation.Inject;
import lombok.AllArgsConstructor;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Collections;
import java.util.Optional;

@Command(name = "clearmap")
@AllArgsConstructor(onConstructor_ = @Inject)
public class ClearMapCommand implements CommandBase {
    private final ClearMapRunnable clearMapRunnable;
    private final ClearMapManager clearMapManager;
    private final ClearMapPlugin clearMapPlugin;
    private final PluginConfig pluginConfig;
    private final MessageConfig messageConfig;

    @Executor(path = "wand", description = "Daje rozdzke do tworzenia regionow")
    @Permission("dream-clearmap.command.wand")
    void wand(Player player) {
        InventoryUtil.giveItem(player, new ItemBuilder(this.pluginConfig.wandItemStack, true)
                .fixColors()
                .toItemStack());

        this.messageConfig.wandGiven.send(player);
    }

    @Executor(path = "reload", description = "Przeladowuje pliki konfiguracyjne")
    @Permission("dream-clearmap.command.reload")
    void reload(CommandSender sender) {
        final long time = System.currentTimeMillis();

        try {
            this.messageConfig.load();
            this.pluginConfig.load();

            this.clearMapManager.registerRegions(this.pluginConfig);

            this.messageConfig.configsReloaded.send(sender, new MapBuilder<String, Object>()
                    .put("time", TimeUtil.format(System.currentTimeMillis() - time))
                    .build());
        }
        catch (NullPointerException | OkaeriException e) {
            e.printStackTrace();

            this.messageConfig.reloadError.send(sender, new MapBuilder<String, Object>()
                    .put("error", e.getMessage())
                    .build());
        }
    }

    @Executor(path = "create", description = "Tworzy region z zaznaczonych rozdzka rogow")
    @Permission("dream-clearmap.command.create")
    void create(Player player, @Arg(value = "id") String id, @Arg(value = "czas") int time) {
        if (!this.clearMapManager.getWandSelections().containsKey(player.getUniqueId())
                || this.clearMapManager.getWandSelections().get(player.getUniqueId()).getPosition1() == null
                || this.clearMapManager.getWandSelections().get(player.getUniqueId()).getPosition2() == null) {
            this.messageConfig.setRegionFirst.send(player);
            return;
        }

        if (this.pluginConfig.regions.stream().anyMatch(region -> region.getId().equals(id))) {
            this.messageConfig.regionAlreadyExists.send(player);
            return;
        }

        Region newRegion = Region.fromWandSelection(id, time, this.clearMapManager.getWandSelections().get(player.getUniqueId()));

        this.pluginConfig.regions.add(newRegion);

        this.pluginConfig.save();
        this.pluginConfig.load();

        this.clearMapManager.getWandSelections().remove(player.getUniqueId());

        this.clearMapManager.getRegionsTime().put(newRegion.getId(), newRegion.getClearTime());
        this.clearMapManager.getBlocksPlaced().put(newRegion.getId(), Collections.emptyList());

        this.messageConfig.regionSaved.send(player);
    }

    @Executor(path = "remove", description = "Usuwa wybrany region")
    @Permission("dream-clearmap.command.remove")
    @Completion(arg = "id", value = "@ids")
    void remove(CommandSender sender, @Arg(value = "id") String id) {
        if (this.pluginConfig.regions.stream().noneMatch(region -> region.getId().equals(id))) {
            this.messageConfig.noSuchRegion.send(sender);
            return;
        }

        this.pluginConfig.regions.stream()
                .filter(region -> region.getId().equals(id))
                .findAny()
                .ifPresent(region -> {
                    this.pluginConfig.regions.remove(region);

                    this.pluginConfig.save();
                    this.pluginConfig.load();

                    this.clearMapManager.getRegionsTime().remove(id);
                    this.clearMapManager.getBlocksPlaced().remove(id);

                    this.messageConfig.regionRemoved.send(sender);
                });
    }

    @Executor(path = "list", description = "Lista aktywnych regionow")
    @Permission("dream-clearmap.command.list")
    void list(CommandSender sender) {
        if (this.pluginConfig.regions.isEmpty()) {
            this.messageConfig.noRegionsExist.send(sender);
            return;
        }

        StringBuilder stringBuilder = new StringBuilder();

        this.pluginConfig.regions.forEach(region -> {
            stringBuilder.append(this.messageConfig.regionInfoTemplate
                    .replace("{id}", region.getId())
                    .replace("{minX}", String.valueOf(region.getMinX()))
                    .replace("{minY}", String.valueOf(region.getMinY()))
                    .replace("{minZ}", String.valueOf(region.getMinZ()))
                    .replace("{maxX}", String.valueOf(region.getMaxX()))
                    .replace("{maxY}", String.valueOf(region.getMaxY()))
                    .replace("{maxZ}", String.valueOf(region.getMaxZ()))
                    .replace("%NEWLINE%", "\n")
            );

            stringBuilder.append("\n");
        });

        this.messageConfig.clearMapList.send(sender, Collections.singletonMap("regions", stringBuilder.toString()));
    }

    @Executor(path = "addblock", description = "Dodaje blok do listy blokow")
    @Permission("dream-clearmap.command.addblock")
    void addBlock(CommandSender sender, @Arg(value = "blok") String block) {
        if (!XMaterial.matchXMaterial(block).isPresent()) {
            this.messageConfig.noSuchMaterial.send(sender);
            return;
        }

        XMaterial xMaterial = XMaterial.matchXMaterial(block).get();

        if (!xMaterial.parseMaterial().isBlock()) {
            this.messageConfig.materialNotABlock.send(sender);
            return;
        }

        if (this.pluginConfig.blockList.contains(xMaterial.parseMaterial())) {
            this.messageConfig.blockAlreadyAdded.send(sender);
            return;
        }

        this.pluginConfig.blockList.add(xMaterial.parseMaterial());

        this.pluginConfig.save();
        this.pluginConfig.load();

        this.messageConfig.blockAdded.send(sender);
    }

    @Executor(path = "delblock", description = "Usuwa blok z listy blokow")
    @Permission("dream-clearmap.command.delblock")
    void delBlock(CommandSender sender, @Arg(value = "blok") String block) {
        if (!XMaterial.matchXMaterial(block).isPresent()) {
            this.messageConfig.noSuchMaterial.send(sender);
            return;
        }

        XMaterial xMaterial = XMaterial.matchXMaterial(block).get();

        if (!xMaterial.parseMaterial().isBlock()) {
            this.messageConfig.materialNotABlock.send(sender);
            return;
        }

        if (!this.pluginConfig.blockList.contains(xMaterial.parseMaterial())) {
            this.messageConfig.blockNotAdded.send(sender);
            return;
        }

        this.pluginConfig.blockList.remove(xMaterial.parseMaterial());

        this.pluginConfig.save();
        this.pluginConfig.load();

        this.messageConfig.blockRemoved.send(sender);
    }

    @Executor(path = "settime", description = "Ustawia czas czyszczenia regionu")
    @Permission("dream-clearmap.command.settime")
    @Completion(arg = "id", value = "@ids")
    void setTime(CommandSender sender, @Arg(value = "id") String id, @Arg(value = "czas") int time) {
        Optional<Region> region = this.pluginConfig.regions.stream().filter(region1 -> region1.getId().equals(id)).findFirst();

        if (!region.isPresent()) {
            this.messageConfig.noSuchRegion.send(sender);
            return;
        }

        region.get().setClearTime(time);

        this.pluginConfig.save();
        this.pluginConfig.load();

        this.clearMapManager.getRegionsTime().put(region.get().getId(), time);

        this.messageConfig.timeChanged.send(sender, Collections.singletonMap("id", region.get().getId()));
    }

    @Executor(path = "reset", description = "Automatycznie czysci podany region")
    @Permission("dream-clearmap.command.reset")
    @Completion(arg = "id", value = "@ids")
    void reset(CommandSender sender, @Arg(value = "id") String id) {
        if (this.pluginConfig.regions.stream().noneMatch(region -> region.getId().equals(id))) {
            this.messageConfig.noSuchRegion.send(sender);
            return;
        }

        this.clearMapPlugin.getServer().getScheduler().runTask(this.clearMapPlugin, () -> {
            this.clearMapManager.getBlocksPlaced().get(id).forEach(block -> block.setType(Material.AIR));

            this.clearMapManager.getBlocksPlaced().put(id, Collections.emptyList());
        });

        this.messageConfig.mapCleared.send(sender);
    }
}
