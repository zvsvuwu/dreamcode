package cc.dreamcode.clearmap.config;

import cc.dreamcode.clearmap.list.ListType;
import cc.dreamcode.clearmap.rawlocation.RawLocation;
import cc.dreamcode.clearmap.region.Region;
import cc.dreamcode.platform.bukkit.component.configuration.Configuration;
import cc.dreamcode.utilities.builder.ListBuilder;
import cc.dreamcode.utilities.bukkit.builder.ItemBuilder;
import com.cryptomorin.xseries.XMaterial;
import eu.okaeri.configs.OkaeriConfig;
import eu.okaeri.configs.annotation.Comment;
import eu.okaeri.configs.annotation.CustomKey;
import eu.okaeri.configs.annotation.Header;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

import java.util.Arrays;
import java.util.List;

@Configuration(child = "config.yml")
@Header("## Dream-ClearMap (Main-Config) ##")
public class PluginConfig extends OkaeriConfig {
    @Comment("Debug pokazuje dodatkowe informacje do konsoli. Lepiej wylaczyc. :P")
    @CustomKey("debug")
    public boolean debug = true;

    @Comment("Placeholder pozostalego czasu to \"%dream-clearmap_time%\"")
    @Comment("Permisja na bypass usuwania itemow to \"dream-clearmap.bypass\"")

    @Comment("Ustaw typ listy blokow (WHITELIST - tylko te bloki beda usuwane, BLACKLIST - te bloki nie beda usuwane)")
    @CustomKey("list-type")
    public ListType listType = ListType.WHITELIST;

    @Comment("Lista blokow")
    @CustomKey("block-list")
    public List<Material> blockList = Arrays.asList(XMaterial.STONE.parseMaterial(), XMaterial.COBBLESTONE.parseMaterial(),
            XMaterial.LAVA.parseMaterial(), XMaterial.WATER.parseMaterial());

    @Comment("Lista koordynatow regionow w ktorych dziala plugin")
    @CustomKey("regions")
    public List<Region> regions = new ListBuilder<Region>()
            .add(new Region(
                    "test",
                    300,
                    "world",
                    -20,
                    0,
                    -20,
                    20,
                    319,
                    20
            ))
            .build();

    @Comment("Ustaw jak bedzie wygladala rozdzka do zaznaczania regionu")
    @CustomKey("wand-item-stack")
    public ItemStack wandItemStack = new ItemBuilder(XMaterial.BLAZE_ROD.parseMaterial())
            .setName("&#fb7800&lM&#fb8100&la&#fc8a00&lg&#fc9300&li&#fc9b00&lc&#fca400&lz&#fdad00&ln&#fdb600&la " +
                    "&#fdad00&lR&#fca400&ló&#fc9b00&lż&#fc9300&ld&#fc8a00&lż&#fb8100&lk&#fb7800&la")
            .setLore("", "&8» &fTen przedmiot pozwala stworzyć tobie region,",
                    "&8» &fw którym bloki znikają co jakiś czas")
            .toItemStack();

    @Comment("Lista sekund pozostalych do wyczyszczenia mapy w ktorych bedzie wysylana informacja na chat")
    @CustomKey("map-clear-notices")
    public List<Integer> mapClearNotices = Arrays.asList(1,2,3,5,10,20,30,60);

    @Comment("Czy po wyczyszczeniu mapy gracze ktorzy sie w niej znajdowali maja byc teleportowani w ustawiona lokalizacje")
    @CustomKey("tp-on-clear")
    public boolean tpOnClear = false;

    @Comment("Ustaw lokalizacje gdzie beda teleportowani gracze przy clearowaniu mapy (dziala tylko gdy opcja wyzej jest na true)")
    @CustomKey("tp-location")
    public RawLocation tpLocation = new RawLocation(
            "world",
            0.0,
            63.0,
            0
    );

    @Comment("Czy wiadomosci informujace za ile mapa bedzie wyczyszczona ma byc wysylana")
    @CustomKey("send-messages")
    public boolean sendMessages = true;

    @Comment("Czy wiadomosc o wyczyszczeniu mapy ma byc wysylana")
    @CustomKey("send-map-clear-notice")
    public boolean sendMapClearNotice = true;
}
