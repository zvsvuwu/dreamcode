package cc.dreamcode.clearmap.runnable;

import cc.dreamcode.clearmap.ClearMapPlugin;
import cc.dreamcode.clearmap.config.MessageConfig;
import cc.dreamcode.clearmap.config.PluginConfig;
import cc.dreamcode.clearmap.manager.ClearMapManager;
import cc.dreamcode.clearmap.region.Region;
import cc.dreamcode.platform.bukkit.component.scheduler.Scheduler;
import eu.okaeri.injector.annotation.Inject;
import lombok.AllArgsConstructor;
import org.bukkit.Material;

import java.util.Collections;

@Scheduler(interval = 20, delay = 0)
@AllArgsConstructor(onConstructor_ = @Inject)
public class ClearMapRunnable implements Runnable {
    private final ClearMapManager clearMapManager;
    private final ClearMapPlugin clearMapPlugin;
    private final MessageConfig messageConfig;
    private final PluginConfig pluginConfig;

    @Override
    public void run() {
        this.clearMapManager.getRegionsTime().forEach((id, timeLeft) -> {
            Region region = this.pluginConfig.regions.stream().filter(regions -> regions.getId().equals(id)).findFirst().get();

            if (timeLeft != 0) {
                if (this.pluginConfig.sendMessages) {
                    if (this.pluginConfig.mapClearNotices.contains(timeLeft)) {
                        this.clearMapPlugin.getServer().getOnlinePlayers().forEach(player -> {
                            if (region.isLocationNotInRegion(player.getLocation())) return;

                            this.messageConfig.mapClearNotice.send(player, Collections.singletonMap("time", timeLeft));
                        });
                    }
                }

                this.clearMapManager.getRegionsTime().put(id, timeLeft -1);
                return;
            }

            this.clearMapPlugin.getServer().getScheduler().runTask(this.clearMapPlugin, () -> {
                this.clearMapManager.getBlocksPlaced().get(id).forEach(block -> block.setType(Material.AIR));

                this.clearMapManager.getBlocksPlaced().put(id, Collections.emptyList());
            });

            if (this.pluginConfig.sendMapClearNotice) {
                this.clearMapPlugin.getServer().getOnlinePlayers().forEach(player -> {
                    if (region.isLocationNotInRegion(player.getLocation())) return;

                    this.messageConfig.mapCleared.send(player);
                });
            }

            if (this.pluginConfig.tpOnClear) {
                this.clearMapPlugin.getServer().getScheduler().runTask(this.clearMapPlugin, () -> {
                    this.clearMapPlugin.getServer().getOnlinePlayers().forEach(player -> {
                        if (region.isLocationNotInRegion(player.getLocation())) return;

                        player.teleport(this.pluginConfig.tpLocation.toLocation());
                    });
                });
            }

            this.clearMapManager.getRegionsTime().put(id, region.getClearTime());
        });
    }
}
