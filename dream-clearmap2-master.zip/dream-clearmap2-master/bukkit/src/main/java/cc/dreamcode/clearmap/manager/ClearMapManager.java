package cc.dreamcode.clearmap.manager;

import cc.dreamcode.clearmap.config.PluginConfig;
import cc.dreamcode.clearmap.wandselection.WandSelection;
import lombok.Getter;
import org.bukkit.block.Block;

import java.util.*;

@Getter
public class ClearMapManager {

    private final Map<String, List<Block>> blocksPlaced = new HashMap<>();
    private final Map<UUID, WandSelection> wandSelections = new HashMap<>();
    private final Map<String, Integer> regionsTime = new HashMap<>();

    public void registerRegions(PluginConfig pluginConfig) {
        this.regionsTime.clear();

        pluginConfig.regions.forEach(region -> {
            this.regionsTime.put(region.getId(), region.getClearTime());
            this.blocksPlaced.put(region.getId(), Collections.emptyList());
        });
    }
}
