package cc.dreamcode.clearmap.hook;

import cc.dreamcode.clearmap.hook.placeholderapi.PlaceholderApiHook;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum PluginHookType {
    PLACEHOLDER_API("PlaceholderApiHook", "me.clip", PlaceholderApiHook.class);

    private final String name;
    private final String classPackageName;
    private final Class<? extends PluginHook> pluginHookClass;
}
