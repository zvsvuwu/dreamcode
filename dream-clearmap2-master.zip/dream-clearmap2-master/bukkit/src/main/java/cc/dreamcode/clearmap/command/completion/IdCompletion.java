package cc.dreamcode.clearmap.command.completion;

import cc.dreamcode.clearmap.config.PluginConfig;
import cc.dreamcode.clearmap.region.Region;
import cc.dreamcode.command.suggestion.supplier.SuggestionSupplier;
import cc.dreamcode.platform.other.component.annotation.SuggestionKey;
import eu.okaeri.injector.annotation.Inject;
import lombok.NonNull;

import java.util.List;
import java.util.stream.Collectors;

@SuggestionKey("@ids")
public class IdCompletion implements SuggestionSupplier {

    private @Inject PluginConfig pluginConfig;

    @Override
    public List<String> supply(@NonNull Class<?> paramType) {
        return this.pluginConfig.regions.stream()
                .map(Region::getId)
                .collect(Collectors.toList());
    }
}
