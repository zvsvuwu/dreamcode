package cc.dreamcode.clearmap.region;

import cc.dreamcode.clearmap.config.PluginConfig;
import cc.dreamcode.clearmap.wandselection.WandSelection;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.bukkit.Location;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

@Data
@AllArgsConstructor
public class Region {

    private String id;
    private int clearTime;
    private String world;
    private double minX, minY, minZ, maxX, maxY, maxZ;

    public static Region fromCorners(String id, int clearTime, String world, double x1, double y1, double z1, double x2, double y2, double z2) {
        return new Region(
                id,clearTime,
                world,
                Math.min(x1, x2),
                Math.min(y1, y2),
                Math.min(z1, z2),
                Math.max(x1, x2),
                Math.max(y1, y2),
                Math.max(z1, z2));
    }

    public static boolean isLocationInRegion(Region region, Location location) {
        if (!location.getWorld().getName().equals(region.getWorld())) return false;

        double x = location.getX();
        double y = location.getY();
        double z = location.getZ();

        return x >= region.getMinX() && x <= region.getMaxX() &&
                y >= region.getMinY() && y <= region.getMaxY() &&
                z >= region.getMinZ() && z <= region.getMaxZ();
    }

    public boolean isLocationNotInRegion(Location location) {
        if (!location.getWorld().getName().equals(this.getWorld())) return true;

        double x = location.getX();
        double y = location.getY();
        double z = location.getZ();

        return !(x >= this.getMinX()) || !(x <= this.getMaxX()) ||
                !(y >= this.getMinY()) || !(y <= this.getMaxY()) ||
                !(z >= this.getMinZ()) || !(z <= this.getMaxZ());
    }

    public static Region fromWandSelection(String id, int clearTime, WandSelection wandSelection) {
        return Region.fromCorners(id,
                clearTime,
                wandSelection.getPosition1().getWorld().getName(),
                wandSelection.getPosition1().getX(),
                wandSelection.getPosition1().getY(),
                wandSelection.getPosition1().getZ(),
                wandSelection.getPosition2().getX(),
                wandSelection.getPosition2().getY(),
                wandSelection.getPosition2().getZ());
    }

    public static boolean isLocationInAnyRegion(Location location, PluginConfig pluginConfig) {
        AtomicBoolean atomicBoolean = new AtomicBoolean(false);

        pluginConfig.regions.forEach(region -> {
            if (isLocationInRegion(region, location)) {
                atomicBoolean.set(true);
            }
        });

        return atomicBoolean.get();
    }

    public static List<Region> getRegionsFromLocation(Location location, PluginConfig pluginConfig) {
        List<Region> regions = new ArrayList<>();

        pluginConfig.regions.forEach(region -> {
            if (region.isLocationNotInRegion(location)) return;

            regions.add(region);
        });

        return regions;
    }
}
