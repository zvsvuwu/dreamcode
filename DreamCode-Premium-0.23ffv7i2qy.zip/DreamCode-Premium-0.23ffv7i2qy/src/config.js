module.exports = {
    applicationConfig: {
        debug: true,
    },
    clientConfig: {
        "mongoURI": "mongodb+srv://test:K4MCXlNv3gLpENUY@cluster0.69i77gv.mongodb.net/DCS4",
        "token": "twojtokentutaj",
        /*
        Jak zdobyć token?
          1. Wejdź na stronę discord.com/developers/applications
          2. Stwórz nową aplikację
          3. Wejdź w zakładkę "Bot"
          4. Kliknij "Add Bot"
          5. Kliknij "Copy Token"
          6. Wklej token do config.js
          7. Uzupełnij resztę danych
         */


        /* Jak zdobyć mongoURI?
          1. Wejdź na stronę mongodb.com
          2. Zarejestruj się
          3. Stwórz nową bazę danych
          4. Przydziel użytkownika do bazy danych i skopiuj jego hasło
          5. Dodaj adres IP swojego serwera do białej listy
          6. Kliknij "Connect"
          7. Wybierz "Connect your application"
          8. Skopiuj link i wklej do config.js
          9. Uzupełnij resztę danych

         */
    },

    botConfig: {
        interactionPrefix: "**DreamCode |** ",
        permissionsPrefix: "dreamcode.",
        embedColor: "#a352f8",


    },


punishConfig: {
        //Każdy z embedów ma swoje własne zmienne, które są zastępowane w treści embeda
        //            {USER} - użytkownik, który został ukarany (ping)
        //            {MODERATOR} - moderator, który ukarał użytkownika (ping)
        //            {REASON} - powód ukarania
        //            {TIME} - czas ukarania
        //            {DATE} - data ukarania

        embeds: {
            ban: {
                title: "Ban",
                description: "Użytkownik {user} został zbanowany przez {moderator}",
                color: 0x36393f
            },
            kick: {
                title: "Kick",
                description: "Użytkownik {user} został wyrzucony przez {moderator}",
                color: 0x36393f
            },
            mute: {
                title: "Mute",
                description: "Użytkownik {user} został wyciszony przez {moderator}",
                color: 0x36393f
            },
            unmute: {
                title: "Unmute",
                description: "Użytkownik {user} został odmutowany przez {moderator}",
                color: 0x36393f
            }
        },

        muteConfig: {
            muteStrategy: "ROLE", // Tutaj możesz dać "ROLE" lub "TIMEOUT" w przypadku, gdy chcesz, aby bot nadał rolę wyciszenia lub po prostu zablokował możliwość wysyłania wiadomości
            muteRole: "", // ID roli wyciszenia nie bedzie uzywane jesli muteTactic jest ustawione na "TIMEOUT"
        },
        //            //Każdy z embedów ma swoje własne zmienne, które są zastępowane w treści embeda
        //             //            {USER} - użytkownik, który został ukarany (ping)
        //             //            {MODERATOR} - moderator, który ukarał użytkownika (ping)
        //             //            {REASON} - powód ukarania
        //             //            {TIME} - czas ukarania
        //             //            {DATE} - data ukarania
    },


propositionConfig: {
        channelId: "",
        embed:{
            author: {
                name: "{username}",
                icon_url: "{avatar}"
            },


            description: "\`📝\` **Treść propozycji:** \n\n{content}  \n\n\`🧑\` **Autor:** {author} \n\`🆔\` **ID:** {id} \n\`⌚\` **Data:** {date}",
            color: 0x36393f,
            emojiyes: "👍",
            emojino: "👎",
            emojicheck: "🔍",

        },
        checkEmbed: {
            title: "Lista głosujących",
            description: "Głosujący: \n\n {votes}",
            color: 0x36393f
        }



    },


ticketConfig: {
        createTicketEmbed: {
            title: "Ticket",
            description: "jebnij w guzik ponizej aby pierdonalc ticketa!",
            color: 0x36393f,

        },

        createTicketButton: {
            label: "Stwórz ticket",
            customId: "createTicket",
            style: "1",
            emoji: "🎫"
        },

        ticketModal: {
            title: "Opisz swój problem",
            customId: "ticketModal",
            inputs: [
                {
                    customId: "nick",
                    type: "short",
                    name: "nick",
                    label: "Nick",
                    placeholder: "Twój nick",
                    required: true,
                    min: 1,
                    max: 10,
                },
                {
                    customId: "problem",
                    type: "long",
                    name: "problem",
                    label: "Problem",
                    placeholder: "Opisz swój problem",
                    required: true,
                    min: 1,
                    max: 1000,

                }

            ]
        },
        ticketChannel: {
            name: "ticket",
            parent: "",
        },

        ticketEmbed: {
            "title": "Nowy Ticket!",
            "description": "\n\`📭\`️ **Informacje:** \n\n`\-\` \`🧑\` <@{userid}> \n`\-\` \`⌚\` {date} \n`\-\` \`🆔\` {userid}\n\n  \`📝\`️ **Nick:** \n\n`\-\` {nick} \n\n\`📝\`️ **Problem:** \n\n`\-\` {problem}",
            //COLOR W INCIE
            "color": 0x36393f
        },

        ticketClosedEmbed: {
            "title": "Ticket zamknięty!",
            "description": "Ticket został zamknięty przez: {user}",
            "color": 0x36393f
        },
        ticketReopenedEmbed: {
            "title": "Ticket ponownie otwarty!",
            "description": "Ticket został ponownie otwarty przez: {user}",
            "color": 0x36393f
        },

        ticketLogsChannel: "",
    },



}
//Disclaimer: Ten plik został wygenerowany automatycznie. W razie potrzeby, możesz go dowolnie edytować. Pamiętaj aby zgłośić wszelkie błędy na naszym serwerze!